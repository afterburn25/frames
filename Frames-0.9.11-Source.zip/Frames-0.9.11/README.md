# Frames 0.9.11 — Unsigned Runtime Semantics Repair

Frames 0.9.11 is a targeted runtime repair driven by real QEMU/OVMF evidence from Frames 0.9.10.

## What 0.9.10 proved
- UEFI -> Frames kernel boot reaches `FRAMES_KERNEL_READY`.
- The 0.9.10 bootstrap-heap enlargement worked: runtime now reaches GDT/TSS, audio, driver, security, recovery/update state and Worker 0.
- NVMe read-only storage runtime certification remains PASS.

## Remaining 0.9.10 failures
- ACPI stopped at `FRAMES_ACPI_DIAG=0x8` before MADT/platform/SMP promotion.
- `FRAMES_USER_COPY_OK` did not appear, so the ring-3 probe remained gated.

## Root repair
Both failures expose the same Nexus 5.15 x64 backend bug: division, modulo and ordered comparisons were lowered with signed machine semantics even when the Nexus operands were `u64`/`u32`.

Frames 0.9.11 bundles Nexus 5.16.0:
- `u64`/`u32` `/` and `%` use zero-extended x86-64 `divq`;
- unsigned `<`, `>`, `<=`, `>=` use `b`, `a`, `be`, `ae` condition codes;
- `i64`/`i32` retain signed `idivq` and signed ordering.

This is required for arbitrary ACPI 64-bit chunks and for page-table entries carrying the NX high bit.

## Safety status
- No persistent-media write path has been enabled.
- Physical boot remains diagnostic-only and explicitly BLOCKED.
- Frames 1.0 remains BLOCKED until real runtime, stress/fault and physical-machine evidence satisfy the fail-closed promotion gate.
