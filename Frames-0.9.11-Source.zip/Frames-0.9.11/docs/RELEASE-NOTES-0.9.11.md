# Frames 0.9.11 — Unsigned Runtime Semantics Repair

Frames 0.9.11 is a runtime-repair release driven by the first QEMU/OVMF evidence from 0.9.10.

## Runtime evidence entering this release
- 0.9.10 reached `FRAMES_KERNEL_READY`, `FRAMES_GDT_OK`, `FRAMES_TSS_OK`, the complete audio/driver/security/update self-test tail, and `FRAMES_WORKER0_ENTER`.
- NVMe read-only runtime certification remained PASS.
- ACPI failed with `FRAMES_ACPI_DIAG=0x8`.
- User-copy validation did not emit `FRAMES_USER_COPY_OK`, so ring-3 execution remained gated.

## Root cause and repair
Nexus 5.15 used signed x86-64 `idivq` and signed ordered condition codes for all integer types, including `u64`/`u32`. Frames uses unsigned 64-bit values for ACPI byte extraction, physical addresses, page-table entries, and NX-bearing PTEs. When bit 63 was set, signed lowering corrupted unsigned division/modulo/ordering semantics.

Frames 0.9.11 bundles Nexus 5.16.0, which:
- lowers `u64`/`u32` division and modulo with zero-extended `divq`;
- lowers unsigned ordered comparisons with `b/a/be/ae` condition codes;
- preserves `idivq` and signed ordering for `i64`/`i32`.

This directly repairs the two runtime-sensitive paths exposed by 0.9.10: ACPI checksum byte extraction and NX-bearing user PTE permission validation.

Physical boot remains diagnostic-only and BLOCKED. Fresh QEMU/OVMF runtime evidence is required before any runtime promotion.
