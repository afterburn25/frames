Frames 0.9.11: Unsigned Runtime Semantics Repair.

Local structural/reproducibility target:
- Nexus 5.16.0 unsigned-codegen regression: PASS
- Frames kernel/FEX/EFI/GPT/FAT32 release structure: PASS
- NVMe read-only source gates: PASS
- physical boot: BLOCKED

External runtime status:
- 0.9.10 QEMU/OVMF reached GDT/TSS and Worker 0 and retained NVMe runtime PASS.
- 0.9.10 ACPI: BLOCKED at MADT checksum path (`FRAMES_ACPI_DIAG=0x8`).
- 0.9.10 userspace: BLOCKED before `FRAMES_USER_COPY_OK` / ring-3 transition.
- 0.9.11 requires a fresh QEMU/OVMF evidence run to validate the Nexus 5.16 unsigned-semantics repair.
