Frames 0.9.10: Runtime Gate Repair 1. Structural verification passes; fresh QEMU/OVMF runtime evidence required. Physical boot remains BLOCKED.
