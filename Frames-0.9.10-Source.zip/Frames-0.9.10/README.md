# Frames 0.9.10 — Runtime Gate Repair 1

Frames 0.9.10 is a targeted runtime-repair release built from the structurally verified 0.9.9 pre-1.0 baseline after the first successful QEMU/OVMF evidence run.

Implemented repairs:
- expands the UEFI bootstrap heap from 64 pages (256 KiB) to 192 pages (768 KiB); the current kernel reserves 133 pages before steady-state execution, so the old heap exhausted before audio, GDT/TSS, ring-3 stacks, and later platform gates could initialize;
- validates ACPI RSDP candidates in the UEFI configuration table and accepts a validated signature candidate even if GUID matching is unavailable;
- emits `FRAMES_ACPI_DIAG=<code>` on bounded ACPI parse failure so the next runtime run identifies the exact ACPI rejection stage;
- makes `qemu_certify.sh` create `build/` before copying a writable OVMF VARS image;
- corrects the stale UEFI banner from Frames 0.0.40 to Frames 0.9.10.

Runtime status:
- 0.9.9 QEMU/OVMF evidence proved kernel boot, NVMe read-only storage runtime, xHCI enumeration through USB configuration, networking core self-tests, hardening/recovery foundations, and software display self-tests through `FRAMES_KERNEL_READY`.
- 0.9.9 storage runtime profile: PASS.
- 0.9.9 platform/SMP/userspace groups: BLOCKED.
- 0.9.10 is structurally verified locally, but its new runtime behavior still requires a fresh external QEMU/OVMF run.
- Physical boot remains explicitly BLOCKED.
