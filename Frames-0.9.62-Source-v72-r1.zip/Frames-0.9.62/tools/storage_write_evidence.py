#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json, re

ROOT=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser()
a.add_argument('--serial',default=str(ROOT/'build/serial.log'))
a.add_argument('--media',default=str(ROOT/'build/WRITE-MEDIA-INTEGRITY.json'))
a.add_argument('--require-pass',action='store_true')
n=a.parse_args()
serial=Path(n.serial); media_path=Path(n.media)
raw=serial.read_bytes() if serial.is_file() else b''
text=raw.decode('utf-8','replace')
required=[
 'FRAMES_NVME_WRITE_TARGET_FOUND',
 'FRAMES_NVME_WRITE_OK',
 'FRAMES_NVME_FLUSH_OK',
 'FRAMES_STORAGE_WRITE_GUARDS_OK',
 'FRAMES_STORAGE_WRITE_INTEGRITY_OK',
]
missing=[m for m in required if m not in text]
fatal='FRAMES_STORAGE_WRITE_INTEGRITY_FAIL' in text
diag={}
for sm,dm in re.findall(r'FRAMES_STORAGE_WRITE_DIAG stage=0x([0-9A-Fa-f]+) detail=0x([0-9A-Fa-f]+)',text):
    diag[int(sm,16)]=int(dm,16)
expected={1:32768,2:4096,3:16,4:48,5:48,6:16,7:3,8:167}
diag_ok=all(diag.get(k)==v for k,v in expected.items())
media={}
if media_path.is_file():
    try: media=json.loads(media_path.read_text())
    except Exception: media={}
media_ok=media.get('status')=='PASS' and media.get('byte_identical_after_restore') is True
status='PASS' if not missing and not fatal and diag_ok and media_ok else 'FAIL'
doc={
 'frames_version':(ROOT/'VERSION').read_text().strip(),
 'profile':'post-stress-storage-write-integrity-gate1',
 'status':status,
 'serial_sha256':hashlib.sha256(raw).hexdigest(),
 'required_markers':required,
 'missing_markers':missing,
 'fatal_marker_present':fatal,
 'diagnostics':{str(k):diag.get(k) for k in sorted(expected)},
 'expected_diagnostics':{str(k):v for k,v in expected.items()},
 'diagnostics_match':diag_ok,
 'media_integrity_status':media.get('status'),
 'media_byte_identical_after_restore':media.get('byte_identical_after_restore'),
 'write_path_certified':status=='PASS',
 'boot_volume_write_certified':False,
 'sacrificial_target_only':True,
}
out=ROOT/'build/STORAGE-WRITE-EVIDENCE.json'
out.write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps(doc,indent=2))
if n.require_pass and status!='PASS': raise SystemExit(2)
