#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"; QEMU="${QEMU:-qemu-system-x86_64}"; OVMF_CODE="${OVMF_CODE:-}"; OVMF_VARS="${OVMF_VARS:-}"; LANE="${1:-normal}"
case "$LANE" in normal|detach) ;; *) echo "lane must be normal or detach" >&2; exit 2;; esac
[[ -n "$OVMF_CODE" && -f "$OVMF_CODE" ]] || { echo "Set OVMF_CODE=/path/to/OVMF_CODE.fd" >&2; exit 2; }
mkdir -p "$ROOT/build"
[[ -f "$ROOT/build/Frames-${VER}-USB-Boot.img" ]] || { "$ROOT/tools/build.sh"; python3 "$ROOT/tools/make_esp.py"; python3 "$ROOT/tools/make_usb_boot_image.py"; }
python3 "$ROOT/tools/make_internal_usb_guard.py"
USB="$ROOT/build/Frames-${VER}-USB-Boot-${LANE}.img"; cp "$ROOT/build/Frames-${VER}-USB-Boot.img" "$USB"; cp "$USB" "$USB.before"
INTERNAL="$ROOT/build/Frames-${VER}-Internal-Support-${LANE}.img"; cp "$ROOT/build/Frames-${VER}-ESP.img" "$INTERNAL"; cp "$INTERNAL" "$INTERNAL.before"
GUARD="$ROOT/build/Frames-${VER}-USB-Internal-Guard-${LANE}.img"; cp "$ROOT/build/Frames-${VER}-USB-Internal-Guard.img" "$GUARD"; cp "$GUARD" "$GUARD.before"
LOG="$ROOT/build/usb-${LANE}-serial.log"; QMP="$ROOT/build/usb-${LANE}-qmp.sock"; MON="$ROOT/build/usb-${LANE}-monitor.log"; DBG="$ROOT/build/usb-${LANE}-qemu-debug.log"; RCF="$ROOT/build/USB-BOOT-${LANE^^}-QEMU-EXIT-CODE.txt"; EV="$ROOT/build/USB-BOOT-${LANE^^}-EVIDENCE.json"
rm -f "$LOG" "$QMP" "$MON" "$DBG" "$RCF" "$EV"
VAR_DRIVE=(); if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.usb-${LANE}.fd"; VAR_DRIVE=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.usb-${LANE}.fd"); fi
TIMEOUT=240
set +e
timeout "$TIMEOUT" "$QEMU" -machine q35 -accel tcg,thread=multi -m 1024M -smp 4 -cpu max -display none -serial file:"$LOG" -no-reboot -no-shutdown -qmp "unix:$QMP,server=on,wait=off" -d guest_errors -D "$DBG" \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${VAR_DRIVE[@]}" \
  -device qemu-xhci,id=bootxhci \
  -drive if=none,id=usbdrive,format=raw,readonly=on,file="$USB" \
  -device usb-storage,bus=bootxhci.0,drive=usbdrive,id=usbboot,bootindex=1 \
  -drive if=none,id=internalboot,format=raw,readonly=on,file="$INTERNAL" \
  -device nvme,serial=FRAMESINT0938,drive=internalboot,bootindex=20 \
  -drive if=none,id=guarddrive,format=raw,file="$GUARD" \
  -device nvme,serial=FRAMESGUARD0938,drive=guarddrive &
qpid=$!
if [[ "$LANE" == normal ]]; then python3 "$ROOT/tools/qmp_marker_quit.py" "$QMP" "$LOG" FRAMES_USB_BOOT_RESIDENT_OK "$TIMEOUT" >"$MON" 2>&1 & mpid=$!; else python3 "$ROOT/tools/qmp_usb_detach.py" "$QMP" "$LOG" "$TIMEOUT" >"$MON" 2>&1 & mpid=$!; fi
wait "$qpid"; rc=$?; wait "$mpid"; mrc=$?
set -e
printf '%s\n' "$rc" > "$RCF"
[[ "$rc" -eq 0 && "$mrc" -eq 0 ]] || { echo "USB $LANE QEMU/monitor failure qemu=$rc monitor=$mrc" >&2; tail -200 "$LOG" >&2 || true; cat "$MON" >&2 || true; exit 1; }
python3 "$ROOT/tools/verify_internal_usb_guard.py" --before "$GUARD.before" --after "$GUARD" --require-pass
MEDIA="$ROOT/build/USB-BOOT-${LANE^^}-MEDIA.json"
python3 "$ROOT/tools/usb_boot_media_evidence.py" --usb-before "$USB.before" --usb-after "$USB" --internal-before "$INTERNAL.before" --internal-after "$INTERNAL" --guard-before "$GUARD.before" --guard-after "$GUARD" --require-pass > "$MEDIA"
python3 "$ROOT/tools/usb_boot_evidence.py" --serial "$LOG" --qemu-exit "$rc" --lane "$LANE" --monitor "$MON" --before-guard "$GUARD.before" --after-guard "$GUARD" --media "$MEDIA" --require-pass > "$EV"
cat "$EV"
echo "FRAMES ${VER} REMOVABLE USB BOOT ${LANE^^} LANE PASS"
