#!/usr/bin/env python3
import json, socket, sys, time
from pathlib import Path
sock_path=sys.argv[1]
cycles=int(sys.argv[2]) if len(sys.argv)>2 else 48
stop_log=Path(sys.argv[3]) if len(sys.argv)>4 else None
stop_marker=sys.argv[4] if len(sys.argv)>4 else None
deadline=time.time()+15
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
while True:
    try:
        s.connect(sock_path); break
    except OSError:
        if time.time()>=deadline: raise SystemExit('QMP socket did not become ready')
        time.sleep(0.05)
f=s.makefile('rwb', buffering=0)
def recv_obj(timeout=5):
    s.settimeout(timeout)
    while True:
        line=f.readline()
        if not line: raise EOFError('QMP closed')
        obj=json.loads(line)
        if 'event' in obj: continue
        return obj
def cmd(execute,args=None):
    payload={'execute':execute}
    if args is not None: payload['arguments']=args
    f.write((json.dumps(payload,separators=(',',':'))+'\n').encode())
    return recv_obj()
def stop_requested():
    if stop_log is None or stop_marker is None or not stop_log.exists():
        return False
    try:
        return stop_marker in stop_log.read_text(errors='ignore')
    except OSError:
        return False
recv_obj(); cmd('qmp_capabilities')
# Periodic down/up pairs keep at least one real keyboard transition pending
# while firmware + kernel enumeration proceeds under TCG. In lifecycle mode,
# release this single QMP client immediately after the second-boot proof marker
# so the independent quit client can take ownership of the QMP chardev.
keys=['a','b','c','d','e','f','g','h']
for i in range(cycles):
    if stop_requested():
        print('stop-marker',stop_marker,flush=True)
        break
    qcode=keys[i % len(keys)]
    down=[{'type':'key','data':{'down':True,'key':{'type':'qcode','data':qcode}}}]
    up=[{'type':'key','data':{'down':False,'key':{'type':'qcode','data':qcode}}}]
    r=cmd('input-send-event',{'events':down})
    if 'error' in r:
        r=cmd('human-monitor-command',{'command-line':f'sendkey {qcode},hold-time=120'})
        if 'error' in r: raise SystemExit(str(r))
        print('sent-hmp',qcode,flush=True)
        time.sleep(0.45)
        continue
    print('down',qcode,flush=True)
    time.sleep(0.12)
    r=cmd('input-send-event',{'events':up})
    if 'error' in r: raise SystemExit(str(r))
    print('up',qcode,flush=True)
    time.sleep(0.33)
f.close(); s.close()
