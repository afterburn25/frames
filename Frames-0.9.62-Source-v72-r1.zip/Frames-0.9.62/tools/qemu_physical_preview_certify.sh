#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"; QEMU="${QEMU:-qemu-system-x86_64}"; OVMF_CODE="${OVMF_CODE:-}"; OVMF_VARS="${OVMF_VARS:-}"; LANE="${1:-generic}"
case "$LANE" in generic|raw|reboot|shutdown|filesystem|system-volume|fat-lifecycle) ;; *) echo "invalid Gate-8 lane" >&2; exit 2;; esac
[[ -n "$OVMF_CODE" && -f "$OVMF_CODE" ]] || { echo "Set OVMF_CODE" >&2; exit 2; }
mkdir -p "$ROOT/build"
# Build all immutable boot inputs first.
[[ -f "$ROOT/build/Frames-${VER}-ESP.img" ]] || { "$ROOT/tools/build.sh"; python3 "$ROOT/tools/make_esp.py"; }
python3 "$ROOT/tools/make_physical_preview_image.py" >/dev/null
python3 "$ROOT/tools/make_internal_usb_guard.py" >/dev/null
python3 "$ROOT/tools/make_physical_sata_guard.py" >/dev/null
python3 "$ROOT/tools/make_write_test_nvme.py" >/dev/null
python3 "$ROOT/tools/make_lifecycle_test_nvme.py" --mode both >/dev/null
python3 "$ROOT/tools/make_filesystem_test_nvme.py" --scenario 0 >/dev/null
python3 "$ROOT/tools/make_system_volume_clone.py" >/dev/null
python3 "$ROOT/tools/make_fat_lifecycle_clone.py" >/dev/null

case "$LANE" in
 generic) TARGET_SRC="$ROOT/build/Frames-${VER}-USB-Internal-Guard.img"; TARGET_SERIAL="FRAMESGUARD0939" ;;
 raw) TARGET_SRC="$ROOT/build/Frames-${VER}-Write-Test.img"; TARGET_SERIAL="FRAMESWRITE0932" ;;
 reboot) TARGET_SRC="$ROOT/build/Frames-${VER}-Lifecycle-reboot.img"; TARGET_SERIAL="FRAMESREBOOT0933" ;;
 shutdown) TARGET_SRC="$ROOT/build/Frames-${VER}-Lifecycle-shutdown.img"; TARGET_SERIAL="FRAMESSHUTDOWN0933" ;;
 filesystem) TARGET_SRC="$ROOT/build/Frames-${VER}-Filesystem-s0.img"; TARGET_SERIAL="FRAMESFS0934" ;;
 system-volume) TARGET_SRC="$ROOT/build/Frames-${VER}-System-Clone.img"; TARGET_SERIAL="FRAMESSYS0935" ;;
 fat-lifecycle) TARGET_SRC="$ROOT/build/Frames-${VER}-FAT-Lifecycle-Clone.img"; TARGET_SERIAL="FRAMESFAT0936" ;;
esac

USB="$ROOT/build/Frames-${VER}-Physical-Preview-${LANE}.img"; cp "$ROOT/build/Frames-${VER}-Physical-Hardware-Preview.img" "$USB"; cp "$USB" "$USB.before"
SUPPORT="$ROOT/build/Frames-${VER}-Physical-Support-${LANE}.img"; cp "$ROOT/build/Frames-${VER}-ESP.img" "$SUPPORT"; cp "$SUPPORT" "$SUPPORT.before"
TARGET="$ROOT/build/Frames-${VER}-Physical-Target-${LANE}.img"; cp "$TARGET_SRC" "$TARGET"; cp "$TARGET" "$TARGET.before"
SATA="$ROOT/build/Frames-${VER}-Physical-SATA-${LANE}.img"; cp "$ROOT/build/Frames-${VER}-Physical-SATA-Guard.img" "$SATA"; cp "$SATA" "$SATA.before"
LOG="$ROOT/build/physical-${LANE}-serial.log"; QMP="$ROOT/build/physical-${LANE}-qmp.sock"; MON="$ROOT/build/physical-${LANE}-monitor.log"; DBG="$ROOT/build/physical-${LANE}-qemu-debug.log"; RCF="$ROOT/build/PHYSICAL-PREVIEW-${LANE^^}-QEMU-EXIT-CODE.txt"; EV="$ROOT/build/PHYSICAL-PREVIEW-${LANE^^}-EVIDENCE.json"; MEDIA="$ROOT/build/PHYSICAL-PREVIEW-${LANE^^}-MEDIA.json"
rm -f "$LOG" "$QMP" "$MON" "$DBG" "$RCF" "$EV" "$MEDIA"
VAR_DRIVE=(); if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.physical-${LANE}.fd"; VAR_DRIVE=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.physical-${LANE}.fd"); fi
TIMEOUT=300
set +e
timeout "$TIMEOUT" "$QEMU" -machine q35 -accel tcg,thread=multi -m 2048M -smp 4 -cpu max -display none -serial file:"$LOG" -no-reboot -no-shutdown -qmp "unix:$QMP,server=on,wait=off" -d guest_errors -D "$DBG" \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${VAR_DRIVE[@]}" \
  -device qemu-xhci,id=bootxhci \
  -drive if=none,id=usbdrive,format=raw,readonly=on,file="$USB" \
  -device usb-storage,bus=bootxhci.0,drive=usbdrive,id=usbboot,bootindex=1 \
  -drive if=none,id=supportdrive,format=raw,file="$SUPPORT" \
  -device nvme,serial=FRAMESSUPPORT0939,drive=supportdrive,bootindex=20 \
  -drive if=none,id=targetdrive,format=raw,file="$TARGET" \
  -device nvme,serial="$TARGET_SERIAL",drive=targetdrive \
  -drive if=none,id=sataguard,format=raw,file="$SATA" \
  -device ide-hd,bus=ide.0,drive=sataguard \
  -netdev user,id=net0,restrict=on -device e1000e,netdev=net0 &
qpid=$!
python3 "$ROOT/tools/qmp_marker_quit.py" "$QMP" "$LOG" FRAMES_KERNEL_READY "$TIMEOUT" >"$MON" 2>&1 & mpid=$!
wait "$qpid"; rc=$?; wait "$mpid"; mrc=$?
set -e
printf '%s\n' "$rc" > "$RCF"
[[ "$rc" -eq 0 && "$mrc" -eq 0 ]] || { echo "Gate-8 $LANE QEMU/monitor failure qemu=$rc monitor=$mrc" >&2; tail -240 "$LOG" >&2 || true; cat "$MON" >&2 || true; exit 1; }
python3 "$ROOT/tools/physical_preview_media_evidence.py" \
 --usb-before "$USB.before" --usb-after "$USB" \
 --support-before "$SUPPORT.before" --support-after "$SUPPORT" \
 --target-before "$TARGET.before" --target-after "$TARGET" \
 --sata-before "$SATA.before" --sata-after "$SATA" --require-pass > "$MEDIA"
python3 "$ROOT/tools/physical_preview_evidence.py" --serial "$LOG" --qemu-exit "$rc" --lane "$LANE" --media "$MEDIA" --require-pass > "$EV"
cat "$EV"
echo "FRAMES ${VER} PHYSICAL PREVIEW SAFETY ${LANE^^} LANE PASS"
