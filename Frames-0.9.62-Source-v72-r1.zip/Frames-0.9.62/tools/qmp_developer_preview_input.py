#!/usr/bin/env python3
import json,socket,sys,time
from pathlib import Path
if len(sys.argv)<3: raise SystemExit('usage: qmp_developer_preview_input.py SOCKET SERIAL_LOG')
sock_path=sys.argv[1]; log=Path(sys.argv[2]); deadline=time.time()+90
while time.time()<deadline:
    if log.exists() and 'FRAMES_DEVPREV_READY' in log.read_text(errors='ignore'): break
    time.sleep(0.05)
else: raise SystemExit('developer preview ready marker not observed')

s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
connect_deadline=time.time()+10
while True:
    try: s.connect(sock_path); break
    except OSError:
        if time.time()>=connect_deadline: raise SystemExit('QMP socket unavailable')
        time.sleep(0.05)
f=s.makefile('rwb',buffering=0)

def recv_obj(timeout=5):
    s.settimeout(timeout)
    while True:
        line=f.readline()
        if not line: raise EOFError('QMP closed')
        obj=json.loads(line)
        if 'event' in obj: continue
        return obj

def cmd(execute,args=None):
    payload={'execute':execute}
    if args is not None: payload['arguments']=args
    f.write((json.dumps(payload,separators=(',',':'))+'\n').encode())
    return recv_obj()

recv_obj()
cmd('qmp_capabilities')

def log_text():
    return log.read_text(errors='ignore') if log.exists() else ''

def wait_marker(marker,timeout=5.0):
    end=time.time()+timeout
    while time.time()<end:
        if marker in log_text(): return True
        time.sleep(0.05)
    return False

def key(qcode):
    for down in (True,False):
        r=cmd('input-send-event',{'events':[{'type':'key','data':{'down':down,'key':{'type':'qcode','data':qcode}}}]})
        if 'error' in r: raise SystemExit(str(r))
        time.sleep(0.08)

def type_command(text):
    for ch in text:
        key(ch)
    key('ret')
    time.sleep(0.20)

commands=('help','version','cpu','memory','devices','processes','filesystems','sdk','app','run','reboot','shutdown','exit')
markers={
    'help':'FRAMES_DEVPREV_CMD_HELP_OK',
    'version':'FRAMES_DEVPREV_CMD_VERSION_OK',
    'cpu':'FRAMES_DEVPREV_CMD_CPU_OK',
    'memory':'FRAMES_DEVPREV_CMD_MEMORY_OK',
    'devices':'FRAMES_DEVPREV_CMD_DEVICES_OK',
    'processes':'FRAMES_DEVPREV_CMD_PROCESSES_OK',
    'filesystems':'FRAMES_DEVPREV_CMD_FILESYSTEMS_OK',
    'sdk':'FRAMES_DEVPREV_CMD_SDK_OK',
    'app':'FRAMES_DEVPREV_CMD_APP_OK',
    'run':'FRAMES_DEVPREV_CMD_RUN_OK',
    'reboot':'FRAMES_DEVPREV_CMD_REBOOT_BLOCKED',
    'shutdown':'FRAMES_DEVPREV_CMD_SHUTDOWN_BLOCKED',
    'exit':'FRAMES_DEVPREV_CMD_EXIT_OK',
}

for command in commands:
    marker=markers[command]
    delivered=False
    for attempt in range(2):
        type_command(command)
        if wait_marker(marker,5.0):
            print(f'ACK command={command} marker={marker} attempt={attempt+1}',flush=True)
            delivered=True
            break
        print(f'RETRY command={command} marker={marker} attempt={attempt+1}',flush=True)
        time.sleep(0.25)
    if not delivered:
        raise SystemExit(f'developer preview command marker not observed: command={command} marker={marker}')

if not wait_marker('FRAMES_DEVPREV_CERT_OK',5.0):
    raise SystemExit('developer preview certification marker not observed')
r=cmd('quit')
print('PASS: developer preview Phase 3 paced USB input/system inspection command sequence certified; quit=',r,flush=True)
f.close()
s.close()
raise SystemExit(0)
