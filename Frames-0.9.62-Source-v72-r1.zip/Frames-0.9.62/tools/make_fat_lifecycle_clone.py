#!/usr/bin/env python3
from pathlib import Path
import struct, json, hashlib
ROOT=Path(__file__).resolve().parents[1]
VER=(ROOT/'VERSION').read_text().strip()
SECTOR=512
SRC=ROOT/'build'/f'Frames-{VER}-ESP.img'
OUT=ROOT/'build'/f'Frames-{VER}-FAT-Lifecycle-Clone.img'
MAN=ROOT/'build'/'FAT-LIFECYCLE-TARGET.json'

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def u64(b,o): return struct.unpack_from('<Q',b,o)[0]
def fat_entry(img, fat_base, c): return u32(img,fat_base+c*4)&0x0fffffff
def set_fat(img, base, reserved, fat_sectors, nfats, cluster, value):
    for f in range(nfats):
        off=base+(reserved+f*fat_sectors)*SECTOR+cluster*4
        struct.pack_into('<I',img,off,value)
def cluster_off(base,data_start,spc,c): return base+(data_start+(c-2)*spc)*SECTOR
def cluster_lba(part_start,data_start,spc,c): return part_start+data_start+(c-2)*spc
def short_cluster(e): return u16(e,20)*65536+u16(e,26)

def descriptor_block(part_start,dir_lba,dir_off,pool,fat1_lba,fat2_lba,desc_cluster,desc_lba):
    x=bytearray(SECTOR)
    x[:15]=b'FRAMES_FATLC_V1'
    struct.pack_into('<Q',x,32,936)
    struct.pack_into('<Q',x,40,part_start)
    struct.pack_into('<Q',x,48,dir_lba)
    struct.pack_into('<Q',x,56,dir_off)
    struct.pack_into('<Q',x,64,len(pool))
    for i,c in enumerate(pool): struct.pack_into('<Q',x,72+i*8,c)
    struct.pack_into('<Q',x,104,fat1_lba)
    struct.pack_into('<Q',x,112,fat2_lba)
    struct.pack_into('<Q',x,120,desc_cluster)
    struct.pack_into('<Q',x,128,desc_lba)
    x[160:171]=b'FATGATE CFG'
    x[176:187]=b'LIFE0001TST'
    x[192:203]=b'LIFE0002TST'
    x[208:219]=b'LIFE0003TST'
    return x

img=bytearray(SRC.read_bytes())
source_sha=sha_bytes(img)
if len(img)!=64*1024*1024: raise SystemExit('expected exact 64 MiB Frames ESP')
if img[SECTOR:SECTOR+8]!=b'EFI PART': raise SystemExit('bad GPT')
entry_lba=u64(img,SECTOR+72); entry_size=u32(img,SECTOR+84)
part_off=entry_lba*SECTOR
part_start=u64(img,part_off+32); part_end=u64(img,part_off+40)
base=part_start*SECTOR
if img[base+82:base+90]!=b'FAT32   ': raise SystemExit('not FAT32')
bps=u16(img,base+11); spc=img[base+13]; reserved=u16(img,base+14); nfats=img[base+16]; fat_sectors=u32(img,base+36); root=u32(img,base+44)&0x0fffffff
if bps!=512 or spc!=1 or nfats!=2: raise SystemExit('Gate 5 requires 512-byte sectors, 1 sector/cluster, 2 FATs')
fat1_base=base+reserved*SECTOR
fat1_lba=part_start+reserved
fat2_lba_base=part_start+reserved+fat_sectors
data_start=reserved+nfats*fat_sectors

def next_cluster(c): return fat_entry(img,fat1_base,c)
# Find FRAMES directory cluster.
frames=None; c=root
for _ in range(128):
    off=cluster_off(base,data_start,spc,c)
    for ent in range(0,SECTOR,32):
        e=img[off+ent:off+ent+32]
        if e[0]==0: break
        if e[0]!=0xE5 and e[11]!=0x0F and bytes(e[:11])==b'FRAMES     ':
            frames=short_cluster(e); break
    if frames: break
    n=next_cluster(c)
    if n>=0x0ffffff8: break
    c=n
if not frames: raise SystemExit('FRAMES directory missing')
frames_lba=cluster_lba(part_start,data_start,spc,frames)
frames_off=frames_lba*SECTOR
# Need two consecutive pristine free directory slots in first directory cluster.
slot=None
for ent in range(0,SECTOR-32,32):
    if img[frames_off+ent] in (0,0xE5) and img[frames_off+ent+32] in (0,0xE5):
        slot=ent; break
if slot is None: raise SystemExit('need two free Frames directory entries')
desc_dir_off=slot; test_dir_off=slot+32; dir_lba=frames_lba
# Pick four free clusters whose FAT entries live in one FAT sector, plus one descriptor cluster elsewhere/free.
max_cluster=((part_end-part_start+1)-data_start)//spc+1
# Select a FAT sector whose valid cluster entries are entirely free. This keeps
# the writable FAT-sector pair away from live system allocations.
pool=None; pool_sec=None
max_fat_sec=(max_cluster*4)//SECTOR
for sec in range(1,max_fat_sec+1):
    first=max(2,(sec*SECTOR)//4); last=min(max_cluster,(((sec+1)*SECTOR)//4)-1)
    vals=list(range(first,last+1))
    if len(vals)>=4 and all(fat_entry(img,fat1_base,c)==0 for c in vals):
        pool=vals[:4]; pool_sec=sec; break
if not pool: raise SystemExit('no fully-free FAT sector with four pool clusters')
desc_cluster=None
for c in range(2,max_cluster+1):
    if fat_entry(img,fat1_base,c)==0 and (c*4)//SECTOR != pool_sec:
        desc_cluster=c; break
if not desc_cluster: raise SystemExit('no descriptor cluster outside pool FAT sector')
# Allocate descriptor only. Pool remains genuinely free.
set_fat(img,base,reserved,fat_sectors,nfats,desc_cluster,0x0fffffff)
desc_lba=cluster_lba(part_start,data_start,spc,desc_cluster)
pool_lbas=[cluster_lba(part_start,data_start,spc,c) for c in pool]
fat1_mut_lba=fat1_lba+pool_sec
fat2_mut_lba=fat2_lba_base+pool_sec
# Descriptor directory entry.
entry=bytearray(32); entry[:11]=b'FATGATE CFG'; entry[11]=0x20
struct.pack_into('<H',entry,20,(desc_cluster>>16)&0xffff); struct.pack_into('<H',entry,26,desc_cluster&0xffff); struct.pack_into('<I',entry,28,SECTOR)
img[frames_off+desc_dir_off:frames_off+desc_dir_off+32]=entry
# Test slot is explicitly all-zero in pristine clone.
img[frames_off+test_dir_off:frames_off+test_dir_off+32]=b'\0'*32
# Descriptor body and zero pool data.
img[desc_lba*SECTOR:(desc_lba+1)*SECTOR]=descriptor_block(part_start,dir_lba,test_dir_off,pool,fat1_mut_lba,fat2_mut_lba,desc_cluster,desc_lba)
for lba in pool_lbas: img[lba*SECTOR:(lba+1)*SECTOR]=b'\0'*SECTOR
OUT.write_bytes(img)
manifest={
 'status':'READY','profile':'disposable-fat32-allocation-file-lifecycle-gate5','version':VER,
 'serial':'FRAMESFAT0936','bytes':len(img),'sectors':len(img)//SECTOR,'sector_bytes':SECTOR,
 'source_esp_sha256':source_sha,'pristine_clone_sha256':sha_bytes(img),
 'partition_start_lba':part_start,'partition_end_lba':part_end,'fat_copies':nfats,'fat_sectors':fat_sectors,
 'frames_directory_cluster':frames,'directory_lba':dir_lba,'descriptor_directory_offset':desc_dir_off,'test_directory_offset':test_dir_off,
 'descriptor_short_name':'FATGATE CFG','descriptor_cluster':desc_cluster,'descriptor_lba':desc_lba,
 'pool_clusters':pool,'pool_lbas':pool_lbas,'fat1_mutation_lba':fat1_mut_lba,'fat2_mutation_lba':fat2_mut_lba,
 'write_allowlist_lbas':[dir_lba,fat1_mut_lba,fat2_mut_lba,*pool_lbas],
 'lifecycle_names':['LIFE0001TST','LIFE0002TST','LIFE0003TST'],
 'pool_initially_free':True,'fat_mutation_sector_pristine_free':True,'fat_mirror_writable_only_for_pool_sector':True,'boot_or_system_volume_clone':True,
 'real_boot_volume_writable':False,'disposable_clone_only':True
}
MAN.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(OUT)
print(json.dumps(manifest,indent=2,sort_keys=True))
