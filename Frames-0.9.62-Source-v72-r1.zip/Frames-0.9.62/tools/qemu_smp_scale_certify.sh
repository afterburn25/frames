#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VER="$(cat "$ROOT/VERSION")"
QEMU="${QEMU:-qemu-system-x86_64}"
OVMF_CODE="${OVMF_CODE:-}"
OVMF_VARS="${OVMF_VARS:-}"
CPUS="${1:-2}"
case "$CPUS" in 2|4|8|16|32|64|96) ;; *) echo "unsupported SMP certification count: $CPUS" >&2; exit 2;; esac
if [[ -z "$OVMF_CODE" || ! -f "$OVMF_CODE" ]]; then echo "Set OVMF_CODE=/path/to/OVMF_CODE.fd" >&2; exit 2; fi
mkdir -p "$ROOT/build"
if [[ ! -f "$ROOT/build/Frames-${VER}-ESP.img" ]]; then "$ROOT/tools/build.sh"; python3 "$ROOT/tools/make_esp.py"; fi
LOG="$ROOT/build/smp-${CPUS}-serial.log"
QMP="$ROOT/build/smp-${CPUS}-qmp.sock"
INPUT="$ROOT/build/smp-${CPUS}-qmp-input.log"
MON="$ROOT/build/smp-${CPUS}-monitor.log"
DBG="$ROOT/build/smp-${CPUS}-qemu-debug.log"
RCF="$ROOT/build/SMP-${CPUS}-QEMU-EXIT-CODE.txt"
rm -f "$LOG" "$QMP" "$INPUT" "$MON" "$DBG" "$RCF"
VAR_DRIVE=()
if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then
  cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.smp-${CPUS}.fd"
  VAR_DRIVE=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.smp-${CPUS}.fd")
fi
# Small/medium lanes prove complete kernel readiness. Large lanes terminate at
# the SMP proof marker so 96-vCPU TCG certification measures SMP correctness,
# not unrelated post-SMP subsystem emulation time.
STOP=FRAMES_SMP_SCALE_CERT_OK
REQUIRE_READY=()
if (( CPUS <= 16 )); then STOP=FRAMES_KERNEL_READY; REQUIRE_READY=(--require-kernel-ready); fi
TIMEOUT=420
if (( CPUS >= 32 )); then TIMEOUT=720; fi
if (( CPUS >= 96 )); then TIMEOUT=1200; fi
set +e
timeout "$TIMEOUT" "$QEMU" -machine q35 -accel tcg,thread=multi -m 1024M -smp "$CPUS" -cpu max -display none \
  -serial file:"$LOG" -no-reboot -no-shutdown -qmp "unix:$QMP,server=on,wait=off" -d guest_errors -D "$DBG" \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${VAR_DRIVE[@]}" \
  -device qemu-xhci,id=xhci -device usb-kbd,bus=xhci.0 \
  -netdev user,id=framesnet,restrict=on -device e1000e,netdev=framesnet \
  -drive if=none,id=framesnvme,format=raw,readonly=on,file="$ROOT/build/Frames-${VER}-ESP.img" \
  -device nvme,serial=FRAMESSMP0937,drive=framesnvme &
qemu_pid=$!
python3 "$ROOT/tools/qmp_input_inject.py" "$QMP" 2400 "$LOG" "$STOP" >"$INPUT" 2>&1 & input_pid=$!
python3 "$ROOT/tools/qmp_marker_quit.py" "$QMP" "$LOG" "$STOP" "$TIMEOUT" >"$MON" 2>&1 & mon_pid=$!
wait "$qemu_pid"; rc=$?
wait "$input_pid" 2>/dev/null || true
wait "$mon_pid"; mon_rc=$?
set -e
printf '%s\n' "$rc" > "$RCF"
[[ -f "$LOG" ]] || { echo "SMP $CPUS serial log missing" >&2; exit 1; }
if [[ "$rc" -ne 0 || "$mon_rc" -ne 0 ]]; then
  echo "SMP $CPUS QEMU/monitor failure qemu=$rc monitor=$mon_rc" >&2
  tail -200 "$LOG" >&2 || true; cat "$MON" >&2 || true; exit 1
fi
python3 "$ROOT/tools/smp_scale_evidence.py" --serial "$LOG" --expected-cpus "$CPUS" "${REQUIRE_READY[@]}" --require-pass
for fatal in FRAMES_USB_BOOT_CERT_FAIL FRAMES_SMP_SCALE_CERT_FAIL FRAMES_PAGE_FAULT FRAMES_AP_PROTECTION_FAULT= PANIC ASSERT TRIPLE; do
  if grep -Fq "$fatal" "$LOG"; then echo "SMP $CPUS fatal marker: $fatal" >&2; exit 1; fi
done
echo "FRAMES ${VER} SMP ${CPUS} CPU CERTIFICATION PASS"
