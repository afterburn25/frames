#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib
p=argparse.ArgumentParser(); p.add_argument('--developer-evidence',required=True); p.add_argument('--serial',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
dev=json.loads(Path(a.developer_evidence).read_text()); raw=Path(a.serial).read_bytes(); text=raw.decode(errors='replace')
required=['FRAMES_DEVPREV_USB_POLL_ARMED','FRAMES_DEVPREV_USB_REPORT_OK','FRAMES_DEVPREV_CMD_PROCESSES_OK','FRAMES_DEVPREV_CMD_FILESYSTEMS_OK']
checks={
 'developer_preview_pass':dev.get('status')=='PASS',
 'phase3_markers_exact_once':all(text.count(m)==1 for m in required),
 'usb_polling_certified':text.find('FRAMES_DEVPREV_USB_POLL_ARMED')>=0 and text.find('FRAMES_DEVPREV_USB_REPORT_OK')>text.find('FRAMES_DEVPREV_USB_POLL_ARMED'),
 'processes_command_after_ready':text.find('FRAMES_DEVPREV_CMD_PROCESSES_OK')>text.find('FRAMES_DEVPREV_READY'),
 'filesystems_command_after_processes':text.find('FRAMES_DEVPREV_CMD_FILESYSTEMS_OK')>text.find('FRAMES_DEVPREV_CMD_PROCESSES_OK'),
 'physical_write_lock_retained':'FRAMES_DEVPREV_CMD_REBOOT_BLOCKED' in text and 'FRAMES_DEVPREV_CMD_SHUTDOWN_BLOCKED' in text,
}
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'developer-preview-phase3','checks':checks,'serial_sha256':hashlib.sha256(raw).hexdigest()}
print(json.dumps(out,indent=2))
if a.require_pass and status!='PASS': raise SystemExit(1)
