#!/usr/bin/env python3
from pathlib import Path
import struct, shutil, hashlib
ROOT=Path(__file__).resolve().parents[1]; VER=(ROOT/'VERSION').read_text().strip(); B=ROOT/'build'
base=B/f'Frames-{VER}-Physical-Hardware-Preview.img'; out=B/f'Frames-{VER}-USB-MSC-Cert-Boot.img'
if not base.exists(): raise SystemExit('physical preview image missing')
shutil.copy2(base,out); d=bytearray(out.read_bytes()); sec=512; challenge=b'FRAMES_USB_MASS_STORAGE_CERT_V1\n'
# Known deterministic 0.9.x image geometry; verify rather than assume silently.
if d[sec:sec+8]!=b'EFI PART': raise SystemExit('GPT missing')
part=struct.unpack_from('<Q',d,sec+72)[0]; ent=part*sec; first=struct.unpack_from('<Q',d,ent+32)[0]; baseoff=first*sec
bps=struct.unpack_from('<H',d,baseoff+11)[0]; spc=d[baseoff+13]; rsv=struct.unpack_from('<H',d,baseoff+14)[0]; nf=d[baseoff+16]; fatsz=struct.unpack_from('<I',d,baseoff+36)[0]
if bps!=512 or spc!=1 or nf!=2: raise SystemExit('unexpected FAT32 geometry')
data_start=rsv+nf*fatsz; frames_cluster=5
def coff(c): return baseoff+(data_start+(c-2))*sec
fat1=baseoff+rsv*sec; fat2=baseoff+(rsv+fatsz)*sec
free=6
while free<65525:
    if (struct.unpack_from('<I',d,fat1+free*4)[0]&0x0fffffff)==0: break
    free+=1
if free>=65525: raise SystemExit('no free FAT cluster')
for fo in (fat1,fat2): struct.pack_into('<I',d,fo+free*4,0x0fffffff)
raw=coff(frames_cluster); slot=None
for off in range(0,sec,32):
    if d[raw+off] in (0,0xe5): slot=raw+off; break
if slot is None: raise SystemExit('Frames directory full')
e=bytearray(32); e[:11]=b'USBMSC  CFG'; e[11]=0x20; struct.pack_into('<H',e,20,(free>>16)&0xffff); struct.pack_into('<H',e,26,free&0xffff); struct.pack_into('<I',e,28,len(challenge)); d[slot:slot+32]=e
if slot+32<raw+sec and d[slot+32]!=0: pass
else: d[slot+32:slot+64]=b'\0'*32
d[coff(free):coff(free)+sec]=challenge.ljust(sec,b'\0'); out.write_bytes(d)
print(out); print('USBMSC.CFG sha256='+hashlib.sha256(challenge).hexdigest()); print('image sha256='+hashlib.sha256(d).hexdigest())
