#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
"$ROOT/tools/qemu_usb_msc_certify.sh" normal
"$ROOT/tools/qemu_usb_msc_certify.sh" detach
python3 "$ROOT/tools/usb_msc_matrix_evidence.py" --normal "$ROOT/build/USB-MSC-NORMAL-EVIDENCE.json" --detach "$ROOT/build/USB-MSC-DETACH-EVIDENCE.json" --require-pass > "$ROOT/build/USB-MSC-MATRIX-EVIDENCE.json"
cat "$ROOT/build/USB-MSC-MATRIX-EVIDENCE.json"
