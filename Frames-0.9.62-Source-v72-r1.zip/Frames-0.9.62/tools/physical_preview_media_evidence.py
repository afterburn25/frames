#!/usr/bin/env python3
import argparse,hashlib,json,sys
from pathlib import Path
p=argparse.ArgumentParser()
for n in ('usb_before','usb_after','support_before','support_after','target_before','target_after','sata_before','sata_after'):
 p.add_argument('--'+n.replace('_','-'),required=True,dest=n)
p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
def pair(b,a):
 rb=Path(b).read_bytes(); ra=Path(a).read_bytes(); return {'before_sha256':hashlib.sha256(rb).hexdigest(),'after_sha256':hashlib.sha256(ra).hexdigest(),'same_size':len(rb)==len(ra),'byte_identical':rb==ra,'bytes':len(rb)}
out={k:pair(getattr(a,k+'_before'),getattr(a,k+'_after')) for k in ('usb','support','target','sata')}
checks={f'{k}_byte_identical':v['byte_identical'] and v['same_size'] for k,v in out.items()}
status='PASS' if all(checks.values()) else 'FAIL'; result={'status':status,'checks':checks,'media':out}; print(json.dumps(result,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': sys.exit(1)
