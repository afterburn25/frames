#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,subprocess
ap=argparse.ArgumentParser(); ap.add_argument('--package',required=True); ap.add_argument('--image',required=True); ap.add_argument('--require-pass',action='store_true'); a=ap.parse_args()
r=Path(__file__).resolve().parents[1]; pkg=Path(a.package); img=Path(a.image)
v=subprocess.run(['python3',str(r/'sdk/fapp_tool.py'),'verify',str(pkg)],cwd=r,text=True,capture_output=True)
m=subprocess.run(['python3',str(r/'tools/verify_developer_preview_image.py'),'--image',str(img),'--package',str(pkg),'--require-pass'],cwd=r,text=True,capture_output=True)
info=json.loads(v.stdout) if v.returncode==0 else {}
checks={
 'package_verify':v.returncode==0 and info.get('status')=='PASS',
 'format_fapp1':info.get('manifest',{}).get('format')=='FAPP1',
 'target_frames_x64':info.get('manifest',{}).get('target')=='frames-x64',
 'fex_abi_1':info.get('manifest',{}).get('fex_abi')==1,
 'package_nonzero':pkg.exists() and pkg.stat().st_size>0,
 'preview_embed':m.returncode==0,
}
status='PASS' if all(checks.values()) else 'FAIL'
ev={'status':status,'profile':'frames-sdk-fapp-packaging-phase2','checks':checks,
    'package':info,'package_sha256':hashlib.sha256(pkg.read_bytes()).hexdigest() if pkg.exists() else None,
    'preview_image_sha256':hashlib.sha256(img.read_bytes()).hexdigest() if img.exists() else None,
    'embed_stdout':m.stdout.strip()}
(r/'build/APP-PACKAGING-EVIDENCE.json').write_text(json.dumps(ev,indent=2)+'\n')
print(json.dumps(ev,indent=2))
if a.require_pass and status!='PASS': raise SystemExit(1)
