#!/usr/bin/env python3
import os,signal,sys,time
from pathlib import Path
log=Path(sys.argv[1]); marker=sys.argv[2]; pid=int(sys.argv[3]); deadline=time.time()+300
while time.time()<deadline:
    if log.exists() and marker in log.read_text(errors='ignore'):
        try: os.kill(pid,signal.SIGKILL)
        except ProcessLookupError: raise SystemExit('qemu already exited before crash kill')
        print('SIGKILL sent after',marker,flush=True); raise SystemExit(0)
    time.sleep(.1)
raise SystemExit('marker timeout '+marker)
