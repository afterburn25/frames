#!/usr/bin/env python3
from pathlib import Path
import json,struct,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1]
VER=(ROOT/'VERSION').read_text().strip(); B=ROOT/'build'
img_path=B/f'Frames-{VER}-FAT-Lifecycle-Clone.img'; man=json.loads((B/'FAT-LIFECYCLE-TARGET.json').read_text())
pristine=img_path.read_bytes(); img=bytearray(pristine); SECTOR=512
writes=flushes=mirror_updates=0; phases=[]

def write_sector(lba,data,flush=True):
    global writes,flushes
    assert len(data)==SECTOR
    img[lba*SECTOR:(lba+1)*SECTOR]=data; writes+=1
    if flush: flushes+=1

def fat_value(lba,c): return struct.unpack_from('<I',img,lba*SECTOR+(c*4)%SECTOR)[0]&0x0fffffff
def fat_pair_set(c,v):
    global mirror_updates,writes,flushes
    for lba in (man['fat1_mutation_lba'],man['fat2_mutation_lba']):
        sec=bytearray(img[lba*SECTOR:(lba+1)*SECTOR]); struct.pack_into('<I',sec,(c*4)%SECTOR,v); img[lba*SECTOR:(lba+1)*SECTOR]=sec; writes+=1
    flushes+=1; mirror_updates+=1
    assert fat_value(man['fat1_mutation_lba'],c)==(v&0x0fffffff)==fat_value(man['fat2_mutation_lba'],c)
def data_block(gen,c):
    x=bytearray(SECTOR); x[:15]=b'FRAMES_FATDATA1'; struct.pack_into('<QQQ',x,32,936,gen,c)
    for i in range(64,SECTOR): x[i]=(41+(i*19)+(gen*11)+(c*3))&0xff
    return x
def dir_sector(): return bytearray(img[man['directory_lba']*SECTOR:(man['directory_lba']+1)*SECTOR])
def set_entry(name,c,size):
    sec=dir_sector(); off=man['test_directory_offset']; sec[off:off+32]=b'\0'*32; sec[off:off+11]=name.encode(); sec[off+11]=0x20; struct.pack_into('<H',sec,off+20,(c>>16)&0xffff); struct.pack_into('<H',sec,off+26,c&0xffff); struct.pack_into('<I',sec,off+28,size); write_sector(man['directory_lba'],sec)
def update_size(size):
    sec=dir_sector(); off=man['test_directory_offset']; struct.pack_into('<I',sec,off+28,size); write_sector(man['directory_lba'],sec)
def rename(name):
    sec=dir_sector(); off=man['test_directory_offset']; sec[off:off+11]=name.encode(); write_sector(man['directory_lba'],sec)
def delete_mark():
    sec=dir_sector(); off=man['test_directory_offset']; sec[off]=0xE5; write_sector(man['directory_lba'],sec)
def clear_entry():
    sec=dir_sector(); off=man['test_directory_offset']; sec[off:off+32]=b'\0'*32; write_sector(man['directory_lba'],sec)
def zero_pool(i): write_sector(man['pool_lbas'][i],bytes(SECTOR))
def entry(): return bytes(img[man['directory_lba']*SECTOR+man['test_directory_offset']:man['directory_lba']*SECTOR+man['test_directory_offset']+32])
def entry_cluster(e): return struct.unpack_from('<H',e,20)[0]*65536+struct.unpack_from('<H',e,26)[0]
P=man['pool_clusters']; L=man['pool_lbas']; EOC=0x0fffffff
# pristine FAT sector must contain no live entries.
for lba in (man['fat1_mutation_lba'],man['fat2_mutation_lba']):
    sec=img[lba*SECTOR:(lba+1)*SECTOR]
    assert all((struct.unpack_from('<I',sec,o)[0]&0x0fffffff)==0 for o in range(0,SECTOR,4))
# 1 create
write_sector(L[0],data_block(1,P[0])); fat_pair_set(P[0],EOC); set_entry('LIFE0001TST',P[0],512); phases.append('create')
assert entry()[:11]==b'LIFE0001TST' and entry_cluster(entry())==P[0] and fat_value(man['fat1_mutation_lba'],P[0])==EOC
# 2 grow to 4
for i,g in ((1,2),(2,3),(3,4)): write_sector(L[i],data_block(g,P[i]))
fat_pair_set(P[0],P[1]); fat_pair_set(P[1],P[2]); fat_pair_set(P[2],P[3]); fat_pair_set(P[3],EOC); update_size(2048); phases.append('grow')
# 3 truncate to two
update_size(1024); fat_pair_set(P[1],EOC); fat_pair_set(P[2],0); fat_pair_set(P[3],0); zero_pool(2); zero_pool(3); phases.append('truncate')
# 4 rename
rename('LIFE0002TST'); phases.append('rename'); assert entry()[:11]==b'LIFE0002TST'
# 5 delete/free
# first deletion marker, then release clusters and contents
delete_mark(); fat_pair_set(P[0],0); fat_pair_set(P[1],0); zero_pool(0); zero_pool(1); phases.append('delete')
# 6 realloc c2,c3
write_sector(L[2],data_block(5,P[2])); write_sector(L[3],data_block(6,P[3])); fat_pair_set(P[2],P[3]); fat_pair_set(P[3],EOC); set_entry('LIFE0003TST',P[2],1024); phases.append('realloc')
# 7 restore/delete
clear_entry(); fat_pair_set(P[2],0); fat_pair_set(P[3],0); zero_pool(2); zero_pool(3); phases.append('restore')
assert writes==47 and flushes==33 and mirror_updates==14
assert bytes(img)==pristine
out={'status':'PASS','profile':'disposable-fat32-allocation-file-lifecycle-gate5-synthetic','phases':phases,'writes':writes,'flushes':flushes,'fat_mirror_updates':mirror_updates,'final_byte_identical':True,'pristine_sha256':hashlib.sha256(pristine).hexdigest(),'final_sha256':hashlib.sha256(img).hexdigest()}
(B/'FAT-LIFECYCLE-SYNTHETIC.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
