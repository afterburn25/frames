#!/usr/bin/env python3
from pathlib import Path
import json,tempfile,subprocess,sys
R=Path(__file__).resolve().parents[1]
lanes=['generic','raw','reboot','shutdown','filesystem','system-volume','fat-lifecycle']
markers=['FRAMES_PHYSICAL_PREVIEW_POLICY_OK','FRAMES_USB_BOOT_POLICY_OK','FRAMES_USB_BOOT_DEVICE_PATH_OK','FRAMES_USB_BOOT_MEDIA_OK','FRAMES_USB_BOOT_SYSTEM_READ_OK','FRAMES_USB_BOOT_CERT_OK','FRAMES_USB_BOOT_DETACH_WINDOW','FRAMES_PHYSICAL_PREVIEW_WRITE_LOCK_OK','FRAMES_PHYSICAL_PREVIEW_DESTRUCTIVE_LOCK_OK','FRAMES_PHYSICAL_PREVIEW_CPU_MEMORY_OK','FRAMES_PHYSICAL_PREVIEW_ACPI_APIC_OK','FRAMES_PHYSICAL_PREVIEW_PCI_STORAGE_OK','FRAMES_PHYSICAL_PREVIEW_USB_INPUT_OK','FRAMES_PHYSICAL_PREVIEW_DISPLAY_OK','FRAMES_PHYSICAL_PREVIEW_NETWORK_PASSIVE_OK','FRAMES_PHYSICAL_PREVIEW_CERT_OK','FRAMES_PHYSICAL_PREVIEW_READY','FRAMES_USB_BOOT_RESIDENT_OK','FRAMES_KERNEL_READY']
summary={'status':'PASS','profile':'physical-boot-safety-gate8-synthetic','lanes':{}}
with tempfile.TemporaryDirectory() as td:
 t=Path(td); blob=b'guard-data-0939'*64
 for lane in lanes:
  serial=t/(lane+'.log'); serial.write_text('\n'.join(markers)+'\n')
  media={'status':'PASS','checks':{'usb_byte_identical':True,'support_byte_identical':True,'target_byte_identical':True,'sata_byte_identical':True},'media':{}}
  mf=t/(lane+'.media.json'); mf.write_text(json.dumps(media))
  cp=subprocess.run(['python3',str(R/'tools/physical_preview_evidence.py'),'--serial',str(serial),'--qemu-exit','0','--lane',lane,'--media',str(mf),'--require-pass'],capture_output=True,text=True)
  if cp.returncode!=0:
   print(cp.stdout,cp.stderr,file=sys.stderr); raise SystemExit(1)
  d=json.loads(cp.stdout); summary['lanes'][lane]={'status':d['status'],'markers_exact':all(v==1 for v in d['markers'].values()),'no_write_or_destructive_arm':d['checks']['no_write_or_destructive_arm']}
 if not all(x['status']=='PASS' and x['markers_exact'] and x['no_write_or_destructive_arm'] for x in summary['lanes'].values()): summary['status']='FAIL'
out=R/'build/PHYSICAL-PREVIEW-MATRIX-SYNTHETIC.json'; out.parent.mkdir(exist_ok=True); out.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n'); print(json.dumps(summary,indent=2,sort_keys=True))
if '--require-pass' in sys.argv and summary['status']!='PASS': sys.exit(1)
