#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"; QEMU="${QEMU:-qemu-system-x86_64}"; OVMF_CODE="${OVMF_CODE:-}"; OVMF_VARS="${OVMF_VARS:-}"; TIMEOUT="${FRAMES_FILESYSTEM_TIMEOUT:-300}"
[[ -n "$OVMF_CODE" && -f "$OVMF_CODE" ]] || { echo 'Set OVMF_CODE' >&2; exit 2; }; command -v "$QEMU" >/dev/null || exit 2
mkdir -p "$ROOT/build"; "$ROOT/tools/build.sh"; python3 "$ROOT/tools/make_esp.py"; python3 "$ROOT/tools/make_filesystem_test_nvme.py" --all; python3 "$ROOT/tools/verify_release.py"
for s in 0 1 2 3 4; do python3 "$ROOT/tools/verify_filesystem_test_image.py" --image "$ROOT/build/Frames-${VER}-Filesystem-s${s}.img" --scenario "$s" --phase initial --require-pass >/dev/null; done
common_args(){ :; }
run_vm(){
  local scenario="$1" phase="$2" marker="$3" hard="$4"; local img="$ROOT/build/Frames-${VER}-Filesystem-s${scenario}.img"
  local stem="fs-s${scenario}-${phase}"; [[ "$scenario" == 0 ]] && stem="fs-s0"
  local log="$ROOT/build/${stem}-serial.log" qmp="$ROOT/build/${stem}-qmp.sock" dbg="$ROOT/build/${stem}-qemu-debug.log" inlog="$ROOT/build/${stem}-input.log" mon="$ROOT/build/${stem}-monitor.log"
  rm -f "$log" "$qmp" "$dbg" "$inlog" "$mon"
  local vars=(); if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.${stem}.fd"; vars=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.${stem}.fd"); fi
  set +e
  "$QEMU" -machine q35 -m 512M -smp 2 -cpu max -display none -serial file:"$log" -no-reboot -no-shutdown \
    -qmp "unix:$qmp,server=on,wait=off" -d guest_errors -D "$dbg" \
    -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${vars[@]}" \
    -device qemu-xhci,id=xhci -device usb-kbd,bus=xhci.0 -netdev user,id=framesnet,restrict=on -device e1000e,netdev=framesnet \
    -drive if=none,id=framesnvme,format=raw,readonly=on,file="$ROOT/build/Frames-${VER}-ESP.img" -device nvme,serial=FRAMES${VER},drive=framesnvme \
    -drive if=none,id=framesfs,format=raw,file="$img" -device nvme,serial=FRAMESFS0934,drive=framesfs &
  local pid=$!
  local inpid monpid watchdog watchdog_log="$ROOT/build/${stem}-watchdog.log"
  rm -f "$watchdog_log"
  (
    sleep "$TIMEOUT"
    if kill -0 "$pid" 2>/dev/null; then
      echo "FILESYSTEM_QEMU_WATCHDOG_TIMEOUT scenario=$scenario phase=$phase seconds=$TIMEOUT pid=$pid" > "$watchdog_log"
      kill -TERM "$pid" 2>/dev/null || true
      sleep 2
      kill -KILL "$pid" 2>/dev/null || true
    fi
  ) & watchdog=$!
  if [[ "$hard" == 1 ]]; then
    # Crash lanes terminate QEMU with SIGKILL and do not need a second QMP client.
    python3 "$ROOT/tools/qmp_input_inject.py" "$qmp" 180 >"$inlog" 2>&1 & inpid=$!
    python3 "$ROOT/tools/marker_kill.py" "$log" "$marker" "$pid" >"$mon" 2>&1 & monpid=$!
  else
    # Normal/recovery lanes need the hardened quit client. Release the single
    # QMP input connection as soon as the exact proof marker is durable.
    python3 "$ROOT/tools/qmp_input_inject.py" "$qmp" 180 "$log" "$marker" >"$inlog" 2>&1 & inpid=$!
    python3 "$ROOT/tools/qmp_marker_quit.py" "$qmp" "$log" "$marker" >"$mon" 2>&1 & monpid=$!
  fi
  wait "$pid"; local rc=$?
  kill "$watchdog" 2>/dev/null || true
  wait "$watchdog" 2>/dev/null || true
  wait "$inpid" 2>/dev/null || true
  wait "$monpid"; local mrc=$?; set -e
  if [[ -s "$watchdog_log" ]]; then
    cat "$watchdog_log" >&2
    return 124
  fi
  [[ "$mrc" -eq 0 ]] || { echo "monitor failed scenario=$scenario phase=$phase rc=$mrc" >&2; return 1; }
  if [[ "$hard" == 1 ]]; then [[ "$rc" -eq 137 ]] || { echo "expected hard-kill rc=137 got $rc" >&2; return 1; } else [[ "$rc" -eq 0 ]] || { echo "qemu rc=$rc" >&2; return 1; } fi
  echo "$rc"
}
# Normal mutation lane.
rc=$(run_vm 0 normal FRAMES_FS_MUTATION_OK 0); echo "$rc" > "$ROOT/build/FILESYSTEM-S0-EXIT-CODE.txt"
python3 "$ROOT/tools/verify_filesystem_test_image.py" --image "$ROOT/build/Frames-${VER}-Filesystem-s0.img" --scenario 0 --phase final --require-pass > "$ROOT/build/FILESYSTEM-S0-MEDIA.json"
# Four hard-crash / second-boot recovery lanes.
for s in 1 2 3 4; do
  rc=$(run_vm "$s" crash FRAMES_FS_CRASH_POINT_READY 1); echo "$rc" > "$ROOT/build/FILESYSTEM-S${s}-CRASH-EXIT-CODE.txt"
  rc=$(run_vm "$s" recovery FRAMES_FS_RECOVERY_OK 0); echo "$rc" > "$ROOT/build/FILESYSTEM-S${s}-RECOVERY-EXIT-CODE.txt"
  python3 "$ROOT/tools/verify_filesystem_test_image.py" --image "$ROOT/build/Frames-${VER}-Filesystem-s${s}.img" --scenario "$s" --phase final --require-pass > "$ROOT/build/FILESYSTEM-S${s}-MEDIA.json"
done
python3 "$ROOT/tools/filesystem_evidence.py" --build-dir "$ROOT/build" --require-pass
echo "FRAMES ${VER} FILESYSTEM WRITE + CRASH RECOVERY CERTIFICATION PASS"
