#!/usr/bin/env python3
import argparse,hashlib,json,sys
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--serial',required=True); p.add_argument('--qemu-exit',type=int,required=True); p.add_argument('--lane',required=True); p.add_argument('--media',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
raw=Path(a.serial).read_bytes(); text=raw.decode(errors='ignore'); media=json.loads(Path(a.media).read_text())
markers=[
'FRAMES_PHYSICAL_PREVIEW_POLICY_OK','FRAMES_PHYSICAL_PREVIEW_WRITE_LOCK_OK','FRAMES_PHYSICAL_PREVIEW_DESTRUCTIVE_LOCK_OK','FRAMES_PHYSICAL_PREVIEW_CPU_MEMORY_OK','FRAMES_PHYSICAL_PREVIEW_ACPI_APIC_OK','FRAMES_PHYSICAL_PREVIEW_PCI_STORAGE_OK','FRAMES_PHYSICAL_PREVIEW_USB_INPUT_OK','FRAMES_PHYSICAL_PREVIEW_DISPLAY_OK','FRAMES_PHYSICAL_PREVIEW_NETWORK_PASSIVE_OK','FRAMES_PHYSICAL_PREVIEW_CERT_OK','FRAMES_PHYSICAL_PREVIEW_READY',
'FRAMES_USB_BOOT_POLICY_OK','FRAMES_USB_BOOT_DEVICE_PATH_OK','FRAMES_USB_BOOT_MEDIA_OK','FRAMES_USB_BOOT_SYSTEM_READ_OK','FRAMES_USB_BOOT_CERT_OK','FRAMES_USB_BOOT_RESIDENT_OK','FRAMES_KERNEL_READY']
checks={m:text.count(m)==1 for m in markers}
checks['qemu_exit_zero']=a.qemu_exit==0; checks['media_pass']=media.get('status')=='PASS'
# No preview lane may enter any persistent/destructive writer even when the disk identity is otherwise valid.
forbidden=['FRAMES_NVME_WRITE_TARGET_FOUND','FRAMES_LIFECYCLE_REBOOT_ARMED','FRAMES_LIFECYCLE_REBOOT_EXECUTE','FRAMES_LIFECYCLE_SHUTDOWN_ARMED','FRAMES_LIFECYCLE_SHUTDOWN_EXECUTE','FRAMES_FS_WRITE_TARGET_FOUND','FRAMES_SYSTEM_VOLUME_CLONE_FOUND','FRAMES_FAT_LIFECYCLE_TARGET_FOUND']
checks['no_write_or_destructive_arm']=not any(x in text for x in forbidden)
fatals=['FRAMES_PHYSICAL_PREVIEW_CERT_FAIL','FRAMES_USB_BOOT_CERT_FAIL','FRAMES_SMP_SCALE_CERT_FAIL','FRAMES_FAT_LIFECYCLE_CERT_FAIL','FRAMES_SYSTEM_VOLUME_WRITE_CERT_FAIL','FRAMES_FS_WRITE_CERT_FAIL','FRAMES_LIFECYCLE_DESTRUCTIVE_FAIL','FRAMES_STORAGE_WRITE_INTEGRITY_FAIL','FRAMES_STRESS_ALLOCATOR_FAIL','FRAMES_STRESS_SCHEDULER_FAIL','FRAMES_STRESS_STORAGE_READ_FAIL','FRAMES_STRESS_USB_INPUT_FAIL','FRAMES_STRESS_NETWORK_FAIL','FRAMES_STRESS_DISPLAY_FAIL','FRAMES_STRESS_RECOVERY_FAIL','FRAMES_STRESS_POWER_FAIL','FRAMES_PAGE_FAULT','FRAMES_AP_PROTECTION_FAULT=','PANIC','ASSERT','TRIPLE']
checks['no_fatal']=not any(x in text for x in fatals)
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'physical-boot-safety-gate8','lane':a.lane,'serial_sha256':hashlib.sha256(raw).hexdigest(),'checks':checks,'markers':{m:text.count(m) for m in markers},'media':media,'forbidden_present':[x for x in forbidden if x in text]}
print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': sys.exit(1)
