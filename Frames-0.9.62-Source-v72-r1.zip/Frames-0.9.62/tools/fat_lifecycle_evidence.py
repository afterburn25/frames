#!/usr/bin/env python3
from pathlib import Path
import argparse,json,re,hashlib
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(); p.add_argument('--serial',required=True); p.add_argument('--media',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
log=Path(a.serial).read_text(errors='replace'); media=json.loads(Path(a.media).read_text())
markers=['FRAMES_FAT_LIFECYCLE_TARGET_FOUND','FRAMES_FAT_CREATE_OK','FRAMES_FAT_GROW_OK','FRAMES_FAT_TRUNCATE_OK','FRAMES_FAT_RENAME_OK','FRAMES_FAT_DELETE_OK','FRAMES_FAT_REALLOC_OK','FRAMES_FAT_MIRROR_OK','FRAMES_FAT_RESTORE_OK','FRAMES_FAT_LIFECYCLE_CERT_OK','FRAMES_KERNEL_READY']
checks={m:(m in log) for m in markers}
fatal_markers=[
 'FRAMES_FAT_LIFECYCLE_CERT_FAIL','FRAMES_STORAGE_WRITE_INTEGRITY_FAIL','FRAMES_FS_WRITE_CERT_FAIL',
 'FRAMES_SYSTEM_VOLUME_WRITE_CERT_FAIL','FRAMES_LIFECYCLE_DESTRUCTIVE_FAIL','FRAMES_PAGE_FAULT',
 'FRAMES_AP_PROTECTION_FAULT=','FRAMES_STRESS_ALLOCATOR_FAIL','FRAMES_STRESS_SCHEDULER_FAIL',
 'FRAMES_STRESS_STORAGE_READ_FAIL','FRAMES_STRESS_USB_INPUT_FAIL','FRAMES_STRESS_NETWORK_FAIL',
 'FRAMES_STRESS_DISPLAY_FAIL','FRAMES_STRESS_RECOVERY_FAIL','FRAMES_STRESS_POWER_FAIL','PANIC','ASSERT','TRIPLE'
]
fatal_present=[m for m in fatal_markers if m in log]
checks['no_fail']=not fatal_present; checks['media_pass']=media.get('status')=='PASS'
stages={}
for mm in re.finditer(r'FRAMES_FAT_LIFECYCLE_DIAG stage=0x([0-9A-Fa-f]+) detail=0x([0-9A-Fa-f]+)',log): stages[int(mm.group(1),16)]=int(mm.group(2),16)
checks['partition_lba']=stages.get(1)==2048
checks['pool_count']=stages.get(2)==4
checks['lifecycle_ops']=stages.get(3)==7
checks['write_count']=stages.get(4)==47
checks['flush_count']=stages.get(5)==33
checks['fat_mirror_updates']=stages.get(6)==14
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'disposable-fat32-allocation-file-lifecycle-gate5','serial_sha256':hashlib.sha256(Path(a.serial).read_bytes()).hexdigest(),'checks':checks,'diagnostics':{str(k):v for k,v in sorted(stages.items())},'media':media,'fatal_markers':fatal_present}
(ROOT/'build'/'FAT-LIFECYCLE-EVIDENCE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': raise SystemExit(1)
