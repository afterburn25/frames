#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VER="$(cat "$ROOT/VERSION")"
QEMU="${QEMU:-qemu-system-x86_64}"
OVMF_CODE="${OVMF_CODE:-}"
OVMF_VARS="${OVMF_VARS:-}"
TIMEOUT="${FRAMES_SYSTEM_VOLUME_TIMEOUT:-300}"
[[ -n "$OVMF_CODE" && -f "$OVMF_CODE" ]] || { echo 'Set OVMF_CODE' >&2; exit 2; }
command -v "$QEMU" >/dev/null || exit 2
mkdir -p "$ROOT/build"
"$ROOT/tools/build.sh"
python3 "$ROOT/tools/make_esp.py"
python3 "$ROOT/tools/make_system_volume_clone.py" > "$ROOT/build/SYSTEM-VOLUME-GENERATOR.log"
cp "$ROOT/build/Frames-${VER}-System-Clone.img" "$ROOT/build/Frames-${VER}-System-Clone.before.img"
python3 "$ROOT/tools/verify_system_volume_clone.py" \
  --before "$ROOT/build/Frames-${VER}-System-Clone.before.img" \
  --after "$ROOT/build/Frames-${VER}-System-Clone.img" \
  --manifest "$ROOT/build/SYSTEM-VOLUME-TARGET.json" --require-pass >/dev/null
python3 "$ROOT/tools/verify_release.py"
LOG="$ROOT/build/system-volume-serial.log"
QMP="$ROOT/build/system-volume-qmp.sock"
DBG="$ROOT/build/system-volume-qemu-debug.log"
INLOG="$ROOT/build/system-volume-input.log"
MON="$ROOT/build/system-volume-monitor.log"
rm -f "$LOG" "$QMP" "$DBG" "$INLOG" "$MON"
vars=()
if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then
  cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.system-volume.fd"
  vars=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.system-volume.fd")
fi
set +e
"$QEMU" -machine q35 -m 512M -smp 2 -cpu max -display none -serial file:"$LOG" -no-reboot -no-shutdown \
  -qmp "unix:$QMP,server=on,wait=off" -d guest_errors -D "$DBG" \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${vars[@]}" \
  -device qemu-xhci,id=xhci -device usb-kbd,bus=xhci.0 -netdev user,id=framesnet,restrict=on -device e1000e,netdev=framesnet \
  -drive if=none,id=framesnvme,format=raw,readonly=on,file="$ROOT/build/Frames-${VER}-ESP.img" -device nvme,serial=FRAMES${VER},drive=framesnvme \
  -drive if=none,id=framessys,format=raw,file="$ROOT/build/Frames-${VER}-System-Clone.img" -device nvme,serial=FRAMESSYS0935,drive=framessys &
pid=$!
python3 "$ROOT/tools/qmp_input_inject.py" "$QMP" 180 "$LOG" FRAMES_KERNEL_READY >"$INLOG" 2>&1 & inpid=$!
python3 "$ROOT/tools/qmp_marker_quit.py" "$QMP" "$LOG" FRAMES_KERNEL_READY >"$MON" 2>&1 & monpid=$!
wait "$pid"; rc=$?
wait "$inpid" 2>/dev/null || true
wait "$monpid"; mrc=$?
set -e
echo "$rc" > "$ROOT/build/SYSTEM-VOLUME-QEMU-EXIT-CODE.txt"
[[ "$mrc" -eq 0 ]] || { echo "marker monitor failed rc=$mrc" >&2; exit 1; }
[[ "$rc" -eq 0 ]] || { echo "qemu rc=$rc" >&2; exit 1; }
python3 "$ROOT/tools/verify_system_volume_clone.py" \
  --before "$ROOT/build/Frames-${VER}-System-Clone.before.img" \
  --after "$ROOT/build/Frames-${VER}-System-Clone.img" \
  --manifest "$ROOT/build/SYSTEM-VOLUME-TARGET.json" --require-pass > "$ROOT/build/SYSTEM-VOLUME-MEDIA-CONSOLE.json"
python3 "$ROOT/tools/system_volume_evidence.py" --serial "$LOG" --media "$ROOT/build/SYSTEM-VOLUME-MEDIA.json" --require-pass
if grep -q 'FRAMES_SYSTEM_VOLUME_WRITE_CERT_FAIL' "$LOG"; then echo 'fatal system-volume marker present' >&2; exit 1; fi
echo "FRAMES ${VER} DISPOSABLE SYSTEM-VOLUME FILESYSTEM WRITE CERTIFICATION PASS"
