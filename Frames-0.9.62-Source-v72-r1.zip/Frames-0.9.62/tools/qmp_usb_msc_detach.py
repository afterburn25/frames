#!/usr/bin/env python3
import socket,json,sys,time,os
sock_path,log_path,timeout=sys.argv[1],sys.argv[2],float(sys.argv[3]); deadline=time.time()+timeout
while not os.path.exists(sock_path) and time.time()<deadline: time.sleep(.02)
if not os.path.exists(sock_path): raise SystemExit('QMP socket absent')
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM); s.connect(sock_path); f=s.makefile('rwb',buffering=0)
def read_obj(limit=10):
 end=time.time()+limit
 while time.time()<end:
  line=f.readline()
  if line:
   try:return json.loads(line)
   except:continue
 raise RuntimeError('QMP read timeout')
def command(obj):
 f.write((json.dumps(obj)+'\r\n').encode())
 while True:
  o=read_obj(max(1,deadline-time.time()))
  if 'return' in o or 'error' in o:return o
read_obj(); command({'execute':'qmp_capabilities'})
seen='';
while time.time()<deadline:
 try: seen=open(log_path,errors='replace').read()
 except: seen=''
 if 'FRAMES_USB_MSC_RESIDENT_OK' in seen: raise SystemExit('resident marker appeared before detach')
 if 'FRAMES_USB_MSC_DETACH_WINDOW' in seen: break
 time.sleep(.02)
else: raise SystemExit('detach window timeout')
r=command({'execute':'device_del','arguments':{'id':'usbdata'}})
if 'error' in r: raise SystemExit('device_del rejected: '+str(r))
deleted=False
while time.time()<deadline:
 o=read_obj(max(1,deadline-time.time()))
 if o.get('event')=='DEVICE_DELETED':
  data=o.get('data',{}); dev=str(data.get('device',''))
  if dev=='usbdata' or 'usbdata' in str(data): deleted=True; print('QMP USBMSC DEVICE_DELETED event observed'); break
if not deleted: raise SystemExit('DEVICE_DELETED usbdata not observed')
while time.time()<deadline:
 try: seen=open(log_path,errors='replace').read()
 except: seen=''
 if 'FRAMES_USB_MSC_RESIDENT_OK' in seen: print('FRAMES_USB_MSC_RESIDENT_OK observed after USBMSC detach'); break
 time.sleep(.02)
else: raise SystemExit('resident marker after detach timeout')
r=command({'execute':'quit'}); print('QMP quit acknowledged after USBMSC detach survival proof')
