#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"; QEMU="${QEMU:-qemu-system-x86_64}"; OVMF_CODE="${OVMF_CODE:-}"; OVMF_VARS="${OVMF_VARS:-}"; LANE="${1:-normal}"
case "$LANE" in normal|detach) ;; *) echo invalid lane >&2; exit 2;; esac
[[ -n "$OVMF_CODE" && -f "$OVMF_CODE" ]] || { echo Set OVMF_CODE >&2; exit 2; }; mkdir -p "$ROOT/build"
"$ROOT/tools/build.sh" >/dev/null; python3 "$ROOT/tools/make_esp.py" >/dev/null; python3 "$ROOT/tools/make_physical_preview_image.py" >/dev/null; python3 "$ROOT/tools/make_usb_msc_cert_boot_image.py" >/dev/null; python3 "$ROOT/tools/make_usb_msc_data_image.py" >/dev/null
BOOT="$ROOT/build/Frames-${VER}-USB-MSC-${LANE}-Boot.img"; cp "$ROOT/build/Frames-${VER}-USB-MSC-Cert-Boot.img" "$BOOT"; cp "$BOOT" "$BOOT.before"
DATA="$ROOT/build/Frames-${VER}-USB-MSC-${LANE}-Data.img"; cp "$ROOT/build/Frames-${VER}-USB-MSC-Data.img" "$DATA"; cp "$DATA" "$DATA.before"
SUP="$ROOT/build/Frames-${VER}-USB-MSC-${LANE}-Support.img"; cp "$ROOT/build/Frames-${VER}-ESP.img" "$SUP"; cp "$SUP" "$SUP.before"
LOG="$ROOT/build/usb-msc-${LANE}-serial.log"; QMP="$ROOT/build/usb-msc-${LANE}-qmp.sock"; MON="$ROOT/build/usb-msc-${LANE}-monitor.log"; RCF="$ROOT/build/USB-MSC-${LANE^^}-QEMU-EXIT-CODE.txt"; MED="$ROOT/build/USB-MSC-${LANE^^}-MEDIA.json"; EV="$ROOT/build/USB-MSC-${LANE^^}-EVIDENCE.json"; rm -f "$LOG" "$QMP" "$MON" "$RCF" "$MED" "$EV"
VAR=(); if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.usbmsc-${LANE}.fd"; VAR=(-drive if=pflash,format=raw,file="$ROOT/build/OVMF_VARS.usbmsc-${LANE}.fd"); fi
TIMEOUT=360; set +e
timeout "$TIMEOUT" "$QEMU" -machine q35 -accel tcg,thread=multi -m 2048M -smp 4 -cpu max -display none -serial file:"$LOG" -no-reboot -no-shutdown -qmp "unix:$QMP,server=on,wait=off" -d guest_errors -D "$ROOT/build/usb-msc-${LANE}-qemu-debug.log" \
 -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${VAR[@]}" \
 -device ich9-usb-ehci1,id=bootehci -drive if=none,id=bootdrive,format=raw,readonly=on,file="$BOOT" -device usb-storage,bus=bootehci.0,drive=bootdrive,id=usbboot,bootindex=1 \
 -device qemu-xhci,id=nativexhci -drive if=none,id=mscdrive,format=raw,file="$DATA" -device usb-storage,bus=nativexhci.0,drive=mscdrive,id=usbdata \
 -drive if=none,id=supportdrive,format=raw,file="$SUP" -device nvme,serial=FRAMESSUPPORT0941,drive=supportdrive,bootindex=20 -nic none &
qpid=$!
if [[ "$LANE" == detach ]]; then python3 "$ROOT/tools/qmp_usb_msc_detach.py" "$QMP" "$LOG" "$TIMEOUT" >"$MON" 2>&1 & mpid=$!; else python3 "$ROOT/tools/qmp_marker_quit.py" "$QMP" "$LOG" FRAMES_KERNEL_READY "$TIMEOUT" >"$MON" 2>&1 & mpid=$!; fi
wait "$qpid"; rc=$?; wait "$mpid"; mrc=$?; set -e; echo "$rc" > "$RCF"
[[ "$rc" -eq 0 && "$mrc" -eq 0 ]] || { echo "USB MSC $LANE failed qemu=$rc monitor=$mrc" >&2; tail -260 "$LOG" >&2 || true; cat "$MON" >&2 || true; exit 1; }
python3 "$ROOT/tools/usb_msc_media_evidence.py" --boot-before "$BOOT.before" --boot-after "$BOOT" --data-before "$DATA.before" --data-after "$DATA" --support-before "$SUP.before" --support-after "$SUP" --require-pass > "$MED"
python3 "$ROOT/tools/usb_msc_evidence.py" --serial "$LOG" --lane "$LANE" --qemu-exit "$rc" --media "$MED" --monitor "$MON" --require-pass > "$EV"; cat "$EV"
