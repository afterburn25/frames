#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VER="$(cat "$ROOT/VERSION")"
QEMU="${QEMU:-qemu-system-x86_64}"
OVMF_CODE="${OVMF_CODE:-}"
OVMF_VARS="${OVMF_VARS:-}"
TIMEOUT="${FRAMES_BOOT_TIMEOUT:-35}"
LOG="$ROOT/build/serial.log"
mkdir -p "$ROOT/build"
if ! command -v "$QEMU" >/dev/null 2>&1; then echo "qemu-system-x86_64 not found" >&2; exit 2; fi
if [[ -z "$OVMF_CODE" || ! -f "$OVMF_CODE" ]]; then echo "Set OVMF_CODE=/path/to/OVMF_CODE.fd" >&2; exit 2; fi
VAR_DRIVE=()
if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then
  cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.runtime.fd"
  VAR_DRIVE=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.runtime.fd")
fi
"$ROOT/tools/build.sh"
python3 "$ROOT/tools/make_esp.py"
python3 "$ROOT/tools/make_write_test_nvme.py"
cp "$ROOT/build/Frames-${VER}-Write-Test.img" "$ROOT/build/Frames-${VER}-Write-Test.before.img"
python3 "$ROOT/tools/verify_release.py"
rm -f "$LOG"
QMP="$ROOT/build/qmp.sock"
QMP_INPUT_LOG="$ROOT/build/qmp-input.log"
QEMU_DEBUG_LOG="$ROOT/build/qemu-debug.log"
rm -f "$QMP" "$QMP_INPUT_LOG" "$QEMU_DEBUG_LOG"
set +e
timeout "$TIMEOUT" "$QEMU" -machine q35 -m 512M -smp 2 -cpu max -display none -serial file:"$LOG" -no-reboot -no-shutdown \
  -qmp "unix:$QMP,server=on,wait=off" -d guest_errors -D "$QEMU_DEBUG_LOG" \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" \
  "${VAR_DRIVE[@]}" \
  -device qemu-xhci,id=xhci -device usb-kbd,bus=xhci.0 \
  -netdev user,id=framesnet,restrict=on -device e1000e,netdev=framesnet \
  -drive if=none,id=framesnvme,format=raw,readonly=on,file="$ROOT/build/Frames-${VER}-ESP.img" \
  -device nvme,serial=FRAMES${VER},drive=framesnvme \
  -drive if=none,id=frameswrite,format=raw,file="$ROOT/build/Frames-${VER}-Write-Test.img" \
  -device nvme,serial=FRAMESWRITE0932,drive=frameswrite &
qemu_wrapper_pid=$!
python3 "$ROOT/tools/qmp_input_inject.py" "$QMP" >"$QMP_INPUT_LOG" 2>&1 &
input_pid=$!
wait "$qemu_wrapper_pid"
rc=$?
wait "$input_pid" 2>/dev/null || true
set -e
if [[ ! -f "$LOG" ]]; then echo "serial log not produced (qemu rc=$rc)" >&2; exit 1; fi
python3 "$ROOT/tools/verify_write_test_image.py" --before "$ROOT/build/Frames-${VER}-Write-Test.before.img" --after "$ROOT/build/Frames-${VER}-Write-Test.img" --require-pass
for marker in FRAMES_KERNEL_START FRAMES_PAGING_OK FRAMES_IDT_OK FRAMES_EXCEPTION_OK FRAMES_CPU_APIC_OK FRAMES_CPU_TSC_OK FRAMES_PCI_SURVEY_OK FRAMES_CONTROLLER_BAR_OK FRAMES_NVME_PROBE_OK FRAMES_NVME_ADMIN_READY FRAMES_NVME_IDENTIFY_OK FRAMES_NVME_IOQ_READY FRAMES_NVME_READ_OK FRAMES_XHCI_PROBE_OK FRAMES_AHCI_PROBE_OK FRAMES_ACPI_OK FRAMES_MADT_OK FRAMES_PLATFORM_TABLES_OK FRAMES_MMIO_MAP_OK FRAMES_DIAGNOSTIC_ONLY FRAMES_PHYSICAL_BOOT_BLOCKED FRAMES_SMP_TOPOLOGY_OK FRAMES_AP_TRAMPOLINE_READY FRAMES_AP_IMAGE_READY FRAMES_AP_START_SENT FRAMES_AP_ENTER FRAMES_AP_RUNTIME_OK FRAMES_AP_TIMER_OK FRAMES_AP_WORKER_ENTER FRAMES_AP_RUNQUEUE_OK FRAMES_RESCHED_IPI_SENT FRAMES_RESCHED_IPI_OK FRAMES_CPU_AFFINITY_OK FRAMES_SMP_SCHEDULER_OK FRAMES_PROCESS_TABLE_OK FRAMES_ADDRESS_SPACE_OK FRAMES_GDT_OK FRAMES_TSS_OK FRAMES_RING3_ENTER FRAMES_SYSCALL_ABI_OK FRAMES_PROCESS_PLATFORM_OK FRAMES_USERSPACE_PLATFORM_OK FRAMES_FILESYSTEM_PLATFORM_OK FRAMES_NETWORK_CORE_OK FRAMES_DISPLAY_CORE_OK FRAMES_AUDIO_CORE_OK FRAMES_DRIVER_PLATFORM_OK FRAMES_SECURITY_PLATFORM_OK FRAMES_RECOVERY_UPDATE_OK FRAMES_USER_SYSCALL_OK FRAMES_RING3_RETURN FRAMES_FEX_LOADED FRAMES_FEX_EXIT_OK FRAMES_AP_ONLINE_OK FRAMES_LAPIC_OK FRAMES_IOAPIC_OK FRAMES_ISO_OK FRAMES_LAPIC_TIMER_OK FRAMES_SCHEDULER_READY FRAMES_TIMER_ARMED FRAMES_WORKER0_ENTER FRAMES_WORKER1_ENTER FRAMES_WORKER_SLEEP FRAMES_WORKER_WAKE FRAMES_WORKER_RESUMED FRAMES_WORKER_EXIT FRAMES_WORKER_REAPED FRAMES_THREAD_LIFECYCLE_OK FRAMES_SCHEDULER_SUSTAINED FRAMES_KERNEL_READY; do
  grep -Fq "$marker" "$LOG" || { echo "missing marker: $marker (qemu rc=$rc)" >&2; cat "$LOG" >&2; exit 1; }
done
for fatal in FRAMES_USB_BOOT_CERT_FAIL FRAMES_SMP_SCALE_CERT_FAIL FRAMES_STRESS_ALLOCATOR_FAIL FRAMES_STRESS_SCHEDULER_FAIL FRAMES_STRESS_STORAGE_READ_FAIL FRAMES_STRESS_USB_INPUT_FAIL FRAMES_STRESS_NETWORK_FAIL FRAMES_STRESS_DISPLAY_FAIL FRAMES_STRESS_RECOVERY_FAIL FRAMES_STRESS_POWER_FAIL FRAMES_STORAGE_WRITE_INTEGRITY_FAIL FRAMES_FS_WRITE_CERT_FAIL FRAMES_SYSTEM_VOLUME_WRITE_CERT_FAIL FRAMES_FAT_LIFECYCLE_CERT_FAIL; do
  if grep -Fq "$fatal" "$LOG"; then echo "fatal stress marker: $fatal" >&2; exit 1; fi
done
for marker in FRAMES_NVME_WRITE_TARGET_FOUND FRAMES_NVME_WRITE_OK FRAMES_NVME_FLUSH_OK FRAMES_STORAGE_WRITE_GUARDS_OK FRAMES_STORAGE_WRITE_INTEGRITY_OK; do
  grep -Fq "$marker" "$LOG" || { echo "missing write-cert marker: $marker" >&2; exit 1; }
done
echo "FRAMES ${VER} RUNTIME + STORAGE WRITE CERTIFICATION PASS"
