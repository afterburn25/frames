#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"; QEMU="${QEMU:-qemu-system-x86_64}"; OVMF_CODE="${OVMF_CODE:-}"; OVMF_VARS="${OVMF_VARS:-}"
command -v "$QEMU" >/dev/null || { echo 'qemu-system-x86_64 unavailable' >&2; exit 2; }; [[ -f "$OVMF_CODE" ]] || { echo 'OVMF_CODE unavailable' >&2; exit 2; }
mkdir -p "$ROOT/build"; export NEXUS="${NEXUS:-$ROOT/toolchain/Nexus-Language-5.20.0/nexus}"
if [[ "${FRAMES_PREBUILT:-0}" != 1 ]]; then "$ROOT/tools/build.sh"; python3 "$ROOT/tools/make_esp.py"; python3 "$ROOT/tools/verify_release.py"; python3 "$ROOT/tools/sdk_selftest.py" --require-pass; fi; python3 "$ROOT/tools/make_developer_preview_image.py"; python3 "$ROOT/tools/verify_developer_preview_image.py" --image "$ROOT/build/Frames-${VER}-Developer-Preview.img" --package "$ROOT/build/HelloFrames.fapp" --require-pass
BOOT="$ROOT/build/Frames-${VER}-Developer-Preview.img"; BEFORE="$BOOT.before"; cp "$BOOT" "$BEFORE"
LOG="$ROOT/build/developer-preview-serial.log"; QMP="$ROOT/build/developer-preview-qmp.sock"; MON="$ROOT/build/developer-preview-qmp-input.log"; DBG="$ROOT/build/developer-preview-qemu-debug.log"; RCF="$ROOT/build/DEVELOPER-PREVIEW-QEMU-EXIT-CODE.txt"; EV="$ROOT/build/DEVELOPER-PREVIEW-EVIDENCE.json"; ALEV="$ROOT/build/APP-LOADER-EVIDENCE.json"; HEV="$ROOT/build/HELIXFS-PHASE2-EVIDENCE.json"; H3EV="$ROOT/build/HELIXFS-PHASE3-EVIDENCE.json"
rm -f "$LOG" "$QMP" "$MON" "$DBG" "$RCF" "$EV" "$ALEV" "$HEV" "$H3EV"
VAR_DRIVE=(); if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.developer-preview.fd"; VAR_DRIVE=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.developer-preview.fd"); fi
set +e
timeout 180 "$QEMU" -machine q35 -accel tcg,thread=multi -m 2048M -smp 4 -cpu max -display none -serial file:"$LOG" -no-reboot -no-shutdown -qmp "unix:$QMP,server=on,wait=off" -d guest_errors -D "$DBG" \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${VAR_DRIVE[@]}" \
  -drive if=none,id=devboot,format=raw,readonly=on,file="$BOOT" -device nvme,serial=FRAMESDEVPREV0951,drive=devboot,bootindex=1 \
  -device qemu-xhci,id=devxhci -device usb-kbd,bus=devxhci.0 \
  -netdev user,id=net0,restrict=on -device e1000e,netdev=net0 &
qpid=$!
python3 "$ROOT/tools/qmp_developer_preview_input.py" "$QMP" "$LOG" >"$MON" 2>&1 & ipid=$!
wait "$qpid"; qrc=$?; wait "$ipid"; irc=$?
set -e
printf '%s\n' "$qrc" > "$RCF"
[[ "$qrc" -eq 0 && "$irc" -eq 0 ]] || { echo "developer preview QEMU/input failure qemu=$qrc input=$irc" >&2; tail -240 "$LOG" >&2 || true; cat "$MON" >&2 || true; exit 1; }
python3 "$ROOT/tools/developer_preview_evidence.py" --serial "$LOG" --qemu-exit "$qrc" --media-before "$BEFORE" --media-after "$BOOT" --require-pass > "$EV"
python3 "$ROOT/tools/app_loader_evidence.py" --developer-evidence "$EV" --require-pass > "$ALEV"
python3 "$ROOT/tools/developer_preview_phase3_evidence.py" --developer-evidence "$EV" --serial "$LOG" --require-pass > "$ROOT/build/DEVELOPER-PREVIEW-PHASE3-EVIDENCE.json"
python3 "$ROOT/tools/helixfs_phase2_evidence.py" --developer-evidence "$EV" --serial "$LOG" --require-pass > "$HEV"
python3 "$ROOT/tools/helixfs_phase3_evidence.py" --developer-evidence "$EV" --serial "$LOG" --require-pass > "$H3EV"
cat "$EV"; cat "$ALEV"; cat "$ROOT/build/DEVELOPER-PREVIEW-PHASE3-EVIDENCE.json"; cat "$HEV"; cat "$H3EV"; echo "FRAMES ${VER} DEVELOPER PREVIEW + HELIXFS READ-ONLY PHASE 3 PASS"
