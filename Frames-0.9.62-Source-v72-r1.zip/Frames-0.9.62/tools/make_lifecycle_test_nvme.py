#!/usr/bin/env python3
from pathlib import Path
import argparse, struct, json, hashlib
r=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(); p.add_argument('--mode',choices=['reboot','shutdown','both'],default='both'); a=p.parse_args()
ver=(r/'VERSION').read_text().strip(); size=16*1024*1024; sectors=size//512

def make(mode):
    mid=1 if mode=='reboot' else 2
    serial='FRAMESREBOOT0933' if mid==1 else 'FRAMESSHUTDOWN0933'
    out=r/'build'/f'Frames-{ver}-Lifecycle-{mode}.img'; out.parent.mkdir(exist_ok=True)
    data=bytearray(size)
    hdr=b'FRAMES_LIFECYCLE_V1'; data[:len(hdr)]=hdr
    struct.pack_into('<QQQQ',data,32,mid,sectors,512,933)
    st=512; magic=b'FRAMES_LIFE_STATE_V1'; data[st:st+len(magic)]=magic
    struct.pack_into('<QQQQ',data,st+32,0,mid,0,0)
    out.write_bytes(data)
    manifest={'status':'READY','mode':mode,'mode_id':mid,'serial':serial,'bytes':size,'sectors':sectors,'sector_bytes':512,'header':'FRAMES_LIFECYCLE_V1','state_lba':1,'initial_state':0,'sha256':hashlib.sha256(data).hexdigest()}
    (r/'build'/f'LIFECYCLE-{mode.upper()}-TARGET.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    print(out)
if a.mode in ('reboot','both'): make('reboot')
if a.mode in ('shutdown','both'): make('shutdown')
