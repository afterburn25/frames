#!/usr/bin/env python3
import argparse, json, hashlib, re, sys
REQ=[
'FRAMES_HWCOMPAT_CPU_FINGERPRINT_OK','FRAMES_HWCOMPAT_ACPI_INVENTORY_OK','FRAMES_HWCOMPAT_PCI_INVENTORY_OK',
'FRAMES_HWCOMPAT_STORAGE_FLEX_OK','FRAMES_HWCOMPAT_USB_INVENTORY_OK','FRAMES_HWCOMPAT_INPUT_PATH_OK',
'FRAMES_HWCOMPAT_FRAMEBUFFER_OK','FRAMES_HWCOMPAT_NETWORK_OPTIONAL_OK','FRAMES_HWCOMPAT_REPORT_OK','FRAMES_KERNEL_READY']
FATAL=['FRAMES_HWCOMPAT_REPORT_FAIL','FRAMES_PHYSICAL_PREVIEW_CERT_FAIL','FRAMES_USB_BOOT_CERT_FAIL','PANIC','ASSERT','TRIPLE']
ap=argparse.ArgumentParser(); ap.add_argument('--serial',required=True); ap.add_argument('--profile',required=True); ap.add_argument('--qemu-exit',type=int,required=True); ap.add_argument('--require-pass',action='store_true'); a=ap.parse_args()
b=open(a.serial,'rb').read(); t=b.decode('utf-8','replace')
markers={m:t.count(m) for m in REQ}; fatal=[f for f in FATAL if f in t]
diag={}
for m in re.finditer(r'FRAMES_HWCOMPAT_DIAG stage=0x([0-9A-Fa-f]{16}) value=0x([0-9A-Fa-f]{16})',t): diag[int(m.group(1),16)]=int(m.group(2),16)
checks={'qemu_exit_zero':a.qemu_exit==0,'markers_exact_once':all(v==1 for v in markers.values()),'no_fatal':not fatal,'diag_1_9':all(i in diag for i in range(1,10))}
# Profile-specific expectations. Storage mask: NVMe=1 AHCI=2 IDE=4 RAID=8. USB mask: UHCI=1 OHCI=2 EHCI=4 xHCI=8 other=16.
sm=diag.get(4,0); um=diag.get(5,0); net=diag.get(6,-1)
if a.profile=='baseline': checks['nvme']=bool(sm&1); checks['xhci']=bool(um&8); checks['network']=net>0
elif a.profile=='qemu64': checks['nvme']=bool(sm&1); checks['xhci']=bool(um&8)
elif a.profile=='ahci': checks['ahci']=bool(sm&2)
elif a.profile=='no-network': checks['network_optional']=net==0
elif a.profile=='ehci-ps2': checks['ehci']=bool(um&4); checks['no_xhci']=not bool(um&8)
elif a.profile=='virtio-vga': checks['framebuffer']=diag.get(7,0)>=640 and diag.get(8,0)>=480
elif a.profile=='mixed-storage': checks['nvme_ahci']=bool(sm&1) and bool(sm&2)
else: checks['known_profile']=False
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':a.profile,'serial_sha256':hashlib.sha256(b).hexdigest(),'markers':markers,'diagnostics':{str(k):v for k,v in sorted(diag.items())},'fatal':fatal,'checks':checks}
print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': sys.exit(1)
