#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, struct
R=Path(__file__).resolve().parents[1]; V=(R/'VERSION').read_text().strip(); O=R/'build'/f'Frames-{V}-Physical-SATA-Guard.img'
size=16*1024*1024; b=bytearray(size)
b[:32]=b'FRAMES_PHYSICAL_SATA_GUARD_V1\n'[:32]
for i in range(4096,size,4096):
    struct.pack_into('<Q',b,i,(i//4096)^0x0939093909390939)
O.parent.mkdir(exist_ok=True); O.write_bytes(b)
print(json.dumps({'path':str(O),'bytes':size,'sha256':hashlib.sha256(b).hexdigest(),'writable_by_qemu':True,'expected_guest_writes':0},indent=2))
