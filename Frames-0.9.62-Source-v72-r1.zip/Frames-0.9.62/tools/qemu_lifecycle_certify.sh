#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"; QEMU="${QEMU:-qemu-system-x86_64}"; OVMF_CODE="${OVMF_CODE:-}"; OVMF_VARS="${OVMF_VARS:-}"; TIMEOUT="${FRAMES_LIFECYCLE_TIMEOUT:-300}"
[[ -n "$OVMF_CODE" && -f "$OVMF_CODE" ]] || { echo 'Set OVMF_CODE' >&2; exit 2; }
command -v "$QEMU" >/dev/null || exit 2
mkdir -p "$ROOT/build"; "$ROOT/tools/build.sh"; python3 "$ROOT/tools/make_esp.py"; python3 "$ROOT/tools/make_lifecycle_test_nvme.py" --mode both; python3 "$ROOT/tools/verify_release.py"
run_reboot(){
  local log="$ROOT/build/reboot-serial.log" qmp="$ROOT/build/reboot-qmp.sock" qdbg="$ROOT/build/reboot-qemu-debug.log" qin="$ROOT/build/reboot-qmp-input.log" img="$ROOT/build/Frames-${VER}-Lifecycle-reboot.img"; rm -f "$log" "$qmp" "$qdbg" "$qin"
  local vars=(); if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.reboot.fd"; vars=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.reboot.fd"); fi
  set +e
  timeout "$TIMEOUT" "$QEMU" -machine q35 -m 512M -smp 2 -cpu max -display none -serial file:"$log" \
    -qmp "unix:$qmp,server=on,wait=off" -d guest_errors -D "$qdbg" \
    -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${vars[@]}" \
    -device qemu-xhci,id=xhci -device usb-kbd,bus=xhci.0 -netdev user,id=framesnet,restrict=on -device e1000e,netdev=framesnet \
    -drive if=none,id=framesnvme,format=raw,readonly=on,file="$ROOT/build/Frames-${VER}-ESP.img" -device nvme,serial=FRAMES${VER},drive=framesnvme \
    -drive if=none,id=frameslife,format=raw,file="$img" -device nvme,serial=FRAMESREBOOT0933,drive=frameslife &
  local pid=$!; python3 "$ROOT/tools/qmp_input_inject.py" "$qmp" 600 "$log" FRAMES_LIFECYCLE_REBOOT_RETURNED >"$qin" 2>&1 & local inpid=$!; python3 "$ROOT/tools/qmp_marker_quit.py" "$qmp" "$log" FRAMES_LIFECYCLE_REBOOT_RETURNED >"$ROOT/build/reboot-monitor.log" 2>&1 & local monpid=$!
  wait "$pid"; local rc=$?; wait "$inpid" 2>/dev/null || true; wait "$monpid"; local mrc=$?; set -e
  [[ "$mrc" -eq 0 ]] || { echo "reboot monitor failed $mrc" >&2; return 1; }; echo "$rc" > "$ROOT/build/REBOOT-QEMU-EXIT-CODE.txt"; [[ "$rc" -eq 0 ]] || { echo "reboot qemu rc $rc" >&2; return 1; }
  python3 "$ROOT/tools/verify_lifecycle_image.py" --image "$img" --mode reboot --require-pass > "$ROOT/build/REBOOT-MEDIA-VERIFY.json"
}
run_shutdown(){
  local log="$ROOT/build/shutdown-serial.log" qmp="$ROOT/build/shutdown-qmp.sock" qdbg="$ROOT/build/shutdown-qemu-debug.log" qin="$ROOT/build/shutdown-qmp-input.log" img="$ROOT/build/Frames-${VER}-Lifecycle-shutdown.img"; rm -f "$log" "$qmp" "$qdbg" "$qin"
  local vars=(); if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.shutdown.fd"; vars=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.shutdown.fd"); fi
  set +e
  timeout "$TIMEOUT" "$QEMU" -machine q35 -m 512M -smp 2 -cpu max -display none -serial file:"$log" \
    -qmp "unix:$qmp,server=on,wait=off" -d guest_errors -D "$qdbg" \
    -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${vars[@]}" \
    -device qemu-xhci,id=xhci -device usb-kbd,bus=xhci.0 -netdev user,id=framesnet,restrict=on -device e1000e,netdev=framesnet \
    -drive if=none,id=framesnvme,format=raw,readonly=on,file="$ROOT/build/Frames-${VER}-ESP.img" -device nvme,serial=FRAMES${VER},drive=framesnvme \
    -drive if=none,id=frameslife,format=raw,file="$img" -device nvme,serial=FRAMESSHUTDOWN0933,drive=frameslife &
  local pid=$!; python3 "$ROOT/tools/qmp_input_inject.py" "$qmp" 300 >"$qin" 2>&1 & local inpid=$!; wait "$pid"; local rc=$?; wait "$inpid" 2>/dev/null || true; set -e
  echo "$rc" > "$ROOT/build/SHUTDOWN-QEMU-EXIT-CODE.txt"; [[ "$rc" -eq 0 ]] || { echo "shutdown qemu rc $rc" >&2; return 1; }
  python3 "$ROOT/tools/verify_lifecycle_image.py" --image "$img" --mode shutdown --require-pass > "$ROOT/build/SHUTDOWN-MEDIA-VERIFY.json"
}
run_reboot; run_shutdown
python3 "$ROOT/tools/lifecycle_evidence.py" --reboot-log "$ROOT/build/reboot-serial.log" --shutdown-log "$ROOT/build/shutdown-serial.log" --reboot-exit "$ROOT/build/REBOOT-QEMU-EXIT-CODE.txt" --shutdown-exit "$ROOT/build/SHUTDOWN-QEMU-EXIT-CODE.txt" --require-pass
echo "FRAMES ${VER} DESTRUCTIVE REBOOT + SHUTDOWN CERTIFICATION PASS"
