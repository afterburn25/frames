#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"; QEMU="${QEMU:-qemu-system-x86_64}"; OVMF_CODE="${OVMF_CODE:-}"; OVMF_VARS="${OVMF_VARS:-}"; P="${1:-baseline}"
case "$P" in baseline|qemu64|ahci|no-network|ehci-ps2|virtio-vga|mixed-storage) ;; *) echo bad profile >&2; exit 2;; esac
[[ -n "$OVMF_CODE" && -f "$OVMF_CODE" ]] || { echo Set OVMF_CODE >&2; exit 2; }; mkdir -p "$ROOT/build"
[[ -f "$ROOT/build/Frames-${VER}-ESP.img" ]] || { "$ROOT/tools/build.sh"; python3 "$ROOT/tools/make_esp.py"; }
python3 "$ROOT/tools/make_physical_preview_image.py" >/dev/null; python3 "$ROOT/tools/make_physical_sata_guard.py" >/dev/null
USB="$ROOT/build/Frames-${VER}-HWCompat-${P}-USB.img"; cp "$ROOT/build/Frames-${VER}-Physical-Hardware-Preview.img" "$USB"
INT="$ROOT/build/Frames-${VER}-HWCompat-${P}-Internal.img"; cp "$ROOT/build/Frames-${VER}-ESP.img" "$INT"
SATA="$ROOT/build/Frames-${VER}-HWCompat-${P}-SATA.img"; cp "$ROOT/build/Frames-${VER}-Physical-SATA-Guard.img" "$SATA"
LOG="$ROOT/build/hwcompat-${P}-serial.log"; QMP="$ROOT/build/hwcompat-${P}-qmp.sock"; MON="$ROOT/build/hwcompat-${P}-monitor.log"; RCF="$ROOT/build/HWCOMPAT-${P^^}-QEMU-EXIT-CODE.txt"; EV="$ROOT/build/HWCOMPAT-${P^^}-EVIDENCE.json"; rm -f "$LOG" "$QMP" "$MON" "$RCF" "$EV"
CPU=max; [[ "$P" == qemu64 ]] && CPU=qemu64
USBDEV=(-device qemu-xhci,id=bootxhci -drive if=none,id=usbdrive,format=raw,readonly=on,file="$USB" -device usb-storage,bus=bootxhci.0,drive=usbdrive,id=usbboot,bootindex=1)
if [[ "$P" == ehci-ps2 ]]; then USBDEV=(-device ich9-usb-ehci1,id=bootehci -drive if=none,id=usbdrive,format=raw,readonly=on,file="$USB" -device usb-storage,bus=bootehci.0,drive=usbdrive,id=usbboot,bootindex=1); fi
STORAGE=(-drive if=none,id=nvme0,format=raw,file="$INT" -device nvme,serial=FRAMESCOMPAT0940,drive=nvme0)
if [[ "$P" == ahci ]]; then STORAGE=(-drive if=none,id=sata0,format=raw,file="$INT" -device ide-hd,bus=ide.0,drive=sata0); fi
if [[ "$P" == mixed-storage ]]; then STORAGE=(-drive if=none,id=nvme0,format=raw,file="$INT" -device nvme,serial=FRAMESCOMPAT0940,drive=nvme0 -drive if=none,id=sata0,format=raw,file="$SATA" -device ide-hd,bus=ide.0,drive=sata0); fi
NET=(-netdev user,id=net0,restrict=on -device e1000e,netdev=net0); [[ "$P" == no-network ]] && NET=(-nic none)
VIDEO=(); [[ "$P" == virtio-vga ]] && VIDEO=(-vga none -device virtio-vga)
VAR=(); if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.hwcompat-${P}.fd"; VAR=(-drive if=pflash,format=raw,file="$ROOT/build/OVMF_VARS.hwcompat-${P}.fd"); fi
set +e
timeout 360 "$QEMU" -machine q35 -accel tcg,thread=multi -m 2048M -smp 4 -cpu "$CPU" -display none -serial file:"$LOG" -no-reboot -no-shutdown -qmp "unix:$QMP,server=on,wait=off" -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${VAR[@]}" "${VIDEO[@]}" "${USBDEV[@]}" "${STORAGE[@]}" "${NET[@]}" &
qpid=$!; python3 "$ROOT/tools/qmp_marker_quit.py" "$QMP" "$LOG" FRAMES_KERNEL_READY 360 >"$MON" 2>&1 & mpid=$!; wait "$qpid"; rc=$?; wait "$mpid"; mrc=$?; set -e; echo "$rc" > "$RCF"
[[ "$rc" -eq 0 && "$mrc" -eq 0 ]] || { tail -200 "$LOG" >&2 || true; cat "$MON" >&2 || true; exit 1; }
python3 "$ROOT/tools/hardware_compat_evidence.py" --serial "$LOG" --profile "$P" --qemu-exit "$rc" --require-pass > "$EV"; cat "$EV"
