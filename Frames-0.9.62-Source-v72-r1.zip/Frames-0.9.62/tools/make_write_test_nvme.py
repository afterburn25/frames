#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, struct

ROOT=Path(__file__).resolve().parents[1]
VER=(ROOT/'VERSION').read_text().strip()
SECTOR=512
TOTAL_SECTORS=32768
TEST_START=4096
TEST_COUNT=16
OUT=ROOT/f'build/Frames-{VER}-Write-Test.img'
MANIFEST=ROOT/'build/WRITE-TARGET-MANIFEST.json'

img=bytearray(TOTAL_SECTORS*SECTOR)
header=b'FRAMES_WRITE_CERT_V1'
img[:len(header)]=header
struct.pack_into('<QQQQ',img,32,TEST_START,TEST_COUNT,TOTAL_SECTORS,SECTOR)
label=b'SACRIFICIAL-NVME-ONLY'
img[64:64+len(label)]=label

def fill_guard(lba, seed):
    off=lba*SECTOR
    for i in range(SECTOR):
        img[off+i]=(seed + i*29 + (lba%251)*7) & 0xff

fill_guard(TEST_START-1,0x31)
fill_guard(TEST_START+TEST_COUNT,0x72)
fill_guard(TOTAL_SECTORS-1,0xA4)

# Certification region is intentionally all zero on pristine media.
OUT.parent.mkdir(exist_ok=True)
OUT.write_bytes(img)
sha=hashlib.sha256(img).hexdigest()
doc={
  'frames_version':VER,
  'profile':'sacrificial-nvme-write-target-v1',
  'path':str(OUT),
  'size_bytes':len(img),
  'sector_size':SECTOR,
  'total_sectors':TOTAL_SECTORS,
  'controller_serial':'FRAMESWRITE0932',
  'header':'FRAMES_WRITE_CERT_V1',
  'test_start_lba':TEST_START,
  'test_block_count':TEST_COUNT,
  'guard_lbas':[TEST_START-1,TEST_START+TEST_COUNT,TOTAL_SECTORS-1],
  'initial_sha256':sha,
  'boot_or_system_volume':False,
  'sacrificial_only':True,
}
MANIFEST.write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps(doc,indent=2))
