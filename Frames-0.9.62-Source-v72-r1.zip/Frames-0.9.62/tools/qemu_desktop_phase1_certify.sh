#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"; QEMU="${QEMU:-qemu-system-x86_64}"; OVMF_CODE="${OVMF_CODE:-}"; OVMF_VARS="${OVMF_VARS:-}"
command -v "$QEMU" >/dev/null || { echo 'qemu-system-x86_64 unavailable' >&2; exit 2; }; [[ -f "$OVMF_CODE" ]] || { echo 'OVMF_CODE unavailable' >&2; exit 2; }
mkdir -p "$ROOT/build"; export NEXUS="${NEXUS:-$ROOT/toolchain/Nexus-Language-5.20.0/nexus}"
if [[ "${FRAMES_PREBUILT:-0}" != 1 ]]; then "$ROOT/tools/build.sh"; python3 "$ROOT/tools/make_esp.py"; python3 "$ROOT/tools/verify_release.py"; python3 "$ROOT/tools/sdk_selftest.py" --require-pass; fi; python3 "$ROOT/tools/make_desktop_preview_image.py"
BOOT="$ROOT/build/Frames-${VER}-Desktop-Preview.img"; BEFORE="$BOOT.before"; cp "$BOOT" "$BEFORE"
LOG="$ROOT/build/desktop-phase1-serial.log"; QMP="$ROOT/build/desktop-phase1-qmp.sock"; CAP="$ROOT/build/desktop-phase1.ppm"; CAPLOG="$ROOT/build/desktop-phase1-capture.log"; DBG="$ROOT/build/desktop-phase1-qemu-debug.log"; RCF="$ROOT/build/DESKTOP-PHASE1-QEMU-EXIT-CODE.txt"; EV="$ROOT/build/DESKTOP-PHASE1-EVIDENCE.json"
rm -f "$LOG" "$QMP" "$CAP" "$CAPLOG" "$DBG" "$RCF" "$EV"
VAR_DRIVE=(); if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.desktop.fd"; VAR_DRIVE=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.desktop.fd"); fi
set +e
timeout 180 "$QEMU" -machine q35 -accel tcg,thread=multi -m 2048M -smp 4 -cpu max -display none -vga std -serial file:"$LOG" -no-reboot -no-shutdown -qmp "unix:$QMP,server=on,wait=off" -d guest_errors -D "$DBG" \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${VAR_DRIVE[@]}" \
  -drive if=none,id=desktopboot,format=raw,readonly=on,file="$BOOT" -device nvme,serial=FRAMESDESKTOP0951,drive=desktopboot,bootindex=1 &
qpid=$!
python3 "$ROOT/tools/qmp_desktop_capture.py" "$QMP" "$LOG" "$CAP" >"$CAPLOG" 2>&1 & cpid=$!
wait "$qpid"; qrc=$?; wait "$cpid"; crc=$?
set -e
printf '%s\n' "$qrc" > "$RCF"
[[ "$qrc" -eq 0 && "$crc" -eq 0 ]] || { echo "desktop QEMU/capture failure qemu=$qrc capture=$crc" >&2; tail -240 "$LOG" >&2 || true; cat "$CAPLOG" >&2 || true; exit 1; }
python3 "$ROOT/tools/desktop_phase1_evidence.py" --serial "$LOG" --ppm "$CAP" --qemu-exit "$qrc" --media-before "$BEFORE" --media-after "$BOOT" --require-pass > "$EV"
cat "$EV"; echo "FRAMES ${VER} NATIVE DESKTOP SURFACE PHASE 1 PASS"
