#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,subprocess
ap=argparse.ArgumentParser(); ap.add_argument('--require-pass',action='store_true'); a=ap.parse_args()
r=Path(__file__).resolve().parents[1]; build=r/'build'; build.mkdir(exist_ok=True)
cli=r/'sdk/frames-sdk.sh'; sample=r/'sdk/examples/hello/main.nx'
fex=build/'HelloFrames-SDK.fex'; app=build/'HelloFrames.fapp'; app2=build/'HelloFrames-repeat.fapp'
checks={}
def run(cmd): return subprocess.run(cmd,cwd=r,text=True,capture_output=True)
d=run([str(cli),'doctor']); checks['doctor']=d.returncode==0
b=run([str(cli),'build',str(sample),str(fex)]); checks['build']=b.returncode==0 and fex.exists()
p1=run([str(cli),'package',str(fex),'HelloFrames',str(app),'windowed'])
p2=run([str(cli),'package',str(fex),'HelloFrames',str(app2),'windowed'])
checks['package']=p1.returncode==0 and p2.returncode==0 and app.exists() and app2.exists()
v=run([str(cli),'verify',str(app)]); checks['verify']=v.returncode==0
raw=fex.read_bytes() if fex.exists() else b''
checks['fex_magic']=raw[:8]==b'FEX64\x00\x00\x00'
checks['fex_nonzero']=len(raw)>128
checks['sample_source']=sample.read_text().strip().endswith('}')
manifest=json.loads((r/'sdk/SDK-MANIFEST.json').read_text())
checks['manifest']=manifest.get('fex_abi')==1 and manifest.get('app_bundle_format')=='FAPP1'
checks['package_deterministic']=app.exists() and app2.exists() and app.read_bytes()==app2.read_bytes()
package_info=json.loads(v.stdout) if v.returncode==0 else {}
checks['package_manifest']=package_info.get('manifest',{}).get('app_name')=='HelloFrames' and package_info.get('manifest',{}).get('ui_mode')=='windowed' and package_info.get('manifest',{}).get('window_role')=='application'
status='PASS' if all(checks.values()) else 'FAIL'
ev={'status':status,'profile':'frames-sdk-developer-tooling-phase2','checks':checks,
    'sdk_manifest':manifest,
    'sample_source_sha256':hashlib.sha256(sample.read_bytes()).hexdigest(),
    'sample_fex_sha256':hashlib.sha256(raw).hexdigest() if raw else None,
    'sample_fex_size':len(raw),
    'sample_fapp_sha256':hashlib.sha256(app.read_bytes()).hexdigest() if app.exists() else None,
    'sample_fapp_size':app.stat().st_size if app.exists() else 0,
    'package_info':package_info,
    'doctor_stdout':d.stdout.strip(),'build_stdout':b.stdout.strip()}
(build/'SDK-TOOLING-EVIDENCE.json').write_text(json.dumps(ev,indent=2)+'\n')
print(json.dumps(ev,indent=2))
if a.require_pass and status!='PASS': raise SystemExit(1)
