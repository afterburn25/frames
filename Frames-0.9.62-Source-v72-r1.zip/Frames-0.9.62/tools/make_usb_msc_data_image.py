#!/usr/bin/env python3
from pathlib import Path
import hashlib,struct,json
ROOT=Path(__file__).resolve().parents[1]; VER=(ROOT/'VERSION').read_text().strip(); B=ROOT/'build'; B.mkdir(exist_ok=True)
size=16*1024*1024; d=bytearray(size); challenge=bytearray(1024); magic=b'FRAMES_USB_MASS_STORAGE_V1\n'; challenge[:len(magic)]=magic
for i in range(len(magic),1024): challenge[i]=((i*37)+11)&255
lba=128; d[lba*512:lba*512+1024]=challenge
out=B/f'Frames-{VER}-USB-MSC-Data.img'; out.write_bytes(d)
s=2166136261
for i,b in enumerate(challenge): s=(s+b+((i+1)*257))%4294967296
manifest={'version':VER,'bytes':size,'block_size':512,'last_lba':(size//512)-1,'challenge_lba':128,'challenge_blocks':2,'challenge_checksum':s,'challenge_sha256':hashlib.sha256(challenge).hexdigest(),'image_sha256':hashlib.sha256(d).hexdigest(),'write_commands_implemented':False}
(B/'USB-MSC-DATA-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n'); print(json.dumps(manifest,indent=2))
