#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for p in baseline qemu64 ahci no-network ehci-ps2 virtio-vga mixed-storage; do "$ROOT/tools/qemu_hardware_compat_certify.sh" "$p"; done
python3 "$ROOT/tools/hardware_compat_matrix_evidence.py" --build "$ROOT/build" --require-pass > "$ROOT/build/HWCOMPAT-MATRIX-EVIDENCE.json"
echo 0 > "$ROOT/build/HWCOMPAT-CERTIFY-EXIT-CODE.txt"; cat "$ROOT/build/HWCOMPAT-MATRIX-EVIDENCE.json"
