#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,re
p=argparse.ArgumentParser(); p.add_argument('--serial',required=True); p.add_argument('--ppm',required=True); p.add_argument('--qemu-exit',type=int,required=True); p.add_argument('--media-before',required=True); p.add_argument('--media-after',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
serial=Path(a.serial).read_text(errors='replace'); raw=Path(a.ppm).read_bytes()
# P6 parser with comments.
pos=0
def token():
    global pos
    while pos<len(raw):
        if raw[pos] in b' \t\r\n': pos+=1; continue
        if raw[pos]==35:
            while pos<len(raw) and raw[pos]!=10: pos+=1
            continue
        break
    st=pos
    while pos<len(raw) and raw[pos] not in b' \t\r\n': pos+=1
    return raw[st:pos]
magic=token(); w=int(token()); h=int(token()); maxv=int(token());
while pos<len(raw) and raw[pos] in b' \t\r\n': pos+=1
pixels=raw[pos:]
expected_len=w*h*3
markers=['FRAMES_DESKTOP_POLICY_OK','FRAMES_DESKTOP_WRITE_LOCK_OK','FRAMES_DESKTOP_BACKGROUND_OK','FRAMES_DESKTOP_PANEL_OK','FRAMES_DESKTOP_CURSOR_OK','FRAMES_DESKTOP_PRESENT_OK','FRAMES_DESKTOP_SURFACE_OK','FRAMES_DESKTOP_PHASE1_OK','FRAMES_KERNEL_READY']
counts={m:serial.count(m) for m in markers}
diag={}
for s,v in re.findall(r'FRAMES_DESKTOP_DIAG stage=0x([0-9A-Fa-f]+) value=0x([0-9A-Fa-f]+)',serial): diag[int(s,16)]=int(v,16)
# Colors are written as 0xFFRRGGBB into the QEMU GOP surface. Support a globally swapped R/B interpretation for firmware variants.
colors={'bg_top':0xFF142033,'bg_bottom':0xFF182940,'panel':0xFF0B111B,'card':0xFF202D44,'accent':0xFF4D7CFE,'white':0xFFF4F7FB}
def rgb(c): return ((c>>16)&255,(c>>8)&255,c&255)
def bgr(c): return (c&255,(c>>8)&255,(c>>16)&255)
def pix(x,y):
    if x<0 or y<0 or x>=w or y>=h:return None
    i=(y*w+x)*3; return tuple(pixels[i:i+3])
panel_y=diag.get(4,h-56); half=panel_y//2; cx=(diag.get(5,0)//65536); cy=(diag.get(5,0)%65536)
card_x=(w-280)//2; card_y=(panel_y-140)//2
samples={'bg_top':pix(20,20),'bg_bottom':pix(20,half+8),'panel':pix(100,panel_y+20),'accent':pix(14,panel_y+10),'card':pix(card_x+20,card_y+20),'white':pix(cx+1,cy+1)}
direct=all(samples[k]==rgb(colors[k]) for k in samples); swapped=all(samples[k]==bgr(colors[k]) for k in samples)
checks={
'qemu_exit_zero':a.qemu_exit==0,
'ppm_magic':magic==b'P6','ppm_geometry':w>=640 and h>=480 and maxv==255,'ppm_payload_exact':len(pixels)==expected_len,
'markers_exact_once':all(v==1 for v in counts.values()),'no_desktop_fail':'FRAMES_DESKTOP_CERT_FAIL' not in serial,'no_fatal':all(x not in serial for x in ['FRAMES_FATAL','PANIC','ASSERT_FAIL']),
'no_destructive_storage':all(x not in serial for x in ['FRAMES_NVME_WRITE_OK','SCSI WRITE(10)','FRAMES_STORAGE_WRITE_INTEGRITY_OK']),
'diag_width_matches':diag.get(1)==w,'diag_height_matches':diag.get(2)==h,'diag_stride_valid':diag.get(3,0)>=w,'diag_panel_y':panel_y==h-56,
'diag_present_nonzero':diag.get(6,0)>0,'diag_frame_sequence_nonzero':diag.get(7,0)>0,
'visual_samples_match':direct or swapped,
'media_unchanged':hashlib.sha256(Path(a.media_before).read_bytes()).digest()==hashlib.sha256(Path(a.media_after).read_bytes()).digest(),
}
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'native-graphics-desktop-surface-phase1','serial_sha256':hashlib.sha256(Path(a.serial).read_bytes()).hexdigest(),'ppm_sha256':hashlib.sha256(raw).hexdigest(),'width':w,'height':h,'pixel_order':'RGB' if direct else ('BGR' if swapped else 'UNKNOWN'),'samples':samples,'diagnostics':diag,'markers':counts,'checks':checks,'physical_boot_approved':False,'physical_media_writes_unlocked':False}
print(json.dumps(out,indent=2))
if a.require_pass and status!='PASS': raise SystemExit(1)
