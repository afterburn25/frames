#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--serial',required=True);p.add_argument('--require-pass',action='store_true');a=p.parse_args()
raw=Path(a.serial).read_bytes();text=raw.decode(errors='replace')
markers=['FRAMES_HELIXFS_BLOCK_IMAGE_OK','FRAMES_HELIXFS_SUPERBLOCK_OK','FRAMES_HELIXFS_INODE_OK','FRAMES_HELIXFS_DIRECTORY_OK','FRAMES_HELIXFS_BLOCK_READ_OK','FRAMES_HELIXFS_READ_OK','FRAMES_HELIXFS_READONLY_OK','FRAMES_HELIXFS_MOUNT_OK','FRAMES_HELIXFS_PHASE1_OK','FRAMES_HELIXFS_PATH_RESOLVE_OK','FRAMES_HELIXFS_PATH_READ_OK','FRAMES_HELIXFS_PHASE2_OK','FRAMES_HELIXFS_TRAVERSAL_OK','FRAMES_HELIXFS_MULTIBLOCK_OK','FRAMES_HELIXFS_PHASE3_OK','FRAMES_FILESYSTEM_PLATFORM_OK','FRAMES_KERNEL_READY']
checks={'markers_exact_once':all(text.count(m)==1 for m in markers),'ordered':all(text.find(markers[i])<text.find(markers[i+1]) for i in range(len(markers)-1)),'no_fatal':all(x not in text for x in ['FRAMES_FATAL','PANIC','ASSERT_FAIL']),'no_storage_write':all(x not in text for x in ['SCSI WRITE(10)','FRAMES_STORAGE_WRITE_INTEGRITY_OK','FRAMES_STORAGE_WRITE_INTEGRITY_FAIL']),'physical_boot_blocked':'FRAMES_PHYSICAL_BOOT_BLOCKED' in text}
status='PASS' if all(checks.values()) else 'FAIL'
print(json.dumps({'status':status,'profile':'helixfs-readonly-phase3-kernel-smoke','serial_sha256':hashlib.sha256(raw).hexdigest(),'checks':checks,'markers':{m:text.count(m) for m in markers}},indent=2))
if a.require_pass and status!='PASS':raise SystemExit(1)
