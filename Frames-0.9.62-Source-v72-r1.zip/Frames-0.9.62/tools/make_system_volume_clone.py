#!/usr/bin/env python3
from pathlib import Path
import struct, json, hashlib
ROOT=Path(__file__).resolve().parents[1]
VER=(ROOT/'VERSION').read_text().strip()
SECTOR=512
SRC=ROOT/'build'/f'Frames-{VER}-ESP.img'
OUT=ROOT/'build'/f'Frames-{VER}-System-Clone.img'
MAN=ROOT/'build'/'SYSTEM-VOLUME-TARGET.json'

def sha(b): return hashlib.sha256(b).hexdigest()
def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def u64(b,o): return struct.unpack_from('<Q',b,o)[0]
def set_fat(img, base, reserved, fat_sectors, nfats, cluster, value):
    for f in range(nfats):
        off=base+(reserved+f*fat_sectors)*SECTOR+cluster*4
        struct.pack_into('<I',img,off,value)
def cluster_off(base,data_start,spc,c): return base+(data_start+(c-2)*spc)*SECTOR
def short_cluster(e): return u16(e,20)*65536+u16(e,26)
def find_short(img,base,data_start,spc,fat_start,bps,root_cluster,name11):
    c=root_cluster
    for _ in range(128):
        first=cluster_off(base,data_start,spc,c)
        for s in range(spc):
            sec=first+s*bps
            for off in range(0,bps,32):
                e=img[sec+off:sec+off+32]
                if e[0]==0: return None
                if e[0]!=0xE5 and e[11]!=0x0F and bytes(e[:11])==name11:
                    return sec+off, short_cluster(e)
        fat_off=base+fat_start*SECTOR+c*4
        c=u32(img,fat_off)&0x0fffffff
        if c>=0x0ffffff8: break
    return None

def cert_block(a,b,cycle=0):
    x=bytearray(SECTOR); x[:16]=b'FRAMES_SYSVOL_V1'
    struct.pack_into('<QQQQ',x,32,935,a,b,cycle)
    for i in range(64,SECTOR): x[i]=(17+(i*31)+(cycle*7))&0xff
    return x

img=bytearray(SRC.read_bytes())
source_sha=sha(img)
if img[SECTOR:SECTOR+8]!=b'EFI PART': raise SystemExit('bad GPT')
entry_lba=u64(img,SECTOR+72); entry_size=u32(img,SECTOR+84)
part_off=entry_lba*SECTOR
part_start=u64(img,part_off+32); part_end=u64(img,part_off+40)
base=part_start*SECTOR
if img[base+82:base+90]!=b'FAT32   ': raise SystemExit('not FAT32')
bps=u16(img,base+11); spc=img[base+13]; reserved=u16(img,base+14); nfats=img[base+16]; fat_sectors=u32(img,base+36); root=u32(img,base+44)&0x0fffffff
if bps!=512: raise SystemExit('expected 512-byte FAT sectors')
fat_start=reserved; data_start=reserved+nfats*fat_sectors
root_off=cluster_off(base,data_start,spc,root)
frames=None
for off in range(0,bps,32):
    e=img[root_off+off:root_off+off+32]
    if e[0]==0: break
    if e[0]!=0xE5 and e[11]!=0x0F and bytes(e[:11])==b'FRAMES     ':
        frames=short_cluster(e); break
if not frames: raise SystemExit('FRAMES directory missing')
frames_off=cluster_off(base,data_start,spc,frames)
free_dir=None
for off in range(0,bps,32):
    if img[frames_off+off] in (0,0xE5): free_dir=frames_off+off; break
if free_dir is None: raise SystemExit('no free Frames directory entry')
# Find two free clusters.
fat1=base+reserved*SECTOR
max_cluster=((part_end-part_start+1)-data_start)//spc+1
free=[]
for c in range(2,max_cluster+1):
    if (u32(img,fat1+c*4)&0x0fffffff)==0:
        free.append(c)
        if len(free)==2: break
if len(free)!=2: raise SystemExit('not enough free clusters')
a,b=free
set_fat(img,base,reserved,fat_sectors,nfats,a,0x0fffffff)
set_fat(img,base,reserved,fat_sectors,nfats,b,0x0fffffff)
aoff=cluster_off(base,data_start,spc,a); boff=cluster_off(base,data_start,spc,b)
img[aoff:aoff+SECTOR]=cert_block(a,b,0)
img[boff:boff+SECTOR]=b'\0'*SECTOR
entry=bytearray(32); entry[:11]=b'SYSWRITETST'; entry[11]=0x20
struct.pack_into('<H',entry,20,(a>>16)&0xffff); struct.pack_into('<H',entry,26,a&0xffff); struct.pack_into('<I',entry,28,SECTOR)
img[free_dir:free_dir+32]=entry
OUT.write_bytes(img)
manifest={
 'status':'READY','profile':'disposable-system-volume-fat32-gate4','version':VER,
 'serial':'FRAMESSYS0935','bytes':len(img),'sectors':len(img)//SECTOR,'sector_bytes':SECTOR,
 'source_esp_sha256':source_sha,'pristine_clone_sha256':sha(img),
 'partition_start_lba':part_start,'partition_end_lba':part_end,
 'fat_start_lba':part_start+fat_start,'fat_sectors':fat_sectors,'fat_copies':nfats,
 'frames_directory_cluster':frames,'directory_lba':(free_dir//SECTOR),'directory_offset':free_dir%SECTOR,
 'cert_short_name':'SYSWRITETST','cluster_a':a,'cluster_b':b,
 'cluster_a_lba':part_start+data_start+(a-2)*spc,'cluster_b_lba':part_start+data_start+(b-2)*spc,
 'cert_size':SECTOR,'write_allowlist_lbas':[free_dir//SECTOR,part_start+data_start+(a-2)*spc,part_start+data_start+(b-2)*spc],
 'boot_or_system_volume_clone':True,'real_boot_volume_writable':False,'disposable_clone_only':True
}
MAN.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(OUT); print(json.dumps(manifest,indent=2,sort_keys=True))
