#!/usr/bin/env python3
import argparse,json,os,sys
P=['baseline','qemu64','ahci','no-network','ehci-ps2','virtio-vga','mixed-storage']
a=argparse.ArgumentParser(); a.add_argument('--build',required=True); a.add_argument('--require-pass',action='store_true'); x=a.parse_args(); lanes={}; ok=True
for p in P:
 f=os.path.join(x.build,'HWCOMPAT-'+p.upper()+'-EVIDENCE.json')
 try: d=json.load(open(f)); lanes[p]=d; ok=ok and d.get('status')=='PASS'
 except Exception as e: lanes[p]={'status':'MISSING','error':str(e)}; ok=False
out={'status':'PASS' if ok else 'FAIL','profiles':P,'lanes':lanes}; print(json.dumps(out,indent=2,sort_keys=True))
if x.require_pass and not ok: sys.exit(1)
