#!/usr/bin/env python3
from pathlib import Path
import struct, shutil, hashlib
ROOT=Path(__file__).resolve().parents[1]; VER=(ROOT/'VERSION').read_text().strip(); B=ROOT/'build'
base=B/f'Frames-{VER}-ESP.img'; out=B/f'Frames-{VER}-Developer-Preview.img'
package=B/'HelloFrames.fapp'
if not base.exists(): raise SystemExit('ESP image missing; run build.sh and make_esp.py first')
if not package.exists(): raise SystemExit('HelloFrames.fapp missing; run sdk_selftest.py first')
shutil.copy2(base,out); d=bytearray(out.read_bytes()); sec=512
challenge=b'FRAMES_DEVELOPER_PREVIEW_V1\n'; package_raw=package.read_bytes()
if d[sec:sec+8]!=b'EFI PART': raise SystemExit('GPT missing')
part=struct.unpack_from('<Q',d,sec+72)[0]; ent=part*sec; first=struct.unpack_from('<Q',d,ent+32)[0]; baseoff=first*sec
bps=struct.unpack_from('<H',d,baseoff+11)[0]; spc=d[baseoff+13]; rsv=struct.unpack_from('<H',d,baseoff+14)[0]; nf=d[baseoff+16]; fatsz=struct.unpack_from('<I',d,baseoff+36)[0]
if bps!=512 or spc!=1 or nf!=2: raise SystemExit('unexpected FAT32 geometry')
data_start=rsv+nf*fatsz; frames_cluster=5
def coff(c): return baseoff+(data_start+(c-2))*sec
fat1=baseoff+rsv*sec; fat2=baseoff+(rsv+fatsz)*sec
def fat_get(c): return struct.unpack_from('<I',d,fat1+c*4)[0]&0x0fffffff
def fat_set(c,v):
    for fo in (fat1,fat2): struct.pack_into('<I',d,fo+c*4,v)
def alloc(payload):
    need=max(1,(len(payload)+sec-1)//sec); chain=[]; c=6
    while len(chain)<need and c<65525:
        if fat_get(c)==0: chain.append(c)
        c+=1
    if len(chain)!=need: raise SystemExit('no free FAT clusters')
    for i,c in enumerate(chain): fat_set(c, chain[i+1] if i+1<len(chain) else 0x0fffffff)
    for i,c in enumerate(chain):
        chunk=payload[i*sec:(i+1)*sec]
        d[coff(c):coff(c)+sec]=chunk.ljust(sec,b'\0')
    return chain[0]
def add_entry(short11,payload):
    raw=coff(frames_cluster); slot=None
    for off in range(0,sec,32):
        if d[raw+off] in (0,0xe5): slot=raw+off; break
    if slot is None: raise SystemExit('Frames directory full')
    first=alloc(payload)
    e=bytearray(32); e[:11]=short11; e[11]=0x20
    struct.pack_into('<H',e,20,(first>>16)&0xffff); struct.pack_into('<H',e,26,first&0xffff); struct.pack_into('<I',e,28,len(payload))
    d[slot:slot+32]=e
    if slot+32<raw+sec and d[slot+32] in (0,0xe5): d[slot+32:slot+64]=b'\0'*32
add_entry(b'DEVPREV CFG',challenge)
add_entry(b'HELLO   FAP',package_raw)
out.write_bytes(d)
print(out)
print('DEVPREV.CFG sha256='+hashlib.sha256(challenge).hexdigest())
print('HELLO.FAP sha256='+hashlib.sha256(package_raw).hexdigest())
print('image sha256='+hashlib.sha256(d).hexdigest())
