#!/usr/bin/env python3
from pathlib import Path
import struct, zlib, math, hashlib, uuid

SECTOR=512
TOTAL_SECTORS=131072  # 64 MiB disk
ESP_START=2048
ESP_SECTORS=126976
ESP_END=ESP_START+ESP_SECTORS-1
ROOT_CLUSTER=2

ROOT=Path(__file__).resolve().parents[1]
BOOT=(ROOT/'build/BOOTX64.EFI').read_bytes()
KERNEL=(ROOT/'build/FramesKernel.fkrn').read_bytes()
SYSTEM=(ROOT/'build/System.fex').read_bytes()
BOOTSTAT=(ROOT/'build/BOOTSTAT.TXT').read_bytes()
USBBOOT=b'FRAMES_USB_BOOT_CERT_V1\n'
VER=(ROOT/'VERSION').read_text().strip()
OUT=ROOT/f'build/Frames-{VER}-USB-Boot.img'

def guid_bytes(s):
    u=uuid.UUID(s)
    return struct.pack('<IHH',u.time_low,u.time_mid,u.time_hi_version)+u.bytes[8:]

def short_entry(name11, attr, cluster, size=0):
    assert len(name11)==11
    e=bytearray(32); e[:11]=name11; e[11]=attr
    struct.pack_into('<H',e,20,(cluster>>16)&0xffff); struct.pack_into('<H',e,26,cluster&0xffff); struct.pack_into('<I',e,28,size)
    return bytes(e)

def lfn_checksum(short11):
    s=0
    for b in short11: s=((s&1)<<7)+(s>>1)+b; s&=0xff
    return s

def lfn_entries(name, short11):
    chars=[ord(c) for c in name]+[0]
    while len(chars)%13: chars.append(0xffff)
    chunks=[chars[i:i+13] for i in range(0,len(chars),13)]
    chk=lfn_checksum(short11); out=[]
    for idx in range(len(chunks)-1,-1,-1):
        seq=idx+1
        if idx==len(chunks)-1: seq|=0x40
        c=chunks[idx]; e=bytearray(32); e[0]=seq; e[11]=0x0f; e[12]=0; e[13]=chk
        for j,v in enumerate(c[:5]): struct.pack_into('<H',e,1+j*2,v)
        for j,v in enumerate(c[5:11]): struct.pack_into('<H',e,14+j*2,v)
        struct.pack_into('<H',e,26,0)
        for j,v in enumerate(c[11:13]): struct.pack_into('<H',e,28+j*2,v)
        out.append(bytes(e))
    return out

def solve_fat(total, reserved=32, nfats=2, spc=1):
    fs=1
    while True:
        clusters=(total-reserved-nfats*fs)//spc
        new=math.ceil((clusters+2)*4/SECTOR)
        if new==fs: return fs,clusters
        fs=new

fat_sectors, cluster_count=solve_fat(ESP_SECTORS)
if cluster_count < 65525: raise SystemExit('ESP is not large enough for FAT32')
data_start=32+2*fat_sectors

img=bytearray(TOTAL_SECTORS*SECTOR)

# Protective MBR
mbr=memoryview(img)[:SECTOR]; mbr[:] = b'\0'*SECTOR
mbr[446]=0x00; mbr[450]=0xEE
struct.pack_into('<I',mbr,454,1); struct.pack_into('<I',mbr,458,min(TOTAL_SECTORS-1,0xffffffff)); mbr[510:512]=b'\x55\xaa'

# GPT partition table
entries=bytearray(128*128)
esp_type=guid_bytes('c12a7328-f81f-11d2-ba4b-00a0c93ec93b')
part_guid=guid_bytes('f5a1e500-0001-4500-8000-000000000001')
entries[0:16]=esp_type; entries[16:32]=part_guid
struct.pack_into('<QQQ',entries,32,ESP_START,ESP_END,0)
name='Frames EFI System'.encode('utf-16le'); entries[56:56+len(name)]=name
entries_crc=zlib.crc32(entries)&0xffffffff
img[2*SECTOR:34*SECTOR]=entries
backup_entries_lba=TOTAL_SECTORS-33
img[backup_entries_lba*SECTOR:(backup_entries_lba+32)*SECTOR]=entries

def gpt_header(current, backup, entries_lba, first_usable=34, last_usable=TOTAL_SECTORS-34):
    h=bytearray(SECTOR); h[:8]=b'EFI PART'; struct.pack_into('<I',h,8,0x00010000); struct.pack_into('<I',h,12,92)
    struct.pack_into('<I',h,16,0); struct.pack_into('<I',h,20,0); struct.pack_into('<QQQQ',h,24,current,backup,first_usable,last_usable)
    h[56:72]=guid_bytes('f5a1e500-0000-4500-8000-000000000001')
    struct.pack_into('<QIII',h,72,entries_lba,128,128,entries_crc)
    crc=zlib.crc32(h[:92])&0xffffffff; struct.pack_into('<I',h,16,crc); return h
img[SECTOR:2*SECTOR]=gpt_header(1,TOTAL_SECTORS-1,2)
img[(TOTAL_SECTORS-1)*SECTOR:TOTAL_SECTORS*SECTOR]=gpt_header(TOTAL_SECTORS-1,1,backup_entries_lba)

# FAT32 volume starts at ESP_START
base=ESP_START*SECTOR
boot=bytearray(SECTOR); boot[0:3]=b'\xeb\x58\x90'; boot[3:11]=b'FRAMES  '
struct.pack_into('<H',boot,11,SECTOR); boot[13]=1; struct.pack_into('<H',boot,14,32); boot[16]=2; struct.pack_into('<H',boot,17,0); struct.pack_into('<H',boot,19,0)
boot[21]=0xF8; struct.pack_into('<H',boot,22,0); struct.pack_into('<H',boot,24,63); struct.pack_into('<H',boot,26,255); struct.pack_into('<I',boot,28,ESP_START); struct.pack_into('<I',boot,32,ESP_SECTORS)
struct.pack_into('<I',boot,36,fat_sectors); struct.pack_into('<H',boot,40,0); struct.pack_into('<H',boot,42,0); struct.pack_into('<I',boot,44,ROOT_CLUSTER); struct.pack_into('<H',boot,48,1); struct.pack_into('<H',boot,50,6)
boot[64]=0x80; boot[66]=0x29; struct.pack_into('<I',boot,67,0x46524D31); boot[71:82]=b'FRAMESBOOT '; boot[82:90]=b'FAT32   '; boot[510:512]=b'\x55\xaa'
img[base:base+SECTOR]=boot; img[base+6*SECTOR:base+7*SECTOR]=boot

fsinfo=bytearray(SECTOR); struct.pack_into('<I',fsinfo,0,0x41615252); struct.pack_into('<I',fsinfo,484,0x61417272); struct.pack_into('<I',fsinfo,488,0xffffffff); struct.pack_into('<I',fsinfo,492,6); struct.pack_into('<I',fsinfo,508,0xaa550000)
img[base+SECTOR:base+2*SECTOR]=fsinfo; img[base+7*SECTOR:base+8*SECTOR]=fsinfo

# Allocate clusters: 2 root, 3 EFI, 4 BOOT, 5 Frames, then files.
next_cluster=6

def alloc_file(data):
    global next_cluster
    n=max(1,math.ceil(len(data)/SECTOR)); chain=list(range(next_cluster,next_cluster+n)); next_cluster+=n; return chain
boot_chain=alloc_file(BOOT); kernel_chain=alloc_file(KERNEL); system_chain=alloc_file(SYSTEM); stat_chain=alloc_file(BOOTSTAT); usbboot_chain=alloc_file(USBBOOT)
fat=[0]*(cluster_count+2); fat[0]=0x0ffffff8; fat[1]=0x0fffffff
for c in (2,3,4,5): fat[c]=0x0fffffff
for chain in (boot_chain,kernel_chain,system_chain,stat_chain,usbboot_chain):
    for a,b in zip(chain,chain[1:]): fat[a]=b
    fat[chain[-1]]=0x0fffffff
fat_bytes=bytearray(fat_sectors*SECTOR)
for i,v in enumerate(fat): struct.pack_into('<I',fat_bytes,i*4,v)
for f in range(2):
    off=base+(32+f*fat_sectors)*SECTOR; img[off:off+len(fat_bytes)]=fat_bytes

def cluster_off(c): return base+(data_start+(c-2))*SECTOR

def write_dir(c, entries_list):
    data=b''.join(entries_list)+b'\x00'*32
    if len(data)>SECTOR: raise SystemExit('directory overflow')
    off=cluster_off(c); img[off:off+SECTOR]=data.ljust(SECTOR,b'\0')

def dot(name, cluster): return short_entry(name,0x10,cluster,0)
write_dir(2,[short_entry(b'EFI        ',0x10,3),short_entry(b'FRAMES     ',0x10,5)])
write_dir(3,[dot(b'.          ',3),dot(b'..         ',2),short_entry(b'BOOT       ',0x10,4)])
write_dir(4,[dot(b'.          ',4),dot(b'..         ',3),short_entry(b'BOOTX64 EFI',0x20,boot_chain[0],len(BOOT))])
short_kernel=b'FRAMES~1FKR'
short_system=b'SYSTEM~1FEX'
write_dir(5,[dot(b'.          ',5),dot(b'..         ',2),*lfn_entries('FramesKernel.fkrn',short_kernel),short_entry(short_kernel,0x20,kernel_chain[0],len(KERNEL)),*lfn_entries('System.fex',short_system),short_entry(short_system,0x20,system_chain[0],len(SYSTEM)),short_entry(b'BOOTSTATTXT',0x20,stat_chain[0],len(BOOTSTAT)),short_entry(b'USBBOOT CFG',0x20,usbboot_chain[0],len(USBBOOT))])

def write_chain(chain,data):
    pos=0
    for c in chain:
        chunk=data[pos:pos+SECTOR]; pos+=len(chunk); off=cluster_off(c); img[off:off+SECTOR]=chunk.ljust(SECTOR,b'\0')
write_chain(boot_chain,BOOT); write_chain(kernel_chain,KERNEL); write_chain(system_chain,SYSTEM); write_chain(stat_chain,BOOTSTAT); write_chain(usbboot_chain,USBBOOT)

OUT.write_bytes(img)
print(f'wrote {OUT} ({len(img)} bytes)')
print(f'FAT32 clusters={cluster_count} fat_sectors={fat_sectors}')
print(f'BOOTX64.EFI sha256={hashlib.sha256(BOOT).hexdigest()}')
print(f'FramesKernel.fkrn sha256={hashlib.sha256(KERNEL).hexdigest()}')
print(f'System.fex sha256={hashlib.sha256(SYSTEM).hexdigest()}')
print(f'BOOTSTAT.TXT sha256={hashlib.sha256(BOOTSTAT).hexdigest()}')

print(f'USBBOOT.CFG sha256={hashlib.sha256(USBBOOT).hexdigest()}')
