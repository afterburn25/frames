#!/usr/bin/env python3
import json, socket, time, sys
from pathlib import Path
sock_path,log_path,marker=sys.argv[1],Path(sys.argv[2]),sys.argv[3]
marker_timeout=int(sys.argv[4]) if len(sys.argv)>4 else 240
deadline=time.time()+marker_timeout
while time.time()<deadline:
    if log_path.exists() and marker in log_path.read_text(errors='ignore'):
        break
    time.sleep(.25)
else:
    print('marker timeout',marker); sys.exit(1)
# QEMU's unix QMP chardev is intentionally treated as single-client here.
# The lifecycle input injector releases it after the proof marker. Retry until
# this client receives the real QMP greeting; merely connecting to the socket
# backlog is not considered success.
connect_deadline=time.time()+30
while True:
    s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
    s.settimeout(1.0)
    try:
        s.connect(sock_path)
        f=s.makefile('rwb',buffering=0)
        line=f.readline()
        if line:
            greeting=json.loads(line)
            if 'QMP' in greeting:
                break
    except (OSError,EOFError,json.JSONDecodeError):
        pass
    try: s.close()
    except OSError: pass
    if time.time()>=connect_deadline:
        print('QMP greeting timeout after',marker); sys.exit(2)
    time.sleep(.1)

def recv_reply(timeout=5):
    s.settimeout(timeout)
    while True:
        line=f.readline()
        if not line:
            return None
        obj=json.loads(line)
        if 'event' in obj:
            continue
        return obj

f.write(b'{"execute":"qmp_capabilities"}\n')
r=recv_reply()
if r is None or 'error' in r:
    print('QMP capabilities failed',r); sys.exit(3)
f.write(b'{"execute":"quit"}\n')
# Wait until QEMU has actually consumed the quit command. A normal reply or an
# immediate EOF are both acceptable; the parent shell still requires QEMU rc 0.
try:
    r=recv_reply(timeout=10)
    if r is not None and 'error' in r:
        print('QMP quit failed',r); sys.exit(4)
except (EOFError,OSError,socket.timeout):
    r=None
print('QMP quit acknowledged after',marker)
try: f.close()
except OSError: pass
try: s.close()
except OSError: pass
