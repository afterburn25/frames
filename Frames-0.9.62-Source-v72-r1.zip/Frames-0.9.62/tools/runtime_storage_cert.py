#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json
root=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser()
a.add_argument('--serial',default=str(root/'build/serial.log'))
a.add_argument('--require-pass',action='store_true')
n=a.parse_args(); p=Path(n.serial)
read_req=['FRAMES_CONTROLLER_BAR_OK','FRAMES_NVME_PROBE_OK','FRAMES_NVME_ADMIN_READY','FRAMES_NVME_IDENTIFY_OK','FRAMES_NVME_IOQ_READY','FRAMES_NVME_READ_OK']
write_req=['FRAMES_NVME_WRITE_TARGET_FOUND','FRAMES_NVME_WRITE_OK','FRAMES_NVME_FLUSH_OK','FRAMES_STORAGE_WRITE_GUARDS_OK','FRAMES_STORAGE_WRITE_INTEGRITY_OK']
data={
 'frames_version':(root/'VERSION').read_text().strip(),
 'profile':'storage-nvme-read-plus-sacrificial-write-integrity',
 'status':'BLOCKED','sha256':None,
 'read_missing':read_req,'write_missing':write_req,
 'read_path_certified':False,'write_path_certified':False,
 'boot_volume_write_certified':False,'sacrificial_target_only':True,
 'media_integrity_status':None,
}
if p.is_file():
 raw=p.read_bytes(); t=raw.decode('utf-8','replace'); data['sha256']=hashlib.sha256(raw).hexdigest()
 data['read_missing']=[x for x in read_req if x not in t]
 data['write_missing']=[x for x in write_req if x not in t]
 data['read_path_certified']=not data['read_missing']
 media_path=root/'build/WRITE-MEDIA-INTEGRITY.json'
 media={}
 if media_path.is_file():
  try: media=json.loads(media_path.read_text())
  except Exception: media={}
 data['media_integrity_status']=media.get('status')
 data['write_path_certified']=not data['write_missing'] and 'FRAMES_STORAGE_WRITE_INTEGRITY_FAIL' not in t and media.get('status')=='PASS' and media.get('byte_identical_after_restore') is True
 data['status']='PASS' if data['read_path_certified'] and data['write_path_certified'] else 'FAIL'
(root/'build/STORAGE-RUNTIME-CERT.json').write_text(json.dumps(data,indent=2)+'\n'); print(json.dumps(data,indent=2))
if n.require_pass and data['status']!='PASS': raise SystemExit(2)
