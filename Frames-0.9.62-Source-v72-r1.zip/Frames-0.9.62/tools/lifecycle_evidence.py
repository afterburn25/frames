#!/usr/bin/env python3
from pathlib import Path
import argparse,json,sys,hashlib,re
p=argparse.ArgumentParser(); p.add_argument('--reboot-log',required=True); p.add_argument('--shutdown-log',required=True); p.add_argument('--reboot-exit',required=True); p.add_argument('--shutdown-exit',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
r=Path(a.reboot_log).read_text(errors='replace'); s=Path(a.shutdown_log).read_text(errors='replace')
rx=int(Path(a.reboot_exit).read_text().strip()); sx=int(Path(a.shutdown_exit).read_text().strip())
fatal=['FRAMES_LIFECYCLE_DESTRUCTIVE_FAIL','FRAMES_STRESS_ALLOCATOR_FAIL','FRAMES_STRESS_SCHEDULER_FAIL','FRAMES_STRESS_STORAGE_READ_FAIL','FRAMES_STRESS_USB_INPUT_FAIL','FRAMES_STRESS_NETWORK_FAIL','FRAMES_STRESS_DISPLAY_FAIL','FRAMES_STRESS_RECOVERY_FAIL','FRAMES_STRESS_POWER_FAIL']
checks={
 'reboot_two_kernel_starts':r.count('FRAMES_KERNEL_START')>=2,
 'reboot_two_kernel_ready':r.count('FRAMES_KERNEL_READY')>=2,
 'reboot_target_found':r.count('FRAMES_LIFECYCLE_TARGET_FOUND')>=2,
 'reboot_state_persisted':'FRAMES_LIFECYCLE_STATE_PERSISTED' in r,
 'reboot_armed':'FRAMES_LIFECYCLE_REBOOT_ARMED' in r,
 'reboot_execute':'FRAMES_LIFECYCLE_REBOOT_EXECUTE' in r,
 'reboot_returned':'FRAMES_LIFECYCLE_REBOOT_RETURNED' in r,
 'reboot_no_shutdown_execute':'FRAMES_LIFECYCLE_SHUTDOWN_EXECUTE' not in r,
 'reboot_monitor_exit_zero':rx==0,
 'shutdown_one_kernel_start':s.count('FRAMES_KERNEL_START')==1,
 'shutdown_kernel_ready':'FRAMES_KERNEL_READY' in s,
 'shutdown_target_found':'FRAMES_LIFECYCLE_TARGET_FOUND' in s,
 'shutdown_state_persisted':'FRAMES_LIFECYCLE_STATE_PERSISTED' in s,
 'shutdown_armed':'FRAMES_LIFECYCLE_SHUTDOWN_ARMED' in s,
 'shutdown_execute':'FRAMES_LIFECYCLE_SHUTDOWN_EXECUTE' in s,
 'shutdown_did_not_return':'FRAMES_LIFECYCLE_REBOOT_RETURNED' not in s and 'FRAMES_LIFECYCLE_DESTRUCTIVE_FAIL' not in s,
 'shutdown_qemu_exit_zero':sx==0,
 'reboot_no_fatal':not any(x in r for x in fatal),
 'shutdown_no_fatal':not any(x in s for x in fatal),
}
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'post-stress-destructive-reboot-shutdown-gate2','checks':checks,'reboot_qemu_exit':rx,'shutdown_qemu_exit':sx,'reboot_serial_sha256':hashlib.sha256(r.encode()).hexdigest(),'shutdown_serial_sha256':hashlib.sha256(s.encode()).hexdigest()}
Path(Path(a.reboot_log).parent/'LIFECYCLE-EVIDENCE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': sys.exit(1)
