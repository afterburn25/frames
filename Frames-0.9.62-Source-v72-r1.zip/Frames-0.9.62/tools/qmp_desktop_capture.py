#!/usr/bin/env python3
import json,socket,sys,time
from pathlib import Path
if len(sys.argv)!=4: raise SystemExit('usage: qmp_desktop_capture.py SOCKET SERIAL_LOG OUTPUT.ppm')
sock_path,serial_path,out=sys.argv[1],Path(sys.argv[2]),sys.argv[3]
end=time.time()+120
while time.time()<end:
    if serial_path.exists() and 'FRAMES_DESKTOP_PHASE1_OK' in serial_path.read_text(errors='ignore'): break
    time.sleep(.05)
else: raise SystemExit('desktop phase1 marker not observed')
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
while True:
    try:s.connect(sock_path);break
    except OSError:
        if time.time()>end:raise SystemExit('QMP socket unavailable')
        time.sleep(.05)
f=s.makefile('rwb',buffering=0)
def recv():
    while True:
        line=f.readline()
        if not line:raise SystemExit('QMP closed')
        o=json.loads(line)
        if 'event' not in o:return o
def cmd(name,args=None):
    o={'execute':name}
    if args is not None:o['arguments']=args
    f.write((json.dumps(o,separators=(',',':'))+'\n').encode()); return recv()
recv(); cmd('qmp_capabilities')
r=cmd('screendump',{'filename':out});
if 'error' in r:raise SystemExit(str(r))
for _ in range(100):
    if Path(out).is_file() and Path(out).stat().st_size>1000:break
    time.sleep(.05)
else:raise SystemExit('screendump not created')
print('PASS: desktop framebuffer captured',out,flush=True)
cmd('quit'); f.close(); s.close()
