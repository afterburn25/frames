#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(); p.add_argument('--require-pass',action='store_true'); p.add_argument('--output'); a=p.parse_args()
counts=[2,4,8,16,32,64,96]; lanes={}; checks={}
for n in counts:
    ep=ROOT/'build'/f'SMP-SCALE-{n}-EVIDENCE.json'; rp=ROOT/'build'/f'SMP-{n}-QEMU-EXIT-CODE.txt'
    if ep.exists():
        ev=json.loads(ep.read_text()); lanes[str(n)]=ev
        checks[f'cpu_{n}_evidence_pass']=ev.get('status')=='PASS'
    else:
        checks[f'cpu_{n}_evidence_pass']=False
    if rp.exists():
        try: rc=int(rp.read_text().strip())
        except Exception: rc=-999
        checks[f'cpu_{n}_qemu_exit_0']=rc==0
    else: checks[f'cpu_{n}_qemu_exit_0']=False
checks['matrix_exact']=sorted(int(x) for x in lanes)==counts
checks['96_high_affinity_word']=lanes.get('96',{}).get('diagnostics',{}).get('5')==32
checks['96_online_aps']=lanes.get('96',{}).get('diagnostics',{}).get('2')==95
checks['96_timer_aps']=lanes.get('96',{}).get('diagnostics',{}).get('3')==95
checks['96_worker_aps']=lanes.get('96',{}).get('diagnostics',{}).get('4')==95
checks['96_ipi_aps']=lanes.get('96',{}).get('diagnostics',{}).get('6')==95
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'scalable-smp-2-through-96-matrix-gate6','counts':counts,'architectural_ceiling':128,'certification_ceiling':96,'checks':checks,'lanes':lanes}
outp=Path(a.output) if a.output else ROOT/'build'/'SMP-SCALE-MATRIX-EVIDENCE.json'; outp.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': raise SystemExit(1)
