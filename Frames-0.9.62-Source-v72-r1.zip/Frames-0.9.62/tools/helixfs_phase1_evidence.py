#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,re
p=argparse.ArgumentParser(); p.add_argument('--developer-evidence',required=True); p.add_argument('--serial',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
dev=json.loads(Path(a.developer_evidence).read_text()); raw=Path(a.serial).read_bytes(); text=raw.decode(errors='replace')
markers=['FRAMES_HELIXFS_SUPERBLOCK_OK','FRAMES_HELIXFS_INODE_OK','FRAMES_HELIXFS_DIRECTORY_OK','FRAMES_HELIXFS_READ_OK','FRAMES_HELIXFS_READONLY_OK','FRAMES_HELIXFS_MOUNT_OK','FRAMES_HELIXFS_PHASE1_OK','FRAMES_DEVPREV_HELIXFS_OK']
diag={}; counts={}
for x,y in re.findall(r'FRAMES_DEVPREV_DIAG stage=(?:0x)?([0-9A-Fa-f]+) value=(?:0x)?([0-9A-Fa-f]+)',text):
 st=int(x,16); counts[st]=counts.get(st,0)+1
 if counts[st]==1: diag[st]=int(y,16)
checks={
 'developer_preview_pass':dev.get('status')=='PASS',
 'helix_markers_exact_once':all(text.count(m)==1 for m in markers),
 'superblock_before_mount':text.find('FRAMES_HELIXFS_SUPERBLOCK_OK')>=0 and text.find('FRAMES_HELIXFS_SUPERBLOCK_OK')<text.find('FRAMES_HELIXFS_MOUNT_OK'),
 'readonly_before_mount':text.find('FRAMES_HELIXFS_READONLY_OK')>text.find('FRAMES_HELIXFS_READ_OK') and text.find('FRAMES_HELIXFS_READONLY_OK')<text.find('FRAMES_HELIXFS_MOUNT_OK'),
 'phase1_before_preview':text.find('FRAMES_HELIXFS_PHASE1_OK')<text.find('FRAMES_DEVPREV_READY'),
 'snapshot_diagnostics_unique':all(counts.get(i)==1 for i in (16,17,18,19,20)),
 'version_exact':diag.get(16)==1,
 'inode_count_exact':diag.get(17)==3,
 'directory_count_exact':diag.get(18)==2,
 'readonly_exact':diag.get(19)==1,
 'write_denial_nonzero':diag.get(20,0)>=1,
 'vfs_mount_count_includes_helix':diag.get(11,0)>=5,
 'filesystem_command_after_helix_snapshot':text.find('FRAMES_DEVPREV_CMD_FILESYSTEMS_OK')>text.find('FRAMES_DEVPREV_HELIXFS_OK'),
 'no_destructive_markers':'SCSI WRITE(10)' not in text and 'FRAMES_DEVPREV_CERT_FAIL' not in text and 'FRAMES_FATAL' not in text,
}
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'helixfs-readonly-phase1','serial_sha256':hashlib.sha256(raw).hexdigest(),'checks':checks,'markers':{m:text.count(m) for m in markers},'diagnostics':diag}
print(json.dumps(out,indent=2))
if a.require_pass and status!='PASS': raise SystemExit(1)
