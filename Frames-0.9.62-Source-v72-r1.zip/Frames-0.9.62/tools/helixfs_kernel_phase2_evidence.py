#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib
p=argparse.ArgumentParser(); p.add_argument('--serial',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
raw=Path(a.serial).read_bytes(); text=raw.decode(errors='replace')
markers=['FRAMES_HELIXFS_BLOCK_IMAGE_OK','FRAMES_HELIXFS_BLOCK_READ_OK','FRAMES_HELIXFS_SUPERBLOCK_OK','FRAMES_HELIXFS_INODE_OK','FRAMES_HELIXFS_DIRECTORY_OK','FRAMES_HELIXFS_READ_OK','FRAMES_HELIXFS_READONLY_OK','FRAMES_HELIXFS_MOUNT_OK','FRAMES_HELIXFS_PHASE1_OK','FRAMES_HELIXFS_PATH_RESOLVE_OK','FRAMES_HELIXFS_PATH_READ_OK','FRAMES_HELIXFS_PHASE2_OK','FRAMES_FILESYSTEM_PLATFORM_OK','FRAMES_KERNEL_READY']
checks={
 'markers_exact_once':all(text.count(m)==1 for m in markers),
 'ordered_block_mount_path':text.find('FRAMES_HELIXFS_BLOCK_IMAGE_OK')<text.find('FRAMES_HELIXFS_SUPERBLOCK_OK')<text.find('FRAMES_HELIXFS_MOUNT_OK')<text.find('FRAMES_HELIXFS_PATH_RESOLVE_OK')<text.find('FRAMES_HELIXFS_PATH_READ_OK')<text.find('FRAMES_HELIXFS_PHASE2_OK')<text.find('FRAMES_KERNEL_READY'),
 'no_fatal':'FRAMES_FATAL' not in text and 'PANIC' not in text and 'ASSERT_FAIL' not in text,
 'no_storage_write':'FRAMES_NVME_WRITE_OK' not in text and 'FRAMES_STORAGE_WRITE_INTEGRITY_OK' not in text and 'SCSI WRITE(10)' not in text,
 'physical_boot_blocked':'FRAMES_PHYSICAL_BOOT_BLOCKED' in text,
}
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'helixfs-readonly-phase2-kernel-smoke','serial_sha256':hashlib.sha256(raw).hexdigest(),'checks':checks,'markers':{m:text.count(m) for m in markers}}
print(json.dumps(out,indent=2))
if a.require_pass and status!='PASS': raise SystemExit(1)
