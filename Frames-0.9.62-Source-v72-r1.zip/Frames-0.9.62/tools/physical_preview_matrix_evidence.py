#!/usr/bin/env python3
import argparse,json,sys
from pathlib import Path
LANES=['generic','raw','reboot','shutdown','filesystem','system-volume','fat-lifecycle']
p=argparse.ArgumentParser(); p.add_argument('--build',default='build'); p.add_argument('--require-pass',action='store_true'); a=p.parse_args(); b=Path(a.build)
lanes={}; checks={}
for lane in LANES:
 f=b/f'PHYSICAL-PREVIEW-{lane.upper()}-EVIDENCE.json'; ok=f.exists()
 d=json.loads(f.read_text()) if ok else {'status':'MISSING'}; lanes[lane]=d; checks[lane]=ok and d.get('status')=='PASS'
status='PASS' if all(checks.values()) else 'FAIL'; out={'status':status,'profile':'physical-boot-safety-gate8-matrix','lanes_required':LANES,'checks':checks,'lanes':lanes}
print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': sys.exit(1)
