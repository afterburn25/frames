#!/usr/bin/env python3
from pathlib import Path
import argparse, struct, json, hashlib
ROOT=Path(__file__).resolve().parents[1]
VER=(ROOT/'VERSION').read_text().strip()
SECTOR=512; SECTORS=32768; SIZE=SECTOR*SECTORS

def checksum(data):
    s=2166136261
    for i,b in enumerate(data): s=(s+b+((i+1)*257)) & 0xffffffff
    return s

def fill(size,seed):
    b=bytearray(512)
    for i in range(size): b[i]=(seed+(i*29)+(i//7)) & 0xff
    return b

def make(scenario):
    data=bytearray(SIZE)
    data[0:17]=b'FRAMES_FS_CERT_V2'
    struct.pack_into('<QQQQQQ',data,32,scenario,SECTORS,SECTOR,934,1,255)
    c=SECTOR
    data[c:c+17]=b'FRAMES_FS_CTRL_V2'
    struct.pack_into('<QQQQ',data,c+32,0,scenario,934,0)
    j=8*SECTOR
    data[j:j+16]=b'FRAMES_FS_JNL_V2'
    struct.pack_into('<QQ',data,j+32,0,0)
    m=16*SECTOR
    data[m:m+17]=b'FRAMES_FS_META_V2'
    old=fill(512,100+scenario)
    old_sum=checksum(old)
    struct.pack_into('<QQQQQQ',data,m+32,1,0x1111,512,128,old_sum,1)
    data[128*SECTOR:129*SECTOR]=old
    out=ROOT/'build'/f'Frames-{VER}-Filesystem-s{scenario}.img'
    out.parent.mkdir(exist_ok=True); out.write_bytes(data)
    manifest={
      'status':'READY','profile':'frames-filesystem-crash-gate3','version':VER,
      'scenario':scenario,'serial':'FRAMESFS0934','bytes':SIZE,'sectors':SECTORS,
      'sector_bytes':SECTOR,'superblock':'FRAMES_FS_CERT_V2','control_lba':1,
      'journal_lba':8,'metadata_lba':16,'data_lbas':[128,129],
      'writable_lba_start':1,'writable_lba_count':255,
      'initial_metadata':{'active':1,'name_token':0x1111,'size':512,'data_lba':128,'checksum':old_sum,'generation':1},
      'sha256':hashlib.sha256(data).hexdigest(),'boot_or_system_volume':False,'sacrificial_only':True
    }
    (ROOT/'build'/f'FILESYSTEM-S{scenario}-TARGET.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    print(out)

p=argparse.ArgumentParser(); p.add_argument('--scenario',type=int,choices=range(5)); p.add_argument('--all',action='store_true'); a=p.parse_args()
if a.all:
    for s in range(5): make(s)
elif a.scenario is not None: make(a.scenario)
else: raise SystemExit('use --all or --scenario 0..4')
