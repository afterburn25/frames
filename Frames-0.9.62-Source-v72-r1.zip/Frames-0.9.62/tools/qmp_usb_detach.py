#!/usr/bin/env python3
import json,socket,time,sys
from pathlib import Path
sock_path,log_path=sys.argv[1],Path(sys.argv[2]); timeout=int(sys.argv[3]) if len(sys.argv)>3 else 180
proof='FRAMES_USB_BOOT_DETACH_WINDOW'; resident='FRAMES_USB_BOOT_RESIDENT_OK'
# Connect and negotiate before the guest reaches the detach window.
deadline=time.time()+30; s=None
while time.time()<deadline:
    try:
        s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM); s.settimeout(1); s.connect(sock_path); f=s.makefile('rwb',buffering=0); line=f.readline()
        if line and 'QMP' in json.loads(line): break
    except Exception: pass
    try: s.close()
    except Exception: pass
    time.sleep(.05)
else: print('QMP greeting timeout'); sys.exit(2)
pending=[]
def command(obj,timeout=10):
    f.write((json.dumps(obj)+'\n').encode()); s.settimeout(timeout)
    while True:
        line=f.readline()
        if not line: return None
        x=json.loads(line)
        if 'event' in x: pending.append(x); continue
        return x
r=command({'execute':'qmp_capabilities'}); 
if r is None or 'error' in r: print('QMP capabilities failed',r); sys.exit(3)
# Wait for the guest's explicit host-detach window while the QMP session is already live.
deadline=time.time()+timeout
while time.time()<deadline:
    txt=log_path.read_text(errors='ignore') if log_path.exists() else ''
    if resident in txt:
        print('resident proof arrived before USB detach'); sys.exit(8)
    if proof in txt: break
    time.sleep(.01)
else: print('USB detach-window marker timeout'); sys.exit(1)
r=command({'execute':'device_del','arguments':{'id':'usbboot'}})
if r is None or 'error' in r: print('QMP device_del failed',r); sys.exit(4)
event_deadline=time.time()+15; deleted=any(x.get('event')=='DEVICE_DELETED' for x in pending); s.settimeout(.5)
while not deleted and time.time()<event_deadline:
    try:
        line=f.readline()
        if not line: break
        obj=json.loads(line)
        if obj.get('event')=='DEVICE_DELETED': deleted=True
    except socket.timeout: pass
if not deleted: print('QMP DEVICE_DELETED event timeout'); sys.exit(7)
print('QMP USB DEVICE_DELETED event observed during FRAMES_USB_BOOT_DETACH_WINDOW')
# Only a resident marker observed after the deletion event counts.
ready_deadline=time.time()+timeout
while time.time()<ready_deadline:
    if log_path.exists() and resident in log_path.read_text(errors='ignore'): break
    time.sleep(.01)
else: print('resident proof timeout after USB detach'); sys.exit(5)
print('FRAMES_USB_BOOT_RESIDENT_OK observed after USB detach')
r=command({'execute':'quit'})
if r is not None and 'error' in r: print('QMP quit failed',r); sys.exit(6)
print('QMP quit acknowledged after USB detach survival proof')
