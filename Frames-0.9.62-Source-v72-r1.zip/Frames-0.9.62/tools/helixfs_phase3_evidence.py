#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,re
p=argparse.ArgumentParser();p.add_argument('--developer-evidence',required=True);p.add_argument('--serial',required=True);p.add_argument('--require-pass',action='store_true');a=p.parse_args()
dev=json.loads(Path(a.developer_evidence).read_text());raw=Path(a.serial).read_bytes();text=raw.decode(errors='replace')
markers=['FRAMES_HELIXFS_BLOCK_IMAGE_OK','FRAMES_HELIXFS_BLOCK_READ_OK','FRAMES_HELIXFS_SUPERBLOCK_OK','FRAMES_HELIXFS_INODE_OK','FRAMES_HELIXFS_DIRECTORY_OK','FRAMES_HELIXFS_READ_OK','FRAMES_HELIXFS_READONLY_OK','FRAMES_HELIXFS_MOUNT_OK','FRAMES_HELIXFS_PHASE1_OK','FRAMES_HELIXFS_PATH_RESOLVE_OK','FRAMES_HELIXFS_PATH_READ_OK','FRAMES_HELIXFS_PHASE2_OK','FRAMES_HELIXFS_TRAVERSAL_OK','FRAMES_HELIXFS_MULTIBLOCK_OK','FRAMES_HELIXFS_PHASE3_OK','FRAMES_DEVPREV_HELIXFS_OK','FRAMES_DEVPREV_HELIXFS_PHASE2_OK','FRAMES_DEVPREV_HELIXFS_PHASE3_OK']
diag={};counts={}
for x,y in re.findall(r'FRAMES_DEVPREV_DIAG stage=(?:0x)?([0-9A-Fa-f]+) value=(?:0x)?([0-9A-Fa-f]+)',text):
 st=int(x,16);counts[st]=counts.get(st,0)+1
 if counts[st]==1:diag[st]=int(y,16)
checks={'developer_preview_pass':dev.get('status')=='PASS','phase3_markers_exact_once':all(text.count(m)==1 for m in markers),'phase1_phase2_retained':text.find('FRAMES_HELIXFS_PHASE2_OK')>text.find('FRAMES_HELIXFS_PHASE1_OK')>=0,'traversal_before_multiblock':text.find('FRAMES_HELIXFS_TRAVERSAL_OK')<text.find('FRAMES_HELIXFS_MULTIBLOCK_OK')<text.find('FRAMES_HELIXFS_PHASE3_OK'),'phase3_before_preview':text.find('FRAMES_HELIXFS_PHASE3_OK')<text.find('FRAMES_DEVPREV_READY'),'snapshot_unique':all(counts.get(i)==1 for i in range(16,30)),'inode_count_exact':diag.get(17)==5,'directory_count_exact':diag.get(18)==4,'readonly_exact':diag.get(19)==1,'block_size_exact':diag.get(21)==512,'block_count_exact':diag.get(22)==16,'block_reads_nonzero':diag.get(23,0)>0,'block_write_denial_nonzero':diag.get(24,0)>=1,'path_read_exact':diag.get(25)==6434604069960107346,'image_size_exact':diag.get(26)==8192,'multiblock_checksum_exact':diag.get(27)==8256,'traversal_target_exact':diag.get(28)==5,'phase3_block_reads_nonzero':diag.get(29,0)>0,'no_destructive_markers':all(x not in text for x in ['SCSI WRITE(10)','FRAMES_STORAGE_WRITE_INTEGRITY_FAIL','FRAMES_FATAL','PANIC','ASSERT_FAIL'])}
status='PASS' if all(checks.values()) else 'FAIL'
print(json.dumps({'status':status,'profile':'helixfs-readonly-phase3-multiblock-directory-traversal','serial_sha256':hashlib.sha256(raw).hexdigest(),'checks':checks,'markers':{m:text.count(m) for m in markers},'diagnostics':diag},indent=2))
if a.require_pass and status!='PASS':raise SystemExit(1)
