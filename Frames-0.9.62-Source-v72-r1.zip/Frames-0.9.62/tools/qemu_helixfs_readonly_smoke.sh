#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"; QEMU="${QEMU:-qemu-system-x86_64}"; OVMF_CODE="${OVMF_CODE:-}"; OVMF_VARS="${OVMF_VARS:-}"
command -v "$QEMU" >/dev/null || { echo 'qemu-system-x86_64 unavailable' >&2; exit 2; }
[[ -f "$OVMF_CODE" ]] || { echo 'OVMF_CODE unavailable' >&2; exit 2; }
mkdir -p "$ROOT/build"; export NEXUS="${NEXUS:-$ROOT/toolchain/Nexus-Language-5.20.0/nexus}"
if [[ "${FRAMES_PREBUILT:-0}" != 1 ]]; then "$ROOT/tools/build.sh"; python3 "$ROOT/tools/make_esp.py"; python3 "$ROOT/tools/verify_release.py"; fi
LOG="$ROOT/build/helixfs-readonly-kernel-serial.log"; DBG="$ROOT/build/helixfs-readonly-kernel-qemu-debug.log"; RCF="$ROOT/build/HELIXFS-READONLY-KERNEL-QEMU-EXIT-CODE.txt"; EV="$ROOT/build/HELIXFS-KERNEL-PHASE3-EVIDENCE.json"
rm -f "$LOG" "$DBG" "$RCF" "$EV"
VAR_DRIVE=(); if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.helixfs-readonly.fd"; VAR_DRIVE=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.helixfs-readonly.fd"); fi
set +e
timeout 120 "$QEMU" -machine q35 -accel tcg,thread=multi -m 1024M -smp 4 -cpu max -display none -serial file:"$LOG" -no-reboot -no-shutdown -d guest_errors -D "$DBG" \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${VAR_DRIVE[@]}" \
  -device qemu-xhci,id=xhci -device usb-kbd,bus=xhci.0 \
  -drive if=none,id=framesnvme,format=raw,readonly=on,file="$ROOT/build/Frames-${VER}-ESP.img" -device nvme,serial=FRAMESHELIXRO0951,drive=framesnvme \
  -netdev user,id=net0,restrict=on -device e1000e,netdev=net0
qrc=$?
set -e
printf '%s\n' "$qrc" > "$RCF"
[[ "$qrc" -eq 124 || "$qrc" -eq 0 ]] || { echo "unexpected QEMU exit $qrc" >&2; tail -200 "$LOG" >&2 || true; exit 1; }
python3 "$ROOT/tools/runtime_evidence.py" --serial "$LOG" --require-pass > "$ROOT/build/RUNTIME-EVIDENCE.json"
python3 "$ROOT/tools/helixfs_kernel_phase3_evidence.py" --serial "$LOG" --require-pass > "$EV"
cat "$EV"
echo "FRAMES ${VER} HELIXFS READ-ONLY KERNEL SMOKE PASS qemu_exit=${qrc}"
