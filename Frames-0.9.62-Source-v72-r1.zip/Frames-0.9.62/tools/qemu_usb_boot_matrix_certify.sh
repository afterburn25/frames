#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"; mkdir -p "$ROOT/build"
"$ROOT/tools/qemu_usb_boot_certify.sh" normal
"$ROOT/tools/qemu_usb_boot_certify.sh" detach
python3 "$ROOT/tools/usb_boot_matrix_evidence.py" --normal "$ROOT/build/USB-BOOT-NORMAL-EVIDENCE.json" --detach "$ROOT/build/USB-BOOT-DETACH-EVIDENCE.json" --require-pass > "$ROOT/build/USB-BOOT-MATRIX-EVIDENCE.json"
cat "$ROOT/build/USB-BOOT-MATRIX-EVIDENCE.json"
echo "FRAMES ${VER} REMOVABLE USB BOOT CERTIFICATION PASS"
