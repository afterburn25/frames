#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,sys
p=argparse.ArgumentParser(); p.add_argument('--build-dir',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args(); b=Path(a.build_dir)

def text(name):
    p=b/name
    return p.read_text(errors='ignore') if p.exists() else ''
def js(name):
    p=b/name
    return json.loads(p.read_text()) if p.exists() else {}
def rawsha(name):
    p=b/name
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
fatal='FRAMES_FS_WRITE_CERT_FAIL'
checks={}
n=text('fs-s0-serial.log')
checks['normal_target']='FRAMES_FS_WRITE_TARGET_FOUND' in n
checks['normal_journal']='FRAMES_FS_JOURNAL_OK' in n
checks['normal_mutation']='FRAMES_FS_MUTATION_OK' in n
checks['normal_no_fatal']=fatal not in n
checks['normal_media']=js('FILESYSTEM-S0-MEDIA.json').get('status')=='PASS'
for s in range(1,5):
    f=text(f'fs-s{s}-crash-serial.log'); r=text(f'fs-s{s}-recovery-serial.log')
    checks[f's{s}_crash_target']='FRAMES_FS_WRITE_TARGET_FOUND' in f
    checks[f's{s}_prepared']='FRAMES_FS_JOURNAL_PREPARED' in f
    checks[f's{s}_crash_marker']='FRAMES_FS_CRASH_POINT_READY' in f
    checks[f's{s}_crash_no_fatal']=fatal not in f
    checks[f's{s}_recovery_target']='FRAMES_FS_WRITE_TARGET_FOUND' in r
    checks[f's{s}_recovery_ok']='FRAMES_FS_RECOVERY_OK' in r and 'FRAMES_FS_JOURNAL_OK' in r
    checks[f's{s}_direction']=(('FRAMES_FS_RECOVERY_ROLLBACK' in r and 'FRAMES_FS_RECOVERY_FORWARD' not in r) if s<4 else ('FRAMES_FS_RECOVERY_FORWARD' in r and 'FRAMES_FS_RECOVERY_ROLLBACK' not in r))
    checks[f's{s}_recovery_no_fatal']=fatal not in r
    checks[f's{s}_media']=js(f'FILESYSTEM-S{s}-MEDIA.json').get('status')=='PASS'
    checks[f's{s}_hard_kill']=text(f'FILESYSTEM-S{s}-CRASH-EXIT-CODE.txt').strip()=='137'
    checks[f's{s}_recovery_exit']=text(f'FILESYSTEM-S{s}-RECOVERY-EXIT-CODE.txt').strip()=='0'
    # Stage-specific marker discipline on first boot.
    checks[f's{s}_data_stage']=('FRAMES_FS_DATA_FLUSHED' in f)==(s>=2)
    checks[f's{s}_meta_stage']=('FRAMES_FS_METADATA_FLUSHED' in f)==(s>=3)
    checks[f's{s}_commit_stage']=('FRAMES_FS_COMMIT_FLUSHED' in f)==(s>=4)
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'post-stress-crash-consistent-filesystem-gate3','checks':checks,'serial_sha256':{'normal':rawsha('fs-s0-serial.log'),**{f's{s}_crash':rawsha(f'fs-s{s}-crash-serial.log') for s in range(1,5)},**{f's{s}_recovery':rawsha(f'fs-s{s}-recovery-serial.log') for s in range(1,5)}}}
(b/'FILESYSTEM-EVIDENCE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n'); print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': sys.exit(1)
