#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VER="$(cat "$ROOT/VERSION")"
QEMU="${QEMU:-qemu-system-x86_64}"
OVMF_CODE="${OVMF_CODE:-}"
OVMF_VARS="${OVMF_VARS:-}"
TIMEOUT="${FRAMES_FAT_LIFECYCLE_TIMEOUT:-420}"
[[ -n "$OVMF_CODE" && -f "$OVMF_CODE" ]] || { echo 'Set OVMF_CODE' >&2; exit 2; }
command -v "$QEMU" >/dev/null || exit 2
mkdir -p "$ROOT/build"
"$ROOT/tools/build.sh"
python3 "$ROOT/tools/make_esp.py"
python3 "$ROOT/tools/make_fat_lifecycle_clone.py" > "$ROOT/build/FAT-LIFECYCLE-GENERATOR.log"
cp "$ROOT/build/Frames-${VER}-FAT-Lifecycle-Clone.img" "$ROOT/build/Frames-${VER}-FAT-Lifecycle-Clone.before.img"
python3 "$ROOT/tools/verify_fat_lifecycle_clone.py" --before "$ROOT/build/Frames-${VER}-FAT-Lifecycle-Clone.before.img" --after "$ROOT/build/Frames-${VER}-FAT-Lifecycle-Clone.img" --manifest "$ROOT/build/FAT-LIFECYCLE-TARGET.json" --require-pass >/dev/null
python3 "$ROOT/tools/verify_release.py"
LOG="$ROOT/build/fat-lifecycle-serial.log"; QMP="$ROOT/build/fat-lifecycle-qmp.sock"; DBG="$ROOT/build/fat-lifecycle-qemu-debug.log"; INLOG="$ROOT/build/fat-lifecycle-input.log"; MON="$ROOT/build/fat-lifecycle-monitor.log"
rm -f "$LOG" "$QMP" "$DBG" "$INLOG" "$MON"
vars=()
if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.fat-lifecycle.fd"; vars=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.fat-lifecycle.fd"); fi
set +e
"$QEMU" -machine q35 -m 512M -smp 2 -cpu max -display none -serial file:"$LOG" -no-reboot -no-shutdown \
  -qmp "unix:$QMP,server=on,wait=off" -d guest_errors -D "$DBG" \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" "${vars[@]}" \
  -device qemu-xhci,id=xhci -device usb-kbd,bus=xhci.0 -netdev user,id=framesnet,restrict=on -device e1000e,netdev=framesnet \
  -drive if=none,id=framesnvme,format=raw,readonly=on,file="$ROOT/build/Frames-${VER}-ESP.img" -device nvme,serial=FRAMES${VER},drive=framesnvme \
  -drive if=none,id=framesfat,format=raw,file="$ROOT/build/Frames-${VER}-FAT-Lifecycle-Clone.img" -device nvme,serial=FRAMESFAT0936,drive=framesfat &
pid=$!
python3 "$ROOT/tools/qmp_input_inject.py" "$QMP" 180 "$LOG" FRAMES_KERNEL_READY >"$INLOG" 2>&1 & inpid=$!
python3 "$ROOT/tools/qmp_marker_quit.py" "$QMP" "$LOG" FRAMES_KERNEL_READY >"$MON" 2>&1 & monpid=$!
wait "$pid"; rc=$?
wait "$inpid" 2>/dev/null || true
wait "$monpid"; mrc=$?
set -e
echo "$rc" > "$ROOT/build/FAT-LIFECYCLE-QEMU-EXIT-CODE.txt"
[[ "$mrc" -eq 0 ]] || { echo "marker monitor failed rc=$mrc" >&2; exit 1; }
[[ "$rc" -eq 0 ]] || { echo "qemu rc=$rc" >&2; exit 1; }
python3 "$ROOT/tools/verify_fat_lifecycle_clone.py" --before "$ROOT/build/Frames-${VER}-FAT-Lifecycle-Clone.before.img" --after "$ROOT/build/Frames-${VER}-FAT-Lifecycle-Clone.img" --manifest "$ROOT/build/FAT-LIFECYCLE-TARGET.json" --require-pass > "$ROOT/build/FAT-LIFECYCLE-MEDIA-CONSOLE.json"
python3 "$ROOT/tools/fat_lifecycle_evidence.py" --serial "$LOG" --media "$ROOT/build/FAT-LIFECYCLE-MEDIA.json" --require-pass
if grep -q 'FRAMES_FAT_LIFECYCLE_CERT_FAIL' "$LOG"; then echo 'fatal FAT lifecycle marker present' >&2; exit 1; fi
echo "FRAMES ${VER} FAT32 ALLOCATION + FILE LIFECYCLE CERTIFICATION PASS"
