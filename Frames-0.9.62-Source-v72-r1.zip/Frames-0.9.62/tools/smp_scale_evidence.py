#!/usr/bin/env python3
from pathlib import Path
import argparse,json,re,hashlib
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--serial',required=True)
p.add_argument('--expected-cpus',required=True,type=int)
p.add_argument('--output')
p.add_argument('--require-kernel-ready',action='store_true')
p.add_argument('--require-pass',action='store_true')
a=p.parse_args()
raw=Path(a.serial).read_bytes(); log=raw.decode(errors='replace')
markers=[
 'FRAMES_SMP_SCALE_TOPOLOGY_OK','FRAMES_SMP_SCALE_APS_ONLINE_OK','FRAMES_SMP_SCALE_TIMER_OK',
 'FRAMES_SMP_SCALE_LOAD_OK','FRAMES_SMP_SCALE_AFFINITY128_OK','FRAMES_SMP_SCALE_IPI_OK','FRAMES_SMP_SCALE_CERT_OK'
]
checks={m:(log.count(m)==1) for m in markers}
if a.require_kernel_ready: checks['FRAMES_KERNEL_READY']=('FRAMES_KERNEL_READY' in log)
fatal_markers=[
 'FRAMES_SMP_SCALE_CERT_FAIL','FRAMES_STORAGE_WRITE_INTEGRITY_FAIL','FRAMES_FS_WRITE_CERT_FAIL',
 'FRAMES_SYSTEM_VOLUME_WRITE_CERT_FAIL','FRAMES_FAT_LIFECYCLE_CERT_FAIL','FRAMES_LIFECYCLE_DESTRUCTIVE_FAIL',
 'FRAMES_PAGE_FAULT','FRAMES_AP_PROTECTION_FAULT=','FRAMES_STRESS_ALLOCATOR_FAIL','FRAMES_STRESS_SCHEDULER_FAIL',
 'FRAMES_STRESS_STORAGE_READ_FAIL','FRAMES_STRESS_USB_INPUT_FAIL','FRAMES_STRESS_NETWORK_FAIL',
 'FRAMES_STRESS_DISPLAY_FAIL','FRAMES_STRESS_RECOVERY_FAIL','FRAMES_STRESS_POWER_FAIL','PANIC','ASSERT','TRIPLE'
]
fatal=[x for x in fatal_markers if x in log]; checks['no_fail']=not fatal
stages={}
stage_counts={}
diag_prefixes={}
for m in re.finditer(r'(?m)^(FRAMES_|[A-Z0-9]{1,6}_)?SMP_SCALE_DIAG stage=0x([0-9A-Fa-f]+) detail=0x([0-9A-Fa-f]+)',log):
    prefix=m.group(1) or ''
    stage=int(m.group(2),16); detail=int(m.group(3),16)
    stage_counts[stage]=stage_counts.get(stage,0)+1
    diag_prefixes[str(stage)]=prefix
    if stage_counts[stage]==1:
        stages[stage]=detail
exp=a.expected_cpus; aps=exp-1
checks['cpu_count']=stages.get(1)==exp
checks['online_aps']=stages.get(2)==aps
checks['timer_aps']=stages.get(3)==aps
checks['worker_aps']=stages.get(4)==aps
checks['ipi_aps']=stages.get(6)==aps
checks['affinity_high_word']=stages.get(5)==max(0,exp-64)
checks['diagnostic_stages_unique']=all(stage_counts.get(i,0)==1 for i in range(1,7))
checks['diagnostic_prefix_bounded']=all(
    p=='FRAMES_' or (p.endswith('_') and 1 <= len(p[:-1]) <= 6 and p[:-1].isalnum())
    for p in diag_prefixes.values()
)
status='PASS' if all(checks.values()) else 'FAIL'
out={
 'status':status,'profile':'scalable-smp-multicore-gate6','expected_cpus':exp,'expected_aps':aps,
 'serial_sha256':hashlib.sha256(raw).hexdigest(),'checks':checks,
 'diagnostics':{str(k):v for k,v in sorted(stages.items())},
 'diagnostic_counts':{str(k):v for k,v in sorted(stage_counts.items())},
 'diagnostic_prefixes':diag_prefixes,
 'fatal_markers':fatal,
 'affinity_mask_bits':128,'certified_ceiling':96
}
out_path=Path(a.output) if a.output else ROOT/'build'/f'SMP-SCALE-{exp}-EVIDENCE.json'
out_path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': raise SystemExit(1)
