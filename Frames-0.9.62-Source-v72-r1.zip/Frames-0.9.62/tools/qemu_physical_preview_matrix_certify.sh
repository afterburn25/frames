#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; VER="$(cat "$ROOT/VERSION")"
for lane in generic raw reboot shutdown filesystem system-volume fat-lifecycle; do
  "$ROOT/tools/qemu_physical_preview_certify.sh" "$lane"
done
python3 "$ROOT/tools/physical_preview_matrix_evidence.py" --build "$ROOT/build" --require-pass > "$ROOT/build/PHYSICAL-PREVIEW-MATRIX-EVIDENCE.json"
echo 0 > "$ROOT/build/PHYSICAL-PREVIEW-CERTIFY-EXIT-CODE.txt"
cat "$ROOT/build/PHYSICAL-PREVIEW-MATRIX-EVIDENCE.json"
echo "FRAMES ${VER} PHYSICAL BOOT SAFETY CERTIFICATION PASS"
