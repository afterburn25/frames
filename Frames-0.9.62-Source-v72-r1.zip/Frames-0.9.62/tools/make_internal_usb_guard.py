#!/usr/bin/env python3
from pathlib import Path
import hashlib, struct
ROOT=Path(__file__).resolve().parents[1]; VER=(ROOT/'VERSION').read_text().strip(); out=ROOT/f'build/Frames-{VER}-USB-Internal-Guard.img'
size=16*1024*1024
b=bytearray(size); b[:24]=b'FRAMES_USB_GUARD_V1\0\0\0\0\0'; struct.pack_into('<Q',b,32,938)
for off in range(4096,size,4096): struct.pack_into('<Q',b,off,0x4652414D45530000 ^ off)
out.write_bytes(b)
print(f'wrote {out} ({size} bytes) sha256={hashlib.sha256(b).hexdigest()}')
