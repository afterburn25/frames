# Nexus 5.19.0 — Kernel Segment-State & Protection-Fault Diagnostics

- Adds `reload_data_segments(selector)` for explicit DS/ES/SS normalization after LGDT.
- Adds dedicated #TS/#NP/#SS/#GP kernel stub-address builtins.
- Protection stubs call `kernel_protection_fault(vector,error,rip,cs)` and halt fail-closed.
- LAPIC timer stub records the exact hardware RIP/CS/RFLAGS return frame immediately before `iretq`.
