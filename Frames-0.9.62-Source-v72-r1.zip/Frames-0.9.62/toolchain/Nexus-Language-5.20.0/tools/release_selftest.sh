#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p build
./nexus --version | grep -q 'Nexus 5.20.0'
./nexus test tests
python3 tests/compiler_semantics.py
./nexus doctor | tee build/doctor.txt
grep -q 'nir3-verifier: ready' build/doctor.txt
./nexus verify-ir tests/data_model.nx | tee build/nir-verify.txt
grep -q 'NIR3 verified' build/nir-verify.txt
grep -q 'frames-x64-backend: ready (FEX64/1)' build/doctor.txt
grep -q 'frames-arm64-backend: ready (FEX64/1)' build/doctor.txt
grep -q 'nexus-pe-linker: ready' build/doctor.txt
grep -q 'frames-ed25519-signing: ready' build/doctor.txt
./nexus filetypes > build/filetypes.txt
grep -q '^\.fex' build/filetypes.txt
grep -q '^\.fapp' build/filetypes.txt
grep -q '^\.fsetup' build/filetypes.txt
./nexus build examples/setup_bootstrap.nx --target frames-x64 -o build/Setup.fex
./nexus inspect build/Setup.fex | tee build/Setup-inspect.txt
grep -q 'NEXUS-FRAMES-ABI=1;FEX=1;FORMAT=FEX64;LANG=5.20.0' build/Setup-inspect.txt
grep -q 'format: FEX64/1' build/Setup-inspect.txt
grep -q 'integrity: verified' build/Setup-inspect.txt
grep -q 'verification: native Frames FEX64 payload' build/Setup-inspect.txt
grep -q 'CAPS=boot+storage+system' build/Setup-inspect.txt
test "$(dd if=build/Setup.fex bs=1 count=5 2>/dev/null)" = 'FEX64'
./nexus build examples/native_enum.nx --target frames-x64 -o build/NativeEnum.fex
./nexus inspect build/NativeEnum.fex | tee build/NativeEnum-inspect.txt
grep -q 'NIR=3' build/NativeEnum-inspect.txt
grep -q 'format: FEX64/1' build/NativeEnum-inspect.txt

./nexus build examples/native_refs.nx --target frames-x64 -o build/NativeRefs.fex
./nexus inspect build/NativeRefs.fex | tee build/NativeRefs-inspect.txt
grep -q 'MODULE=NativeRefs' build/NativeRefs-inspect.txt
grep -q 'NIR=3' build/NativeRefs-inspect.txt
grep -q 'format: FEX64/1' build/NativeRefs-inspect.txt

./nexus emit-asm examples/native_short_circuit.nx -o build/NativeShortCircuit.s
python3 tools/short_circuit_selftest.py build/NativeShortCircuit.s compiler/nexus/compiler.py
./nexus build examples/native_short_circuit.nx --target frames-x64 -o build/NativeShortCircuit.fex
./nexus inspect build/NativeShortCircuit.fex | grep -q 'format: FEX64/1'
./nexus build examples/native_short_circuit_arm.nx --target frames-arm64 -o build/NativeShortCircuit-arm64.fex
./nexus inspect build/NativeShortCircuit-arm64.fex | grep -q 'machine: arm64'

./nexus emit-asm examples/native_enum.nx -o build/NativeEnum.s
clang --target=x86_64-pc-windows-msvc -c build/NativeEnum.s -o build/NativeEnum.obj
./nexus link-obj build/NativeEnum.obj -o build/NativeEnum-linked.fex
./nexus inspect build/NativeEnum-linked.fex | grep -q 'verification: native Frames FEX payload'

./nexus build examples/setup_bootstrap.nx --target frames-pe-x64 -o build/Setup-compat.fex
file build/Setup-compat.fex | grep -q 'PE32+'
./nexus inspect build/Setup-compat.fex | grep -q 'verification: native Frames FEX payload'

./nexus build examples/setup_bootstrap.nx --target frames-arm64 -o build/Setup-arm64.fex
./nexus inspect build/Setup-arm64.fex | tee build/Setup-arm64-inspect.txt
grep -q 'format: FEX64/1' build/Setup-arm64-inspect.txt
grep -q 'machine: arm64' build/Setup-arm64-inspect.txt
grep -q 'ARCH=arm64' build/Setup-arm64-inspect.txt
grep -q 'integrity: verified' build/Setup-arm64-inspect.txt
./nexus build examples/freestanding.nx --target frames-arm64 -o build/Freestanding-arm64.fex
./nexus inspect build/Freestanding-arm64.fex | tee build/Freestanding-arm64-inspect.txt
grep -q 'machine: arm64' build/Freestanding-arm64-inspect.txt
./nexus lock examples/setup_project
TMPKEY="$(mktemp)"
TAMPER="$(mktemp --suffix=.fsetup)"
trap 'rm -f "$TMPKEY" "$TAMPER"' EXIT
./nexus keygen -o "$TMPKEY" --publisher 'Frames Project'
./nexus package examples/setup_project --kind setup --locked --sign-key "$TMPKEY" -o build/Setup.fsetup
./nexus inspect build/Setup.fsetup --require-signed --trust-key "$TMPKEY" | tee build/Setup-bundle-inspect.txt
grep -q 'format: FramesBundle/1' build/Setup-bundle-inspect.txt
grep -q 'name: Setup 5.6.0' build/Setup-bundle-inspect.txt
grep -q 'kind: setup' build/Setup-bundle-inspect.txt
grep -q 'entry: Payload/Setup.fex' build/Setup-bundle-inspect.txt
grep -q 'integrity: verified' build/Setup-bundle-inspect.txt
grep -q 'publisher-signature: verified' build/Setup-bundle-inspect.txt
grep -q 'trust: matched Frames Project' build/Setup-bundle-inspect.txt
python3 - "$TAMPER" <<'PY'
from pathlib import Path
import zipfile,sys
src=Path('build/Setup.fsetup'); dst=Path(sys.argv[1])
with zipfile.ZipFile(src,'r') as zin, zipfile.ZipFile(dst,'w') as zout:
    for info in zin.infolist():
        data=zin.read(info.filename)
        if info.filename.startswith('Payload/'):
            data=data+b'X'
        zout.writestr(info,data)
PY
if ./nexus inspect "$TAMPER" --require-signed >/dev/null 2>&1; then
    echo 'tampered bundle unexpectedly verified' >&2
    exit 1
fi
./tools/kernel_selftest.sh
printf 'Nexus 5.20.0 release self-test: PASS\n'
