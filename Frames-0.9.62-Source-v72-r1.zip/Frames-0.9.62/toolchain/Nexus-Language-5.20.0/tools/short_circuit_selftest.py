#!/usr/bin/env python3
from pathlib import Path
import re, sys

if len(sys.argv) != 3:
    raise SystemExit("usage: short_circuit_selftest.py <x86-asm> <compiler.py>")

asm = Path(sys.argv[1]).read_text()
compiler = Path(sys.argv[2]).read_text()

def ok(cond,msg):
    if not cond:
        raise SystemExit("FAIL: "+msg)
    print("PASS:",msg)

ok(".Lnx_and_false_" in asm and re.search(r"\bje \.Lnx_and_false_", asm), "x86 && branches around RHS")
ok(".Lnx_or_true_" in asm and re.search(r"\bjne \.Lnx_or_true_", asm), "x86 || branches around RHS")
ok(asm.count("callq touch") == 4, "x86 short-circuit fixture contains four RHS side-effect calls")
# The generated calls must be after conditional branches, not unconditionally before them.
first_and_branch = asm.find("je .Lnx_and_false_")
first_call = asm.find("callq touch")
ok(0 <= first_and_branch < first_call, "x86 first && guard precedes side-effect call")
first_or_branch = asm.find("jne .Lnx_or_true_")
second_call = asm.find("callq touch", first_call + 1)
ok(0 <= first_or_branch < second_call, "x86 first || guard precedes side-effect call")

# ARM64 lowering is source-checked because emit-asm currently exposes x86-64 only.
ok('if op=="&&":' in compiler and 'b.eq {lf}' in compiler, "ARM64 && uses false-branch short circuit")
ok('if op=="||":' in compiler and 'b.ne {lt}' in compiler, "ARM64 || uses true-branch short circuit")
# Eager native lowering patterns from 5.19 must be absent.
ok('andb %r10b, %al' not in compiler, "x86 eager && lowering removed")
ok('orr x0, x0, x9' not in compiler, "ARM64 eager || lowering removed")
print("Nexus native short-circuit self-test: PASS")
