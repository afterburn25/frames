# Nexus 5.20.0 — Native Short-Circuit Boolean Semantics

- Repairs direct native lowering of `&&` and `||` on x86-64 and ARM64.
- The right operand is now evaluated only when required by the left operand.
- Hosted C behavior is unchanged and remains the reference language semantics.
- Adds side-effect regression coverage so eager logical evaluation cannot silently return.
- Required for Frames 0.9.23 to prevent diagnostic fallback IPIs from executing after a successful targeted acknowledgement.
