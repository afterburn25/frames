from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Tuple, Any
import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import hashlib
import json
import tomllib
import zipfile
import mimetypes
import base64
import struct

VERSION = "5.20.0"

# ----------------------------- Diagnostics -----------------------------

class NexusError(Exception):
    def __init__(self, message: str, *, code: str = "NX0001", token: "Token|None" = None):
        super().__init__(message)
        self.message = message
        self.code = code
        self.token = token

    def render(self) -> str:
        if not self.token:
            return f"{self.code}: {self.message}"
        t = self.token
        head = f"{self.code}: {self.message}\n  --> {t.source}:{t.line}:{t.col}"
        if not t.text:
            return head
        lines = t.text.splitlines()
        if 1 <= t.line <= len(lines):
            src = lines[t.line - 1]
            caret = " " * max(t.col - 1, 0) + "^"
            return f"{head}\n   |\n{t.line:>3} | {src}\n   | {caret}"
        return head

# ----------------------------- Lexer -----------------------------

KEYWORDS = {
    "fn", "let", "var", "const", "return", "if", "else", "while", "for", "in",
    "break", "continue", "true", "false", "module", "import", "struct", "enum",
    "match", "pub", "unsafe", "pure", "effects", "spawn", "sync", "move", "mut", "trait", "impl", "drop", "defer", "async", "await", "capabilities", "kernel",
}

@dataclass(frozen=True)
class Token:
    kind: str
    value: str
    line: int
    col: int
    source: str = "<memory>"
    text: str = ""

class Lexer:
    def __init__(self, text: str, source: str = "<memory>"):
        self.text = text
        self.source = source
        self.i = 0
        self.line = 1
        self.col = 1

    def _peek(self, n=0):
        j = self.i + n
        return self.text[j] if j < len(self.text) else "\0"

    def _advance(self):
        ch = self._peek()
        self.i += 1
        if ch == "\n":
            self.line += 1
            self.col = 1
        else:
            self.col += 1
        return ch

    def _tok(self, kind, value, line, col):
        return Token(kind, value, line, col, self.source, self.text)

    def tokens(self) -> List[Token]:
        out: List[Token] = []
        while self.i < len(self.text):
            ch = self._peek()
            if ch in " \t\r\n":
                self._advance()
                continue
            if ch == "/" and self._peek(1) == "/":
                while self._peek() not in ("\n", "\0"):
                    self._advance()
                continue
            line, col = self.line, self.col
            if ch.isalpha() or ch == "_":
                s = ""
                while self._peek().isalnum() or self._peek() == "_":
                    s += self._advance()
                out.append(self._tok(s if s in KEYWORDS else "IDENT", s, line, col))
                continue
            if ch.isdigit():
                s = ""
                dot = False
                while self._peek().isdigit() or (
                    self._peek() == "." and self._peek(1).isdigit() and not dot
                ):
                    if self._peek() == ".":
                        dot = True
                    s += self._advance()
                out.append(self._tok("FLOAT" if dot else "INT", s, line, col))
                continue
            if ch == '"':
                self._advance()
                s = ""
                while self._peek() != '"':
                    if self._peek() == "\0":
                        raise NexusError("unterminated string literal", code="NX1001", token=self._tok("STRING", s, line, col))
                    if self._peek() == "\\":
                        self._advance()
                        esc = self._advance()
                        table = {"n": "\n", "t": "\t", "r": "\r", '"': '"', "\\": "\\", "0": "\0"}
                        s += table.get(esc, esc)
                    else:
                        s += self._advance()
                self._advance()
                out.append(self._tok("STRING", s, line, col))
                continue
            two = ch + self._peek(1)
            if two in {"->", "==", "!=", "<=", ">=", "&&", "||", "..", "::", "=>"}:
                self._advance(); self._advance()
                out.append(self._tok(two, two, line, col))
                continue
            if ch in "(){}[]:;,=+-*/%<>!.&?|":
                self._advance()
                out.append(self._tok(ch, ch, line, col))
                continue
            raise NexusError(f"unexpected character {ch!r}", code="NX1002", token=self._tok("INVALID", ch, line, col))
        out.append(self._tok("EOF", "", self.line, self.col))
        return out

# ----------------------------- AST -----------------------------

@dataclass
class Program:
    module: Optional[str]
    imports: list
    consts: list
    structs: list
    enums: list
    traits: list
    impls: list
    functions: list
    capabilities: set = field(default_factory=set)
    kernel_profile: object = None

@dataclass
class KernelProfile:
    name: str
    arch: str = "x86_64"
    abi: str = "frames-1"

@dataclass
class ImportDecl:
    name: str

@dataclass
class ConstDecl:
    name: str
    typ: str
    expr: object
    public: bool = False

@dataclass
class StructDecl:
    name: str
    fields: list
    public: bool = False
    type_params: list = field(default_factory=list)

@dataclass
class FieldDecl:
    name: str
    typ: str

@dataclass
class EnumDecl:
    name: str
    variants: list
    public: bool = False
    type_params: list = field(default_factory=list)

@dataclass
class EnumVariant:
    name: str
    payload: Optional[str] = None

@dataclass
class TraitDecl:
    name: str
    public: bool = False
    methods: list = field(default_factory=list)

@dataclass
class ImplDecl:
    trait: str
    typ: str
    methods: list = field(default_factory=list)

@dataclass
class Function:
    name: str
    params: list
    ret: str
    body: list
    public: bool = False
    pure: bool = False
    effects: Optional[set] = None
    type_params: list = field(default_factory=list)
    constraints: dict = field(default_factory=dict)
    is_async: bool = False

@dataclass
class Param:
    name: str
    typ: str

@dataclass
class Let:
    name: str
    typ: Optional[str]
    expr: object
    mutable: bool

@dataclass
class Assign:
    name: str
    expr: object

@dataclass
class DerefAssign:
    name: str
    expr: object

@dataclass
class Return:
    expr: Optional[object]

@dataclass
class If:
    cond: object
    then_body: list
    else_body: list

@dataclass
class While:
    cond: object
    body: list

@dataclass
class ForRange:
    name: str
    start: object
    end: object
    body: list

@dataclass
class ForEach:
    name: str
    iterable: object
    body: list

@dataclass
class Break: pass
@dataclass
class Continue: pass
@dataclass
class ExprStmt: expr: object

@dataclass
class MatchArm:
    enum_name: Optional[str]
    variant: Optional[str]
    binder: Optional[str]
    is_else: bool
    body: list

@dataclass
class MatchStmt:
    expr: object
    arms: list

@dataclass
class Binary:
    op: str
    left: object
    right: object

@dataclass
class Unary:
    op: str
    expr: object

@dataclass
class Literal:
    value: object
    typ: str

@dataclass
class VarRef:
    name: str

@dataclass
class Move:
    name: str

@dataclass
class Borrow:
    name: str
    mutable: bool = False

@dataclass
class Call:
    name: str
    args: list

@dataclass
class StructInit:
    name: str
    fields: list  # list[(name, expr)]

@dataclass
class FieldAccess:
    obj: object
    field: str

@dataclass
class MethodCall:
    obj: object
    method: str
    args: list

@dataclass
class EnumValue:
    enum_name: str
    variant: str
    payload: Optional[object] = None

@dataclass
class ArrayLiteral:
    items: list

@dataclass
class Index:
    obj: object
    index: object

@dataclass
class TryExpr:
    expr: object

@dataclass
class Lambda:
    param: str
    body: object

@dataclass
class AwaitExpr:
    expr: object

@dataclass
class UnsafeBlock:
    body: list

@dataclass
class Spawn:
    function: str

@dataclass
class Sync:
    pass

@dataclass
class Drop:
    name: str

@dataclass
class Defer:
    body: list

# ----------------------------- Parser -----------------------------

class Parser:
    def __init__(self, toks: List[Token]):
        self.toks = toks
        self.i = 0

    def cur(self): return self.toks[self.i]
    def at(self, k): return self.cur().kind == k

    def take(self, k):
        if not self.at(k):
            t = self.cur()
            raise NexusError(f"expected {k}, found {t.kind}", code="NX1101", token=t)
        t = self.cur(); self.i += 1; return t

    def maybe(self, k):
        if self.at(k): return self.take(k)
        return None

    def parse_type(self):
        if self.maybe("&"):
            mutable=bool(self.maybe("mut"))
            inner=self.parse_type()
            return ("&mut " if mutable else "&") + inner
        base=self.take("IDENT").value
        args=[]
        if self.maybe("<"):
            while True:
                args.append(self.parse_type())
                if not self.maybe(","): break
            self.take(">")
        return base + ("<" + ",".join(args) + ">" if args else "")

    def parse_type_params(self):
        out=[]
        if self.maybe("<"):
            while True:
                name=self.take("IDENT").value
                if name in out: raise NexusError(f"duplicate type parameter {name}", code="NX1111", token=self.cur())
                out.append(name)
                if not self.maybe(","): break
            self.take(">")
        return out

    def try_type_application(self, base):
        # Expression-side generic type applications are recognized only when followed by
        # a struct initializer or enum qualifier, avoiding ambiguity with `a < b`.
        if not self.at("<"): return base
        save=self.i
        try:
            self.take("<"); args=[]
            while True:
                args.append(self.parse_type())
                if not self.maybe(","): break
            self.take(">")
            if not (self.at("{") or self.at("::")):
                self.i=save; return base
            return base+"<"+",".join(args)+">"
        except NexusError:
            self.i=save; return base

    def parse(self):
        module = None
        imports, consts, structs, enums, traits, impls, funcs = [], [], [], [], [], [], []
        capabilities=set()
        kernel_profile=None
        if self.at("module"):
            self.take("module")
            module = self.take("IDENT").value
            self.maybe(";")
        while self.at("import"):
            self.take("import")
            imports.append(ImportDecl(self.take("IDENT").value))
            self.take(";")
        if self.at("capabilities"):
            self.take("capabilities"); self.take("(")
            if not self.at(")"):
                while True:
                    capabilities.add(self.take("IDENT").value)
                    if not self.maybe(","): break
            self.take(")"); self.take(";")
        if self.at("kernel"):
            self.take("kernel")
            kname=self.take("IDENT").value
            arch="x86_64"; abi="frames-1"
            self.take("{")
            while not self.at("}"):
                key=self.take("IDENT").value; self.take(":"); value=self.take("IDENT").value; self.take(";")
                if key=="arch": arch=value
                elif key=="abi": abi=value
                else: raise NexusError(f"unknown kernel profile key: {key}", code="NX4601", token=self.cur())
            self.take("}")
            kernel_profile=KernelProfile(kname,arch,abi)
        while not self.at("EOF"):
            public = bool(self.maybe("pub"))
            if self.at("const"):
                consts.append(self.const_decl(public)); continue
            if self.at("struct"):
                structs.append(self.struct_decl(public)); continue
            if self.at("enum"):
                enums.append(self.enum_decl(public)); continue
            if self.at("trait"):
                traits.append(self.trait_decl(public)); continue
            if self.at("impl"):
                if public: raise NexusError("impl cannot be pub", code="NX1112", token=self.cur())
                impls.append(self.impl_decl()); continue
            is_async = bool(self.maybe("async"))
            pure = bool(self.maybe("pure"))
            if self.at("fn"):
                funcs.append(self.function(public, pure, is_async)); continue
            if pure or is_async:
                raise NexusError("async/pure must precede fn", code="NX1105", token=self.cur())
            raise NexusError("expected const, struct, enum, or fn declaration", code="NX1102", token=self.cur())
        return Program(module, imports, consts, structs, enums, traits, impls, funcs, capabilities, kernel_profile)

    def const_decl(self, public=False):
        self.take("const")
        name = self.take("IDENT").value
        self.take(":")
        typ = self.parse_type()
        self.take("=")
        expr = self.expr()
        self.take(";")
        return ConstDecl(name, typ, expr, public)

    def struct_decl(self, public=False):
        self.take("struct")
        name = self.take("IDENT").value
        type_params=self.parse_type_params()
        self.take("{")
        fields = []
        while not self.at("}"):
            fn = self.take("IDENT").value
            self.take(":")
            ft = self.parse_type()
            fields.append(FieldDecl(fn, ft))
            if not self.maybe(","):
                self.maybe(";")
        self.take("}")
        return StructDecl(name, fields, public, type_params)

    def enum_decl(self, public=False):
        self.take("enum")
        name = self.take("IDENT").value
        type_params=self.parse_type_params()
        self.take("{")
        variants = []
        while not self.at("}"):
            vname = self.take("IDENT").value
            payload = None
            if self.maybe("("):
                payload = self.parse_type()
                self.take(")")
            variants.append(EnumVariant(vname, payload))
            if not self.maybe(","):
                self.maybe(";")
        self.take("}")
        return EnumDecl(name, variants, public, type_params)

    def trait_decl(self, public=False):
        self.take("trait")
        name=self.take("IDENT").value; methods=[]
        self.take("{")
        while not self.at("}"):
            self.take("fn"); mn=self.take("IDENT").value; self.take("("); params=[]
            if not self.at(")"):
                while True:
                    pn=self.take("IDENT").value; self.take(":"); params.append(Param(pn,self.parse_type()))
                    if not self.maybe(","): break
            self.take(")"); ret="void"
            if self.maybe("->"): ret=self.parse_type()
            self.take(";"); methods.append(Function(mn,params,ret,[]))
        self.take("}")
        return TraitDecl(name,public,methods)

    def impl_decl(self):
        self.take("impl")
        trait=self.take("IDENT").value
        self.take("for")
        typ=self.parse_type()
        if self.maybe(";"): return ImplDecl(trait,typ,[])
        self.take("{"); methods=[]
        while not self.at("}"): methods.append(self.function(False,False))
        self.take("}")
        return ImplDecl(trait,typ,methods)

    def parse_function_type_params(self):
        out=[]; constraints={}
        if self.maybe("<"):
            while True:
                name=self.take("IDENT").value
                if name in out: raise NexusError(f"duplicate type parameter {name}", code="NX1111", token=self.cur())
                out.append(name)
                if self.maybe(":"):
                    constraints.setdefault(name,set()).add(self.take("IDENT").value)
                    while self.maybe("+"):
                        constraints[name].add(self.take("IDENT").value)
                if not self.maybe(","): break
            self.take(">")
        return out,constraints

    def function(self, public=False, pure=False, is_async=False):
        self.take("fn")
        name = self.take("IDENT").value
        type_params,constraints=self.parse_function_type_params()
        self.take("(")
        params = []
        if not self.at(")"):
            while True:
                pn = self.take("IDENT").value
                self.take(":")
                pt = self.parse_type()
                params.append(Param(pn, pt))
                if not self.maybe(","): break
        self.take(")")
        ret = "void"
        if self.maybe("->"): ret = self.parse_type()
        effects = set() if pure else None
        if self.maybe("effects"):
            if pure: raise NexusError("pure functions cannot also declare effects", code="NX1110", token=self.cur())
            effects=set(); self.take("(")
            if not self.at(")"):
                while True:
                    effects.add(self.take("IDENT").value)
                    if not self.maybe(","): break
            self.take(")")
        return Function(name, params, ret, self.block(), public, pure, effects, type_params, constraints, is_async)

    def block(self):
        self.take("{")
        body = []
        while not self.at("}"):
            if self.at("EOF"):
                raise NexusError("unterminated block", code="NX1103", token=self.cur())
            body.append(self.statement())
        self.take("}")
        return body

    def statement(self):
        if self.at("let") or self.at("var"):
            mutable = self.at("var"); self.i += 1
            name = self.take("IDENT").value
            typ = None
            if self.maybe(":"): typ = self.parse_type()
            self.take("=")
            expr = self.expr(); self.take(";")
            return Let(name, typ, expr, mutable)
        if self.at("return"):
            self.take("return")
            if self.at(";"): self.take(";"); return Return(None)
            e = self.expr(); self.take(";"); return Return(e)
        if self.at("if"):
            self.take("if")
            cond = self.expr(); then_body = self.block(); else_body = []
            if self.at("else"):
                self.take("else")
                if self.at("if"):
                    # desugar else if into else { if ... }
                    else_body = [self.statement()]
                else:
                    else_body = self.block()
            return If(cond, then_body, else_body)
        if self.at("while"):
            self.take("while"); return While(self.expr(), self.block())
        if self.at("for"):
            self.take("for")
            name = self.take("IDENT").value
            self.take("in")
            first = self.expr()
            if self.maybe(".."):
                return ForRange(name, first, self.expr(), self.block())
            return ForEach(name, first, self.block())
        if self.at("spawn"):
            self.take("spawn"); name=self.take("IDENT").value; self.take("("); self.take(")"); self.take(";")
            return Spawn(name)
        if self.at("sync"):
            self.take("sync"); self.take(";"); return Sync()
        if self.at("drop"):
            self.take("drop"); name=self.take("IDENT").value; self.take(";"); return Drop(name)
        if self.at("defer"):
            self.take("defer"); return Defer(self.block())
        if self.at("unsafe"):
            self.take("unsafe")
            return UnsafeBlock(self.block())
        if self.at("match"):
            self.take("match")
            target = self.expr(); self.take("{")
            arms = []
            while not self.at("}"):
                binder = None
                if self.at("else"):
                    self.take("else"); en = va = None; is_else = True
                else:
                    en = self.take("IDENT").value; self.take("::"); va = self.take("IDENT").value; is_else = False
                    if self.maybe("("):
                        binder = self.take("IDENT").value
                        self.take(")")
                self.take("=>")
                body = self.block()
                self.maybe(",")
                arms.append(MatchArm(en, va, binder, is_else, body))
            self.take("}")
            return MatchStmt(target, arms)
        if self.at("break"):
            self.take("break"); self.take(";"); return Break()
        if self.at("continue"):
            self.take("continue"); self.take(";"); return Continue()
        if self.at("*") and self.toks[self.i + 1].kind == "IDENT" and self.toks[self.i + 2].kind == "=":
            self.take("*"); name=self.take("IDENT").value; self.take("="); e=self.expr(); self.take(";")
            return DerefAssign(name,e)
        if self.at("IDENT") and self.toks[self.i + 1].kind == "=":
            name = self.take("IDENT").value; self.take("="); e = self.expr(); self.take(";")
            return Assign(name, e)
        e = self.expr(); self.take(";"); return ExprStmt(e)

    def expr(self): return self.logic_or()
    def logic_or(self):
        e = self.logic_and()
        while self.at("||"): op=self.take("||").value; e=Binary(op,e,self.logic_and())
        return e
    def logic_and(self):
        e=self.equality()
        while self.at("&&"): op=self.take("&&").value; e=Binary(op,e,self.equality())
        return e
    def equality(self):
        e=self.compare()
        while self.at("==") or self.at("!="):
            op=self.cur().value; self.i+=1; e=Binary(op,e,self.compare())
        return e
    def compare(self):
        e=self.term()
        while self.at("<") or self.at(">") or self.at("<=") or self.at(">="):
            op=self.cur().value; self.i+=1; e=Binary(op,e,self.term())
        return e
    def term(self):
        e=self.factor()
        while self.at("+") or self.at("-"):
            op=self.cur().value; self.i+=1; e=Binary(op,e,self.factor())
        return e
    def factor(self):
        e=self.unary()
        while self.at("*") or self.at("/") or self.at("%"):
            op=self.cur().value; self.i+=1; e=Binary(op,e,self.unary())
        return e
    def unary(self):
        if self.at("await"):
            self.take("await")
            return AwaitExpr(self.unary())
        if self.at("move"):
            self.take("move")
            return Move(self.take("IDENT").value)
        if self.at("&"):
            self.take("&"); mutable=bool(self.maybe("mut")); return Borrow(self.take("IDENT").value,mutable)
        if self.at("!") or self.at("-") or self.at("*"):
            op=self.cur().value; self.i+=1; return Unary(op,self.unary())
        return self.postfix()
    def postfix(self):
        e = self.primary()
        while True:
            if self.at("."):
                self.take("."); name=self.take("IDENT").value
                if self.maybe("("):
                    args=[]
                    if not self.at(")"):
                        while True:
                            args.append(self.expr())
                            if not self.maybe(","): break
                    self.take(")"); e=MethodCall(e,name,args)
                else: e=FieldAccess(e,name)
                continue
            if self.at("["):
                self.take("["); idx = self.expr(); self.take("]"); e = Index(e, idx); continue
            if self.at("?"):
                self.take("?"); e = TryExpr(e); continue
            break
        return e
    def primary(self):
        t=self.cur()
        if self.maybe("|"):
            param=self.take("IDENT").value
            self.take("|")
            return Lambda(param,self.expr())
        if self.maybe("INT"): return Literal(int(t.value),"i64")
        if self.maybe("FLOAT"): return Literal(float(t.value),"f64")
        if self.maybe("STRING"): return Literal(t.value,"str")
        if self.maybe("true"): return Literal(True,"bool")
        if self.maybe("false"): return Literal(False,"bool")
        if self.maybe("["):
            items=[]
            if not self.at("]"):
                while True:
                    items.append(self.expr())
                    if not self.maybe(","): break
            self.take("]")
            return ArrayLiteral(items)
        if self.at("IDENT"):
            name=self.take("IDENT").value
            name=self.try_type_application(name)
            if self.maybe("::"):
                variant=self.take("IDENT").value
                payload=None
                if self.maybe("("):
                    payload=self.expr()
                    self.take(")")
                return EnumValue(name,variant,payload)
            if self.at("{") and (self.toks[self.i + 1].kind == "}" or (self.toks[self.i + 1].kind == "IDENT" and self.toks[self.i + 2].kind == ":")):
                self.take("{"); fields=[]
                if not self.at("}"):
                    while True:
                        fn=self.take("IDENT").value; self.take(":"); fields.append((fn,self.expr()))
                        if not self.maybe(","): break
                self.take("}"); return StructInit(name,fields)
            if self.maybe("("):
                args=[]
                if not self.at(")"):
                    while True:
                        args.append(self.expr())
                        if not self.maybe(","): break
                self.take(")"); return Call(name,args)
            return VarRef(name)
        if self.maybe("("):
            e=self.expr(); self.take(")"); return e
        raise NexusError(f"unexpected token {t.kind}", code="NX1104", token=t)

# ----------------------------- Program loading -----------------------------

def parse_file(path: Path) -> Program:
    if not path.exists():
        raise NexusError(f"source file not found: {path}", code="NX1201")
    text = path.read_text(encoding="utf-8")
    return Parser(Lexer(text, str(path)).tokens()).parse()

def merge_programs(programs: List[Program]) -> Program:
    # Imports are loaded before the root source; preserve the root module identity.
    module = programs[-1].module if programs else None
    return Program(
        module,
        [],
        [x for p in programs for x in p.consts],
        [x for p in programs for x in p.structs],
        [x for p in programs for x in p.enums],
        [x for p in programs for x in p.traits],
        [x for p in programs for x in p.impls],
        [x for p in programs for x in p.functions],
        set().union(*(p.capabilities for p in programs)),
        next((p.kernel_profile for p in programs if p.kernel_profile is not None), None),
    )

def load_program(path: Path) -> Program:
    seen: set[Path] = set()
    ordered: list[Program] = []

    def rec(p: Path):
        p = p.resolve()
        if p in seen: return
        seen.add(p)
        prog = parse_file(p)
        for imp in prog.imports:
            candidate = p.parent / f"{imp.name}.nx"
            if not candidate.exists():
                raise NexusError(f"cannot resolve import '{imp.name}' from {p}", code="NX1202")
            rec(candidate)
        ordered.append(prog)

    rec(path)
    merged=merge_programs(ordered)
    # Nexus 1.7 core tagged types are always available without imports.
    builtin_enums=[
        EnumDecl("Option",[EnumVariant("Some","T"),EnumVariant("None")],True,["T"]),
        EnumDecl("Result",[EnumVariant("Ok","T"),EnumVariant("Err","E")],True,["T","E"]),
    ]
    existing={e.name for e in merged.enums}
    for en in builtin_enums:
        if en.name in existing: raise NexusError(f"'{en.name}' is a reserved Nexus core type", code="NX1210")
    merged.enums=builtin_enums+merged.enums
    return merged

# ----------------------------- Semantic analysis + C backend -----------------------------

TYPEMAP = {
    "void": "void", "i32": "int32_t", "i64": "int64_t", "u32": "uint32_t", "u64": "uint64_t",
    "f32": "float", "f64": "double", "bool": "bool", "str": "const char *",
}
NUMERIC={"i32","i64","u32","u64","f32","f64"}; INTEGER={"i32","i64","u32","u64"}
KERNEL_BUILTINS={"cpu_halt","cpu_pause","interrupts_disable","interrupts_enable","io_read8","io_write8","io_read16","io_write16","io_read32","io_write32","volatile_read8","volatile_write8","volatile_read32","volatile_write32","volatile_read64","volatile_write64","mmio_read64","mmio_write64","read_cr0","write_cr0","read_cr2","read_cr3","write_cr3","read_cr4","write_cr4","stac","clac","invalidate_page","interrupt_stub_address","page_fault_stub_address","timer_stub_address","lapic_timer_stub_address","reschedule_stub_address","user_syscall_stub_address","user_enter","user_return","user_enter_context","user_return_context","ap_entry_address","spurious_stub_address","thread_entry_stub_address","context_switch","read_msr","write_msr","cpuid_eax","cpuid_ebx","cpuid_ecx","cpuid_edx","read_tsc","load_idt","load_gdt","load_tr","read_cs","reload_cs","reload_data_segments","ts_fault_stub_address","np_fault_stub_address","ss_fault_stub_address","gp_fault_stub_address"}
BUILTINS={"print","len","assert","addr","new","vector","push","get","concat","contains","starts_with","apply","channel","send","recv","close_channel","atomic","atomic_load","atomic_store","atomic_add","use_capability","has_capability"} | KERNEL_BUILTINS
PRIVILEGED_EFFECTS={"network","filesystem","process","device","graphics","audio","storage","boot","system"}

class CBackend:
    def __init__(self, program: Program):
        self.p=program; self.capabilities=set(program.capabilities); self.funcs={}; self.structs={}; self.enums={}; self.traits={}; self.impls=set(); self.impl_decls=[]; self.impl_methods={}; self.consts={}
        self.lines=[]; self.ind=0; self.env={}; self.mutable={}; self.current_return="void"; self.loop_depth=0; self.unsafe_depth=0; self.current_pure=False; self.current_effects=None; self.current_has_spawn=False; self.match_counter=0; self.try_counter=0; self.deferred=[]; self.current_type_subst={}; self.generic_specs={}; self.lambda_bindings={}; self.defer_scopes=[]; self.resource_scopes=[]
        self._register()

    def _register(self):
        names=set()
        for tr in self.p.traits:
            if tr.name in self.traits: raise NexusError(f"duplicate trait: {tr.name}", code="NX2020")
            self.traits[tr.name]=tr
        for imp in self.p.impls:
            if imp.trait not in self.traits: raise NexusError(f"impl references unknown trait: {imp.trait}", code="NX2021")
            self.impls.add((imp.trait,imp.typ)); self.impl_decls.append(imp)
            tr=self.traits[imp.trait]; required={m.name:m for m in tr.methods}; provided={m.name:m for m in imp.methods}
            missing=[n for n in required if n not in provided]
            if missing: raise NexusError(f"impl {imp.trait} for {imp.typ} missing method(s): {', '.join(missing)}", code="NX2024")
            if imp.methods:
                for mn,m in provided.items():
                    if mn not in required: raise NexusError(f"method {mn} is not part of trait {imp.trait}", code="NX2025")
                    sig=required[mn]
                    if len(m.params)!=len(sig.params): raise NexusError(f"method {mn} parameter count does not match trait", code="NX2026")
                    for got,want in zip(m.params,sig.params):
                        wt=imp.typ if want.typ=="Self" else want.typ
                        if got.typ!=wt: raise NexusError(f"method {mn} parameter {got.name} expects {wt}, got {got.typ}", code="NX2027")
                    wr=imp.typ if sig.ret=="Self" else sig.ret
                    if m.ret!=wr: raise NexusError(f"method {mn} return expects {wr}, got {m.ret}", code="NX2028")
                    self.impl_methods[(imp.typ,mn)]=(imp,m)
        for s in self.p.structs:
            if s.name in names or s.name in TYPEMAP: raise NexusError(f"duplicate type name: {s.name}", code="NX2001")
            names.add(s.name); self.structs[s.name]=s
            seen=set()
            if len(set(s.type_params)) != len(s.type_params): raise NexusError(f"duplicate generic type parameter in struct {s.name}", code="NX2016")
            for f in s.fields:
                if f.name in seen: raise NexusError(f"duplicate field '{f.name}' in struct {s.name}", code="NX2002")
                seen.add(f.name)
        for e in self.p.enums:
            if e.name in names or e.name in TYPEMAP: raise NexusError(f"duplicate type name: {e.name}", code="NX2003")
            names.add(e.name); self.enums[e.name]=e
            if len(set(e.type_params)) != len(e.type_params): raise NexusError(f"duplicate generic type parameter in enum {e.name}", code="NX2017")
            variant_names=[v.name for v in e.variants]
            if len(set(variant_names)) != len(variant_names): raise NexusError(f"duplicate enum variant in {e.name}", code="NX2004")
        for trait_name,typ in sorted(self.impls):
            self.require_type(typ,f"impl {trait_name} for {typ}",False)
        for c in self.p.consts:
            if c.name in self.consts: raise NexusError(f"duplicate constant: {c.name}", code="NX2005")
            self.consts[c.name]=c
        for f in self.p.functions:
            if f.name in self.funcs or f.name in BUILTINS: raise NexusError(f"duplicate or reserved function name: {f.name}", code="NX2006")
            self.funcs[f.name]=f
        # validate type references now all user types are known
        for s in self.p.structs:
            pseudo=Function(s.name,[],"void",[],type_params=s.type_params)
            for fld in s.fields:
                self.require_function_type(fld.typ,pseudo, f"field {s.name}.{fld.name}")
        for e in self.p.enums:
            pseudo=Function(e.name,[],"void",[],type_params=e.type_params)
            for v in e.variants:
                if v.payload: self.require_function_type(v.payload,pseudo,f"payload {e.name}::{v.name}")
        for c in self.p.consts:
            self.require_value_type(c.typ, f"constant {c.name}")
            if self.ref_parts(c.typ): raise NexusError("reference constants are not allowed", code="NX2012")
        for f in self.p.functions:
            if len(set(f.type_params)) != len(f.type_params): raise NexusError(f"duplicate generic type parameter in {f.name}", code="NX2014")
            for tp,traits in f.constraints.items():
                if tp not in f.type_params: raise NexusError(f"constraint references unknown type parameter {tp} in {f.name}", code="NX2022")
                for tr in traits:
                    if tr not in self.traits: raise NexusError(f"unknown trait constraint {tr} in {f.name}", code="NX2023")
            self.require_function_type(f.ret,f, f"return type of {f.name}", allow_void=True)
            seen=set()
            for p in f.params:
                self.require_function_type(p.typ,f, f"parameter {f.name}.{p.name}", allow_void=False)
                if p.name in seen: raise NexusError(f"duplicate parameter '{p.name}' in function {f.name}", code="NX2007")
                seen.add(p.name)
            if f.type_params:
                used=set()
                for prm in f.params:
                    used |= self.type_params_in(prm.typ,set(f.type_params))
                missing=[tp for tp in f.type_params if tp not in used]
                if missing: raise NexusError(f"generic type parameter(s) must be inferable from parameters in {f.name}: {', '.join(missing)}", code="NX2015")

    @staticmethod
    def ref_parts(t):
        if not isinstance(t,str): return None
        if t.startswith("&mut "): return (t[5:], True)
        if t.startswith("&"): return (t[1:], False)
        return None
    @staticmethod
    def generic_parts(t):
        if not isinstance(t,str) or "<" not in t or not t.endswith(">"): return None
        pos=t.find("<"); base=t[:pos]; body=t[pos+1:-1]; args=[]; start=0; depth=0
        for i,ch in enumerate(body):
            if ch=="<": depth+=1
            elif ch==">": depth-=1
            elif ch=="," and depth==0:
                args.append(body[start:i]); start=i+1
        args.append(body[start:])
        return base,args
    @classmethod
    def rebuild_generic(cls,base,args): return base+"<"+",".join(args)+">"
    @classmethod
    def owned_parts(cls,t):
        gp=cls.generic_parts(t)
        return gp[1][0] if gp and gp[0]=="Owned" and len(gp[1])==1 else None
    @classmethod
    def vector_parts(cls,t):
        gp=cls.generic_parts(t)
        return gp[1][0] if gp and gp[0]=="Vector" and len(gp[1])==1 else None
    @classmethod
    def task_parts(cls,t):
        gp=cls.generic_parts(t)
        return gp[1][0] if gp and gp[0]=="Task" and len(gp[1])==1 else None
    @classmethod
    def channel_parts(cls,t):
        gp=cls.generic_parts(t)
        return gp[1][0] if gp and gp[0]=="Channel" and len(gp[1])==1 else None
    @classmethod
    def atomic_parts(cls,t):
        gp=cls.generic_parts(t)
        return gp[1][0] if gp and gp[0]=="Atomic" and len(gp[1])==1 else None

    def is_send_type(self,t):
        if t in INTEGER or t=="bool": return True
        if self.channel_parts(t) or self.atomic_parts(t): return True
        if self.ref_parts(t) or self.owned_parts(t) or self.vector_parts(t) or self.task_parts(t): return False
        decl,subst=self.aggregate_decl(t)
        if isinstance(decl,StructDecl): return all(self.is_send_type(self.materialize_type(f.typ,subst)) for f in decl.fields)
        if isinstance(decl,EnumDecl): return all(v.payload is None or self.is_send_type(self.materialize_type(v.payload,subst)) for v in decl.variants)
        return False
    def aggregate_decl(self,t):
        gp=self.generic_parts(t)
        if not gp: return (self.structs.get(t) or self.enums.get(t), {})
        base,args=gp; decl=self.structs.get(base) or self.enums.get(base)
        if not decl or not getattr(decl,"type_params",[]): return (None,{})
        if len(args)!=len(decl.type_params): return (None,{})
        return decl,dict(zip(decl.type_params,args))
    @classmethod
    def type_params_in(cls,t,candidates):
        rp=cls.ref_parts(t)
        if rp: return cls.type_params_in(rp[0],candidates)
        gp=cls.generic_parts(t)
        if gp:
            out=set()
            for a in gp[1]: out |= cls.type_params_in(a,candidates)
            return out
        return {t} if t in candidates else set()
    def require_function_type(self,t,f,where,allow_void=False):
        rp=self.ref_parts(t)
        if rp:
            inner=rp[0]
            return self.require_function_type(inner,f,where,False)
        if t in f.type_params: return
        gp=self.generic_parts(t)
        if gp:
            base,args=gp
            if base in {"Owned","Vector","Task","Channel","Atomic"}:
                if len(args)!=1: raise NexusError(f"unknown or invalid generic type '{t}' in {where}", code="NX2008")
                self.require_function_type(args[0],f,where,False); return
            decl=self.structs.get(base) or self.enums.get(base)
            if not decl or len(args)!=len(getattr(decl,"type_params",[])):
                raise NexusError(f"unknown or invalid generic type '{t}' in {where}", code="NX2008")
            for a in args: self.require_function_type(a,f,where,False)
            return
        self.require_type(t,where,allow_void)
    def materialize_type(self,t,subst=None):
        subst=self.current_type_subst if subst is None else subst
        rp=self.ref_parts(t)
        if rp:
            inner,mutable=rp
            return ("&mut " if mutable else "&") + self.materialize_type(inner,subst)
        gp=self.generic_parts(t)
        if gp: return self.rebuild_generic(gp[0],[self.materialize_type(a,subst) for a in gp[1]])
        return subst.get(t,t)
    @staticmethod
    def _mangle_type(t):
        out=[]
        for ch in t:
            out.append(ch if ch.isalnum() or ch=='_' else '_')
        return ''.join(out).strip('_') or 'type'
    def generic_cname(self,fn,mapping):
        return fn.name+"__nxg__"+"__".join(self._mangle_type(mapping[tp]) for tp in fn.type_params)
    def match_generic_type(self,pattern,actual,type_params,mapping):
        pr=self.ref_parts(pattern); ar=self.ref_parts(actual)
        if pr:
            if not ar or pr[1]!=ar[1]: return False
            return self.match_generic_type(pr[0],ar[0],type_params,mapping)
        if pattern in type_params:
            old=mapping.get(pattern)
            if old is None: mapping[pattern]=actual; return True
            return self.compatible(old,actual) and self.compatible(actual,old)
        pg=self.generic_parts(pattern); ag=self.generic_parts(actual)
        if pg:
            if not ag or pg[0]!=ag[0] or len(pg[1])!=len(ag[1]): return False
            return all(self.match_generic_type(p,a,type_params,mapping) for p,a in zip(pg[1],ag[1]))
        return self.compatible(self.materialize_type(pattern),actual)
    def is_type(self,t):
        rp=self.ref_parts(t)
        if rp: return self.is_type(rp[0])
        gp=self.generic_parts(t)
        if gp:
            base,args=gp
            if base in {"Owned","Vector","Task","Channel","Atomic"}: return len(args)==1 and self.is_type(args[0])
            decl=self.structs.get(base) or self.enums.get(base)
            return bool(decl and len(args)==len(getattr(decl,"type_params",[])) and all(self.is_type(a) for a in args))
        decl=self.structs.get(t) or self.enums.get(t)
        if decl and getattr(decl,"type_params",[]): return False
        return t in TYPEMAP or decl is not None
    def require_type(self,t,where,allow_void=False):
        if not self.is_type(t) or (t=="void" and not allow_void): raise NexusError(f"unknown or invalid type '{t}' in {where}", code="NX2008")
    def require_value_type(self,t,where): self.require_type(t,where,False)
    def ctype(self,t):
        rp=self.ref_parts(t)
        if rp:
            inner,mutable=rp
            return f"{self.ctype(inner)} *" if mutable else f"const {self.ctype(inner)} *"
        gp=self.generic_parts(t)
        if gp:
            if gp[0]=="Owned": return self.ctype(gp[1][0])+" *"
            if gp[0]=="Vector": return "nx_Vector"
            if gp[0]=="Task": return "nx_Task"
            if gp[0]=="Channel": return "nx_Channel"
            if gp[0]=="Atomic": return "nx_Atomic"
            return "nx_"+gp[0]+"__"+"__".join(self._mangle_type(a) for a in gp[1])
        if t in TYPEMAP: return TYPEMAP[t]
        if t in self.structs: return f"nx_{t}"
        if t in self.enums: return f"nx_{t}"
        raise NexusError(f"unknown type: {t}", code="NX2009")
    def emit(self,s=""): self.lines.append("    "*self.ind+s)
    @staticmethod
    def compatible(expected,actual): return expected==actual or (expected in NUMERIC and actual in NUMERIC)
    @staticmethod
    def array_type(elem,n): return f"array<{elem},{n}>"
    @staticmethod
    def array_parts(t):
        if not (isinstance(t,str) and t.startswith("array<") and t.endswith(">")): return None
        body=t[6:-1]; elem,n=body.rsplit(",",1); return elem,int(n)
    @staticmethod
    def enum_variant(en, name):
        for v in en.variants:
            if v.name == name: return v
        return None
    @staticmethod
    def enum_has_payload(en): return any(v.payload is not None for v in en.variants)

    def require_effect(self,effect):
        if self.current_pure: raise NexusError(f"pure function cannot perform effect '{effect}'", code="NX2150")
        if effect in PRIVILEGED_EFFECTS and effect not in self.capabilities:
            raise NexusError(f"capability '{effect}' is not declared; add capabilities({effect})", code="NX2154")
        if self.current_effects is not None and effect not in self.current_effects:
            raise NexusError(f"function effect set does not permit '{effect}'; add effects({effect})", code="NX2151")
    def resolve_user_call(self,e):
        fn=self.funcs.get(e.name)
        if not fn: raise NexusError(f"unknown function: {e.name}", code="NX2116")
        if self.current_pure and not fn.pure: raise NexusError(f"pure function cannot call impure function {e.name}", code="NX2145")
        if self.current_effects is not None and not self.current_pure:
            if fn.effects is None: raise NexusError(f"effect-restricted function cannot call effect-inferred function {e.name}", code="NX2152")
            missing=set(fn.effects)-set(self.current_effects)
            if missing: raise NexusError(f"call to {e.name} requires effect(s): {', '.join(sorted(missing))}", code="NX2153")
        if len(e.args)!=len(fn.params): raise NexusError(f"{e.name} expects {len(fn.params)} arguments, got {len(e.args)}", code="NX2117")
        actuals=[self.infer(arg) for arg in e.args]
        if not fn.type_params:
            for actual,param in zip(actuals,fn.params):
                expected=self.materialize_type(param.typ)
                if not self.compatible(expected,actual): raise NexusError(f"argument '{param.name}' of {e.name} expects {expected}, got {actual}", code="NX2118")
            ret=self.materialize_type(fn.ret)
            if fn.is_async:
                self.require_effect("task")
                for actual,param in zip(actuals,fn.params):
                    if not self.is_send_type(actual): raise NexusError(f"async parameter '{param.name}' type {actual} is not Send-safe", code="NX2186")
                return fn,{},f"Task<{ret}>",f"nx_async_start_{fn.name}"
            return fn,{},ret,fn.name
        mapping={}
        for actual,param in zip(actuals,fn.params):
            if not self.match_generic_type(param.typ,actual,set(fn.type_params),mapping):
                raise NexusError(f"argument '{param.name}' of generic {e.name} does not match {param.typ}; got {actual}", code="NX2170")
        unresolved=[tp for tp in fn.type_params if tp not in mapping]
        if unresolved: raise NexusError(f"cannot infer generic type parameter(s) for {e.name}: {', '.join(unresolved)}", code="NX2171")
        for tp,traits in fn.constraints.items():
            concrete=mapping[tp]
            for tr in traits:
                if (tr,concrete) not in self.impls:
                    raise NexusError(f"generic {e.name} requires {concrete}: {tr}", code="NX2172")
        key=tuple(mapping[tp] for tp in fn.type_params)
        self.generic_specs.setdefault(fn.name,{})[key]=dict(mapping)
        ret=self.materialize_type(fn.ret,mapping)
        if fn.is_async:
            raise NexusError("generic async functions are deferred beyond Nexus 2.6", code="NX2184")
        return fn,mapping,ret,self.generic_cname(fn,mapping)
    def infer(self,e):
        if isinstance(e,Literal): return e.typ
        if isinstance(e,VarRef):
            if e.name in self.env: return self.env[e.name]
            if e.name in self.consts: return self.consts[e.name].typ
            raise NexusError(f"unknown variable or constant: {e.name}", code="NX2101")
        if isinstance(e,Move):
            if e.name not in self.env: raise NexusError(f"cannot move unknown local: {e.name}", code="NX2160")
            return self.env[e.name]
        if isinstance(e,Borrow):
            if e.name not in self.env: raise NexusError(f"cannot borrow unknown local: {e.name}", code="NX2161")
            if e.mutable and not self.mutable.get(e.name,False): raise NexusError(f"mutable borrow requires `var` binding: {e.name}", code="NX2162")
            base=self.env[e.name]
            if self.ref_parts(base): raise NexusError("borrowing a reference is not supported in the 1.3 borrow profile", code="NX2163")
            return ("&mut " if e.mutable else "&")+base
        if isinstance(e,Unary):
            t=self.infer(e.expr)
            if e.op=="*":
                rp=self.ref_parts(t)
                if rp: return rp[0]
                owned=self.owned_parts(t)
                if owned: return owned
                raise NexusError(f"dereference requires a reference or Owned<T>, got {t}", code="NX2164")
            if e.op=="!":
                if t!="bool": raise NexusError("logical ! requires bool", code="NX2102")
                return "bool"
            if t not in NUMERIC: raise NexusError("unary - requires numeric value", code="NX2103")
            return t
        if isinstance(e,Binary):
            lt,rt=self.infer(e.left),self.infer(e.right)
            if e.op in {"&&","||"}:
                if lt!="bool" or rt!="bool": raise NexusError(f"operator {e.op} requires bool operands", code="NX2104")
                return "bool"
            if e.op in {"==","!="}:
                if not self.compatible(lt,rt): raise NexusError(f"cannot compare {lt} and {rt}", code="NX2105")
                return "bool"
            if e.op in {"<",">","<=",">="}:
                if lt not in NUMERIC or rt not in NUMERIC: raise NexusError(f"operator {e.op} requires numeric operands", code="NX2106")
                return "bool"
            if e.op in {"+","-","*","/","%"}:
                if lt not in NUMERIC or rt not in NUMERIC: raise NexusError(f"operator {e.op} requires numeric operands", code="NX2107")
                if e.op=="%" and (lt not in INTEGER or rt not in INTEGER): raise NexusError("operator % requires integer operands", code="NX2108")
                for pref in ("f64","f32","u64","i64","u32","i32"):
                    if pref in {lt,rt}: return pref
            raise NexusError(f"unknown operator {e.op}", code="NX2109")
        if isinstance(e,ArrayLiteral):
            if not e.items: raise NexusError("cannot infer type of empty array", code="NX2130")
            et=self.infer(e.items[0])
            if et=="void" or self.array_parts(et): raise NexusError("nested/void arrays are not supported in the current fixed-array profile", code="NX2131")
            for item in e.items[1:]:
                it=self.infer(item)
                if not self.compatible(et,it): raise NexusError(f"array items must share a type; expected {et}, got {it}", code="NX2132")
            return self.array_type(et,len(e.items))
        if isinstance(e,Index):
            ot=self.infer(e.obj); parts=self.array_parts(ot)
            if not parts: raise NexusError(f"indexing requires an array, got {ot}", code="NX2133")
            if self.infer(e.index) not in INTEGER: raise NexusError("array index must be an integer", code="NX2134")
            if isinstance(e.index,Literal) and e.index.typ in INTEGER and not (0 <= int(e.index.value) < parts[1]):
                raise NexusError(f"array index {e.index.value} is out of bounds for length {parts[1]}", code="NX2135")
            return parts[0]
        if isinstance(e,AwaitExpr):
            self.require_effect("task")
            inner=self.infer(e.expr); result=self.task_parts(inner)
            if result is None: raise NexusError(f"await requires Task<T>, got {inner}", code="NX2183")
            return result
        if isinstance(e,TryExpr):
            inner=self.infer(e.expr); gp=self.generic_parts(inner)
            if not gp or gp[0] not in {"Result","Option"}: raise NexusError(f"? requires Result<T,E> or Option<T>, got {inner}", code="NX2180")
            outer=self.generic_parts(self.current_return)
            if not outer or outer[0]!=gp[0]: raise NexusError(f"? in this function requires return type {gp[0]}<...>", code="NX2181")
            if gp[0]=="Result":
                if len(gp[1])!=2 or len(outer[1])!=2 or not self.compatible(gp[1][1],outer[1][1]): raise NexusError("? requires matching Result error type", code="NX2182")
                return gp[1][0]
            return gp[1][0]
        if isinstance(e,Call):
            if e.name=="apply":
                if len(e.args)!=2 or not isinstance(e.args[0],Lambda): raise NexusError("apply() requires a lambda and one value", code="NX2199")
                lam=e.args[0]; at=self.infer(e.args[1]); old=self.env.get(lam.param, None); had=lam.param in self.env
                self.env[lam.param]=at
                try: return self.infer(lam.body)
                finally:
                    if had: self.env[lam.param]=old
                    else: self.env.pop(lam.param,None)
            if e.name=="vector":
                self.require_effect("alloc")
                if len(e.args)!=1 or not isinstance(e.args[0],ArrayLiteral): raise NexusError("vector() requires one array literal", code="NX2190")
                at=self.infer(e.args[0]); ap=self.array_parts(at)
                if not ap: raise NexusError("vector() requires an array literal", code="NX2191")
                return f"Vector<{ap[0]}>"
            if e.name=="push":
                self.require_effect("alloc")
                if len(e.args)!=2: raise NexusError("push() requires &mut Vector<T> and value", code="NX2192")
                rt=self.infer(e.args[0]); rp=self.ref_parts(rt)
                if not rp or not rp[1] or not self.vector_parts(rp[0]): raise NexusError("push() first argument must be &mut Vector<T>", code="NX2193")
                elem=self.vector_parts(rp[0]); vt=self.infer(e.args[1])
                if not self.compatible(elem,vt): raise NexusError(f"push() expects {elem}, got {vt}", code="NX2194")
                return "void"
            if e.name=="get":
                if len(e.args)!=2: raise NexusError("get() requires &Vector<T> and integer index", code="NX2195")
                rt=self.infer(e.args[0]); rp=self.ref_parts(rt)
                if not rp or not self.vector_parts(rp[0]): raise NexusError("get() first argument must be &Vector<T>", code="NX2196")
                if self.infer(e.args[1]) not in INTEGER: raise NexusError("get() index must be integer", code="NX2197")
                return self.vector_parts(rp[0])
            if e.name in {"concat","contains","starts_with","apply"}:
                if len(e.args)!=2 or any(self.infer(a)!="str" for a in e.args): raise NexusError(f"{e.name}() requires two str values", code="NX2198")
                if e.name=="concat": self.require_effect("alloc")
                return "str" if e.name=="concat" else "bool"
            if e.name=="channel":
                self.require_effect("task"); self.require_effect("alloc")
                if len(e.args)!=1: raise NexusError("channel() takes one type-witness value", code="NX2199")
                elem=self.infer(e.args[0])
                if elem=="void" or self.ref_parts(elem): raise NexusError("channel() requires a value type witness", code="NX2199")
                return f"Channel<{elem}>"
            if e.name=="send":
                self.require_effect("task")
                if len(e.args)!=2: raise NexusError("send() requires Channel<T> and value", code="NX2199")
                ct=self.infer(e.args[0]); elem=self.channel_parts(ct)
                if elem is None: raise NexusError("send() first argument must be Channel<T>", code="NX2199")
                vt=self.infer(e.args[1])
                if not self.compatible(elem,vt): raise NexusError(f"send() expects {elem}, got {vt}", code="NX2199")
                return "void"
            if e.name=="recv":
                self.require_effect("task")
                if len(e.args)!=1: raise NexusError("recv() requires Channel<T>", code="NX2199")
                ct=self.infer(e.args[0]); elem=self.channel_parts(ct)
                if elem is None: raise NexusError("recv() argument must be Channel<T>", code="NX2199")
                return elem
            if e.name=="close_channel":
                self.require_effect("task")
                if len(e.args)!=1 or self.channel_parts(self.infer(e.args[0])) is None: raise NexusError("close_channel() requires Channel<T>", code="NX2199")
                return "void"
            if e.name in {"use_capability","has_capability"}:
                if len(e.args)!=1 or not isinstance(e.args[0],Literal) or e.args[0].typ!="str": raise NexusError(f"{e.name}() requires one string literal", code="NX2199")
                cap=e.args[0].value
                if cap not in PRIVILEGED_EFFECTS: raise NexusError(f"unknown privileged capability '{cap}'", code="NX2199")
                if e.name=="use_capability": self.require_effect(cap); return "void"
                return "bool"
            if e.name=="atomic":
                self.require_effect("alloc"); self.require_effect("shared")
                if len(e.args)!=1: raise NexusError("atomic() takes one integer value", code="NX2199")
                t=self.infer(e.args[0])
                if t not in INTEGER: raise NexusError("atomic() currently supports integer types", code="NX2199")
                return f"Atomic<{t}>"
            if e.name in {"atomic_load","atomic_store","atomic_add","use_capability","has_capability"}:
                self.require_effect("shared")
                if not e.args: raise NexusError(f"{e.name}() requires Atomic<T>", code="NX2199")
                t=self.infer(e.args[0]); elem=self.atomic_parts(t)
                if elem is None: raise NexusError(f"{e.name}() first argument must be Atomic<T>", code="NX2199")
                if e.name=="atomic_load":
                    if len(e.args)!=1: raise NexusError("atomic_load() takes one argument", code="NX2199")
                    return elem
                if len(e.args)!=2: raise NexusError(f"{e.name}() takes Atomic<T> and value", code="NX2199")
                vt=self.infer(e.args[1])
                if not self.compatible(elem,vt): raise NexusError(f"{e.name}() expects {elem}, got {vt}", code="NX2199")
                return elem if e.name=="atomic_add" else "void"
            if e.name in KERNEL_BUILTINS:
                if not self.p.kernel_profile: raise NexusError(f"{e.name}() is only available in a Nexus kernel profile", code="NX4610")
                sig={
                    "cpu_halt":(0,"void"), "cpu_pause":(0,"void"), "interrupts_disable":(0,"void"), "interrupts_enable":(0,"void"),
                    "io_read8":(1,"u32"), "io_write8":(2,"void"), "io_read16":(1,"u32"), "io_write16":(2,"void"), "io_read32":(1,"u32"), "io_write32":(2,"void"),
                    "volatile_read8":(1,"u32"), "volatile_write8":(2,"void"),
                    "volatile_read32":(1,"u32"), "volatile_write32":(2,"void"),
                    "volatile_read64":(1,"u64"), "volatile_write64":(2,"void"),
                    "mmio_read64":(1,"u64"), "mmio_write64":(2,"void"),
                    "read_cr0":(0,"u64"), "write_cr0":(1,"void"), "read_cr2":(0,"u64"), "read_cr3":(0,"u64"), "write_cr3":(1,"void"), "read_cr4":(0,"u64"), "write_cr4":(1,"void"), "stac":(0,"void"), "clac":(0,"void"), "invalidate_page":(1,"void"),
                    "interrupt_stub_address":(0,"u64"), "page_fault_stub_address":(0,"u64"), "timer_stub_address":(0,"u64"), "lapic_timer_stub_address":(0,"u64"), "reschedule_stub_address":(0,"u64"), "user_syscall_stub_address":(0,"u64"), "user_enter":(4,"void"), "user_return":(2,"void"), "user_enter_context":(4,"void"), "user_return_context":(2,"void"), "ap_entry_address":(0,"u64"), "spurious_stub_address":(0,"u64"), "thread_entry_stub_address":(0,"u64"), "context_switch":(2,"void"), "read_msr":(1,"u64"), "write_msr":(2,"void"), "cpuid_eax":(2,"u64"), "cpuid_ebx":(2,"u64"), "cpuid_ecx":(2,"u64"), "cpuid_edx":(2,"u64"), "read_tsc":(0,"u64"), "load_idt":(2,"void"), "load_gdt":(2,"void"), "load_tr":(1,"void"), "read_cs":(0,"u64"), "reload_cs":(1,"void"), "reload_data_segments":(1,"void"), "ts_fault_stub_address":(0,"u64"), "np_fault_stub_address":(0,"u64"), "ss_fault_stub_address":(0,"u64"), "gp_fault_stub_address":(0,"u64"),
                }
                argc,ret=sig[e.name]
                if len(e.args)!=argc: raise NexusError(f"{e.name}() expects {argc} argument(s)", code="NX4611")
                for a in e.args:
                    if self.infer(a) not in INTEGER: raise NexusError(f"{e.name}() requires integer arguments", code="NX4612")
                return ret
            if e.name=="new":
                self.require_effect("alloc")
                if len(e.args)!=1: raise NexusError("new() takes exactly one value", code="NX2185")
                inner=self.infer(e.args[0])
                if inner=="void" or self.ref_parts(inner): raise NexusError("new() requires an owned value type", code="NX2186")
                return f"Owned<{inner}>"
            if e.name=="print":
                self.require_effect("io")
                if len(e.args)!=1: raise NexusError("print() takes exactly one argument", code="NX2110")
                t=self.infer(e.args[0])
                if t in self.structs: raise NexusError("print() does not yet format structs", code="NX2111")
                return "void"
            if e.name=="len":
                if len(e.args)!=1: raise NexusError("len() takes exactly one argument", code="NX2112")
                lt=self.infer(e.args[0])
                if lt!="str" and not self.array_parts(lt) and not self.vector_parts(lt): raise NexusError("len() requires str, array, or Vector<T>", code="NX2112")
                return "i64"
            if e.name=="assert":
                self.require_effect("panic")
                if len(e.args) not in {1,2}: raise NexusError("assert() takes bool and optional str message", code="NX2113")
                if self.infer(e.args[0])!="bool": raise NexusError("assert() first argument must be bool", code="NX2114")
                if len(e.args)==2 and self.infer(e.args[1])!="str": raise NexusError("assert() message must be str", code="NX2115")
                return "void"
            if e.name=="addr":
                self.require_effect("unsafe")
                if self.unsafe_depth==0: raise NexusError("addr() requires an unsafe block", code="NX2143")
                if len(e.args)!=1 or not isinstance(e.args[0],VarRef): raise NexusError("addr() requires exactly one variable", code="NX2144")
                self.infer(e.args[0]); return "u64"
            fn,mapping,ret,cname=self.resolve_user_call(e)
            return ret
        if isinstance(e,MethodCall):
            ot=self.infer(e.obj); found=self.impl_methods.get((ot,e.method))
            if not found: raise NexusError(f"type {ot} has no trait method '{e.method}'", code="NX2188")
            imp,m=found
            if not m.params: raise NexusError(f"trait method {e.method} requires receiver parameter", code="NX2189")
            if len(e.args)+1!=len(m.params): raise NexusError(f"method {e.method} expects {len(m.params)-1} arguments, got {len(e.args)}", code="NX2199")
            vals=[ot]+[self.infer(a) for a in e.args]
            for actual,param in zip(vals,m.params):
                if not self.compatible(param.typ,actual): raise NexusError(f"method {e.method} argument expects {param.typ}, got {actual}", code="NX2187")
            return m.ret
        if isinstance(e,StructInit):
            s,subst=self.aggregate_decl(e.name)
            if not s or not isinstance(s,StructDecl): raise NexusError(f"unknown struct: {e.name}", code="NX2119")
            provided=dict(e.fields)
            if len(provided)!=len(e.fields): raise NexusError(f"duplicate field in {e.name} initializer", code="NX2120")
            expected={f.name:self.materialize_type(f.typ,subst) for f in s.fields}
            missing=[n for n in expected if n not in provided]; extra=[n for n in provided if n not in expected]
            if missing: raise NexusError(f"missing field(s) for {e.name}: {', '.join(missing)}", code="NX2121")
            if extra: raise NexusError(f"unknown field(s) for {e.name}: {', '.join(extra)}", code="NX2122")
            for name,ex in e.fields:
                at=self.infer(ex); et=expected[name]
                if not self.compatible(et,at): raise NexusError(f"field {e.name}.{name} expects {et}, got {at}", code="NX2123")
            return e.name
        if isinstance(e,FieldAccess):
            ot=self.infer(e.obj)
            rp=self.ref_parts(ot)
            base=rp[0] if rp else ot
            s,subst=self.aggregate_decl(base)
            if not s or not isinstance(s,StructDecl): raise NexusError(f"field access requires struct or reference-to-struct, got {ot}", code="NX2124")
            for f in s.fields:
                if f.name==e.field: return self.materialize_type(f.typ,subst)
            raise NexusError(f"struct {base} has no field '{e.field}'", code="NX2125")
        if isinstance(e,EnumValue):
            en,subst=self.aggregate_decl(e.enum_name)
            if not en or not isinstance(en,EnumDecl): raise NexusError(f"unknown enum: {e.enum_name}", code="NX2126")
            variant=self.enum_variant(en,e.variant)
            if not variant: raise NexusError(f"enum {e.enum_name} has no variant {e.variant}", code="NX2127")
            if variant.payload is None and e.payload is not None:
                raise NexusError(f"enum variant {e.enum_name}::{e.variant} does not accept a payload", code="NX2128")
            if variant.payload is not None and e.payload is None:
                raise NexusError(f"enum variant {e.enum_name}::{e.variant} requires payload type {variant.payload}", code="NX2129")
            if variant.payload is not None:
                actual=self.infer(e.payload)
                expected=self.materialize_type(variant.payload,subst)
                if not self.compatible(expected,actual): raise NexusError(f"payload for {e.enum_name}::{e.variant} expects {expected}, got {actual}", code="NX2136")
            return e.enum_name
        raise NexusError("cannot infer expression type", code="NX2199")

    def expr(self,e):
        if isinstance(e,Literal):
            if e.typ=="str":
                esc=e.value.replace("\\","\\\\").replace('"','\\"').replace("\n","\\n").replace("\t","\\t").replace("\r","\\r").replace("\0","\\0")
                return f'"{esc}"'
            if e.typ=="bool": return "true" if e.value else "false"
            return repr(e.value)
        if isinstance(e,VarRef): self.infer(e); return self.lambda_bindings.get(e.name,e.name)
        if isinstance(e,Move):
            typ=self.infer(e)
            if self.owned_parts(typ): return f"({{ {self.ctype(typ)} nx_mv={e.name}; {e.name}=NULL; nx_mv; }})"
            return e.name
        if isinstance(e,Borrow): self.infer(e); return f"(&{e.name})"
        if isinstance(e,Unary): self.infer(e); return f"({e.op}{self.expr(e.expr)})"
        if isinstance(e,Binary): self.infer(e); return f"({self.expr(e.left)} {e.op} {self.expr(e.right)})"
        if isinstance(e,ArrayLiteral):
            at=self.infer(e); elem,n=self.array_parts(at)
            return f"({self.ctype(elem)}[{n}]){{ {', '.join(self.expr(x) for x in e.items)} }}"
        if isinstance(e,Index):
            ot=self.infer(e.obj); elem,n=self.array_parts(ot); idx=self.expr(e.index)
            return f"(nexus_bounds((int64_t)({idx}), {n}, __FILE__, __LINE__), ({self.expr(e.obj)})[{idx}])"
        if isinstance(e,AwaitExpr):
            rt=self.infer(e); inner=self.task_parts(self.infer(e.expr)); ct=self.ctype(inner); taskv=self.expr(e.expr)
            if inner=="void": return f"({{ nx_Task nx_t=({taskv}); nexus_task_await(&nx_t, NULL, 0); (void)0; }})"
            return f"({{ nx_Task nx_t=({taskv}); {ct} nx_r={{0}}; nexus_task_await(&nx_t, &nx_r, sizeof(nx_r)); nx_r; }})"
        if isinstance(e,TryExpr):
            inner=self.infer(e.expr); gp=self.generic_parts(inner); outer=self.generic_parts(self.current_return); n=self.try_counter; self.try_counter+=1
            tmp=f"nx_try_{n}"; val=self.expr(e.expr); ct=self.ctype(inner); oct=self.ctype(self.current_return)
            if gp[0]=="Result":
                return f"({{ {ct} {tmp}=({val}); if ({tmp}.tag==NX_Result_Err) return ({oct}){{ .tag=NX_Result_Err, .data.Err={tmp}.data.Err }}; {tmp}.data.Ok; }})"
            return f"({{ {ct} {tmp}=({val}); if ({tmp}.tag==NX_Option_None) return ({oct}){{ .tag=NX_Option_None }}; {tmp}.data.Some; }})"
        if isinstance(e,Call):
            t=self.infer(e)
            if e.name=="apply":
                lam=e.args[0]; at=self.infer(e.args[1]); av=self.expr(e.args[1]); old=self.lambda_bindings.get(lam.param); had=lam.param in self.lambda_bindings; oldt=self.env.get(lam.param); hadt=lam.param in self.env
                self.lambda_bindings[lam.param]=f"({av})"; self.env[lam.param]=at
                try: return f"({self.expr(lam.body)})"
                finally:
                    if had: self.lambda_bindings[lam.param]=old
                    else: self.lambda_bindings.pop(lam.param,None)
                    if hadt: self.env[lam.param]=oldt
                    else: self.env.pop(lam.param,None)
            if e.name=="vector":
                arr=e.args[0]; at=self.infer(arr); elem,n=self.array_parts(at); ct=self.ctype(elem)
                return f"nexus_vector_from((const void*)({ct}[{n}]){{ {', '.join(self.expr(x) for x in arr.items)} }}, {n}, sizeof({ct}))"
            if e.name=="push":
                rp=self.ref_parts(self.infer(e.args[0])); elem=self.vector_parts(rp[0]); ct=self.ctype(elem); val=self.expr(e.args[1])
                return f"nexus_vector_push((nx_Vector*)({self.expr(e.args[0])}), (const void*)&({ct}){{ {val} }}, sizeof({ct}))"
            if e.name=="get":
                rp=self.ref_parts(self.infer(e.args[0])); elem=self.vector_parts(rp[0]); ct=self.ctype(elem); idx=self.expr(e.args[1])
                return f"(*({ct}*)nexus_vector_at((nx_Vector*)({self.expr(e.args[0])}), (int64_t)({idx})))"
            if e.name=="concat": return f"nexus_str_concat({self.expr(e.args[0])}, {self.expr(e.args[1])})"
            if e.name=="contains": return f"(strstr({self.expr(e.args[0])}, {self.expr(e.args[1])}) != NULL)"
            if e.name=="starts_with": return f"(strncmp({self.expr(e.args[0])}, {self.expr(e.args[1])}, strlen({self.expr(e.args[1])})) == 0)"
            if e.name=="channel":
                elem=self.infer(e.args[0]); return f"nexus_channel_create(sizeof({self.ctype(elem)}))"
            if e.name=="send":
                elem=self.channel_parts(self.infer(e.args[0])); ct=self.ctype(elem); value=self.expr(e.args[1])
                return f"nexus_channel_send({self.expr(e.args[0])}, (const void*)&({ct}){{ {value} }}, sizeof({ct}))"
            if e.name=="recv":
                elem=self.channel_parts(self.infer(e.args[0])); ct=self.ctype(elem)
                return f"({{ {ct} nx_recv={{0}}; nexus_channel_recv({self.expr(e.args[0])}, &nx_recv, sizeof(nx_recv)); nx_recv; }})"
            if e.name=="close_channel": return f"nexus_channel_close({self.expr(e.args[0])})"
            if e.name=="use_capability": self.infer(e); return "((void)0)"
            if e.name=="has_capability":
                self.infer(e); return "true" if e.args[0].value in self.capabilities else "false"
            if e.name=="atomic": return f"nexus_atomic_create((int64_t)({self.expr(e.args[0])}))"
            if e.name=="atomic_load": return f"(({self.ctype(self.atomic_parts(self.infer(e.args[0])))})nexus_atomic_load({self.expr(e.args[0])}))"
            if e.name=="atomic_store": return f"nexus_atomic_store({self.expr(e.args[0])}, (int64_t)({self.expr(e.args[1])}))"
            if e.name=="atomic_add": return f"(({self.ctype(self.atomic_parts(self.infer(e.args[0])))})nexus_atomic_add({self.expr(e.args[0])}, (int64_t)({self.expr(e.args[1])})))"
            if e.name in KERNEL_BUILTINS:
                # Hosted C is only the semantic/reference backend for kernel profiles.
                self.infer(e)
                return "0" if e.name in {"io_read8","volatile_read64","mmio_read64"} else "((void)0)"
            if e.name=="new":
                inner=self.infer(e.args[0]); ct=self.ctype(inner); value=self.expr(e.args[0])
                return f"({{ {ct} *nx_p=({ct}*)malloc(sizeof({ct})); if (!nx_p) {{ fprintf(stderr, \"Nexus allocation failed\\n\"); abort(); }} *nx_p=({value}); nx_p; }})"
            if e.name=="print":
                a=e.args[0]; at=self.infer(a); x=self.expr(a)
                fmts={"str":"%s\\n","i32":"%d\\n","i64":"%lld\\n","u32":"%u\\n","u64":"%llu\\n","f32":"%g\\n","f64":"%g\\n","bool":"%s\\n"}
                if at in self.enums: return f'printf("%d\\n", (int){x})'
                if at=="bool": x=f'(({x}) ? "true" : "false")'
                casts={"i64":"(long long)","u64":"(unsigned long long)"}
                return f'printf("{fmts[at]}", {casts.get(at,"")}{x})'
            if e.name=="len":
                lt=self.infer(e.args[0])
                if lt=="str": return f"((int64_t)strlen({self.expr(e.args[0])}))"
                if self.vector_parts(lt): return f"((int64_t)({self.expr(e.args[0])}).len)"
                _,n=self.array_parts(lt); return str(n)
            if e.name=="addr": return f"((uint64_t)(uintptr_t)&({self.expr(e.args[0])}))"
            if e.name=="assert":
                cond=self.expr(e.args[0]); msg=self.expr(e.args[1]) if len(e.args)==2 else '"Nexus assertion failed"'
                return f"nexus_assert(({cond}), {msg}, __FILE__, __LINE__)"
            fn,mapping,ret,cname=self.resolve_user_call(e)
            return f"{cname}({', '.join(self.expr(a) for a in e.args)})"
        if isinstance(e,MethodCall):
            self.infer(e); ot=self.infer(e.obj); imp,m=self.impl_methods[(ot,e.method)]
            cname=f"nx_impl_{self._mangle_type(imp.trait)}_{self._mangle_type(imp.typ)}_{e.method}"
            return f"{cname}({', '.join([self.expr(e.obj)]+[self.expr(a) for a in e.args])})"
        if isinstance(e,StructInit):
            self.infer(e)
            s,subst=self.aggregate_decl(e.name); vals=dict(e.fields)
            parts=[f".{f.name} = {self.expr(vals[f.name])}" for f in s.fields]
            return f"({self.ctype(e.name)}){{ {', '.join(parts)} }}"
        if isinstance(e,FieldAccess):
            ot=self.infer(e.obj); rp=self.ref_parts(ot)
            return f"({self.expr(e.obj)})->{e.field}" if rp else f"({self.expr(e.obj)}).{e.field}"
        if isinstance(e,EnumValue):
            self.infer(e); en,subst=self.aggregate_decl(e.enum_name); variant=self.enum_variant(en,e.variant); tagbase=en.name
            if not self.enum_has_payload(en): return f"NX_{tagbase}_{e.variant}"
            ct=self.ctype(e.enum_name)
            if variant.payload is None: return f"({ct}){{ .tag = NX_{tagbase}_{e.variant} }}"
            return f"({ct}){{ .tag = NX_{tagbase}_{e.variant}, .data.{e.variant} = {self.expr(e.payload)} }}"
        raise NexusError("unsupported expression", code="NX2200")

    def body_has_spawn(self,body):
        for st in body:
            if isinstance(st,Spawn): return True
            if isinstance(st,If) and (self.body_has_spawn(st.then_body) or self.body_has_spawn(st.else_body)): return True
            if isinstance(st,(While,ForRange,ForEach,UnsafeBlock)) and self.body_has_spawn(st.body): return True
            if isinstance(st,MatchStmt) and any(self.body_has_spawn(a.body) for a in st.arms): return True
        return False
    def emit_sync(self):
        if self.current_has_spawn:
            self.emit("for (size_t nx_j = 0; nx_j < nx_thread_count; ++nx_j) pthread_join(nx_threads[nx_j], NULL);")
            self.emit("nx_thread_count = 0;")
    def _push_cleanup_scope(self):
        self.defer_scopes.append([]); self.resource_scopes.append([])
    def _register_resource(self,name,typ):
        if not self.resource_scopes: self._push_cleanup_scope()
        if self.owned_parts(typ) or self.vector_parts(typ): self.resource_scopes[-1].append((name,typ))
    def _emit_resource_cleanup(self,name,typ):
        if self.owned_parts(typ): self.emit(f"if ({name}) {{ free({name}); {name}=NULL; }}")
        elif self.vector_parts(typ): self.emit(f"if ({name}.data) {{ free({name}.data); {name}.data=NULL; {name}.len=0; {name}.cap=0; }}")
    def _emit_cleanup_scope(self,index=-1,exclude=None):
        exclude=set(exclude or ())
        if not self.defer_scopes: return
        idx=index if index>=0 else len(self.defer_scopes)-1
        pending=list(reversed(self.defer_scopes[idx])); saved_scopes=self.defer_scopes
        # Deferred statements execute before resource destruction in their scope.
        for body in pending:
            for st in body: self.stmt(st)
        for name,typ in reversed(self.resource_scopes[idx]):
            if name not in exclude: self._emit_resource_cleanup(name,typ)
    def _pop_cleanup_scope(self,emit=True):
        if emit: self._emit_cleanup_scope()
        self.defer_scopes.pop(); self.resource_scopes.pop()
    def emit_all_cleanup(self,exclude=None):
        for i in range(len(self.defer_scopes)-1,-1,-1): self._emit_cleanup_scope(i,exclude)
    def emit_deferred(self):
        # Compatibility alias used by older code paths.
        self.emit_all_cleanup()
    def stmt(self,s):
        if isinstance(s,Let):
            if s.name in self.env: raise NexusError(f"binding already exists in this scope: {s.name}", code="NX2201")
            inf=self.infer(s.expr); typ=self.materialize_type(s.typ) if s.typ else inf
            ap=self.array_parts(typ)
            if ap:
                if s.typ is not None: raise NexusError("explicit array type annotations arrive in a later Nexus release; use inference", code="NX2240")
                elem,n=ap; self.env[s.name]=typ; self.mutable[s.name]=s.mutable; const="" if s.mutable else "const "
                if not isinstance(s.expr,ArrayLiteral): raise NexusError("array bindings must initialize from an array literal", code="NX2241")
                init=', '.join(self.expr(x) for x in s.expr.items)
                self.emit(f"{const}{self.ctype(elem)} {s.name}[{n}] = {{ {init} }};"); return
            self.require_value_type(typ,f"binding {s.name}")
            if not self.compatible(typ,inf): raise NexusError(f"cannot assign {inf} to {typ} variable {s.name}", code="NX2202")
            self.env[s.name]=typ; self.mutable[s.name]=s.mutable; const="" if s.mutable or self.ref_parts(typ) or typ=="str" or self.owned_parts(typ) or self.vector_parts(typ) else "const "
            self.emit(f"{const}{self.ctype(typ)} {s.name} = {self.expr(s.expr)};"); self._register_resource(s.name,typ); return
        if isinstance(s,Assign):
            if s.name not in self.env: raise NexusError(f"unknown variable: {s.name}", code="NX2203")
            if not self.mutable[s.name]: raise NexusError(f"cannot assign to immutable binding '{s.name}'; use var", code="NX2204")
            at=self.infer(s.expr); et=self.env[s.name]
            if not self.compatible(et,at): raise NexusError(f"cannot assign {at} to {et} variable {s.name}", code="NX2205")
            self.emit(f"{s.name} = {self.expr(s.expr)};"); return
        if isinstance(s,DerefAssign):
            if s.name not in self.env: raise NexusError(f"assignment through unknown reference: {s.name}", code="NX2224")
            rp=self.ref_parts(self.env[s.name])
            if not rp or not rp[1]: raise NexusError(f"assignment through {s.name} requires &mut reference", code="NX2225")
            actual=self.infer(s.expr)
            if not self.compatible(rp[0],actual): raise NexusError(f"assignment through {s.name} expects {rp[0]}, got {actual}", code="NX2226")
            self.emit(f"*{s.name} = {self.expr(s.expr)};"); return
        if isinstance(s,Return):
            if s.expr is None:
                if self.current_return!="void": raise NexusError(f"function must return {self.current_return}", code="NX2206")
                self.emit_all_cleanup(); self.emit_sync(); self.emit("return;")
            else:
                at=self.infer(s.expr)
                if self.current_return=="void": raise NexusError("void function cannot return a value", code="NX2207")
                if not self.compatible(self.current_return,at): raise NexusError(f"return expects {self.current_return}, got {at}", code="NX2208")
                if isinstance(s.expr,VarRef) and (self.owned_parts(at) or self.vector_parts(at)):
                    name=s.expr.name; tmp=f"nx_return_{self.try_counter}"; self.try_counter+=1; self.emit(f"{self.ctype(at)} {tmp} = {name};")
                    if self.owned_parts(at): self.emit(f"{name}=NULL;")
                    else: self.emit(f"{name}.data=NULL; {name}.len=0; {name}.cap=0;")
                    self.emit_all_cleanup(exclude={name}); self.emit_sync(); self.emit(f"return {tmp};")
                else:
                    value=self.expr(s.expr); self.emit_all_cleanup(); self.emit_sync(); self.emit(f"return {value};")
            return
        if isinstance(s,ExprStmt): self.emit(self.expr(s.expr)+";"); return
        if isinstance(s,If):
            if self.infer(s.cond)!="bool": raise NexusError("if condition must be bool", code="NX2209")
            olde,oldm=self.env.copy(),self.mutable.copy(); self.emit(f"if ({self.expr(s.cond)}) {{"); self.ind+=1; self._push_cleanup_scope()
            for x in s.then_body: self.stmt(x)
            self._pop_cleanup_scope(True); self.ind-=1; self.emit("}"); self.env,self.mutable=olde.copy(),oldm.copy()
            if s.else_body:
                self.lines[-1]+=" else {"; self.ind+=1; self._push_cleanup_scope()
                for x in s.else_body: self.stmt(x)
                self._pop_cleanup_scope(True); self.ind-=1; self.emit("}"); self.env,self.mutable=olde,oldm
            return
        if isinstance(s,While):
            if self.infer(s.cond)!="bool": raise NexusError("while condition must be bool", code="NX2210")
            olde,oldm=self.env.copy(),self.mutable.copy(); self.emit(f"while ({self.expr(s.cond)}) {{"); self.ind+=1; self.loop_depth+=1; self._push_cleanup_scope()
            for x in s.body: self.stmt(x)
            self._pop_cleanup_scope(True); self.loop_depth-=1; self.ind-=1; self.emit("}"); self.env,self.mutable=olde,oldm; return
        if isinstance(s,ForEach):
            it=self.infer(s.iterable); elem=self.vector_parts(it); ap=self.array_parts(it)
            if not elem and not ap: raise NexusError(f"for-each requires Vector<T> or array, got {it}", code="NX2260")
            if s.name in self.env: raise NexusError(f"for iterator shadows existing binding: {s.name}", code="NX2212")
            olde,oldm=self.env.copy(),self.mutable.copy(); elem=elem or ap[0]; self.env[s.name]=elem; self.mutable[s.name]=False
            idx=f"nx_i_{self.match_counter}"; self.match_counter+=1
            if self.vector_parts(it):
                self.emit(f"for (int64_t {idx}=0; {idx}<({self.expr(s.iterable)}).len; ++{idx}) {{"); self.ind+=1; self.emit(f"{self.ctype(elem)} {s.name}=*({self.ctype(elem)}*)nexus_vector_at((nx_Vector*)&({self.expr(s.iterable)}), {idx});")
            else:
                self.emit(f"for (int64_t {idx}=0; {idx}<{ap[1]}; ++{idx}) {{"); self.ind+=1; self.emit(f"{self.ctype(elem)} {s.name}=({self.expr(s.iterable)})[{idx}];")
            self.loop_depth+=1; self._push_cleanup_scope()
            for x in s.body: self.stmt(x)
            self._pop_cleanup_scope(True); self.loop_depth-=1; self.ind-=1; self.emit("}"); self.env,self.mutable=olde,oldm; return
        if isinstance(s,ForRange):
            st,et=self.infer(s.start),self.infer(s.end)
            if st not in INTEGER or et not in INTEGER: raise NexusError("for range bounds must be integers", code="NX2211")
            if s.name in self.env: raise NexusError(f"for iterator shadows existing binding: {s.name}", code="NX2212")
            olde,oldm=self.env.copy(),self.mutable.copy(); self.env[s.name]="i64"; self.mutable[s.name]=False
            self.emit(f"for (int64_t {s.name}=(int64_t)({self.expr(s.start)}); {s.name}<(int64_t)({self.expr(s.end)}); ++{s.name}) {{")
            self.ind+=1; self.loop_depth+=1; self._push_cleanup_scope()
            for x in s.body: self.stmt(x)
            self._pop_cleanup_scope(True); self.loop_depth-=1; self.ind-=1; self.emit("}"); self.env,self.mutable=olde,oldm; return
        if isinstance(s,Break):
            if self.loop_depth==0: raise NexusError("break used outside a loop", code="NX2213")
            self.emit("break;"); return
        if isinstance(s,Continue):
            if self.loop_depth==0: raise NexusError("continue used outside a loop", code="NX2214")
            self.emit("continue;"); return
        if isinstance(s,Spawn):
            self.require_effect("task")
            fn=self.funcs.get(s.function)
            if not fn: raise NexusError(f"spawn target not found: {s.function}", code="NX2250")
            if fn.params or fn.ret!="void": raise NexusError("spawn target must be fn name() -> void", code="NX2251")
            self.emit('if (nx_thread_count >= 64) { fprintf(stderr, "Nexus task capacity exceeded\\n"); exit(103); }')
            self.emit(f"pthread_create(&nx_threads[nx_thread_count++], NULL, nx_thread_{s.function}, NULL);")
            return
        if isinstance(s,Sync):
            self.require_effect("task"); self.emit_sync(); return
        if isinstance(s,Drop):
            if s.name not in self.env: raise NexusError(f"drop of unknown binding '{s.name}'", code="NX2230")
            typ=self.env[s.name]
            if self.owned_parts(typ): self.emit(f"free({s.name}); {s.name} = NULL;")
            elif self.vector_parts(typ): self.emit(f"if ({s.name}.data) {{ free({s.name}.data); {s.name}.data=NULL; {s.name}.len=0; {s.name}.cap=0; }}")
            else: self.emit(f"/* lifetime ended: {s.name} */")
            return
        if isinstance(s,Defer):
            if not self.defer_scopes: self._push_cleanup_scope()
            self.defer_scopes[-1].append(s.body); return
        if isinstance(s,UnsafeBlock):
            self.emit("/* Nexus unsafe block */")
            self.unsafe_depth+=1; self._push_cleanup_scope()
            for x in s.body: self.stmt(x)
            self._pop_cleanup_scope(True); self.unsafe_depth-=1
            return
        if isinstance(s,MatchStmt):
            typ=self.infer(s.expr)
            en,subst=self.aggregate_decl(typ)
            if not en or not isinstance(en,EnumDecl): raise NexusError(f"match currently requires enum, got {typ}", code="NX2215")
            seen=set(); has_else=False; payload_enum=self.enum_has_payload(en)
            olde0,oldm0=self.env.copy(),self.mutable.copy()
            if payload_enum:
                temp=f"nx_match_{self.match_counter}"; self.match_counter+=1
                self.emit(f"{self.ctype(typ)} {temp} = {self.expr(s.expr)};")
                self.emit(f"switch ({temp}.tag) {{")
            else:
                temp=None; self.emit(f"switch ({self.expr(s.expr)}) {{")
            self.ind+=1
            for arm in s.arms:
                variant=None
                if arm.is_else:
                    if has_else: raise NexusError("duplicate else arm in match", code="NX2216")
                    has_else=True; self.emit("default:")
                    if arm.binder: raise NexusError("else match arm cannot bind a payload", code="NX2221")
                else:
                    if arm.enum_name!=en.name: raise NexusError(f"match arm {arm.enum_name} does not match enum {typ}", code="NX2217")
                    variant=self.enum_variant(en,arm.variant)
                    if not variant: raise NexusError(f"enum {typ} has no variant {arm.variant}", code="NX2218")
                    if arm.variant in seen: raise NexusError(f"duplicate match arm {typ}::{arm.variant}", code="NX2219")
                    if arm.binder and variant.payload is None: raise NexusError(f"variant {typ}::{arm.variant} has no payload to bind", code="NX2222")
                    seen.add(arm.variant); self.emit(f"case NX_{en.name}_{arm.variant}:")
                self.ind+=1; self.env,self.mutable=olde0.copy(),oldm0.copy()
                if arm.binder and variant and variant.payload is not None:
                    if arm.binder in self.env: raise NexusError(f"match payload binder shadows existing binding: {arm.binder}", code="NX2223")
                    payload_type=self.materialize_type(variant.payload,subst)
                    self.env[arm.binder]=payload_type; self.mutable[arm.binder]=False
                    self.emit(f"{self.ctype(payload_type)} {arm.binder} = {temp}.data.{arm.variant};")
                for x in arm.body: self.stmt(x)
                self.emit("break;"); self.ind-=1
            self.ind-=1; self.emit("}"); self.env,self.mutable=olde0,oldm0
            if not has_else:
                missing=[v.name for v in en.variants if v.name not in seen]
                if missing: raise NexusError(f"non-exhaustive match on {typ}; missing: {', '.join(missing)}", code="NX2220")
            return
        raise NexusError("unsupported statement", code="NX2299")

    def const_expr(self,c:ConstDecl):
        # constants are intentionally restricted to backend-safe constant expressions
        t=self.infer(c.expr)
        if not self.compatible(c.typ,t): raise NexusError(f"constant {c.name} expects {c.typ}, got {t}", code="NX2301")
        return self.expr(c.expr)

    def _function_context(self,f,mapping=None):
        mapping=mapping or {}
        self.current_type_subst=dict(mapping)
        self.env={p.name:self.materialize_type(p.typ,mapping) for p in f.params}
        self.mutable={p.name:False for p in f.params}
        self.current_return=self.materialize_type(f.ret,mapping)
        self.loop_depth=0; self.unsafe_depth=0; self.current_pure=f.pure; self.current_effects=f.effects; self.current_has_spawn=self.body_has_spawn(f.body); self.deferred=[]; self.defer_scopes=[[]]; self.resource_scopes=[[]]

    def _scan_function_for_generics(self,f,mapping=None):
        saved=(self.lines,self.ind,self.env,self.mutable,self.current_return,self.loop_depth,self.unsafe_depth,self.current_pure,self.current_effects,self.current_has_spawn,self.current_type_subst,self.match_counter,self.try_counter)
        self.lines=[]; self.ind=0; self._function_context(f,mapping)
        try:
            for st in f.body: self.stmt(st)
        finally:
            (self.lines,self.ind,self.env,self.mutable,self.current_return,self.loop_depth,self.unsafe_depth,self.current_pure,self.current_effects,self.current_has_spawn,self.current_type_subst,self.match_counter,self.try_counter)=saved

    def discover_generic_specializations(self):
        self.generic_specs={}; self.lambda_bindings={}; self.defer_scopes=[]; self.resource_scopes=[]
        for f in self.p.functions:
            if not f.type_params: self._scan_function_for_generics(f,{})
        scanned=set()
        while True:
            pending=[]
            for name,specs in sorted(self.generic_specs.items()):
                for key,mapping in sorted(specs.items(), key=lambda kv: kv[0]):
                    ident=(name,key)
                    if ident not in scanned: pending.append((ident,self.funcs[name],mapping))
            if not pending: break
            for ident,f,mapping in pending:
                scanned.add(ident); self._scan_function_for_generics(f,mapping)

    def _emit_function_definition(self,f,mapping=None,cname=None):
        mapping=mapping or {}; cname=cname or f.name
        self._function_context(f,mapping)
        ps=", ".join(f"{self.ctype(self.materialize_type(p.typ,mapping))} {p.name}" for p in f.params) or "void"
        self.emit(f"{self.ctype(self.current_return)} {cname}({ps}) {{"); self.ind+=1
        if self.current_has_spawn:
            self.emit("pthread_t nx_threads[64];")
            self.emit("size_t nx_thread_count = 0;")
        for st in f.body: self.stmt(st)
        if self.current_return=="void": self.emit_all_cleanup(); self.emit_sync(); self.emit("return;")
        self.ind-=1; self.emit("}"); self.emit()

    def collect_concrete_aggregate_types(self):
        found=set()
        def add_type(t,subst=None):
            t=self.materialize_type(t,subst or {})
            rp=self.ref_parts(t)
            if rp: return add_type(rp[0],{})
            gp=self.generic_parts(t)
            if gp:
                if gp[0] in self.structs or gp[0] in self.enums:
                    if all(self.is_type(a) for a in gp[1]):
                        found.add(t)
                for a in gp[1]: add_type(a,{})
        def ex(e):
            if isinstance(e,StructInit): add_type(e.name); [ex(v) for _,v in e.fields]
            elif isinstance(e,EnumValue): add_type(e.enum_name); ex(e.payload) if e.payload is not None else None
            elif isinstance(e,(Unary,AwaitExpr)): ex(e.expr)
            elif isinstance(e,Binary): ex(e.left); ex(e.right)
            elif isinstance(e,Call): [ex(a) for a in e.args]
            elif isinstance(e,FieldAccess): ex(e.obj)
            elif isinstance(e,ArrayLiteral): [ex(a) for a in e.items]
            elif isinstance(e,Index): ex(e.obj); ex(e.index)
        def body(xs):
            for x in xs:
                if isinstance(x,Let):
                    if x.typ: add_type(x.typ)
                    ex(x.expr)
                elif isinstance(x,(Assign,DerefAssign,ExprStmt)): ex(x.expr)
                elif isinstance(x,Return) and x.expr is not None: ex(x.expr)
                elif isinstance(x,If): ex(x.cond); body(x.then_body); body(x.else_body)
                elif isinstance(x,While): ex(x.cond); body(x.body)
                elif isinstance(x,ForRange): ex(x.start); ex(x.end); body(x.body)
                elif isinstance(x,ForEach): ex(x.iterable); body(x.body)
                elif isinstance(x,UnsafeBlock): body(x.body)
                elif isinstance(x,MatchStmt): ex(x.expr); [body(a.body) for a in x.arms]
        for f in self.p.functions:
            if not f.type_params:
                for p in f.params: add_type(p.typ)
                add_type(f.ret); body(f.body)
        for c in self.p.consts: add_type(c.typ); ex(c.expr)
        return sorted(found)

    def emit_aggregate_definition(self,t):
        gp=self.generic_parts(t)
        if not gp: return
        base,args=gp; decl=self.structs.get(base) or self.enums.get(base); subst=dict(zip(decl.type_params,args)); cname=self.ctype(t)
        if isinstance(decl,StructDecl):
            self.emit(f"typedef struct {cname} {cname};")
            self.emit(f"struct {cname} {{"); self.ind+=1
            for fld in decl.fields: self.emit(f"{self.ctype(self.materialize_type(fld.typ,subst))} {fld.name};")
            self.ind-=1; self.emit("};"); self.emit(); return
        self.emit(f"typedef struct {cname} {{"); self.ind+=1
        self.emit(f"nx_{base}_tag tag;")
        payloads=[v for v in decl.variants if v.payload is not None]
        if payloads:
            self.emit("union {"); self.ind+=1
            for v in payloads: self.emit(f"{self.ctype(self.materialize_type(v.payload,subst))} {v.name};")
            self.ind-=1; self.emit("} data;")
        self.ind-=1; self.emit(f"}} {cname};"); self.emit()

    def _emit_async_wrapper(self,f):
        if f.type_params: raise NexusError("generic async functions are deferred beyond Nexus 2.6", code="NX2184")
        if f.ret=="void": result_ct="void"
        else: result_ct=self.ctype(f.ret)
        ctx=f"nx_async_ctx_{self._mangle_type(f.name)}"
        ps=", ".join(f"{self.ctype(p.typ)} {p.name}" for p in f.params) or "void"
        self.emit(f"typedef struct {ctx} {{ nx_TaskState *state;" + (" " + " ".join(f"{self.ctype(p.typ)} {p.name};" for p in f.params) if f.params else "") + f" }} {ctx};")
        self.emit(f"static void *nx_async_worker_{f.name}(void *raw) {{"); self.ind+=1
        self.emit(f"{ctx} *ctx=({ctx}*)raw;")
        args=", ".join(f"ctx->{p.name}" for p in f.params)
        if f.ret=="void":
            self.emit(f"{f.name}__nx_async_body({args});")
        else:
            self.emit(f"{result_ct} *result=({result_ct}*)malloc(sizeof({result_ct})); if(!result) abort();")
            self.emit(f"*result={f.name}__nx_async_body({args}); ctx->state->result=result; ctx->state->result_size=sizeof({result_ct});")
        self.emit("free(ctx); return NULL;"); self.ind-=1; self.emit("}")
        self.emit(f"nx_Task nx_async_start_{f.name}({ps}) {{"); self.ind+=1
        self.emit("nx_Task task={0}; task.state=(nx_TaskState*)calloc(1,sizeof(nx_TaskState)); if(!task.state) abort();")
        self.emit(f"{ctx} *ctx=({ctx}*)calloc(1,sizeof({ctx})); if(!ctx) abort(); ctx->state=task.state;")
        for p in f.params: self.emit(f"ctx->{p.name}={p.name};")
        self.emit(f"if(pthread_create(&task.state->thread,NULL,nx_async_worker_{f.name},ctx)!=0) abort();")
        self.emit("return task;"); self.ind-=1; self.emit("}"); self.emit()

    def generate(self):
        entry_name="kernel_main" if self.p.kernel_profile else "main"
        if entry_name not in self.funcs: raise NexusError(f"program must define fn {entry_name}()", code="NX2302")
        main=self.funcs[entry_name]
        if main.type_params: raise NexusError(f"{entry_name} cannot be generic", code="NX2304")
        allowed={"void"} if self.p.kernel_profile else {"i32","void"}
        if self.p.kernel_profile:
            if main.ret not in allowed or len(main.params)>1 or (main.params and main.params[0].typ not in {"&FramesBootInfoV1","&mut FramesBootInfoV1","&FramesBootInfoV2","&mut FramesBootInfoV2","&FramesBootInfoV3","&mut FramesBootInfoV3","&FramesBootInfoV4","&mut FramesBootInfoV4"}):
                raise NexusError(f"{entry_name} must return void and accept zero arguments or one supported FramesBootInfo reference", code="NX2303")
        elif main.params or main.ret not in allowed:
            raise NexusError(f"{entry_name} must take no parameters and return i32 or void", code="NX2303")
        self.discover_generic_specializations()
        self.emit(f"/* Generated by Nexus bootstrap compiler {VERSION} */")
        for h in ("stdio.h","stdint.h","stdbool.h","stdlib.h","string.h"): self.emit(f"#include <{h}>")
        self.emit("typedef struct nx_Vector { void *data; int64_t len; int64_t cap; size_t elem_size; } nx_Vector;")
        self.emit("static nx_Vector nexus_vector_from(const void *src, int64_t len, size_t elem) { nx_Vector v={0}; v.len=len; v.cap=len>0?len:1; v.elem_size=elem; v.data=malloc((size_t)v.cap*elem); if(!v.data){abort();} if(len>0) memcpy(v.data,src,(size_t)len*elem); return v; }")
        self.emit("static void nexus_vector_push(nx_Vector *v, const void *item, size_t elem) { if(!v||v->elem_size!=elem){abort();} if(v->len==v->cap){v->cap=v->cap? v->cap*2:4; void *p=realloc(v->data,(size_t)v->cap*elem); if(!p){abort();} v->data=p;} memcpy((char*)v->data+(size_t)v->len*elem,item,elem); v->len++; }")
        self.emit("static void *nexus_vector_at(nx_Vector *v, int64_t i) { if(!v||i<0||i>=v->len){fprintf(stderr, \"Nexus Vector bounds error\\n\"); exit(104);} return (char*)v->data+(size_t)i*v->elem_size; }")
        self.emit("static const char *nexus_str_concat(const char *a, const char *b) { size_t na=strlen(a), nb=strlen(b); char *p=(char*)malloc(na+nb+1); if(!p){abort();} memcpy(p,a,na); memcpy(p+na,b,nb+1); return p; }")
        self.emit()
        uses_threads=any(self.body_has_spawn(f.body) for f in self.p.functions) or any(f.is_async for f in self.p.functions)
        self.emit("#include <pthread.h>")
        self.emit("#include <stdatomic.h>")
        self.emit("typedef struct nx_AtomicState { _Atomic int64_t value; } nx_AtomicState;")
        self.emit("typedef struct nx_Atomic { nx_AtomicState *state; } nx_Atomic;")
        self.emit("static nx_Atomic nexus_atomic_create(int64_t v) { nx_Atomic a={0}; a.state=(nx_AtomicState*)malloc(sizeof(nx_AtomicState)); if(!a.state) abort(); atomic_init(&a.state->value,v); return a; }")
        self.emit("static int64_t nexus_atomic_load(nx_Atomic a) { if(!a.state) abort(); return atomic_load_explicit(&a.state->value,memory_order_seq_cst); }")
        self.emit("static void nexus_atomic_store(nx_Atomic a,int64_t v) { if(!a.state) abort(); atomic_store_explicit(&a.state->value,v,memory_order_seq_cst); }")
        self.emit("static int64_t nexus_atomic_add(nx_Atomic a,int64_t v) { if(!a.state) abort(); return atomic_fetch_add_explicit(&a.state->value,v,memory_order_seq_cst)+v; }")
        self.emit("typedef struct nx_ChannelState { pthread_mutex_t mu; pthread_cond_t nonempty; pthread_cond_t nonfull; unsigned char *data; size_t elem_size; size_t cap; size_t head; size_t tail; size_t count; bool closed; } nx_ChannelState;")
        self.emit("typedef struct nx_Channel { nx_ChannelState *state; } nx_Channel;")
        self.emit("static nx_Channel nexus_channel_create(size_t elem) { nx_Channel c={0}; nx_ChannelState *s=(nx_ChannelState*)calloc(1,sizeof(nx_ChannelState)); if(!s) abort(); s->elem_size=elem; s->cap=64; s->data=(unsigned char*)calloc(s->cap,elem); if(!s->data) abort(); pthread_mutex_init(&s->mu,NULL); pthread_cond_init(&s->nonempty,NULL); pthread_cond_init(&s->nonfull,NULL); c.state=s; return c; }")
        self.emit("static void nexus_channel_send(nx_Channel c,const void *item,size_t elem) { nx_ChannelState *s=c.state; if(!s||elem!=s->elem_size) abort(); pthread_mutex_lock(&s->mu); while(s->count==s->cap&&!s->closed) pthread_cond_wait(&s->nonfull,&s->mu); if(s->closed){pthread_mutex_unlock(&s->mu); abort();} memcpy(s->data+s->tail*elem,item,elem); s->tail=(s->tail+1)%s->cap; s->count++; pthread_cond_signal(&s->nonempty); pthread_mutex_unlock(&s->mu); }")
        self.emit("static void nexus_channel_recv(nx_Channel c,void *out,size_t elem) { nx_ChannelState *s=c.state; if(!s||elem!=s->elem_size) abort(); pthread_mutex_lock(&s->mu); while(s->count==0&&!s->closed) pthread_cond_wait(&s->nonempty,&s->mu); if(s->count==0&&s->closed){pthread_mutex_unlock(&s->mu); abort();} memcpy(out,s->data+s->head*elem,elem); s->head=(s->head+1)%s->cap; s->count--; pthread_cond_signal(&s->nonfull); pthread_mutex_unlock(&s->mu); }")
        self.emit("static void nexus_channel_close(nx_Channel c) { nx_ChannelState *s=c.state; if(!s) return; pthread_mutex_lock(&s->mu); s->closed=true; pthread_cond_broadcast(&s->nonempty); pthread_cond_broadcast(&s->nonfull); pthread_mutex_unlock(&s->mu); }")
        if any(f.is_async for f in self.p.functions):
            self.emit("typedef struct nx_TaskState { pthread_t thread; void *result; size_t result_size; } nx_TaskState;")
            self.emit("typedef struct nx_Task { nx_TaskState *state; } nx_Task;")
            self.emit("static void nexus_task_await(nx_Task *task, void *out, size_t out_size) { if(!task||!task->state){abort();} pthread_join(task->state->thread,NULL); if(out && out_size){ if(!task->state->result || task->state->result_size!=out_size){abort();} memcpy(out,task->state->result,out_size); } free(task->state->result); free(task->state); task->state=NULL; }")
        self.emit()
        for en in self.p.enums:
            if en.type_params:
                self.emit(f"typedef enum nx_{en.name}_tag {{"); self.ind+=1
                for i,v in enumerate(en.variants): self.emit(f"NX_{en.name}_{v.name} = {i},")
                self.ind-=1; self.emit(f"}} nx_{en.name}_tag;"); self.emit(); continue
            if not self.enum_has_payload(en):
                self.emit(f"typedef enum nx_{en.name} {{") ; self.ind+=1
                for i,v in enumerate(en.variants): self.emit(f"NX_{en.name}_{v.name} = {i},")
                self.ind-=1; self.emit(f"}} nx_{en.name};"); self.emit()
            else:
                self.emit(f"typedef enum nx_{en.name}_tag {{"); self.ind+=1
                for i,v in enumerate(en.variants): self.emit(f"NX_{en.name}_{v.name} = {i},")
                self.ind-=1; self.emit(f"}} nx_{en.name}_tag;")
                self.emit(f"typedef struct nx_{en.name} {{"); self.ind+=1
                self.emit(f"nx_{en.name}_tag tag;")
                payloads=[v for v in en.variants if v.payload is not None]
                if payloads:
                    self.emit("union {"); self.ind+=1
                    for v in payloads: self.emit(f"{self.ctype(v.payload)} {v.name};")
                    self.ind-=1; self.emit("} data;")
                self.ind-=1; self.emit(f"}} nx_{en.name};"); self.emit()
        # Forward declare structs before their definitions to allow future recursive references.
        for st in self.p.structs:
            if not st.type_params: self.emit(f"typedef struct nx_{st.name} nx_{st.name};")
        if self.p.structs: self.emit()
        for st in self.p.structs:
            if st.type_params: continue
            self.emit(f"struct nx_{st.name} {{"); self.ind+=1
            for f in st.fields: self.emit(f"{self.ctype(f.typ)} {f.name};")
            self.ind-=1; self.emit("};"); self.emit()
        for gt in self.collect_concrete_aggregate_types(): self.emit_aggregate_definition(gt)
        self.env={}
        for c in self.p.consts:
            self.emit(f"static const {self.ctype(c.typ)} {c.name} = {self.const_expr(c)};")
        if self.p.consts: self.emit()
        self.emit("static void nexus_bounds(int64_t index, int64_t length, const char *file, int line) {"); self.ind+=1
        self.emit("if (index < 0 || index >= length) {"); self.ind+=1
        self.emit('fprintf(stderr, "Nexus bounds error: index %lld, length %lld (%s:%d)\\n", (long long)index, (long long)length, file, line);'); self.emit("exit(102);")
        self.ind-=1; self.emit("}"); self.ind-=1; self.emit("}"); self.emit()
        self.emit("static void nexus_assert(bool condition, const char *message, const char *file, int line) {"); self.ind+=1
        self.emit("if (!condition) {"); self.ind+=1
        self.emit('fprintf(stderr, "Nexus assertion failed: %s (%s:%d)\\n", message, file, line);'); self.emit("exit(101);")
        self.ind-=1; self.emit("}"); self.ind-=1; self.emit("}"); self.emit()
        for imp in self.impl_decls:
            for m in imp.methods:
                cname=f"nx_impl_{self._mangle_type(imp.trait)}_{self._mangle_type(imp.typ)}_{m.name}"
                ps=", ".join(f"{self.ctype(p.typ)} {p.name}" for p in m.params) or "void"
                self.emit(f"{self.ctype(m.ret)} {cname}({ps});")
        for f in self.p.functions:
            if f.type_params: continue
            ps=", ".join(f"{self.ctype(p.typ)} {p.name}" for p in f.params) or "void"
            if f.is_async:
                self.emit(f"{self.ctype(f.ret)} {f.name}__nx_async_body({ps});")
                self.emit(f"nx_Task nx_async_start_{f.name}({ps});")
            else:
                self.emit(f"{self.ctype(f.ret)} {f.name}({ps});")
        for fname,specs in sorted(self.generic_specs.items()):
            f=self.funcs[fname]
            for key,mapping in sorted(specs.items(), key=lambda kv: kv[0]):
                cname=self.generic_cname(f,mapping)
                ps=", ".join(f"{self.ctype(self.materialize_type(p.typ,mapping))} {p.name}" for p in f.params) or "void"
                ret=self.materialize_type(f.ret,mapping)
                self.emit(f"{self.ctype(ret)} {cname}({ps});")
        self.emit()
        if uses_threads:
            targets=set()
            def collect(body):
                for st in body:
                    if isinstance(st,Spawn): targets.add(st.function)
                    elif isinstance(st,If): collect(st.then_body); collect(st.else_body)
                    elif isinstance(st,(While,ForRange,ForEach,UnsafeBlock)): collect(st.body)
                    elif isinstance(st,MatchStmt):
                        for a in st.arms: collect(a.body)
            for f in self.p.functions: collect(f.body)
            for name in sorted(targets):
                fn=self.funcs.get(name)
                if not fn or fn.params or fn.ret!="void": raise NexusError(f"invalid spawn target: {name}", code="NX2252")
                self.emit(f"static void *nx_thread_{name}(void *unused) {{ (void)unused; {name}(); return NULL; }}")
            self.emit()
        for imp in self.impl_decls:
            for m in imp.methods:
                cname=f"nx_impl_{self._mangle_type(imp.trait)}_{self._mangle_type(imp.typ)}_{m.name}"
                self._emit_function_definition(m,{},cname)
        for f in self.p.functions:
            if not f.type_params:
                if f.is_async:
                    self._emit_function_definition(f,{},f.name+"__nx_async_body")
                    self._emit_async_wrapper(f)
                else:
                    self._emit_function_definition(f,{},f.name)
        for fname,specs in sorted(self.generic_specs.items()):
            f=self.funcs[fname]
            for key,mapping in sorted(specs.items(), key=lambda kv: kv[0]):
                self._emit_function_definition(f,mapping,self.generic_cname(f,mapping))
        return "\n".join(self.lines)



# ----------------------------- Ownership / move validation -----------------------------

class LifetimeAnalyzer:
    """Nexus 1.9 inferred reference-return lifetime analysis.

    A reference return is tied to one reference parameter. Nexus infers that source from all
    return paths; ambiguous/mixed sources and references to locals are rejected. This gives
    returned references a concrete provenance without requiring annotations for the common case.
    """
    def __init__(self,p): self.p=p; self.origins={}
    @staticmethod
    def ref_parts(t):
        if isinstance(t,str) and t.startswith("&mut "): return (t[5:],True)
        if isinstance(t,str) and t.startswith("&"): return (t[1:],False)
        return None
    def returns(self,body):
        out=[]
        for st in body:
            if isinstance(st,Return): out.append(st)
            elif isinstance(st,If): out += self.returns(st.then_body)+self.returns(st.else_body)
            elif isinstance(st,(While,ForRange,ForEach,UnsafeBlock)): out += self.returns(st.body)
            elif isinstance(st,MatchStmt):
                for arm in st.arms: out += self.returns(arm.body)
        return out
    def run(self):
        structs={x.name:x for x in self.p.structs}; enums={x.name:x for x in self.p.enums}
        for f in self.p.functions:
            decl=structs.get(f.ret) or enums.get(f.ret)
            if decl:
                ref_fields=[]
                if isinstance(decl,StructDecl): ref_fields=[x.name for x in decl.fields if self.ref_parts(x.typ)]
                else: ref_fields=[x.name for x in decl.variants if x.payload and self.ref_parts(x.payload)]
                if ref_fields:
                    ref_params={p.name for p in f.params if self.ref_parts(p.typ)}
                    for r in self.returns(f.body):
                        if isinstance(r.expr,StructInit):
                            vals=dict(r.expr.fields)
                            for fn in ref_fields:
                                v=vals.get(fn)
                                if not isinstance(v,VarRef) or v.name not in ref_params:
                                    raise NexusError(f"reference-bearing return from {f.name} must source field {fn} from a reference parameter", code="NX2810")
                        elif isinstance(r.expr,EnumValue) and r.expr.variant in ref_fields:
                            v=r.expr.payload
                            if not isinstance(v,VarRef) or v.name not in ref_params:
                                raise NexusError(f"reference-bearing enum return from {f.name} must source payload from a reference parameter", code="NX2811")
            rr=self.ref_parts(f.ret)
            if not rr: continue
            candidates={p.name:(i,self.ref_parts(p.typ)) for i,p in enumerate(f.params) if self.ref_parts(p.typ)}
            if not candidates: raise NexusError(f"reference-returning function {f.name} needs a reference parameter", code="NX2801")
            origins=set()
            for r in self.returns(f.body):
                if r.expr is None: continue
                name=None
                if isinstance(r.expr,(VarRef,Move)): name=r.expr.name
                if name not in candidates:
                    raise NexusError(f"reference return in {f.name} must originate from a reference parameter", code="NX2802")
                pt=candidates[name][1]
                if pt and (pt[0]!=rr[0] or (rr[1] and not pt[1])):
                    # Generic placeholders are allowed to match structurally by spelling.
                    if pt[0]!=rr[0]: raise NexusError(f"reference return type in {f.name} does not match parameter {name}", code="NX2803")
                origins.add(name)
            if len(origins)!=1:
                raise NexusError(f"cannot infer a unique returned lifetime for {f.name}", code="NX2804")
            name=next(iter(origins)); self.origins[f.name]=candidates[name][0]
        return self.origins

@dataclass
class MoveState:
    declared: set = field(default_factory=set)
    mutable: set = field(default_factory=set)
    moved: set = field(default_factory=set)
    def copy(self): return MoveState(set(self.declared),set(self.mutable),set(self.moved))

class MoveChecker:
    """Nexus 1.0 linear-move safety pass.

    `move value` transfers a local binding and the source cannot be read again until a mutable
    binding is explicitly reassigned. Branch merges are conservative: moved on any reachable
    path means moved afterward.
    """
    def __init__(self,p): self.p=p; self.return_origins=LifetimeAnalyzer(p).run(); self.funcs={f.name:f for f in p.functions}
    def use(self,e,st:MoveState):
        if isinstance(e,VarRef):
            if e.name in st.moved: raise NexusError(f"use of moved value '{e.name}'", code="NX2601")
        elif isinstance(e,Borrow):
            if e.name in st.moved: raise NexusError(f"cannot borrow moved value '{e.name}'", code="NX2605")
        elif isinstance(e,Move):
            if e.name not in st.declared: raise NexusError(f"cannot move unknown local '{e.name}'", code="NX2602")
            if e.name in st.moved: raise NexusError(f"value '{e.name}' was already moved", code="NX2603")
            st.moved.add(e.name)
        elif isinstance(e,Unary): self.use(e.expr,st)
        elif isinstance(e,TryExpr): self.use(e.expr,st)
        elif isinstance(e,Lambda): self.use(e.body,st)
        elif isinstance(e,Binary): self.use(e.left,st); self.use(e.right,st)
        elif isinstance(e,Call):
            for a in e.args: self.use(a,st)
        elif isinstance(e,StructInit):
            for _,v in e.fields: self.use(v,st)
        elif isinstance(e,FieldAccess): self.use(e.obj,st)
        elif isinstance(e,MethodCall): self.use(e.obj,st); [self.use(a,st) for a in e.args]
        elif isinstance(e,ArrayLiteral):
            for x in e.items: self.use(x,st)
        elif isinstance(e,Index): self.use(e.obj,st); self.use(e.index,st)
        elif isinstance(e,EnumValue) and e.payload is not None: self.use(e.payload,st)
    def block(self,body,st:MoveState,lexical=True):
        base_decl=set(st.declared); base_mut=set(st.mutable)
        for x in body: self.stmt(x,st)
        if lexical:
            locals_added=st.declared-base_decl
            st.declared=base_decl; st.mutable=base_mut; st.moved-=locals_added
        return st
    def stmt(self,x,st):
        if isinstance(x,Let):
            self.use(x.expr,st); st.declared.add(x.name)
            if x.mutable: st.mutable.add(x.name)
            st.moved.discard(x.name)
        elif isinstance(x,Assign):
            self.use(x.expr,st)
            if x.name in st.moved:
                if x.name not in st.mutable: raise NexusError(f"immutable moved value '{x.name}' cannot be reinitialized", code="NX2604")
                st.moved.remove(x.name)
        elif isinstance(x,DerefAssign): self.use(x.expr,st)
        elif isinstance(x,Return) and x.expr is not None: self.use(x.expr,st)
        elif isinstance(x,ExprStmt): self.use(x.expr,st)
        elif isinstance(x,If):
            self.use(x.cond,st); a=st.copy(); b=st.copy(); self.block(x.then_body,a); self.block(x.else_body,b)
            st.moved |= a.moved | b.moved
        elif isinstance(x,While):
            self.use(x.cond,st); body=st.copy(); self.block(x.body,body); st.moved |= body.moved
        elif isinstance(x,ForRange):
            self.use(x.start,st); self.use(x.end,st); body=st.copy(); body.declared.add(x.name); self.block(x.body,body); body.moved.discard(x.name); st.moved |= body.moved
        elif isinstance(x,Drop):
            if x.name not in st.declared: raise NexusError(f"drop of unknown binding '{x.name}'", code="NX2610")
            if x.name in st.moved: raise NexusError(f"value '{x.name}' was already moved or dropped", code="NX2611")
            st.moved.add(x.name)
        elif isinstance(x,Defer):
            # Deferred actions execute at function exit and do not consume values at registration time.
            pass
        elif isinstance(x,UnsafeBlock): self.block(x.body,st)
        elif isinstance(x,MatchStmt):
            self.use(x.expr,st); merged=set(st.moved)
            for arm in x.arms:
                a=st.copy(); self.block(arm.body,a); merged |= a.moved
            st.moved=merged
    def run(self):
        for f in self.p.functions:
            st=MoveState({p.name for p in f.params},set(),set())
            self.block(f.body,st,lexical=False)
        return self.p

@dataclass
class BorrowState:
    declared: set = field(default_factory=set)
    mutable: set = field(default_factory=set)
    refs: dict = field(default_factory=dict)      # ref local/synthetic -> (target|None, mutable)
    immut: dict = field(default_factory=dict)    # target -> set(ref locals)
    mutref: dict = field(default_factory=dict)   # target -> ref local
    aggregate_refs: dict = field(default_factory=dict) # aggregate local -> synthetic ref locals
    def copy(self):
        return BorrowState(set(self.declared),set(self.mutable),dict(self.refs),{k:set(v) for k,v in self.immut.items()},dict(self.mutref),{k:list(v) for k,v in self.aggregate_refs.items()})

class BorrowChecker:
    """Nexus 1.9 borrow checker with inferred returned-reference provenance and
    statement-level non-lexical expiration for stored reference aliases.
    """
    def __init__(self,p):
        self.p=p
        self.return_origins=LifetimeAnalyzer(p).run()
        self.funcs={f.name:f for f in p.functions}
    @staticmethod
    def _ref_type(t):
        if isinstance(t,str) and t.startswith("&mut "): return (t[5:],True)
        if isinstance(t,str) and t.startswith("&"): return (t[1:],False)
        return None
    def _release(self,name,st):
        if name in st.aggregate_refs:
            for synthetic in list(st.aggregate_refs.pop(name)):
                self._release(synthetic,st)
        info=st.refs.pop(name,None)
        if not info: return
        target,mutable=info
        if target is None: return
        if mutable:
            if st.mutref.get(target)==name: st.mutref.pop(target,None)
        else:
            holders=st.immut.get(target)
            if holders:
                holders.discard(name)
                if not holders: st.immut.pop(target,None)
    def _check_borrow(self,e,st,persist_name=None):
        if e.name not in st.declared: raise NexusError(f"cannot borrow unknown local '{e.name}'", code="NX2701")
        if e.mutable and e.name not in st.mutable: raise NexusError(f"mutable borrow requires `var` binding: {e.name}", code="NX2702")
        if e.mutable:
            if e.name in st.mutref or st.immut.get(e.name): raise NexusError(f"cannot mutably borrow '{e.name}' while it is already borrowed", code="NX2703")
        else:
            if e.name in st.mutref: raise NexusError(f"cannot immutably borrow '{e.name}' while a mutable borrow is active", code="NX2704")
        if persist_name:
            st.refs[persist_name]=(e.name,e.mutable)
            if e.mutable: st.mutref[e.name]=persist_name
            else: st.immut.setdefault(e.name,set()).add(persist_name)
    def expr(self,e,st,temp=True):
        if isinstance(e,Borrow): self._check_borrow(e,st,None)
        elif isinstance(e,Move):
            if e.name in st.mutref or st.immut.get(e.name): raise NexusError(f"cannot move '{e.name}' while it is borrowed", code="NX2705")
        elif isinstance(e,Unary): self.expr(e.expr,st)
        elif isinstance(e,TryExpr): self.expr(e.expr,st)
        elif isinstance(e,Lambda): self.expr(e.body,st)
        elif isinstance(e,Binary): self.expr(e.left,st); self.expr(e.right,st)
        elif isinstance(e,Call):
            for a in e.args: self.expr(a,st)
        elif isinstance(e,StructInit):
            for _,v in e.fields: self.expr(v,st)
        elif isinstance(e,FieldAccess): self.expr(e.obj,st)
        elif isinstance(e,MethodCall): self.expr(e.obj,st); [self.expr(a,st) for a in e.args]
        elif isinstance(e,EnumValue) and e.payload is not None: self.expr(e.payload,st)
        elif isinstance(e,ArrayLiteral):
            for x in e.items: self.expr(x,st)
        elif isinstance(e,Index): self.expr(e.obj,st); self.expr(e.index,st)
    def let(self,x,st):
        # Persistent borrow/reference aliases are tracked by the binding that stores them.
        if isinstance(x.expr,Borrow):
            self._check_borrow(x.expr,st,x.name)
        elif isinstance(x.expr,VarRef) and x.expr.name in st.refs:
            target,mutable=st.refs[x.expr.name]
            if mutable: raise NexusError(f"mutable reference '{x.expr.name}' cannot be copied; use move", code="NX2706")
            st.refs[x.name]=(target,False)
            if target is not None: st.immut.setdefault(target,set()).add(x.name)
        elif isinstance(x.expr,Move) and x.expr.name in st.refs:
            target,mutable=st.refs[x.expr.name]
            self._release(x.expr.name,st)
            st.refs[x.name]=(target,mutable)
            if target is not None:
                if mutable: st.mutref[target]=x.name
                else: st.immut.setdefault(target,set()).add(x.name)
        elif isinstance(x.expr,Call) and x.expr.name in self.return_origins:
            self.expr(x.expr,st)
            idx=self.return_origins[x.expr.name]
            arg=x.expr.args[idx]
            target=None; mutable=self._ref_type(self.funcs[x.expr.name].ret)[1]
            if isinstance(arg,Borrow): target=arg.name
            elif isinstance(arg,VarRef) and arg.name in st.refs: target=st.refs[arg.name][0]
            elif isinstance(arg,Move) and arg.name in st.refs:
                target=st.refs[arg.name][0]; self._release(arg.name,st)
            if target is not None:
                st.refs[x.name]=(target,mutable)
                if mutable: st.mutref[target]=x.name
                else: st.immut.setdefault(target,set()).add(x.name)
        elif isinstance(x.expr,StructInit):
            held=[]
            for fname,v in x.expr.fields:
                if isinstance(v,Borrow):
                    synthetic=f"{x.name}::{fname}"; self._check_borrow(v,st,synthetic); held.append(synthetic)
                else: self.expr(v,st)
            if held: st.aggregate_refs[x.name]=held
        elif isinstance(x.expr,EnumValue) and isinstance(x.expr.payload,Borrow):
            synthetic=f"{x.name}::payload"; self._check_borrow(x.expr.payload,st,synthetic); st.aggregate_refs[x.name]=[synthetic]
        else: self.expr(x.expr,st)
        st.declared.add(x.name)
        if x.mutable: st.mutable.add(x.name)
    def stmt(self,x,st):
        if isinstance(x,Let): self.let(x,st)
        elif isinstance(x,Assign):
            if x.name in st.mutref or st.immut.get(x.name): raise NexusError(f"cannot assign to '{x.name}' while it is borrowed", code="NX2707")
            if x.name in st.refs: raise NexusError("reassigning stored references is reserved until lifetime tracking is implemented", code="NX2708")
            self.expr(x.expr,st)
        elif isinstance(x,DerefAssign):
            info=st.refs.get(x.name)
            # Function reference parameters have target=None and are registered in run().
            if not info or not info[1]: raise NexusError(f"cannot write through non-mutable reference '{x.name}'", code="NX2709")
            self.expr(x.expr,st)
        elif isinstance(x,Return):
            if x.expr is not None: self.expr(x.expr,st)
        elif isinstance(x,ExprStmt): self.expr(x.expr,st)
        elif isinstance(x,If):
            self.expr(x.cond,st); a=st.copy(); b=st.copy(); self.block(x.then_body,a); self.block(x.else_body,b)
        elif isinstance(x,While):
            self.expr(x.cond,st); a=st.copy(); self.block(x.body,a)
        elif isinstance(x,ForRange):
            self.expr(x.start,st); self.expr(x.end,st); a=st.copy(); a.declared.add(x.name); self.block(x.body,a)
        elif isinstance(x,ForEach):
            self.expr(x.iterable,st); a=st.copy(); a.declared.add(x.name); self.block(x.body,a)
        elif isinstance(x,Drop):
            if x.name in st.mutref or st.immut.get(x.name): raise NexusError(f"cannot drop '{x.name}' while it is borrowed", code="NX2710")
            if x.name in st.refs or x.name in st.aggregate_refs: self._release(x.name,st)
        elif isinstance(x,Defer):
            pass
        elif isinstance(x,UnsafeBlock): self.block(x.body,st)
        elif isinstance(x,MatchStmt):
            self.expr(x.expr,st)
            for arm in x.arms:
                a=st.copy()
                if arm.binder: a.declared.add(arm.binder)
                self.block(arm.body,a)
    def _expr_names(self,e):
        out=set()
        if isinstance(e,(VarRef,Move,Borrow)): out.add(e.name)
        elif isinstance(e,(Unary,TryExpr)): out |= self._expr_names(e.expr)
        elif isinstance(e,Lambda): out |= (self._expr_names(e.body)-{e.param})
        elif isinstance(e,Binary): out |= self._expr_names(e.left) | self._expr_names(e.right)
        elif isinstance(e,Call):
            for a in e.args: out |= self._expr_names(a)
        elif isinstance(e,StructInit):
            for _,v in e.fields: out |= self._expr_names(v)
        elif isinstance(e,FieldAccess): out |= self._expr_names(e.obj)
        elif isinstance(e,MethodCall): out |= self._expr_names(e.obj); [out.update(self._expr_names(a)) for a in e.args]
        elif isinstance(e,EnumValue) and e.payload is not None: out |= self._expr_names(e.payload)
        elif isinstance(e,ArrayLiteral):
            for a in e.items: out |= self._expr_names(a)
        elif isinstance(e,Index): out |= self._expr_names(e.obj) | self._expr_names(e.index)
        return out
    def _stmt_names(self,x):
        out=set()
        if isinstance(x,Let): out |= self._expr_names(x.expr)
        elif isinstance(x,(Assign,DerefAssign)): out.add(x.name); out |= self._expr_names(x.expr)
        elif isinstance(x,Return) and x.expr is not None: out |= self._expr_names(x.expr)
        elif isinstance(x,ExprStmt): out |= self._expr_names(x.expr)
        elif isinstance(x,If):
            out |= self._expr_names(x.cond)
            for y in x.then_body+x.else_body: out |= self._stmt_names(y)
        elif isinstance(x,While):
            out |= self._expr_names(x.cond)
            for y in x.body: out |= self._stmt_names(y)
        elif isinstance(x,ForRange):
            out |= self._expr_names(x.start)|self._expr_names(x.end)
            for y in x.body: out |= self._stmt_names(y)
        elif isinstance(x,ForEach):
            out |= self._expr_names(x.iterable)
            for y in x.body: out |= self._stmt_names(y)
        elif isinstance(x,Drop): out.add(x.name)
        elif isinstance(x,(UnsafeBlock,Defer)):
            for y in x.body: out |= self._stmt_names(y)
        elif isinstance(x,MatchStmt):
            out |= self._expr_names(x.expr)
            for a in x.arms:
                for y in a.body: out |= self._stmt_names(y)
        return out

    def block(self,body,st,lexical=True):
        before=set(st.declared)
        for i,x in enumerate(body):
            self.stmt(x,st)
            # Non-lexical lifetime approximation: a stored reference expires immediately
            # after its final syntactic use in the current block.
            future=set()
            for y in body[i+1:]: future |= self._stmt_names(y)
            for name in list(st.refs):
                if "::" not in name and name not in future and name not in before:
                    self._release(name,st)
            for name in list(st.aggregate_refs):
                if name not in future and name not in before:
                    self._release(name,st)
        if lexical:
            for name in list(st.declared-before): self._release(name,st)
            st.declared=before
        return st
    def run(self):
        for f in self.p.functions:
            st=BorrowState()
            for param in f.params:
                st.declared.add(param.name)
                rp=self._ref_type(param.typ)
                if rp: st.refs[param.name]=(None,rp[1])
            self.block(f.body,st,lexical=False)
        return self.p

def validate_defers(p):
    def scan_defer_body(body):
        for x in body:
            if isinstance(x,(Return,Defer)): raise NexusError("defer body cannot contain return or nested defer", code="NX2851")
            if isinstance(x,If): scan_defer_body(x.then_body); scan_defer_body(x.else_body)
            elif isinstance(x,(While,ForRange,ForEach,UnsafeBlock)): scan_defer_body(x.body)
            elif isinstance(x,MatchStmt):
                for a in x.arms: scan_defer_body(a.body)
    def walk(body):
        for st in body:
            if isinstance(st,Defer): scan_defer_body(st.body)
            elif isinstance(st,If): walk(st.then_body); walk(st.else_body)
            elif isinstance(st,(While,ForRange,ForEach,UnsafeBlock)): walk(st.body)
            elif isinstance(st,MatchStmt):
                for a in st.arms: walk(a.body)
    for f in p.functions: walk(f.body)

def validate_moves(p):
    validate_defers(p)
    MoveChecker(p).run()
    BorrowChecker(p).run()
    return p

# ----------------------------- Nexus IR + optimization -----------------------------

class ConstantFolder:
    """Small, semantics-preserving frontend optimization pass used before lowering."""
    def expr(self, e):
        if isinstance(e, TryExpr):
            e.expr=self.expr(e.expr); return e
        if isinstance(e, Binary):
            e.left=self.expr(e.left); e.right=self.expr(e.right)
            if isinstance(e.left, Literal) and isinstance(e.right, Literal):
                a,b=e.left.value,e.right.value
                try:
                    if e.op=="+": v=a+b
                    elif e.op=="-": v=a-b
                    elif e.op=="*": v=a*b
                    elif e.op=="/":
                        if b==0: return e
                        v=a/b
                    elif e.op=="%":
                        if b==0: return e
                        v=a%b
                    elif e.op=="==": return Literal(a==b,"bool")
                    elif e.op=="!=": return Literal(a!=b,"bool")
                    elif e.op=="<": return Literal(a<b,"bool")
                    elif e.op==">": return Literal(a>b,"bool")
                    elif e.op=="<=": return Literal(a<=b,"bool")
                    elif e.op==">=": return Literal(a>=b,"bool")
                    elif e.op=="&&": return Literal(bool(a and b),"bool")
                    elif e.op=="||": return Literal(bool(a or b),"bool")
                    else: return e
                    if isinstance(v,float) or e.left.typ.startswith("f") or e.right.typ.startswith("f"):
                        return Literal(float(v),"f64")
                    return Literal(int(v),"i64")
                except Exception:
                    return e
            return e
        if isinstance(e,Unary):
            e.expr=self.expr(e.expr)
            if isinstance(e.expr,Literal):
                if e.op=="!" and e.expr.typ=="bool": return Literal(not e.expr.value,"bool")
                if e.op=="-" and e.expr.typ in NUMERIC: return Literal(-e.expr.value,e.expr.typ)
            return e
        if isinstance(e,Call): e.args=[self.expr(x) for x in e.args]
        elif isinstance(e,StructInit): e.fields=[(n,self.expr(x)) for n,x in e.fields]
        elif isinstance(e,FieldAccess): e.obj=self.expr(e.obj)
        elif isinstance(e,MethodCall): e.obj=self.expr(e.obj); e.args=[self.expr(a) for a in e.args]
        elif isinstance(e,ArrayLiteral): e.items=[self.expr(x) for x in e.items]
        elif isinstance(e,Index): e.obj=self.expr(e.obj); e.index=self.expr(e.index)
        elif isinstance(e,EnumValue) and e.payload is not None: e.payload=self.expr(e.payload)
        return e

    def stmt(self, st):
        if isinstance(st,(Let,Assign,DerefAssign)): st.expr=self.expr(st.expr)
        elif isinstance(st,Return) and st.expr is not None: st.expr=self.expr(st.expr)
        elif isinstance(st,ExprStmt): st.expr=self.expr(st.expr)
        elif isinstance(st,If):
            st.cond=self.expr(st.cond); st.then_body=[self.stmt(x) for x in st.then_body]; st.else_body=[self.stmt(x) for x in st.else_body]
        elif isinstance(st,While): st.cond=self.expr(st.cond); st.body=[self.stmt(x) for x in st.body]
        elif isinstance(st,ForRange): st.start=self.expr(st.start); st.end=self.expr(st.end); st.body=[self.stmt(x) for x in st.body]
        elif isinstance(st,ForEach): st.iterable=self.expr(st.iterable); st.body=[self.stmt(x) for x in st.body]
        elif isinstance(st,UnsafeBlock): st.body=[self.stmt(x) for x in st.body]
        elif isinstance(st,MatchStmt):
            st.expr=self.expr(st.expr)
            for arm in st.arms: arm.body=[self.stmt(x) for x in arm.body]
        return st

    def run(self,p):
        for c in p.consts: c.expr=self.expr(c.expr)
        for f in p.functions: f.body=[self.stmt(x) for x in f.body]
        return p

class CFGBuilder:
    """Build a deterministic control-flow graph from validated Nexus AST.

    NIR3 keeps memory-backed locals for now, but control flow is explicit and
    verifier-visible. This is the bridge to later full SSA promotion.
    """
    def __init__(self):
        self.next_id=0; self.blocks={}; self.edges=[]
    def block(self, hint="bb"):
        name=f"bb.{self.next_id}.{hint}"; self.next_id+=1; self.blocks[name]=[]; return name
    def edge(self,a,b,kind="next"):
        self.edges.append((a,b,kind))
    def walk_seq(self, body, cur, exit_block):
        for st in body:
            self.blocks[cur].append(type(st).__name__)
            if isinstance(st,If):
                bt=self.block("if.then"); bf=self.block("if.else"); bj=self.block("if.join")
                self.edge(cur,bt,"true"); self.edge(cur,bf,"false")
                et=self.walk_seq(st.then_body,bt,exit_block); ef=self.walk_seq(st.else_body,bf,exit_block)
                if et is not None: self.edge(et,bj)
                if ef is not None: self.edge(ef,bj)
                cur=bj
            elif isinstance(st,While):
                bc=self.block("while.cond"); bb=self.block("while.body"); bj=self.block("while.exit")
                self.edge(cur,bc); self.edge(bc,bb,"true"); self.edge(bc,bj,"false")
                eb=self.walk_seq(st.body,bb,exit_block)
                if eb is not None: self.edge(eb,bc,"back")
                cur=bj
            elif isinstance(st,(ForRange,ForEach)):
                bc=self.block("for.cond"); bb=self.block("for.body"); bj=self.block("for.exit")
                self.edge(cur,bc); self.edge(bc,bb,"true"); self.edge(bc,bj,"false")
                eb=self.walk_seq(st.body,bb,exit_block)
                if eb is not None: self.edge(eb,bc,"back")
                cur=bj
            elif isinstance(st,Return):
                self.edge(cur,exit_block,"return"); return None
        return cur
    def function(self,f):
        self.next_id=0; self.blocks={}; self.edges=[]
        entry=self.block("entry"); exit_block=self.block("exit")
        tail=self.walk_seq(f.body,entry,exit_block)
        if tail is not None: self.edge(tail,exit_block,"fallthrough")
        return entry,exit_block,dict(self.blocks),list(self.edges)

class NIREmitter:
    """NIR3: typed structural IR plus explicit CFG metadata and memory-SSA contract."""
    def __init__(self,p):
        self.p=p; self.lines=[]; self.backend=CBackend(p); self.ind=0
    def emit(self,x=""): self.lines.append("  "*self.ind+x)
    def ex(self,e):
        if isinstance(e,Literal): return f"const.{e.typ} {e.value!r}"
        if isinstance(e,VarRef): return f"%{e.name}"
        if isinstance(e,Move): return f"move %{e.name}"
        if isinstance(e,Borrow): return ("borrow_mut " if e.mutable else "borrow ")+f"%{e.name}"
        if isinstance(e,Unary): return f"({e.op} {self.ex(e.expr)})"
        if isinstance(e,Binary): return f"({e.op} {self.ex(e.left)} {self.ex(e.right)})"
        if isinstance(e,Call): return f"call @{e.name}({', '.join(self.ex(a) for a in e.args)})"
        if isinstance(e,StructInit): return f"new %{e.name}{{{', '.join(n+': '+self.ex(v) for n,v in e.fields)}}}"
        if isinstance(e,FieldAccess): return f"field {self.ex(e.obj)}.{e.field}"
        if isinstance(e,MethodCall): return f"method {self.ex(e.obj)}.{e.method}({', '.join(self.ex(a) for a in e.args)})"
        if isinstance(e,EnumValue): return f"enum %{e.enum_name}::{e.variant}" + (f"({self.ex(e.payload)})" if e.payload is not None else "")
        if isinstance(e,ArrayLiteral): return f"array[{', '.join(self.ex(x) for x in e.items)}]"
        if isinstance(e,Lambda): return f"lambda %{e.param} => {self.ex(e.body)}"
        if isinstance(e,AwaitExpr): return f"await {self.ex(e.expr)}"
        if isinstance(e,Index): return f"index {self.ex(e.obj)}[{self.ex(e.index)}]"
        return "<?>"
    def st(self,x):
        b=self.backend
        if isinstance(x,Let):
            typ=b.infer(x.expr); typ=x.typ or typ; b.env[x.name]=typ; b.mutable[x.name]=x.mutable
            self.emit(f"{'var' if x.mutable else 'let'} %{x.name}: {typ} = {self.ex(x.expr)}")
        elif isinstance(x,Assign): self.emit(f"store %{x.name} = {self.ex(x.expr)}")
        elif isinstance(x,DerefAssign): self.emit(f"store_deref %{x.name} = {self.ex(x.expr)}")
        elif isinstance(x,Return): self.emit("ret"+(" "+self.ex(x.expr) if x.expr else ""))
        elif isinstance(x,ExprStmt): self.emit(self.ex(x.expr))
        elif isinstance(x,If):
            self.emit(f"if {self.ex(x.cond)}"); self.ind+=1
            for y in x.then_body: self.st(y)
            self.ind-=1
            if x.else_body:
                self.emit("else"); self.ind+=1
                for y in x.else_body: self.st(y)
                self.ind-=1
        elif isinstance(x,While):
            self.emit(f"while {self.ex(x.cond)}"); self.ind+=1
            for y in x.body: self.st(y)
            self.ind-=1
        elif isinstance(x,ForRange):
            self.emit(f"for %{x.name} in {self.ex(x.start)} .. {self.ex(x.end)}"); self.ind+=1
            old=b.env.copy(); b.env[x.name]="i64"
            for y in x.body: self.st(y)
            b.env=old; self.ind-=1
        elif isinstance(x,Break): self.emit("break")
        elif isinstance(x,Continue): self.emit("continue")
        elif isinstance(x,Spawn): self.emit(f"spawn @{x.function}")
        elif isinstance(x,Sync): self.emit("sync")
        elif isinstance(x,UnsafeBlock):
            self.emit("unsafe"); self.ind+=1
            for y in x.body: self.st(y)
            self.ind-=1
        elif isinstance(x,MatchStmt):
            self.emit(f"match {self.ex(x.expr)}"); self.ind+=1
            for arm in x.arms:
                self.emit("arm else" if arm.is_else else f"arm %{arm.enum_name}::{arm.variant}" + (f"(%{arm.binder})" if arm.binder else "")); self.ind+=1
                for y in arm.body: self.st(y)
                self.ind-=1
            self.ind-=1
    def generate(self):
        self.emit("nir.version 3")
        self.emit(f"source.language Nexus/{VERSION}")
        self.emit("target portable")
        self.emit("cfg.mode explicit")
        self.emit("ssa.mode memory")
        if self.p.capabilities: self.emit("capabilities " + ",".join(sorted(self.p.capabilities)))
        if self.p.module: self.emit(f"module @{self.p.module}")
        for st in self.p.structs: self.emit(f"type %{st.name} = struct {{ "+", ".join(f.name+": "+f.typ for f in st.fields)+" }")
        for en in self.p.enums: self.emit(f"type %{en.name} = enum {{ "+", ".join(v.name+("("+v.payload+")" if v.payload else "") for v in en.variants)+" }")
        for c in self.p.consts: self.emit(f"global const @{c.name}: {c.typ} = {self.ex(c.expr)}")
        for f in self.p.functions:
            b=self.backend; b.env={p.name:p.typ for p in f.params}; b.mutable={p.name:False for p in f.params}; b.current_return=f.ret; b.current_pure=f.pure
            eff=" [pure]" if f.pure else (" [effects="+",".join(sorted(f.effects))+"]" if f.effects is not None else " [effects=infer]")
            gen=("<"+", ".join(f.type_params)+">") if f.type_params else ""
            async_mark=" [async]" if f.is_async else ""
            entry,exit_block,blocks,edges=CFGBuilder().function(f)
            self.emit(f"cfg @{f.name} entry={entry} exit={exit_block} blocks={len(blocks)} edges={len(edges)}")
            self.ind+=1
            for a,d,k in edges: self.emit(f"edge {a} -> {d} [{k}]")
            self.ind-=1
            self.emit(f"fn @{f.name}{gen}("+", ".join(f"%{p.name}: {p.typ}" for p in f.params)+f") -> {f.ret}"+async_mark+eff)
            self.ind+=1
            self.emit("bb.entry:")
            self.ind+=1
            for x in f.body: self.st(x)
            self.ind-=1
            self.ind-=1
        return "\n".join(self.lines)

def optimize_program(p): return ConstantFolder().run(validate_moves(p))
def compile_to_nir(src:Path): return NIREmitter(optimize_program(load_program(src))).generate()

def verify_nir_text(ir:str):
    lines=[x.rstrip() for x in ir.splitlines() if x.strip()]
    if not lines or lines[0].strip()!="nir.version 3": raise NexusError("NIR verifier expected nir.version 3", code="NX4301")
    if not any(x.strip()=="target portable" for x in lines): raise NexusError("NIR verifier missing target declaration", code="NX4302")
    if not any(x.strip()=="cfg.mode explicit" for x in lines): raise NexusError("NIR3 verifier missing explicit CFG mode", code="NX4304")
    if not any(x.strip()=="ssa.mode memory" for x in lines): raise NexusError("NIR3 verifier missing SSA mode", code="NX4305")
    fn_count=sum(1 for x in lines if x.lstrip().startswith("fn @"))
    entry_count=sum(1 for x in lines if x.strip()=="bb.entry:")
    cfg_lines=[x.strip() for x in lines if x.strip().startswith("cfg @")]
    edge_lines=[x.strip() for x in lines if x.strip().startswith("edge ")]
    if fn_count==0 or entry_count!=fn_count or len(cfg_lines)!=fn_count: raise NexusError("NIR3 verifier requires one CFG and bb.entry per function", code="NX4303")
    declared=set()
    total_blocks=0
    for line in cfg_lines:
        parts=line.split()
        try:
            entry=next(x.split("=",1)[1] for x in parts if x.startswith("entry="))
            exitb=next(x.split("=",1)[1] for x in parts if x.startswith("exit="))
            blocks=int(next(x.split("=",1)[1] for x in parts if x.startswith("blocks=")))
        except Exception:
            raise NexusError("malformed NIR3 CFG declaration", code="NX4306")
        declared.update((entry,exitb)); total_blocks+=blocks
    # CFG block names are function-local; verify every edge is structurally well formed.
    for edge in edge_lines:
        parts=edge.split()
        if len(parts)<4 or parts[2]!="->" or not parts[1].startswith("bb.") or not parts[3].startswith("bb."):
            raise NexusError("malformed NIR3 CFG edge", code="NX4307")
    return {"functions":fn_count,"entry_blocks":entry_count,"cfg_blocks":total_blocks,"edges":len(edge_lines),"lines":len(lines)}

def cmd_verify_ir(src):
    ir=compile_to_nir(Path(src)); stats=verify_nir_text(ir)
    print(f"✓ NIR3 verified: {stats['functions']} function(s), {stats['cfg_blocks']} CFG block(s), {stats['edges']} edge(s), {stats['lines']} IR lines")

# ----------------------------- Direct x86-64 backend -----------------------------

class X64FramesBackend:
    """Direct Nexus -> x86-64 backend for Frames FEX64.

    Nexus 3.6-4.0 expands this backend in staged, version-gated steps:
    3.6 stack aggregates, 3.7 tagged payload enums, 3.8 scalar generic
    monomorphization, 3.9 deterministic defer/move/drop lowering, and 4.0
    a native-generation-1 support contract. Aggregate function ABI passing and
    heap allocation remain intentionally outside this generation.
    """
    ARG_REGS=["%rcx","%rdx","%r8","%r9"]
    ALLOWED={"i32","i64","u32","u64","bool","void"}
    def __init__(self,p):
        self.p=optimize_program(p)
        # The hosted semantic engine remains the reference checker. Native code
        # generation runs only after the whole program passes the same type,
        # ownership, effect, borrow, trait and capability checks as host builds.
        CBackend(self.p).generate()
        self.funcs={f.name:f for f in self.p.functions}; self.consts={c.name:c for c in self.p.consts}
        self.structs={x.name:x for x in self.p.structs}; self.enums={x.name:x for x in self.p.enums}
        self.lines=[]; self.label_id=0; self.layouts={}; self.local_types={}; self.stack_depth=0
        self.break_labels=[]; self.continue_labels=[]; self.loop_defer_depths=[]; self.defer_scopes=[]; self.epilogue=""
        self.current_subst={}; self.current_function=None; self.generic_queue=[]; self.generic_seen=set(); self.current_label=""
        self.level=tuple(int(x) for x in VERSION.split('.')[:2])
        self.allow_structs=self.level >= (3,6)
        self.allow_payload_enums=self.level >= (3,7)
        self.allow_generics=self.level >= (3,8)
        self.allow_resources=self.level >= (3,9)
        self.native_gen1=self.level >= (4,0)
        self.entry_symbol="kernel_main" if self.p.kernel_profile else "main"
        if self.entry_symbol not in self.funcs: raise NexusError(f"x64 backend requires {self.entry_symbol}", code="NX4002")
        for f in self.p.functions:
            if f.is_async: raise NexusError("async functions require the future Frames scheduler ABI in direct native builds", code="NX4030")
            if f.type_params and not self.allow_generics:
                # Generic definitions may exist in source before 3.8, but a direct
                # build cannot lower them until monomorphization is enabled.
                continue
            if not f.type_params:
                self._validate_signature(f,{})
    def emit(self,x=""): self.lines.append(x)
    def lab(self,p="L"): self.label_id+=1; return f".Lnx_{p}_{self.label_id}"
    @staticmethod
    def _generic_parts(t):
        if not isinstance(t,str) or '<' not in t or not t.endswith('>'): return None
        pos=t.find('<'); base=t[:pos]; body=t[pos+1:-1]; args=[]; start=0; depth=0
        for i,ch in enumerate(body):
            if ch=='<': depth+=1
            elif ch=='>': depth-=1
            elif ch==',' and depth==0: args.append(body[start:i]); start=i+1
        args.append(body[start:]); return base,args
    @staticmethod
    def _ref_parts(t):
        if isinstance(t,str) and t.startswith('&mut '): return t[5:],True
        if isinstance(t,str) and t.startswith('&'): return t[1:],False
        return None
    @staticmethod
    def _mangle_type(t): return ''.join(ch if ch.isalnum() or ch=='_' else '_' for ch in t).strip('_') or 'type'
    def materialize(self,t,subst=None):
        subst=self.current_subst if subst is None else subst
        rp=self._ref_parts(t)
        if rp: return ('&mut ' if rp[1] else '&')+self.materialize(rp[0],subst)
        gp=self._generic_parts(t)
        if gp: return gp[0]+'<'+','.join(self.materialize(a,subst) for a in gp[1])+'>'
        return subst.get(t,t)
    def aggregate_decl(self,t):
        gp=self._generic_parts(t)
        if gp:
            decl=self.structs.get(gp[0]) or self.enums.get(gp[0])
            if not decl or len(gp[1])!=len(getattr(decl,'type_params',[])): return None,{}
            if getattr(decl,'type_params',[]) and not self.allow_generics and gp[0] not in {'Option','Result'}: return None,{}
            return decl,dict(zip(decl.type_params,gp[1]))
        return self.structs.get(t) or self.enums.get(t),{}
    def enum_info(self,t):
        decl,subst=self.aggregate_decl(t)
        return (decl,subst) if isinstance(decl,EnumDecl) else (None,{})
    def struct_info(self,t):
        decl,subst=self.aggregate_decl(t)
        return (decl,subst) if isinstance(decl,StructDecl) else (None,{})
    def is_scalar(self,t):
        t=self.materialize(t)
        if t in self.ALLOWED-{'void'} or self._ref_parts(t): return True
        # Ownership handles can cross the native ABI from 3.9, although `new`
        # itself still needs the future Frames allocator/syscall ABI.
        gp=self._generic_parts(t)
        if self.allow_resources and gp and gp[0]=='Owned' and len(gp[1])==1: return True
        en,_=self.enum_info(t)
        return bool(en and not any(v.payload is not None for v in en.variants))
    def size_of(self,t):
        t=self.materialize(t)
        if self.is_scalar(t): return 8
        st,subst=self.struct_info(t)
        if st:
            if not self.allow_structs: raise NexusError("direct x64 structs require Nexus 3.6+", code="NX4040")
            total=0
            for f in st.fields:
                ft=self.materialize(f.typ,subst); sz=self.size_of(ft)
                if sz>16: raise NexusError(f"native aggregate field {st.name}.{f.name} is too large for generation 1", code="NX4041")
                total += _align_up(sz,8)
            return max(total,8)
        en,subst=self.enum_info(t)
        if en:
            payloads=[self.materialize(v.payload,subst) for v in en.variants if v.payload is not None]
            if not payloads: return 8
            if not self.allow_payload_enums: raise NexusError("payload enum lowering requires Nexus 3.7+", code="NX4042")
            if any(not self.is_scalar(x) for x in payloads): raise NexusError("native generation 1 payload enums require scalar/reference payloads", code="NX4043")
            return 16
        raise NexusError(f"x64 backend cannot lay out type {t}", code="NX4044")
    def field_layout(self,t,field):
        st,subst=self.struct_info(t)
        if not st: raise NexusError(f"field access requires native struct, got {t}", code="NX4045")
        off=0
        for f in st.fields:
            ft=self.materialize(f.typ,subst); sz=_align_up(self.size_of(ft),8)
            if f.name==field: return off,ft
            off+=sz
        raise NexusError(f"unknown field {field} on {t}", code="NX4046")
    def _validate_signature(self,f,subst):
        ret=self.materialize(f.ret,subst)
        # Generation 1 keeps aggregate calling convention out of the ABI until
        # register/stack classification is specified. Locals can still be rich.
        if ret!='void' and not self.is_scalar(ret): raise NexusError(f"native generation 1 does not yet return aggregate type {ret} ({f.name})", code="NX4047")
        for p in f.params:
            pt=self.materialize(p.typ,subst)
            if not self.is_scalar(pt): raise NexusError(f"native generation 1 does not yet pass aggregate parameter {pt} ({f.name}.{p.name})", code="NX4048")
        if len(f.params)>4: raise NexusError(f"x64 backend supports at most 4 parameters ({f.name})", code="NX4004")
    def match_generic(self,pattern,actual,type_params,mapping):
        pr=self._ref_parts(pattern); ar=self._ref_parts(actual)
        if pr:
            return bool(ar and pr[1]==ar[1] and self.match_generic(pr[0],ar[0],type_params,mapping))
        if pattern in type_params:
            old=mapping.get(pattern)
            if old is None: mapping[pattern]=actual; return True
            return old==actual
        pg=self._generic_parts(pattern); ag=self._generic_parts(actual)
        if pg:
            return bool(ag and pg[0]==ag[0] and len(pg[1])==len(ag[1]) and all(self.match_generic(a,b,type_params,mapping) for a,b in zip(pg[1],ag[1])))
        return self.materialize(pattern)==actual
    def resolve_call(self,e):
        fn=self.funcs.get(e.name)
        if not fn: raise NexusError(f"unknown function {e.name}", code="NX4012")
        if not fn.type_params: return fn,{},fn.name,self.materialize(fn.ret)
        if not self.allow_generics: raise NexusError("direct generic lowering requires Nexus 3.8+", code="NX4050")
        actuals=[self.type_of(a) for a in e.args]; mapping={}
        for param,actual in zip(fn.params,actuals):
            if not self.match_generic(param.typ,actual,set(fn.type_params),mapping): raise NexusError(f"cannot infer native generic {fn.name} from {actual}", code="NX4051")
        if any(tp not in mapping for tp in fn.type_params): raise NexusError(f"cannot infer all native generic parameters for {fn.name}", code="NX4052")
        key=tuple(mapping[tp] for tp in fn.type_params); label=fn.name+'__nxg__'+'__'.join(self._mangle_type(x) for x in key)
        q=(fn.name,key)
        if q not in self.generic_seen: self.generic_seen.add(q); self.generic_queue.append((fn,dict(mapping),label))
        self._validate_signature(fn,mapping)
        return fn,mapping,label,self.materialize(fn.ret,mapping)
    def type_of(self,e):
        if isinstance(e,Literal): return e.typ
        if isinstance(e,(VarRef,Move)):
            if e.name in self.local_types: return self.local_types[e.name]
            if e.name in self.consts: return self.materialize(self.consts[e.name].typ)
            raise NexusError(f"native backend unknown value {e.name}", code="NX4006")
        if isinstance(e,Borrow):
            if e.name not in self.local_types: raise NexusError(f"native backend cannot borrow unknown local {e.name}", code="NX4017")
            return ('&mut ' if e.mutable else '&')+self.local_types[e.name]
        if isinstance(e,Unary):
            t=self.type_of(e.expr)
            if e.op=='*':
                rp=self._ref_parts(t)
                if rp: return rp[0]
                gp=self._generic_parts(t)
                if gp and gp[0]=='Owned': return gp[1][0]
            if e.op=='!': return 'bool'
            return t
        if isinstance(e,Binary):
            if e.op in {'==','!=','<','>','<=','>=','&&','||'}: return 'bool'
            a=self.type_of(e.left); b=self.type_of(e.right)
            for pref in ('u64','i64','u32','i32'):
                if pref in {a,b}: return pref
            return a
        if isinstance(e,Call):
            if e.name in KERNEL_BUILTINS:
                if not self.p.kernel_profile: raise NexusError(f"{e.name} requires kernel profile", code="NX4610")
                return {"cpu_halt":"void","cpu_pause":"void","interrupts_disable":"void","interrupts_enable":"void","io_read8":"u32","io_write8":"void","io_read16":"u32","io_write16":"void","io_read32":"u32","io_write32":"void","volatile_read8":"u32","volatile_write8":"void","volatile_read32":"u32","volatile_write32":"void","volatile_read64":"u64","volatile_write64":"void","mmio_read64":"u64","mmio_write64":"void","read_cr0":"u64","write_cr0":"void","read_cr2":"u64","read_cr3":"u64","write_cr3":"void","read_cr4":"u64","write_cr4":"void","stac":"void","clac":"void","invalidate_page":"void","interrupt_stub_address":"u64","page_fault_stub_address":"u64","timer_stub_address":"u64","lapic_timer_stub_address":"u64","reschedule_stub_address":"u64","user_syscall_stub_address":"u64","user_enter":"void","user_return":"void","user_enter_context":"void","user_return_context":"void","ap_entry_address":"u64","spurious_stub_address":"u64","thread_entry_stub_address":"u64","context_switch":"void","read_msr":"u64","write_msr":"void","cpuid_eax":"u64","cpuid_ebx":"u64","cpuid_ecx":"u64","cpuid_edx":"u64","read_tsc":"u64","load_idt":"void","load_gdt":"void","load_tr":"void","read_cs":"u64","reload_cs":"void","reload_data_segments":"void","ts_fault_stub_address":"u64","np_fault_stub_address":"u64","ss_fault_stub_address":"u64","gp_fault_stub_address":"u64"}[e.name]
            return self.resolve_call(e)[3]
        if isinstance(e,StructInit): return self.materialize(e.name)
        if isinstance(e,FieldAccess):
            ot=self.type_of(e.obj); rp=self._ref_parts(ot); base=rp[0] if rp else ot
            return self.field_layout(base,e.field)[1]
        if isinstance(e,EnumValue): return self.materialize(e.enum_name)
        if isinstance(e,TryExpr):
            gp=self._generic_parts(self.type_of(e.expr))
            if gp and gp[0]=='Option': return gp[1][0]
            if gp and gp[0]=='Result': return gp[1][0]
        raise NexusError(f"expression is outside x64 native generation profile: {type(e).__name__}", code="NX4014")
    def discover_body(self,body,env):
        old=self.local_types; self.local_types=env
        try:
            for st in body:
                if isinstance(st,Let):
                    typ=self.materialize(st.typ) if st.typ else self.type_of(st.expr); env[st.name]=typ
                elif isinstance(st,ForRange):
                    env[st.name]='i64'; self.discover_body(st.body,env)
                elif isinstance(st,If): self.discover_body(st.then_body,env); self.discover_body(st.else_body,env)
                elif isinstance(st,While): self.discover_body(st.body,env)
                elif isinstance(st,UnsafeBlock): self.discover_body(st.body,env)
                elif isinstance(st,Defer): self.discover_body(st.body,env)
                elif isinstance(st,MatchStmt):
                    et=self.type_of(st.expr); en,subst=self.enum_info(et)
                    if en:
                        for arm in st.arms:
                            if arm.binder:
                                var=next((v for v in en.variants if v.name==arm.variant),None)
                                if var and var.payload: env[arm.binder]=self.materialize(var.payload,subst)
                            self.discover_body(arm.body,env)
        finally: self.local_types=old
    def prepare_function(self,f,subst,label):
        self.current_function=f; self.current_subst=dict(subst); self.current_label=label
        env={p.name:self.materialize(p.typ,subst) for p in f.params}
        self.local_types=env; self.discover_body(f.body,env); self.local_types=env
        self._validate_signature(f,subst)
        offset=0; self.layouts={}
        for name,t in env.items():
            sz=_align_up(self.size_of(t),8); offset+=sz; self.layouts[name]=(offset,sz,t)
        self.frame=_align_up(offset,16); self.stack_depth=0; self.defer_scopes=[]; self.break_labels=[]; self.continue_labels=[]; self.loop_defer_depths=[]
    def mem(self,name,extra=0):
        if name not in self.layouts: raise NexusError(f"x64 backend unknown local {name}", code="NX4006")
        base=self.layouts[name][0]; return f"-{base-extra}(%rbp)"
    def load_scalar(self,name,extra=0): self.emit(f"    movq {self.mem(name,extra)}, %rax")
    def store_scalar(self,name,extra=0,reg='%rax'): self.emit(f"    movq {reg}, {self.mem(name,extra)}")
    def zero_value(self,name):
        _,sz,_=self.layouts[name]
        for off in range(0,sz,8): self.emit(f"    movq $0, {self.mem(name,off)}")
    def enum_variant(self,t,name):
        en,subst=self.enum_info(t)
        if not en: return None,None,None
        for i,v in enumerate(en.variants):
            if v.name==name: return en,subst,(i,v)
        return en,subst,None
    def store_value(self,name,e,typ=None):
        typ=typ or self.local_types[name]
        st,subst=self.struct_info(typ)
        if st:
            if isinstance(e,Move):
                src=e.name
                if self.local_types.get(src)!=typ: raise NexusError("aggregate move type mismatch", code="NX4053")
                _,sz,_=self.layouts[name]
                for off in range(0,sz,8): self.emit(f"    movq {self.mem(src,off)}, %r10"); self.emit(f"    movq %r10, {self.mem(name,off)}")
                if self.allow_resources: self.zero_value(src)
                return
            if not isinstance(e,StructInit): raise NexusError("native aggregate assignment currently requires struct initializer or move", code="NX4054")
            vals=dict(e.fields); off=0
            for f in st.fields:
                ft=self.materialize(f.typ,subst); self.expr(vals[f.name]); self.emit(f"    movq %rax, {self.mem(name,off)}"); off+=_align_up(self.size_of(ft),8)
            return
        en,esub=self.enum_info(typ)
        if en and any(v.payload is not None for v in en.variants):
            if not isinstance(e,EnumValue): raise NexusError("native tagged enum assignment currently requires enum constructor", code="NX4055")
            _en,_sub,info=self.enum_variant(typ,e.variant)
            if not info: raise NexusError(f"unknown enum variant {e.variant}", code="NX4024")
            idx,var=info; self.emit(f"    movq ${idx}, {self.mem(name,0)}")
            if var.payload is not None: self.expr(e.payload); self.emit(f"    movq %rax, {self.mem(name,8)}")
            else: self.emit(f"    movq $0, {self.mem(name,8)}")
            return
        self.expr(e); self.store_scalar(name)
    def check_expr(self,e):
        # type_of performs the profile checks; this keeps a dedicated hook for
        # clearer backend diagnostics and future legalization passes.
        self.type_of(e)
    def expr(self,e):
        self.check_expr(e)
        if isinstance(e,Literal): self.emit(f"    movq ${1 if e.value is True else 0 if e.value is False else int(e.value)}, %rax"); return
        if isinstance(e,VarRef):
            if e.name in self.consts:
                c=self.consts[e.name]
                if isinstance(c.expr,Literal): self.emit(f"    movq ${1 if c.expr.value is True else 0 if c.expr.value is False else int(c.expr.value)}, %rax"); return
                if isinstance(c.expr,EnumValue):
                    et=self.materialize(c.typ); en,_,info=self.enum_variant(et,c.expr.variant)
                    if en and info and not any(v.payload is not None for v in en.variants): self.emit(f"    movq ${info[0]}, %rax"); return
                raise NexusError("native constant must be primitive or payloadless enum", code="NX4016")
            if self.size_of(self.local_types[e.name])!=8: raise NexusError("whole aggregate value requires field/match context in native generation 1", code="NX4056")
            self.load_scalar(e.name); return
        if isinstance(e,Move):
            if self.size_of(self.local_types[e.name])!=8: raise NexusError("aggregate move must initialize an aggregate local", code="NX4057")
            self.load_scalar(e.name)
            if self.allow_resources: self.emit(f"    movq $0, {self.mem(e.name)}")
            return
        if isinstance(e,Borrow): self.emit(f"    leaq {self.mem(e.name)}, %rax"); return
        if isinstance(e,Unary):
            self.expr(e.expr)
            if e.op=='-': self.emit("    negq %rax")
            elif e.op=='!': self.emit("    cmpq $0, %rax"); self.emit("    sete %al"); self.emit("    movzbq %al, %rax")
            elif e.op=='*': self.emit("    movq (%rax), %rax")
            return
        if isinstance(e,FieldAccess):
            if not isinstance(e.obj,VarRef): raise NexusError("native generation 1 field access requires a local struct or reference", code="NX4058")
            ot=self.local_types[e.obj.name]; rp=self._ref_parts(ot); base=rp[0] if rp else ot
            off,ft=self.field_layout(base,e.field)
            if self.size_of(ft)!=8: raise NexusError("nested aggregate field value is not yet first-class", code="NX4059")
            if rp:
                self.load_scalar(e.obj.name); self.emit(f"    movq {off}(%rax), %rax")
            else:
                self.load_scalar(e.obj.name,off)
            return
        if isinstance(e,EnumValue):
            et=self.materialize(e.enum_name); en,_,info=self.enum_variant(et,e.variant)
            if not en or not info: raise NexusError("unknown enum value", code="NX4015")
            if any(v.payload is not None for v in en.variants): raise NexusError("payload enum constructor must initialize a native local", code="NX4060")
            self.emit(f"    movq ${info[0]}, %rax"); return
        if isinstance(e,Binary):
            op=e.op
            if op=='&&':
                lf=self.lab("and_false"); ld=self.lab("and_done")
                self.expr(e.left)
                self.emit("    cmpq $0, %rax"); self.emit(f"    je {lf}")
                self.expr(e.right)
                self.emit("    cmpq $0, %rax"); self.emit("    setne %al"); self.emit("    movzbq %al, %rax")
                self.emit(f"    jmp {ld}")
                self.emit(f"{lf}:"); self.emit("    xorq %rax, %rax")
                self.emit(f"{ld}:")
                return
            if op=='||':
                lt=self.lab("or_true"); ld=self.lab("or_done")
                self.expr(e.left)
                self.emit("    cmpq $0, %rax"); self.emit(f"    jne {lt}")
                self.expr(e.right)
                self.emit("    cmpq $0, %rax"); self.emit("    setne %al"); self.emit("    movzbq %al, %rax")
                self.emit(f"    jmp {ld}")
                self.emit(f"{lt}:"); self.emit("    movq $1, %rax")
                self.emit(f"{ld}:")
                return
            self.expr(e.left); self.emit("    pushq %rax"); self.stack_depth+=1
            self.expr(e.right); self.emit("    movq %rax, %r10"); self.emit("    popq %rax"); self.stack_depth-=1
            if op=='+': self.emit("    addq %r10, %rax")
            elif op=='-': self.emit("    subq %r10, %rax")
            elif op=='*': self.emit("    imulq %r10, %rax")
            elif op in {'/','%'}:
                arithmetic_type=self.type_of(e)
                if arithmetic_type in {'u64','u32'}:
                    self.emit("    xorq %rdx, %rdx"); self.emit("    divq %r10")
                else:
                    self.emit("    cqto"); self.emit("    idivq %r10")
                if op=='%': self.emit("    movq %rdx, %rax")
            elif op in {'==','!=','<','>','<=','>='}:
                self.emit("    cmpq %r10, %rax")
                if op in {'==','!='}:
                    cc={'==':'e','!=':'ne'}[op]
                else:
                    left_type=self.type_of(e.left); right_type=self.type_of(e.right)
                    unsigned = left_type in {'u64','u32'} or right_type in {'u64','u32'}
                    cc=({'<':'b','>':'a','<=':'be','>=':'ae'} if unsigned else {'<':'l','>':'g','<=':'le','>=':'ge'})[op]
                self.emit(f"    set{cc} %al"); self.emit("    movzbq %al, %rax")
            return
        if isinstance(e,Call):
            if e.name in KERNEL_BUILTINS:
                if not self.p.kernel_profile: raise NexusError(f"{e.name} requires kernel profile", code="NX4610")
                if e.name=="cpu_halt": self.emit("    hlt"); self.emit("    xorq %rax, %rax"); return
                if e.name=="cpu_pause": self.emit("    pause"); self.emit("    xorq %rax, %rax"); return
                if e.name=="interrupts_disable": self.emit("    cli"); self.emit("    xorq %rax, %rax"); return
                if e.name=="interrupts_enable": self.emit("    sti"); self.emit("    xorq %rax, %rax"); return
                if e.name=="io_read8":
                    self.expr(e.args[0]); self.emit("    movw %ax, %dx"); self.emit("    xorl %eax, %eax"); self.emit("    inb %dx, %al"); return
                if e.name=="io_write8":
                    self.expr(e.args[0]); self.emit("    movw %ax, %dx"); self.emit("    pushq %rdx"); self.expr(e.args[1]); self.emit("    movb %al, %cl"); self.emit("    popq %rdx"); self.emit("    movb %cl, %al"); self.emit("    outb %al, %dx"); self.emit("    xorq %rax, %rax"); return
                if e.name=="io_read16":
                    self.expr(e.args[0]); self.emit("    movw %ax, %dx"); self.emit("    xorl %eax, %eax"); self.emit("    inw %dx, %ax"); return
                if e.name=="io_write16":
                    self.expr(e.args[0]); self.emit("    movw %ax, %dx"); self.emit("    pushq %rdx"); self.expr(e.args[1]); self.emit("    movw %ax, %r10w"); self.emit("    popq %rdx"); self.emit("    movw %r10w, %ax"); self.emit("    outw %ax, %dx"); self.emit("    xorq %rax, %rax"); return
                if e.name=="io_read32":
                    self.expr(e.args[0]); self.emit("    movw %ax, %dx"); self.emit("    xorl %eax, %eax"); self.emit("    inl %dx, %eax"); return
                if e.name=="io_write32":
                    self.expr(e.args[0]); self.emit("    movw %ax, %dx"); self.emit("    pushq %rdx"); self.expr(e.args[1]); self.emit("    movl %eax, %r10d"); self.emit("    popq %rdx"); self.emit("    movl %r10d, %eax"); self.emit("    outl %eax, %dx"); self.emit("    xorq %rax, %rax"); return
                if e.name=="volatile_read8":
                    self.expr(e.args[0]); self.emit("    movzbl (%rax), %eax"); return
                if e.name=="volatile_write8":
                    self.expr(e.args[0]); self.emit("    pushq %rax"); self.expr(e.args[1]); self.emit("    movb %al, %r10b"); self.emit("    popq %rax"); self.emit("    movb %r10b, (%rax)"); self.emit("    xorq %rax, %rax"); return
                if e.name=="volatile_read32":
                    self.expr(e.args[0]); self.emit("    movl (%rax), %eax"); return
                if e.name=="volatile_write32":
                    self.expr(e.args[0]); self.emit("    pushq %rax"); self.expr(e.args[1]); self.emit("    movl %eax, %r10d"); self.emit("    popq %rax"); self.emit("    movl %r10d, (%rax)"); self.emit("    xorq %rax, %rax"); return
                if e.name in {"volatile_read64","mmio_read64"}:
                    self.expr(e.args[0]); self.emit("    movq (%rax), %rax"); return
                if e.name in {"volatile_write64","mmio_write64"}:
                    self.expr(e.args[0]); self.emit("    pushq %rax"); self.expr(e.args[1]); self.emit("    movq %rax, %r10"); self.emit("    popq %rax"); self.emit("    movq %r10, (%rax)"); self.emit("    xorq %rax, %rax"); return
                if e.name=="read_cr0": self.emit("    movq %cr0, %rax"); return
                if e.name=="write_cr0": self.expr(e.args[0]); self.emit("    movq %rax, %cr0"); self.emit("    xorq %rax, %rax"); return
                if e.name=="read_cr2": self.emit("    movq %cr2, %rax"); return
                if e.name=="read_cr3": self.emit("    movq %cr3, %rax"); return
                if e.name=="write_cr3": self.expr(e.args[0]); self.emit("    movq %rax, %cr3"); self.emit("    xorq %rax, %rax"); return
                if e.name=="read_cr4": self.emit("    movq %cr4, %rax"); return
                if e.name=="write_cr4": self.expr(e.args[0]); self.emit("    movq %rax, %cr4"); self.emit("    xorq %rax, %rax"); return
                if e.name=="stac": self.emit("    stac"); self.emit("    xorq %rax, %rax"); return
                if e.name=="clac": self.emit("    clac"); self.emit("    xorq %rax, %rax"); return
                if e.name=="invalidate_page": self.expr(e.args[0]); self.emit("    invlpg (%rax)"); self.emit("    xorq %rax, %rax"); return
                if e.name=="interrupt_stub_address": self.emit("    leaq nx_kernel_interrupt_halt(%rip), %rax"); return
                if e.name=="page_fault_stub_address": self.emit("    leaq nx_kernel_page_fault_stub(%rip), %rax"); return
                if e.name=="timer_stub_address": self.emit("    leaq nx_kernel_timer_stub(%rip), %rax"); return
                if e.name=="lapic_timer_stub_address": self.emit("    leaq nx_kernel_lapic_timer_stub(%rip), %rax"); return
                if e.name=="reschedule_stub_address": self.emit("    leaq nx_kernel_reschedule_stub(%rip), %rax"); return
                if e.name=="user_syscall_stub_address": self.emit("    leaq nx_kernel_user_syscall_stub(%rip), %rax"); return
                if e.name=="user_enter":
                    for a in e.args: self.expr(a); self.emit("    pushq %rax"); self.stack_depth+=1
                    for i in range(4): self.emit(f"    movq {8*(3-i)}(%rsp), {self.ARG_REGS[i]}")
                    pad=8 if (self.stack_depth % 2) else 0
                    if pad: self.emit("    subq $8, %rsp")
                    self.emit("    subq $32, %rsp"); self.emit("    callq nx_kernel_user_enter"); self.emit("    addq $32, %rsp")
                    if pad: self.emit("    addq $8, %rsp")
                    self.emit("    addq $32, %rsp"); self.stack_depth-=4; self.emit("    xorq %rax, %rax"); return
                if e.name=="user_return":
                    self.expr(e.args[0]); self.emit("    pushq %rax"); self.stack_depth+=1; self.expr(e.args[1]); self.emit("    movq %rax, %rdx"); self.emit("    popq %rcx"); self.stack_depth-=1
                    self.emit("    subq $32, %rsp"); self.emit("    callq nx_kernel_user_return"); self.emit("    ud2"); return
                if e.name=="user_enter_context":
                    for a in e.args: self.expr(a); self.emit("    pushq %rax"); self.stack_depth+=1
                    for i in range(4): self.emit(f"    movq {8*(3-i)}(%rsp), {self.ARG_REGS[i]}")
                    pad=8 if (self.stack_depth % 2) else 0
                    if pad: self.emit("    subq $8, %rsp")
                    self.emit("    subq $32, %rsp"); self.emit("    callq nx_kernel_user_enter_context"); self.emit("    addq $32, %rsp")
                    if pad: self.emit("    addq $8, %rsp")
                    self.emit("    addq $32, %rsp"); self.stack_depth-=4; self.emit("    xorq %rax, %rax"); return
                if e.name=="user_return_context":
                    self.expr(e.args[0]); self.emit("    pushq %rax"); self.stack_depth+=1; self.expr(e.args[1]); self.emit("    movq %rax, %rdx"); self.emit("    popq %rcx"); self.stack_depth-=1
                    self.emit("    subq $32, %rsp"); self.emit("    callq nx_kernel_user_return_context"); self.emit("    ud2"); return
                if e.name=="ap_entry_address": self.emit("    leaq kernel_ap_entry(%rip), %rax"); return
                if e.name=="spurious_stub_address": self.emit("    leaq nx_kernel_spurious_stub(%rip), %rax"); return
                if e.name=="thread_entry_stub_address": self.emit("    leaq nx_kernel_thread_entry_stub(%rip), %rax"); return
                if e.name=="context_switch":
                    self.expr(e.args[0]); self.emit("    pushq %rax"); self.stack_depth+=1
                    self.expr(e.args[1]); self.emit("    movq %rax, %rdx"); self.emit("    popq %rcx"); self.stack_depth-=1
                    pad=8 if (self.stack_depth % 2) else 0
                    if pad: self.emit("    subq $8, %rsp")
                    self.emit("    subq $32, %rsp"); self.emit("    callq nx_kernel_context_switch"); self.emit("    addq $32, %rsp")
                    if pad: self.emit("    addq $8, %rsp")
                    self.emit("    xorq %rax, %rax"); return
                if e.name=="read_msr":
                    self.expr(e.args[0]); self.emit("    movl %eax, %ecx"); self.emit("    rdmsr"); self.emit("    shlq $32, %rdx"); self.emit("    orq %rdx, %rax"); return
                if e.name=="write_msr":
                    self.expr(e.args[0]); self.emit("    pushq %rax"); self.expr(e.args[1]); self.emit("    movq %rax, %r10"); self.emit("    popq %rcx"); self.emit("    movl %r10d, %eax"); self.emit("    shrq $32, %r10"); self.emit("    movl %r10d, %edx"); self.emit("    wrmsr"); self.emit("    xorq %rax, %rax"); return
                if e.name in {"cpuid_eax","cpuid_ebx","cpuid_ecx","cpuid_edx"}:
                    self.expr(e.args[0]); self.emit("    pushq %rax"); self.expr(e.args[1]); self.emit("    movl %eax, %ecx"); self.emit("    popq %rax"); self.emit("    pushq %rbx"); self.emit("    cpuid")
                    if e.name=="cpuid_eax": self.emit("    movl %eax, %r10d")
                    elif e.name=="cpuid_ebx": self.emit("    movl %ebx, %r10d")
                    elif e.name=="cpuid_ecx": self.emit("    movl %ecx, %r10d")
                    else: self.emit("    movl %edx, %r10d")
                    self.emit("    popq %rbx"); self.emit("    movl %r10d, %eax"); return
                if e.name=="read_tsc":
                    self.emit("    rdtsc"); self.emit("    shlq $32, %rdx"); self.emit("    orq %rdx, %rax"); return
                if e.name=="read_cs": self.emit("    xorq %rax, %rax"); self.emit("    movw %cs, %ax"); return
                if e.name=="reload_cs":
                    self.expr(e.args[0]); self.emit("    movq %rax, %r10")
                    target=self.lab("reload_cs")
                    self.emit("    pushq %r10"); self.emit(f"    leaq {target}(%rip), %rax"); self.emit("    pushq %rax"); self.emit("    lretq"); self.emit(f"{target}:"); self.emit("    xorq %rax, %rax"); return
                if e.name=="reload_data_segments":
                    self.expr(e.args[0]); self.emit("    movw %ax, %ds"); self.emit("    movw %ax, %es"); self.emit("    movw %ax, %ss"); self.emit("    xorq %rax, %rax"); return
                if e.name=="ts_fault_stub_address": self.emit("    leaq nx_kernel_ts_fault_stub(%rip), %rax"); return
                if e.name=="np_fault_stub_address": self.emit("    leaq nx_kernel_np_fault_stub(%rip), %rax"); return
                if e.name=="ss_fault_stub_address": self.emit("    leaq nx_kernel_ss_fault_stub(%rip), %rax"); return
                if e.name=="gp_fault_stub_address": self.emit("    leaq nx_kernel_gp_fault_stub(%rip), %rax"); return
                if e.name=="load_gdt":
                    self.expr(e.args[0]); self.emit("    pushq %rax"); self.expr(e.args[1]); self.emit("    movq %rax, %r10"); self.emit("    popq %rax")
                    self.emit("    subq $16, %rsp"); self.emit("    movw %r10w, (%rsp)"); self.emit("    movq %rax, 2(%rsp)"); self.emit("    lgdt (%rsp)"); self.emit("    addq $16, %rsp"); self.emit("    xorq %rax, %rax"); return
                if e.name=="load_tr":
                    self.expr(e.args[0]); self.emit("    ltr %ax"); self.emit("    xorq %rax, %rax"); return
                if e.name=="load_idt":
                    self.expr(e.args[0]); self.emit("    pushq %rax"); self.expr(e.args[1]); self.emit("    movq %rax, %r10"); self.emit("    popq %rax");
                    self.emit("    subq $16, %rsp"); self.emit("    movw %r10w, (%rsp)"); self.emit("    movq %rax, 2(%rsp)"); self.emit("    lidt (%rsp)"); self.emit("    addq $16, %rsp"); self.emit("    xorq %rax, %rax"); return
            fn,mapping,label,_ret=self.resolve_call(e); n=len(e.args)
            if n>4: raise NexusError("x64 backend supports at most 4 call arguments", code="NX4013")
            for a in e.args:
                if self.size_of(self.type_of(a))!=8: raise NexusError("native generation 1 calls require scalar/reference arguments", code="NX4061")
                self.expr(a); self.emit("    pushq %rax"); self.stack_depth+=1
            for i in range(n): self.emit(f"    movq {8*(n-1-i)}(%rsp), {self.ARG_REGS[i]}")
            pad=8 if (self.stack_depth % 2) else 0
            if pad: self.emit("    subq $8, %rsp")
            self.emit("    subq $32, %rsp"); self.emit(f"    callq {label}"); self.emit("    addq $32, %rsp")
            if pad: self.emit("    addq $8, %rsp")
            if n: self.emit(f"    addq ${8*n}, %rsp"); self.stack_depth-=n
            return
        raise NexusError(f"expression is outside x64 native generation profile: {type(e).__name__}", code="NX4014")
    def emit_pending_defers(self,min_depth=0):
        if not self.allow_resources: return
        for scope in reversed(self.defer_scopes[min_depth:]):
            for body in reversed(scope):
                for x in body: self.stmt(x,from_defer=True)
    def emit_block(self,body):
        self.defer_scopes.append([])
        for st in body: self.stmt(st)
        if self.allow_resources:
            for dbody in reversed(self.defer_scopes[-1]):
                for x in dbody: self.stmt(x,from_defer=True)
        self.defer_scopes.pop()
    def stmt(self,st,from_defer=False):
        if isinstance(st,Let): self.store_value(st.name,st.expr,self.local_types[st.name]); return
        if isinstance(st,Assign):
            if self.size_of(self.local_types[st.name])!=8: raise NexusError("native aggregate reassignment is deferred; initialize or move it", code="NX4062")
            self.expr(st.expr); self.store_scalar(st.name); return
        if isinstance(st,DerefAssign): self.expr(st.expr); self.emit("    movq %rax, %r10"); self.load_scalar(st.name); self.emit("    movq %r10, (%rax)"); return
        if isinstance(st,Drop):
            if self.allow_resources: self.zero_value(st.name)
            return
        if isinstance(st,Defer):
            if not self.allow_resources: raise NexusError("direct defer lowering requires Nexus 3.9+", code="NX4063")
            if from_defer: raise NexusError("nested direct defer is not supported", code="NX4064")
            self.defer_scopes[-1].append(st.body); return
        if isinstance(st,Return):
            if st.expr is not None: self.expr(st.expr)
            else: self.emit("    xorq %rax, %rax")
            if self.allow_resources:
                self.emit("    pushq %rax"); self.emit_pending_defers(0); self.emit("    popq %rax")
            self.emit(f"    jmp {self.epilogue}"); return
        if isinstance(st,ExprStmt): self.expr(st.expr); return
        if isinstance(st,If):
            le=self.lab('else'); ld=self.lab('endif'); self.expr(st.cond); self.emit("    cmpq $0, %rax"); self.emit(f"    je {le}"); self.emit_block(st.then_body); self.emit(f"    jmp {ld}"); self.emit(f"{le}:"); self.emit_block(st.else_body); self.emit(f"{ld}:"); return
        if isinstance(st,While):
            ls=self.lab('while'); le=self.lab('endwhile'); self.emit(f"{ls}:"); self.expr(st.cond); self.emit("    cmpq $0, %rax"); self.emit(f"    je {le}")
            self.break_labels.append(le); self.continue_labels.append(ls); self.loop_defer_depths.append(len(self.defer_scopes)); self.emit_block(st.body); self.loop_defer_depths.pop(); self.break_labels.pop(); self.continue_labels.pop(); self.emit(f"    jmp {ls}"); self.emit(f"{le}:"); return
        if isinstance(st,ForRange):
            self.expr(st.start); self.store_scalar(st.name); ls=self.lab('for'); li=self.lab('forinc'); le=self.lab('endfor'); self.emit(f"{ls}:"); self.expr(st.end); self.emit("    movq %rax, %r10"); self.load_scalar(st.name); self.emit("    cmpq %r10, %rax"); self.emit(f"    jge {le}")
            self.break_labels.append(le); self.continue_labels.append(li); self.loop_defer_depths.append(len(self.defer_scopes)); self.emit_block(st.body); self.loop_defer_depths.pop(); self.break_labels.pop(); self.continue_labels.pop(); self.emit(f"{li}:"); self.emit(f"    addq $1, {self.mem(st.name)}"); self.emit(f"    jmp {ls}"); self.emit(f"{le}:"); return
        if isinstance(st,MatchStmt):
            et=self.type_of(st.expr); en,subst=self.enum_info(et)
            if not en: raise NexusError("native match requires enum", code="NX4023")
            payload=any(v.payload is not None for v in en.variants)
            if payload:
                if not self.allow_payload_enums or not isinstance(st.expr,VarRef): raise NexusError("native payload match requires a local tagged enum", code="NX4065")
                self.emit(f"    movq {self.mem(st.expr.name,0)}, %r11")
            else: self.expr(st.expr); self.emit("    movq %rax, %r11")
            end=self.lab('endmatch'); else_arm=None
            for arm in st.arms:
                if arm.is_else: else_arm=arm; continue
                idxvar=next(((i,v) for i,v in enumerate(en.variants) if v.name==arm.variant),None)
                if not idxvar: raise NexusError(f"unknown enum variant {arm.variant}", code="NX4024")
                idx,var=idxvar; nxt=self.lab('matchnext'); self.emit(f"    cmpq ${idx}, %r11"); self.emit(f"    jne {nxt}")
                if arm.binder:
                    if not payload or var.payload is None: raise NexusError("payload binder requires payload variant", code="NX4005")
                    self.emit(f"    movq {self.mem(st.expr.name,8)}, %r10"); self.emit(f"    movq %r10, {self.mem(arm.binder)}")
                self.emit_block(arm.body); self.emit(f"    jmp {end}"); self.emit(f"{nxt}:")
            if else_arm: self.emit_block(else_arm.body)
            self.emit(f"{end}:"); return
        if isinstance(st,Break):
            if not self.break_labels: raise NexusError("break outside loop", code="NX4020")
            if self.allow_resources and self.loop_defer_depths: self.emit_pending_defers(self.loop_defer_depths[-1])
            self.emit(f"    jmp {self.break_labels[-1]}"); return
        if isinstance(st,Continue):
            if not self.continue_labels: raise NexusError("continue outside loop", code="NX4021")
            if self.allow_resources and self.loop_defer_depths: self.emit_pending_defers(self.loop_defer_depths[-1])
            self.emit(f"    jmp {self.continue_labels[-1]}"); return
        if isinstance(st,UnsafeBlock): self.emit_block(st.body); return
        raise NexusError(f"statement is outside x64 native generation profile: {type(st).__name__}", code="NX4022")
    def function(self,f,subst=None,label=None):
        subst=subst or {}; label=label or f.name; self.prepare_function(f,subst,label); self.epilogue=self.lab(f"ret_{label}")
        self.emit(f".globl {label}"); self.emit(f"{label}:"); self.emit("    pushq %rbp"); self.emit("    movq %rsp, %rbp")
        if self.frame: self.emit(f"    subq ${self.frame}, %rsp")
        for i,p in enumerate(f.params): self.emit(f"    movq {self.ARG_REGS[i]}, {self.mem(p.name)}")
        self.emit_block(f.body)
        self.emit("    xorq %rax, %rax"); self.emit(f"{self.epilogue}:"); self.emit("    movq %rbp, %rsp"); self.emit("    popq %rbp"); self.emit("    retq"); self.emit()
    def generate(self):
        self.emit("# Nexus direct x86-64 backend") ; self.emit(".text")
        for f in self.p.functions:
            if not f.type_params: self.function(f)
        while self.generic_queue:
            f,subst,label=self.generic_queue.pop(0); self.function(f,subst,label)
        if self.p.kernel_profile:
            self.emit('.globl nx_kernel_interrupt_halt'); self.emit('nx_kernel_interrupt_halt:'); self.emit('    cli'); self.emit('.Lnx_interrupt_halt_loop:'); self.emit('    hlt'); self.emit('    jmp .Lnx_interrupt_halt_loop'); self.emit()
            if any(isinstance(n,Call) and n.name=='page_fault_stub_address' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_page_fault_stub'); self.emit('nx_kernel_page_fault_stub:')
                self.emit('    cli')
                self.emit('    movq %rsp, %r11')
                self.emit('    movq 0(%r11), %rcx')
                self.emit('    movq 8(%r11), %rdx')
                self.emit('    movq %cr2, %r8')
                self.emit('    movq 24(%r11), %r9')
                self.emit('    andq $-16, %rsp')
                self.emit('    subq $32, %rsp')
                self.emit('    call kernel_page_fault')
                self.emit('.Lnx_page_fault_halt_loop:'); self.emit('    hlt'); self.emit('    jmp .Lnx_page_fault_halt_loop'); self.emit()
            if any(isinstance(n,Call) and n.name=='timer_stub_address' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_timer_stub'); self.emit('nx_kernel_timer_stub:')
                for reg in ['%rax','%rcx','%rdx','%r8','%r9','%r10','%r11','%r12']: self.emit(f'    pushq {reg}')
                self.emit('    movq %rsp, %r12'); self.emit('    andq $-16, %rsp'); self.emit('    subq $32, %rsp'); self.emit('    call kernel_timer_tick'); self.emit('    movq %r12, %rsp')
                for reg in ['%r12','%r11','%r10','%r9','%r8','%rdx','%rcx','%rax']: self.emit(f'    popq {reg}')
                self.emit('    iretq'); self.emit()
            if any(isinstance(n,Call) and n.name=='lapic_timer_stub_address' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_lapic_timer_stub'); self.emit('nx_kernel_lapic_timer_stub:')
                for reg in ['%rax','%rcx','%rdx','%r8','%r9','%r10','%r11','%r12']: self.emit(f'    pushq {reg}')
                self.emit('    movq %rsp, %r12'); self.emit('    andq $-16, %rsp'); self.emit('    subq $32, %rsp'); self.emit('    call kernel_lapic_timer_tick'); self.emit('    movq %r12, %rsp')
                self.emit('    movl $0xC0000101, %ecx'); self.emit('    rdmsr'); self.emit('    shlq $32, %rdx'); self.emit('    orq %rdx, %rax')
                snap_skip=self.lab("lapic_frame_skip")
                self.emit('    testq %rax, %rax'); self.emit(f'    jz {snap_skip}')
                self.emit('    movq 64(%rsp), %r10'); self.emit('    movq %r10, 400(%rax)')
                self.emit('    movq 72(%rsp), %r10'); self.emit('    movq %r10, 408(%rax)')
                self.emit('    movq 80(%rsp), %r10'); self.emit('    movq %r10, 416(%rax)')
                self.emit('    leaq 64(%rsp), %r10'); self.emit('    movq %r10, 424(%rax)')
                self.emit('    movq $1, 432(%rax)')
                self.emit(f'{snap_skip}:')
                for reg in ['%r12','%r11','%r10','%r9','%r8','%rdx','%rcx','%rax']: self.emit(f'    popq {reg}')
                self.emit('    iretq'); self.emit()
            protection_stubs=[
                ('ts_fault_stub_address','nx_kernel_ts_fault_stub',10),
                ('np_fault_stub_address','nx_kernel_np_fault_stub',11),
                ('ss_fault_stub_address','nx_kernel_ss_fault_stub',12),
                ('gp_fault_stub_address','nx_kernel_gp_fault_stub',13),
            ]
            for builtin,label,vector in protection_stubs:
                if any(isinstance(n,Call) and n.name==builtin for n in _walk_ast(self.p)):
                    self.emit(f'.globl {label}'); self.emit(f'{label}:'); self.emit('    cli'); self.emit('    movq %rsp, %r11')
                    self.emit(f'    movq ${vector}, %rcx'); self.emit('    movq 0(%r11), %rdx'); self.emit('    movq 8(%r11), %r8'); self.emit('    movq 16(%r11), %r9')
                    self.emit('    andq $-16, %rsp'); self.emit('    subq $32, %rsp'); self.emit('    call kernel_protection_fault')
                    self.emit(f'.Lnx_{label}_halt:'); self.emit('    hlt'); self.emit(f'    jmp .Lnx_{label}_halt'); self.emit()
            if any(isinstance(n,Call) and n.name=='user_syscall_stub_address' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_user_syscall_stub'); self.emit('nx_kernel_user_syscall_stub:')
                for reg in ['%rax','%rcx','%rdx','%r8','%r9','%r10','%r11','%r12']: self.emit(f'    pushq {reg}')
                self.emit('    movq 56(%rsp), %rcx'); self.emit('    movq 48(%rsp), %rdx'); self.emit('    movq 40(%rsp), %r8'); self.emit('    movq 32(%rsp), %r9'); self.emit('    movq %rsp, %r12'); self.emit('    andq $-16, %rsp'); self.emit('    subq $32, %rsp'); self.emit('    call kernel_user_syscall'); self.emit('    movq %rax, 56(%r12)'); self.emit('    movq %r12, %rsp')
                for reg in ['%r12','%r11','%r10','%r9','%r8','%rdx','%rcx','%rax']: self.emit(f'    popq {reg}')
                self.emit('    iretq'); self.emit()
            if any(isinstance(n,Call) and n.name=='user_enter' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_user_enter'); self.emit('nx_kernel_user_enter:')
                self.emit('    movq %rsp, (%r9)')
                self.emit('    movq %rcx, %cr3')
                self.emit('    pushq $0x113'); self.emit('    pushq %r8'); self.emit('    pushq $0x202'); self.emit('    pushq $0x11b'); self.emit('    pushq %rdx'); self.emit('    iretq'); self.emit()
            if any(isinstance(n,Call) and n.name=='user_return' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_user_return'); self.emit('nx_kernel_user_return:')
                self.emit('    cli'); self.emit('    movq %rcx, %cr3'); self.emit('    movq %rdx, %rsp'); self.emit('    retq'); self.emit()
            if any(isinstance(n,Call) and n.name=='user_enter_context' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_user_enter_context'); self.emit('nx_kernel_user_enter_context:')
                self.emit('    movq %rsp, (%r9)'); self.emit('    movq %rbp, 8(%r9)')
                self.emit('    movq %rcx, %cr3')
                self.emit('    pushq $0x113'); self.emit('    pushq %r8'); self.emit('    pushq $0x202'); self.emit('    pushq $0x11b'); self.emit('    pushq %rdx'); self.emit('    iretq'); self.emit()
            if any(isinstance(n,Call) and n.name=='user_return_context' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_user_return_context'); self.emit('nx_kernel_user_return_context:')
                self.emit('    cli'); self.emit('    movq %rcx, %cr3'); self.emit('    movq 8(%rdx), %rbp'); self.emit('    movq (%rdx), %rsp'); self.emit('    retq'); self.emit()
            if any(isinstance(n,Call) and n.name=='reschedule_stub_address' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_reschedule_stub'); self.emit('nx_kernel_reschedule_stub:')
                for reg in ['%rax','%rcx','%rdx','%r8','%r9','%r10','%r11','%r12']: self.emit(f'    pushq {reg}')
                self.emit('    movq %rsp, %r12'); self.emit('    andq $-16, %rsp'); self.emit('    subq $32, %rsp'); self.emit('    call kernel_reschedule_ipi'); self.emit('    movq %r12, %rsp')
                for reg in ['%r12','%r11','%r10','%r9','%r8','%rdx','%rcx','%rax']: self.emit(f'    popq {reg}')
                self.emit('    iretq'); self.emit()
            if any(isinstance(n,Call) and n.name=='spurious_stub_address' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_spurious_stub'); self.emit('nx_kernel_spurious_stub:')
                for reg in ['%rax','%rcx','%rdx','%r8','%r9','%r10','%r11','%r12']: self.emit(f'    pushq {reg}')
                self.emit('    movq %rsp, %r12'); self.emit('    andq $-16, %rsp'); self.emit('    subq $32, %rsp'); self.emit('    call kernel_spurious_interrupt'); self.emit('    movq %r12, %rsp')
                for reg in ['%r12','%r11','%r10','%r9','%r8','%rdx','%rcx','%rax']: self.emit(f'    popq {reg}')
                self.emit('    iretq'); self.emit()
            if any(isinstance(n,Call) and n.name=='thread_entry_stub_address' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_thread_entry_stub'); self.emit('nx_kernel_thread_entry_stub:'); self.emit('    subq $32, %rsp'); self.emit('    call kernel_thread_entry'); self.emit('    cli'); self.emit('.Lnx_thread_entry_halt:'); self.emit('    hlt'); self.emit('    jmp .Lnx_thread_entry_halt'); self.emit()
            if any(isinstance(n,Call) and n.name=='context_switch' for n in _walk_ast(self.p)):
                self.emit('.globl nx_kernel_context_switch'); self.emit('nx_kernel_context_switch:')
                self.emit('    pushfq'); self.emit('    pushq %rbp'); self.emit('    pushq %rbx'); self.emit('    pushq %rdi'); self.emit('    pushq %rsi'); self.emit('    pushq %r12'); self.emit('    pushq %r13'); self.emit('    pushq %r14'); self.emit('    pushq %r15')
                self.emit('    movq %rsp, (%rcx)'); self.emit('    movq %rdx, %rsp')
                self.emit('    popq %r15'); self.emit('    popq %r14'); self.emit('    popq %r13'); self.emit('    popq %r12'); self.emit('    popq %rsi'); self.emit('    popq %rdi'); self.emit('    popq %rbx'); self.emit('    popq %rbp'); self.emit('    popfq'); self.emit('    retq'); self.emit()
        self.emit('.section .nxmeta,"dr"'); mod=self.p.module or ('FramesKernel' if self.p.kernel_profile else 'application'); caps='+'.join(sorted(self.p.capabilities)) or 'none'
        extra=';COMPILER=native-gen1' if self.native_gen1 else ''
        if self.p.kernel_profile:
            kp=self.p.kernel_profile; kabi=4 if kp.abi in {"frames_4","frames4"} else (3 if kp.abi in {"frames_3","frames3"} else (2 if kp.abi in {"frames_2","frames2"} else 1))
            self.emit(f'.asciz "NEXUS-FRAMES-KERNEL-ABI={kabi};FKRN=1;FORMAT=FKRN64;LANG={VERSION};ARCH=x86_64;MODULE={mod};KIND=kernel;NIR=3;ABI={kp.abi};CAPS={caps};COMPILER=kernel-gen3"')
        else:
            self.emit(f'.asciz "NEXUS-FRAMES-ABI=1;FEX=1;FORMAT=FEX64;LANG={VERSION};ARCH=x86_64;MODULE={mod};KIND=app;NIR=3;CAPS={caps}{extra}"')
        return "\n".join(self.lines)

def compile_to_x64_frames_asm(src:Path): return X64FramesBackend(load_program(src)).generate()

class ARM64FramesBackend:
    """Direct AArch64 backend preview for the freestanding Frames ABI.

    Nexus 3.5 intentionally starts with the primitive/control-flow subset: integer
    and bool functions, locals, arithmetic, calls, if/while/range loops. It emits
    Windows-COFF-compatible AArch64 assembly only as an intermediate assembler input;
    the final default artifact is the custom FEX64/1 container.
    """
    ARG_REGS=["x0","x1","x2","x3","x4","x5","x6","x7"]
    ALLOWED={"i32","i64","u32","u64","bool","void"}
    def __init__(self,p):
        self.p=optimize_program(p); self.funcs={f.name:f for f in self.p.functions}; self.consts={c.name:c for c in self.p.consts}
        self.lines=[]; self.label_id=0; self.slots={}; self.break_labels=[]; self.continue_labels=[]; self.epilogue=""
        user_enums=[e for e in self.p.enums if e.name not in {"Option","Result"}]
        if self.p.structs or user_enums: raise NexusError("ARM64 backend 3.5 supports the primitive profile; aggregate lowering is next", code="NX4401")
        if "main" not in self.funcs: raise NexusError("ARM64 backend requires main", code="NX4402")
        for f in self.p.functions:
            if f.is_async: raise NexusError("ARM64 async lowering requires the future Frames scheduler ABI", code="NX4430")
            if f.ret not in self.ALLOWED or any(x.typ not in self.ALLOWED-{"void"} for x in f.params): raise NexusError(f"ARM64 backend does not support signature of {f.name}", code="NX4403")
            if len(f.params)>8: raise NexusError(f"ARM64 backend supports at most 8 parameters ({f.name})", code="NX4404")
    def emit(self,x=""): self.lines.append(x)
    def lab(self,p="L"): self.label_id+=1; return f".Lna_{p}_{self.label_id}"
    def collect_locals(self,body,names):
        for st in body:
            if isinstance(st,Let): names.append(st.name)
            elif isinstance(st,ForRange): names.append(st.name); self.collect_locals(st.body,names)
            elif isinstance(st,If): self.collect_locals(st.then_body,names); self.collect_locals(st.else_body,names)
            elif isinstance(st,While): self.collect_locals(st.body,names)
            elif isinstance(st,UnsafeBlock): self.collect_locals(st.body,names)
    def slot(self,name):
        if name not in self.slots: raise NexusError(f"ARM64 backend unknown local {name}", code="NX4405")
        return self.slots[name]
    def mem(self,name): return f"[x29, #-{self.slot(name)}]"
    def check_expr(self,e):
        if isinstance(e,Literal):
            if e.typ not in {"i32","i64","u32","u64","bool"}: raise NexusError(f"ARM64 backend cannot lower {e.typ} literal", code="NX4410")
        elif isinstance(e,(VarRef,Move)):
            if isinstance(e,VarRef) and e.name not in self.consts and e.name not in self.slots: raise NexusError(f"ARM64 backend unknown value {e.name}", code="NX4405")
        elif isinstance(e,Unary): self.check_expr(e.expr)
        elif isinstance(e,Binary): self.check_expr(e.left); self.check_expr(e.right)
        elif isinstance(e,Call):
            if e.name in BUILTINS: raise NexusError(f"builtin {e.name} is outside ARM64 freestanding profile", code="NX4411")
            if e.name not in self.funcs: raise NexusError(f"unknown function {e.name}", code="NX4412")
            if len(e.args)>8: raise NexusError("ARM64 backend supports at most 8 call arguments", code="NX4413")
            for a in e.args: self.check_expr(a)
        else: raise NexusError(f"expression is outside ARM64 backend profile: {type(e).__name__}", code="NX4414")
    def imm(self,value):
        v=int(value)
        if not (-65535 <= v <= 65535): raise NexusError("ARM64 preview currently accepts immediate literals in ±65535", code="NX4415")
        if v<0: self.emit(f"    mov x0, #{-v}"); self.emit("    neg x0, x0")
        else: self.emit(f"    mov x0, #{v}")
    def expr(self,e):
        self.check_expr(e)
        if isinstance(e,Literal): self.imm(1 if e.value is True else 0 if e.value is False else e.value); return
        if isinstance(e,VarRef):
            if e.name in self.consts:
                c=self.consts[e.name]
                if not isinstance(c.expr,Literal): raise NexusError("ARM64 constant must be a primitive literal", code="NX4416")
                self.imm(1 if c.expr.value is True else 0 if c.expr.value is False else c.expr.value); return
            self.emit(f"    ldr x0, {self.mem(e.name)}"); return
        if isinstance(e,Move): self.emit(f"    ldr x0, {self.mem(e.name)}"); return
        if isinstance(e,Unary):
            self.expr(e.expr)
            if e.op=="-": self.emit("    neg x0, x0")
            elif e.op=="!": self.emit("    cmp x0, #0"); self.emit("    cset x0, eq")
            return
        if isinstance(e,Binary):
            op=e.op
            if op=="&&":
                lf=self.lab("and_false"); ld=self.lab("and_done")
                self.expr(e.left)
                self.emit("    cmp x0, #0"); self.emit(f"    b.eq {lf}")
                self.expr(e.right)
                self.emit("    cmp x0, #0"); self.emit("    cset x0, ne")
                self.emit(f"    b {ld}")
                self.emit(f"{lf}:"); self.emit("    mov x0, #0")
                self.emit(f"{ld}:")
                return
            if op=="||":
                lt=self.lab("or_true"); ld=self.lab("or_done")
                self.expr(e.left)
                self.emit("    cmp x0, #0"); self.emit(f"    b.ne {lt}")
                self.expr(e.right)
                self.emit("    cmp x0, #0"); self.emit("    cset x0, ne")
                self.emit(f"    b {ld}")
                self.emit(f"{lt}:"); self.emit("    mov x0, #1")
                self.emit(f"{ld}:")
                return
            self.expr(e.left); self.emit("    sub sp, sp, #16"); self.emit("    str x0, [sp]")
            self.expr(e.right); self.emit("    mov x9, x0"); self.emit("    ldr x0, [sp]"); self.emit("    add sp, sp, #16")
            if op=="+": self.emit("    add x0, x0, x9")
            elif op=="-": self.emit("    sub x0, x0, x9")
            elif op=="*": self.emit("    mul x0, x0, x9")
            elif op=="/": self.emit("    sdiv x0, x0, x9")
            elif op=="%": self.emit("    sdiv x10, x0, x9"); self.emit("    msub x0, x10, x9, x0")
            elif op in {"==","!=","<",">","<=",">="}:
                self.emit("    cmp x0, x9"); cc={"==":"eq","!=":"ne","<":"lt",">":"gt","<=":"le",">=":"ge"}[op]; self.emit(f"    cset x0, {cc}")
            return
        if isinstance(e,Call):
            n=len(e.args); reserve=_align_up(max(1,n)*8,16); self.emit(f"    sub sp, sp, #{reserve}")
            for i,a in enumerate(e.args): self.expr(a); self.emit(f"    str x0, [sp, #{i*8}]")
            for i in range(n): self.emit(f"    ldr {self.ARG_REGS[i]}, [sp, #{i*8}]")
            self.emit(f"    bl {e.name}"); self.emit(f"    add sp, sp, #{reserve}"); return
    def stmt(self,st):
        if isinstance(st,Let): self.expr(st.expr); self.emit(f"    str x0, {self.mem(st.name)}"); return
        if isinstance(st,Assign): self.expr(st.expr); self.emit(f"    str x0, {self.mem(st.name)}"); return
        if isinstance(st,Return):
            if st.expr is not None: self.expr(st.expr)
            else: self.emit("    mov x0, #0")
            self.emit(f"    b {self.epilogue}"); return
        if isinstance(st,ExprStmt): self.expr(st.expr); return
        if isinstance(st,If):
            le=self.lab("else"); ld=self.lab("endif"); self.expr(st.cond); self.emit("    cmp x0, #0"); self.emit(f"    b.eq {le}")
            for x in st.then_body: self.stmt(x)
            self.emit(f"    b {ld}"); self.emit(f"{le}:")
            for x in st.else_body: self.stmt(x)
            self.emit(f"{ld}:"); return
        if isinstance(st,While):
            ls=self.lab("while"); le=self.lab("endwhile"); self.emit(f"{ls}:"); self.expr(st.cond); self.emit("    cmp x0, #0"); self.emit(f"    b.eq {le}")
            self.break_labels.append(le); self.continue_labels.append(ls)
            for x in st.body: self.stmt(x)
            self.break_labels.pop(); self.continue_labels.pop(); self.emit(f"    b {ls}"); self.emit(f"{le}:"); return
        if isinstance(st,ForRange):
            self.expr(st.start); self.emit(f"    str x0, {self.mem(st.name)}"); ls=self.lab("for"); li=self.lab("forinc"); le=self.lab("endfor"); self.emit(f"{ls}:")
            self.expr(st.end); self.emit("    mov x9, x0"); self.emit(f"    ldr x0, {self.mem(st.name)}"); self.emit("    cmp x0, x9"); self.emit(f"    b.ge {le}")
            self.break_labels.append(le); self.continue_labels.append(li)
            for x in st.body: self.stmt(x)
            self.break_labels.pop(); self.continue_labels.pop(); self.emit(f"{li}:"); self.emit(f"    ldr x0, {self.mem(st.name)}"); self.emit("    add x0, x0, #1"); self.emit(f"    str x0, {self.mem(st.name)}"); self.emit(f"    b {ls}"); self.emit(f"{le}:"); return
        if isinstance(st,Break): self.emit(f"    b {self.break_labels[-1]}"); return
        if isinstance(st,Continue): self.emit(f"    b {self.continue_labels[-1]}"); return
        if isinstance(st,UnsafeBlock):
            for x in st.body: self.stmt(x)
            return
        raise NexusError(f"statement is outside ARM64 backend profile: {type(st).__name__}", code="NX4422")
    def function(self,f):
        locals=[]; self.collect_locals(f.body,locals); ordered=[]
        for p in f.params:
            if p.name not in ordered: ordered.append(p.name)
        for x in locals:
            if x not in ordered: ordered.append(x)
        self.slots={name:(i+1)*8 for i,name in enumerate(ordered)}; frame=_align_up(len(ordered)*8,16); self.epilogue=self.lab(f"ret_{f.name}")
        self.emit(f".globl {f.name}"); self.emit(f"{f.name}:"); self.emit("    stp x29, x30, [sp, #-16]!"); self.emit("    mov x29, sp")
        if frame: self.emit(f"    sub sp, sp, #{frame}")
        for i,p in enumerate(f.params): self.emit(f"    str {self.ARG_REGS[i]}, {self.mem(p.name)}")
        for st in f.body: self.stmt(st)
        self.emit("    mov x0, #0"); self.emit(f"{self.epilogue}:")
        if frame: self.emit(f"    add sp, sp, #{frame}")
        self.emit("    ldp x29, x30, [sp], #16"); self.emit("    ret"); self.emit()
    def generate(self):
        self.emit("// Nexus direct ARM64 backend") ; self.emit(".text")
        for f in self.p.functions: self.function(f)
        self.emit('.section .nxmeta,"dr"'); mod=self.p.module or "application"; caps="+".join(sorted(self.p.capabilities)) or "none"
        self.emit(f'.asciz "NEXUS-FRAMES-ABI=1;FEX=1;FORMAT=FEX64;LANG={VERSION};ARCH=arm64;MODULE={mod};KIND=app;NIR=3;CAPS={caps}"')
        return "\n".join(self.lines)

def compile_to_arm64_frames_asm(src:Path): return ARM64FramesBackend(load_program(src)).generate()

def find_tool(name):
    p=shutil.which(name)
    if not p: raise NexusError(f"required native-backend tool not found: {name}", code="NX4100")
    return p


def _align_up(value:int, alignment:int)->int:
    return (value + alignment - 1) // alignment * alignment

class NexusPELinker:
    """Minimal deterministic PE32+ linker for Nexus's single-COFF freestanding profile.

    Clang is still used as the assembler in 3.3, but lld-link is no longer required
    for normal Frames x64 builds. The linker owns PE headers, section layout, entry
    resolution, and rejects unsupported COFF relocations rather than guessing.
    """
    MACHINE_X64=0x8664
    MACHINE_ARM64=0xaa64
    KEEP={".text", ".nxmeta", ".rdata", ".data"}
    def __init__(self, obj:Path):
        self.obj=Path(obj); self.data=self.obj.read_bytes(); self.sections=[]; self.symbols={}
        self.machine=0; self._parse()
    def _parse(self):
        b=self.data
        if len(b)<20: raise NexusError("COFF object is truncated", code="NX4110")
        machine,nsec,_ts,psym,nsym,opt,_chars=struct.unpack_from('<HHLLLHH',b,0)
        if machine not in {self.MACHINE_X64,self.MACHINE_ARM64}: raise NexusError(f"Nexus COFF reader does not support machine 0x{machine:04x}", code="NX4111")
        self.machine=machine; off=20+opt
        for i in range(nsec):
            if off+40>len(b): raise NexusError("COFF section table is truncated", code="NX4112")
            rawname=b[off:off+8].split(b'\0',1)[0]; name=rawname.decode('ascii','replace')
            _vsize,_vaddr,rawsize,rawptr,relptr,_lineptr,nrel,_nline,chars=struct.unpack_from('<LLLLLLHHL',b,off+8)
            if nrel:
                raise NexusError(f"Nexus PE linker 3.3 does not yet accept unresolved relocations in {name}", code="NX4113")
            payload=b[rawptr:rawptr+rawsize] if rawptr and rawsize else b''
            self.sections.append({"index":i+1,"name":name,"data":payload,"chars":chars,"relptr":relptr,"nrel":nrel})
            off+=40
        strtab_off=psym+nsym*18
        strtab=b[strtab_off:] if strtab_off<len(b) else b''
        i=0
        while i<nsym:
            so=psym+i*18
            if so+18>len(b): raise NexusError("COFF symbol table is truncated", code="NX4114")
            raw=b[so:so+8]
            if raw[:4]==b'\0\0\0\0':
                noff=struct.unpack_from('<L',raw,4)[0]
                end=strtab.find(b'\0',noff)
                name=strtab[noff:end].decode('utf-8','replace') if noff<len(strtab) and end!=-1 else ''
            else: name=raw.split(b'\0',1)[0].decode('ascii','replace')
            value,secnum,_typ,sclass,naux=struct.unpack_from('<LhHBB',b,so+8)
            if name: self.symbols[name]={"value":value,"section":secnum,"class":sclass}
            i += 1+naux
    def link(self,out:Path,entry="main"):
        keep=[s for s in self.sections if s["name"] in self.KEEP and s["data"]]
        text=next((s for s in keep if s["name"]==".text"),None)
        if not text: raise NexusError("COFF object has no .text section", code="NX4115")
        ent=self.symbols.get(entry)
        if not ent or ent["section"]<=0: raise NexusError(f"entry symbol not found in COFF object: {entry}", code="NX4116")
        file_align=0x200; sec_align=0x1000; image_base=0x140000000; opt_size=0xF0
        n=len(keep); header_end=0x80+4+20+opt_size+n*40; headers=_align_up(header_end,file_align)
        rva=0x1000; raw=headers; layout=[]
        for sec in keep:
            size=len(sec["data"]); rawsize=_align_up(size,file_align)
            layout.append({"sec":sec,"rva":rva,"raw":raw,"size":size,"rawsize":rawsize})
            rva=_align_up(rva+max(size,1),sec_align); raw+=rawsize
        size_image=_align_up(rva,sec_align)
        entry_layout=next((x for x in layout if x["sec"]["index"]==ent["section"]),None)
        if not entry_layout: raise NexusError("entry symbol references a discarded COFF section", code="NX4117")
        entry_rva=entry_layout["rva"]+ent["value"]
        text_layout=next(x for x in layout if x["sec"]["name"]==".text")
        size_code=sum(x["rawsize"] for x in layout if x["sec"]["name"]==".text")
        size_init=sum(x["rawsize"] for x in layout if x["sec"]["name"]!=".text")
        dos=bytearray(0x80); dos[:2]=b'MZ'; struct.pack_into('<L',dos,0x3c,0x80)
        pe=bytearray(dos); pe+=b'PE\0\0'
        pe+=struct.pack('<HHLLLHH',self.machine,n,0,0,0,opt_size,0x0002|0x0020)
        optb=bytearray(opt_size)
        struct.pack_into('<HBBLLLLLQ',optb,0,0x20b,14,0,size_code,size_init,0,entry_rva,text_layout["rva"],image_base)
        struct.pack_into('<LL',optb,32,sec_align,file_align)
        struct.pack_into('<HHHHHH',optb,40,6,0,0,0,6,0)
        struct.pack_into('<L',optb,52,0)
        struct.pack_into('<LLL',optb,56,size_image,headers,0)
        struct.pack_into('<HH',optb,68,1,0x8160)
        struct.pack_into('<QQQQ',optb,72,0x100000,0x1000,0x100000,0x1000)
        struct.pack_into('<LL',optb,104,0,16)
        pe+=optb
        for x in layout:
            sec=x["sec"]; name=sec["name"].encode('ascii')[:8].ljust(8,b'\0')
            schars=0x60000020 if sec["name"]==".text" else (0xC0000040 if sec["name"]==".data" else 0x40000040)
            pe+=name+struct.pack('<LLLLLLHHL',x["size"],x["rva"],x["rawsize"],x["raw"],0,0,0,0,schars)
        pe+=b'\0'*(headers-len(pe))
        for x in layout:
            if len(pe)<x["raw"]: pe+=b'\0'*(x["raw"]-len(pe))
            pe+=x["sec"]["data"]; pe+=b'\0'*(x["rawsize"]-x["size"])
        out=Path(out); out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(pe); return out

def cmd_link_obj(obj,output,entry="main"):
    out=Path(output or Path(obj).with_suffix('.fex')); NexusPELinker(Path(obj)).link(out,entry); print(f"✓ Nexus-linked PE32+ executable: {out}")

FEX64_MAGIC=b"FEX64\0\0\0"
FEX64_HEADER_SIZE=128
FEX_ARCH_X64=1
FEX_ARCH_ARM64=2

def _fex64_from_coff(obj:Path,out:Path,entry="main",arch=FEX_ARCH_X64):
    coff=NexusPELinker(Path(obj))
    expected={FEX_ARCH_X64:NexusPELinker.MACHINE_X64,FEX_ARCH_ARM64:NexusPELinker.MACHINE_ARM64}.get(arch)
    if expected and coff.machine!=expected: raise NexusError("FEX64 architecture does not match COFF machine", code="NX4123")
    text=next((s for s in coff.sections if s["name"]==".text" and s["data"]),None)
    meta=next((s for s in coff.sections if s["name"]==".nxmeta" and s["data"]),None)
    if not text: raise NexusError("FEX64 builder requires .text", code="NX4120")
    ent=coff.symbols.get(entry)
    if not ent or ent["section"]!=text["index"]: raise NexusError("FEX64 entry must resolve into .text", code="NX4121")
    code=bytes(text["data"]); metadata=bytes(meta["data"]) if meta else b''
    code_off=FEX64_HEADER_SIZE; meta_off=_align_up(code_off+len(code),16)
    digest=hashlib.sha256(code+metadata).digest()
    head=struct.pack('<8sHHHHIIQQQQQQ32s',FEX64_MAGIC,1,FEX64_HEADER_SIZE,arch,0,1,3,ent["value"],code_off,len(code),meta_off,len(metadata),0,digest)
    if len(head)>FEX64_HEADER_SIZE: raise NexusError("internal FEX64 header overflow", code="NX4122")
    payload=bytearray(head); payload+=b'\0'*(FEX64_HEADER_SIZE-len(payload)); payload+=code
    payload+=b'\0'*(meta_off-len(payload)); payload+=metadata
    out=Path(out); out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(payload); return out

def build_frames_fex64(src:Path,out:Path):
    asm=compile_to_x64_frames_asm(src); out.parent.mkdir(parents=True,exist_ok=True); clang=find_tool("clang")
    with tempfile.TemporaryDirectory() as td:
        sp=Path(td)/"nexus_frames.s"; op=Path(td)/"nexus_frames.obj"; sp.write_text(asm,encoding="utf-8")
        r=subprocess.run([clang,"--target=x86_64-pc-windows-msvc","-c",str(sp),"-o",str(op)],capture_output=True,text=True)
        if r.returncode: raise NexusError("x64 assembler failed:\n"+r.stderr, code="NX4101")
        _fex64_from_coff(op,out,"main",FEX_ARCH_X64)
    return out

def build_frames_arm64_fex64(src:Path,out:Path):
    asm=compile_to_arm64_frames_asm(src); out.parent.mkdir(parents=True,exist_ok=True); clang=find_tool("clang")
    with tempfile.TemporaryDirectory() as td:
        sp=Path(td)/"nexus_frames_arm64.s"; op=Path(td)/"nexus_frames_arm64.obj"; sp.write_text(asm,encoding="utf-8")
        r=subprocess.run([clang,"--target=aarch64-pc-windows-msvc","-c",str(sp),"-o",str(op)],capture_output=True,text=True)
        if r.returncode: raise NexusError("ARM64 assembler failed:\n"+r.stderr, code="NX4451")
        _fex64_from_coff(op,out,"main",FEX_ARCH_ARM64)
    return out

def inspect_fex64(path:Path):
    data=Path(path).read_bytes()
    if len(data)<FEX64_HEADER_SIZE or data[:8]!=FEX64_MAGIC: raise NexusError("invalid FEX64 magic/header", code="NX6201")
    vals=struct.unpack_from('<8sHHHHIIQQQQQQ32s',data,0)
    _magic,ver,hsize,arch,flags,abi,nir,entry,code_off,code_size,meta_off,meta_size,_reserved,digest=vals
    if ver!=1 or hsize!=FEX64_HEADER_SIZE: raise NexusError("unsupported FEX64 header version", code="NX6202")
    if code_off+code_size>len(data) or meta_off+meta_size>len(data): raise NexusError("truncated FEX64 sections", code="NX6203")
    code=data[code_off:code_off+code_size]; meta=data[meta_off:meta_off+meta_size]
    ok=hashlib.sha256(code+meta).digest()==digest
    metadata=meta.split(b'\0',1)[0].decode('utf-8','replace') if meta else None
    return {"version":ver,"arch":arch,"flags":flags,"abi":abi,"nir":nir,"entry":entry,"code_size":code_size,"meta_size":meta_size,"metadata":metadata,"integrity":ok}

def build_frames_x64(src:Path,out:Path):
    asm=compile_to_x64_frames_asm(src); out.parent.mkdir(parents=True,exist_ok=True)
    clang=find_tool("clang")
    with tempfile.TemporaryDirectory() as td:
        sp=Path(td)/"nexus_frames.s"; op=Path(td)/"nexus_frames.obj"; sp.write_text(asm,encoding="utf-8")
        r=subprocess.run([clang,"--target=x86_64-pc-windows-msvc","-c",str(sp),"-o",str(op)],capture_output=True,text=True)
        if r.returncode: raise NexusError("x64 assembler failed:\n"+r.stderr, code="NX4101")
        NexusPELinker(op).link(out,"main")
    return out


# ----------------------------- Frames kernel toolchain -----------------------------

FKRN_MAGIC=b"FKRN64\0\0"
FKRN_HEADER_SIZE=160
FKRN_ARCH_X64=1
FKRN_FLAG_FREESTANDING=1

def _version_level(): return tuple(int(x) for x in VERSION.split(".")[:2])
KERNEL_HOSTED_FORBIDDEN={"print","new","vector","push","get","concat","contains","starts_with","apply","channel","send","recv","close_channel","atomic","atomic_load","atomic_store","atomic_add"}

def _walk_ast(node):
    if node is None: return
    if isinstance(node,(str,int,float,bool,bytes)): return
    if isinstance(node,(list,tuple,set)):
        for x in node: yield from _walk_ast(x)
        return
    if isinstance(node,dict):
        for x in node.values(): yield from _walk_ast(x)
        return
    yield node
    if hasattr(node,'__dict__'):
        for x in vars(node).values(): yield from _walk_ast(x)

def validate_kernel_profile(p:Program):
    kp=p.kernel_profile
    if not kp: raise NexusError("source is not a Nexus kernel profile; add kernel Name { arch: x86_64; abi: frames_1; }", code="NX4600")
    if kp.arch not in {"x86_64"}: raise NexusError(f"kernel architecture {kp.arch} is not supported by Nexus 4.5 kernel tooling", code="NX4602")
    if kp.abi not in {"frames_1","frames1","frames","frames_2","frames2","frames_3","frames3","frames_4","frames4"}: raise NexusError(f"unsupported Frames kernel ABI: {kp.abi}", code="NX4603")
    funcs={f.name:f for f in p.functions}
    ent=funcs.get("kernel_main")
    if not ent: raise NexusError("kernel profile requires fn kernel_main() -> void", code="NX4604")
    if ent.ret!="void" or ent.type_params or ent.is_async: raise NexusError("kernel_main must be non-generic, synchronous, and return void", code="NX4605")
    if len(ent.params)>1: raise NexusError("kernel_main accepts at most one FramesBootInfoV1 reference", code="NX4605")
    if ent.params and ent.params[0].typ not in {"&FramesBootInfoV1","&mut FramesBootInfoV1","&FramesBootInfoV2","&mut FramesBootInfoV2","&FramesBootInfoV3","&mut FramesBootInfoV3","&FramesBootInfoV4","&mut FramesBootInfoV4"}:
        raise NexusError("kernel_main parameter must be a supported FramesBootInfo reference when present", code="NX4605")
    for f in p.functions:
        if f.is_async: raise NexusError("async functions are unavailable in the freestanding kernel profile", code="NX4606")
        if f.effects and ({"io","alloc","task","shared"} & set(f.effects)):
            raise NexusError(f"kernel function {f.name} requests hosted effect(s): {', '.join(sorted(set(f.effects)&{'io','alloc','task','shared'}))}", code="NX4607")
    uses_protection_stub=any(isinstance(n,Call) and n.name in {'ts_fault_stub_address','np_fault_stub_address','ss_fault_stub_address','gp_fault_stub_address'} for n in _walk_ast(p))
    if uses_protection_stub:
        ph=funcs.get('kernel_protection_fault')
        if not ph or ph.ret!='void' or ph.is_async or ph.type_params or [x.typ for x in ph.params] != ['u64','u64','u64','u64']:
            raise NexusError('protection fault stubs require fn kernel_protection_fault(vector: u64, error: u64, rip: u64, cs: u64) -> void', code='NX4951')
    uses_page_fault_stub=any(isinstance(n,Call) and n.name=='page_fault_stub_address' for n in _walk_ast(p))
    if uses_page_fault_stub:
        pf=funcs.get('kernel_page_fault')
        if not pf or pf.ret!='void' or pf.is_async or pf.type_params or [x.typ for x in pf.params] != ['u64','u64','u64','u64']:
            raise NexusError('page_fault_stub_address() requires fn kernel_page_fault(error: u64, rip: u64, fault_address: u64, rflags: u64) -> void', code='NX4901')
    uses_timer_stub=any(isinstance(n,Call) and n.name=='timer_stub_address' for n in _walk_ast(p))
    if uses_timer_stub:
        th=funcs.get('kernel_timer_tick')
        if not th or th.ret!='void' or th.is_async or th.type_params or th.params:
            raise NexusError('timer_stub_address() requires fn kernel_timer_tick() -> void', code='NX5001')
    uses_lapic_timer_stub=any(isinstance(n,Call) and n.name=='lapic_timer_stub_address' for n in _walk_ast(p))
    if uses_lapic_timer_stub:
        lh=funcs.get('kernel_lapic_timer_tick')
        if not lh or lh.ret!='void' or lh.is_async or lh.type_params or lh.params:
            raise NexusError('lapic_timer_stub_address() requires fn kernel_lapic_timer_tick() -> void', code='NX5501')
    uses_user_syscall_stub=any(isinstance(n,Call) and n.name=='user_syscall_stub_address' for n in _walk_ast(p))
    if uses_user_syscall_stub:
        uh=funcs.get('kernel_user_syscall')
        if not uh or uh.ret!='u64' or uh.is_async or uh.type_params or [x.typ for x in uh.params] != ['u64','u64','u64','u64']:
            raise NexusError('user_syscall_stub_address() requires fn kernel_user_syscall(number: u64, arg0: u64, arg1: u64, arg2: u64) -> u64', code='NX5901')
    uses_reschedule_stub=any(isinstance(n,Call) and n.name=='reschedule_stub_address' for n in _walk_ast(p))
    if uses_reschedule_stub:
        rh=funcs.get('kernel_reschedule_ipi')
        if not rh or rh.ret!='void' or rh.is_async or rh.type_params or rh.params:
            raise NexusError('reschedule_stub_address() requires fn kernel_reschedule_ipi() -> void', code='NX5701')
    uses_ap_entry=any(isinstance(n,Call) and n.name=='ap_entry_address' for n in _walk_ast(p))
    if uses_ap_entry:
        ah=funcs.get('kernel_ap_entry')
        if not ah or ah.ret!='void' or ah.is_async or ah.type_params or [x.typ for x in ah.params] != ['u64']:
            raise NexusError('ap_entry_address() requires fn kernel_ap_entry(smp_state: u64) -> void', code='NX5601')
    uses_spurious_stub=any(isinstance(n,Call) and n.name=='spurious_stub_address' for n in _walk_ast(p))
    if uses_spurious_stub:
        sh=funcs.get('kernel_spurious_interrupt')
        if not sh or sh.ret!='void' or sh.is_async or sh.type_params or sh.params:
            raise NexusError('spurious_stub_address() requires fn kernel_spurious_interrupt() -> void', code='NX5401')
    uses_thread_stub=any(isinstance(n,Call) and n.name=='thread_entry_stub_address' for n in _walk_ast(p))
    if uses_thread_stub:
        te=funcs.get('kernel_thread_entry')
        if not te or te.ret!='void' or te.is_async or te.type_params or te.params:
            raise NexusError('thread_entry_stub_address() requires fn kernel_thread_entry() -> void', code='NX5002')
    for n in _walk_ast(p):
        if isinstance(n,Call) and n.name in KERNEL_BUILTINS and _version_level() < (4,2):
            raise NexusError("kernel architecture intrinsics require Nexus 4.2+", code="NX4613")
        if isinstance(n,Call) and n.name in KERNEL_HOSTED_FORBIDDEN:
            raise NexusError(f"hosted builtin {n.name}() is unavailable in the freestanding kernel profile", code="NX4608")
        if isinstance(n,(Spawn,Sync,AwaitExpr)):
            raise NexusError("hosted task primitives are unavailable in the freestanding kernel profile", code="NX4609")
    # Run the normal semantic/move/borrow checker too. C is only used as an internal checker, never emitted/compiled.
    CBackend(optimize_program(p)).generate()
    return p

def compile_kernel_x64_asm(src:Path):
    p=load_program(Path(src)); validate_kernel_profile(p)
    return X64FramesBackend(p).generate()

def _fkrn_from_coff(obj:Path,out:Path,entry="kernel_main",abi_version=1):
    coff=NexusPELinker(Path(obj))
    if coff.machine!=NexusPELinker.MACHINE_X64: raise NexusError("FKRN64 currently requires AMD64 COFF input", code="NX4620")
    text=next((s for s in coff.sections if s["name"]==".text" and s["data"]),None)
    meta=next((s for s in coff.sections if s["name"]==".nxmeta" and s["data"]),None)
    if not text: raise NexusError("FKRN builder requires .text", code="NX4621")
    ent=coff.symbols.get(entry)
    if not ent or ent["section"]!=text["index"]: raise NexusError("FKRN entry kernel_main must resolve into .text", code="NX4622")
    code=bytes(text["data"]); metadata=bytes(meta["data"]) if meta else b''
    code_off=FKRN_HEADER_SIZE; meta_off=_align_up(code_off+len(code),16)
    digest=hashlib.sha256(code+metadata).digest()
    # magic, version, hsize, arch, flags, kernelABI, nir, entry, code off/size, meta off/size, reserved, digest, build-id
    build_id=hashlib.sha256((VERSION+":"+str(len(code))).encode()+digest).digest()[:16]
    head=struct.pack('<8sHHHHIIQQQQQQ32s16s',FKRN_MAGIC,1,FKRN_HEADER_SIZE,FKRN_ARCH_X64,FKRN_FLAG_FREESTANDING,abi_version,3,ent["value"],code_off,len(code),meta_off,len(metadata),0,digest,build_id)
    if len(head)>FKRN_HEADER_SIZE: raise NexusError("internal FKRN64 header overflow", code="NX4623")
    payload=bytearray(head); payload+=b'\0'*(FKRN_HEADER_SIZE-len(payload)); payload+=code
    payload+=b'\0'*(meta_off-len(payload)); payload+=metadata
    out=Path(out); out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(payload); return out

def build_frames_kernel(src:Path,out:Path):
    if _version_level() < (4,4): raise NexusError("FKRN64 kernel image generation requires Nexus 4.4+", code="NX4625")
    src=Path(src); out=Path(out); p=load_program(src); validate_kernel_profile(p)
    asm=X64FramesBackend(p).generate(); clang=find_tool("clang")
    with tempfile.TemporaryDirectory() as td:
        sp=Path(td)/"frames_kernel.s"; op=Path(td)/"frames_kernel.obj"; sp.write_text(asm,encoding="utf-8")
        r=subprocess.run([clang,"--target=x86_64-pc-windows-msvc","-c",str(sp),"-o",str(op)],capture_output=True,text=True)
        if r.returncode: raise NexusError("kernel assembler failed:\n"+r.stderr, code="NX4624")
        kabi=4 if p.kernel_profile and p.kernel_profile.abi in {"frames_4","frames4"} else (3 if p.kernel_profile and p.kernel_profile.abi in {"frames_3","frames3"} else (2 if p.kernel_profile and p.kernel_profile.abi in {"frames_2","frames2"} else 1))
        _fkrn_from_coff(op,out,"kernel_main",kabi)
    return out

def inspect_fkrn(path:Path):
    data=Path(path).read_bytes()
    if len(data)<FKRN_HEADER_SIZE or data[:8]!=FKRN_MAGIC: raise NexusError("invalid FKRN64 magic/header", code="NX4630")
    vals=struct.unpack_from('<8sHHHHIIQQQQQQ32s16s',data,0)
    _magic,ver,hsize,arch,flags,abi,nir,entry,code_off,code_size,meta_off,meta_size,_reserved,digest,build_id=vals
    if ver!=1 or hsize!=FKRN_HEADER_SIZE: raise NexusError("unsupported FKRN64 header version", code="NX4631")
    if code_off+code_size>len(data) or meta_off+meta_size>len(data): raise NexusError("truncated FKRN64 sections", code="NX4632")
    code=data[code_off:code_off+code_size]; meta=data[meta_off:meta_off+meta_size]
    ok=hashlib.sha256(code+meta).digest()==digest
    metadata=meta.split(b'\0',1)[0].decode('utf-8','replace') if meta else None
    return {"version":ver,"arch":arch,"flags":flags,"abi":abi,"nir":nir,"entry":entry,"code_size":code_size,"meta_size":meta_size,"metadata":metadata,"integrity":ok,"build_id":build_id.hex()}

def cmd_kernel(action,source=None,output=None):
    if action=="check":
        src=resolve_source(source); p=load_program(src); validate_kernel_profile(p); asm=compile_kernel_x64_asm(src)
        print(f"✓ kernel-check: {src}"); print(f"profile: {p.kernel_profile.name}"); print(f"arch: {p.kernel_profile.arch}"); print(f"abi: {p.kernel_profile.abi}"); print(f"assembly_lines: {len(asm.splitlines())}"); return 0
    if action=="build":
        if _version_level() < (4,5): raise NexusError("nexus kernel build is introduced in Nexus 4.5", code="NX4636")
        src=resolve_source(source); out=Path(output or Path(src).with_suffix('.fkrn')); build_frames_kernel(src,out); print(f"✓ built Frames kernel image: {out}"); return 0
    if action=="inspect":
        if _version_level() < (4,5): raise NexusError("nexus kernel inspect is introduced in Nexus 4.5", code="NX4637")
        if not source: raise NexusError("kernel inspect requires a .fkrn file", code="NX4633")
        info=inspect_fkrn(Path(source)); names={1:"x86-64"}; print(f"format: FKRN64/{info['version']}"); print(f"machine: {names.get(info['arch'],info['arch'])}"); print(f"kernel-abi: frames-{info['abi']}"); print(f"nir: {info['nir']}"); print(f"entry-offset: {info['entry']}"); print(f"code-size: {info['code_size']}"); print(f"build-id: {info['build_id']}"); print(f"integrity: {'verified' if info['integrity'] else 'FAILED'}"); print("nexus: "+str(info['metadata'])); return 0 if info['integrity'] else 1
    raise NexusError(f"unknown kernel action: {action}", code="NX4634")

# ----------------------------- CLI -----------------------------

def compile_to_c(src: Path): return CBackend(optimize_program(load_program(src))).generate()

def find_cc():
    for cc in (os.environ.get("NEXUS_CC"),"clang","gcc","cc"):
        if cc and shutil.which(cc): return cc
    raise NexusError("no C backend compiler found (tried NEXUS_CC, clang, gcc, cc)", code="NX3001")

def cmd_check(src):
    p=load_program(Path(src))
    if p.kernel_profile: validate_kernel_profile(p)
    else: compile_to_c(Path(src))
    print(f"✓ {src}: Nexus check passed")

def cmd_emit_c(src,output=None):
    c=compile_to_c(Path(src))
    if output: Path(output).write_text(c,encoding="utf-8"); print(f"✓ emitted C: {output}")
    else: print(c)

def cmd_emit_asm(src,output=None):
    asm=compile_to_x64_frames_asm(Path(src))
    if output: Path(output).write_text(asm,encoding="utf-8"); print(f"✓ emitted x86-64 assembly: {output}")
    else: print(asm)

def cmd_native_check(src, arch="x64"):
    srcp=Path(src)
    if arch != "x64":
        raise NexusError("native-check generation 1 currently reports x64 parity; ARM64 remains preview", code="NX4070")
    asm=compile_to_x64_frames_asm(srcp)
    p=load_program(srcp)
    features={
        "semantic_reference_checker":"ready",
        "primitive_control_flow":"native",
        "references":"native",
        "stack_structs":"native",
        "tagged_payload_enums":"native",
        "option_local_match":"native",
        "scalar_generic_monomorphization":"native",
        "move_drop_defer":"native",
        "aggregate_function_abi":"deferred",
        "heap_owned_allocation":"deferred",
        "async_channels_atomics":"deferred",
    }
    print(f"✓ native-check: {srcp} -> Frames x86-64 generation 1")
    for k,v in features.items(): print(f"{k}: {v}")
    print(f"assembly_lines: {len(asm.splitlines())}")
    print(f"module: {p.module or 'application'}")

def cmd_emit_arm64(src,output=None):
    asm=compile_to_arm64_frames_asm(Path(src))
    if output: Path(output).write_text(asm,encoding="utf-8"); print(f"✓ emitted ARM64 assembly: {output}")
    else: print(asm)

def cmd_emit_ir(src,output=None):
    ir=compile_to_nir(Path(src))
    if output: Path(output).write_text(ir,encoding="utf-8"); print(f"✓ emitted NIR: {output}")
    else: print(ir)

def cmd_build(src,output=None,optimize="2",backend="c",target="host"):
    srcp=Path(src)
    if target=="frames-x64":
        out=Path(output or srcp.with_suffix(".fex")); build_frames_fex64(srcp,out); print(f"✓ built Frames x64 FEX64 executable: {out}"); return out
    if target=="frames-arm64":
        out=Path(output or srcp.with_suffix(".fex")); build_frames_arm64_fex64(srcp,out); print(f"✓ built Frames ARM64 FEX64 executable: {out}"); return out
    if target=="frames-pe-x64" or backend=="x64":
        out=Path(output or srcp.with_suffix(".fex")); build_frames_x64(srcp,out); print(f"✓ built Frames PE compatibility executable: {out}"); return out
    c=compile_to_c(srcp); out=Path(output or srcp.with_suffix("")); out.parent.mkdir(parents=True,exist_ok=True); cc=find_cc()
    with tempfile.TemporaryDirectory() as td:
        cp=Path(td)/"nexus_generated.c"; cp.write_text(c,encoding="utf-8")
        args=[cc,"-std=c17",f"-O{optimize}","-Wall","-Wextra",str(cp),"-o",str(out)]
        if "pthread_" in c: args.append("-pthread")
        proc=subprocess.run(args,capture_output=True,text=True)
        if proc.returncode: raise NexusError("backend compilation failed:\n"+proc.stderr, code="NX3002")
    print(f"✓ built {out}"); return out

def cmd_run(src):
    with tempfile.TemporaryDirectory() as td:
        exe=cmd_build(src,str(Path(td)/"nexus_app")); return subprocess.run([str(exe)]).returncode

def cmd_test(path):
    root=Path(path); files=[root] if root.is_file() else sorted(root.rglob("*.nx"))
    if not files: raise NexusError(f"no .nx tests found in {path}", code="NX3003")
    failed=0
    for src in files:
        try:
            preview=load_program(src)
            if not any(f.name == "main" for f in preview.functions):
                print(f"SKIP {src} (library module)")
                continue
        except NexusError as e:
            failed+=1; print(f"FAIL {src} ({e.render()})"); continue
        print(f"TEST {src}")
        with tempfile.TemporaryDirectory() as td:
            try:
                exe=cmd_build(str(src),str(Path(td)/"test_app")); r=subprocess.run([str(exe)])
                if r.returncode==0: print("PASS")
                else: failed+=1; print(f"FAIL (exit {r.returncode})")
            except NexusError as e:
                failed+=1; print(f"FAIL ({e.render()})")
    runnable=sum(1 for src in files if any(f.name == "main" for f in load_program(src).functions))
    print(f"Nexus tests: {runnable-failed} passed, {failed} failed")
    return 1 if failed else 0

def cmd_new(name):
    root=Path(name)
    if root.exists() and any(root.iterdir()): raise NexusError(f"directory is not empty: {root}", code="NX3004")
    (root/"src").mkdir(parents=True,exist_ok=True); (root/"tests").mkdir(parents=True,exist_ok=True)
    (root/"src"/"main.nx").write_text(f'module {root.name.replace("-","_")};\n\nfn main() -> i32 {{\n    print("Hello from Nexus");\n    return 0;\n}}\n',encoding="utf-8")
    (root/"nexus.toml").write_text(f'[package]\nname = "{root.name}"\nversion = "0.1.0"\npublisher = "Unknown"\n\n[build]\nentry = "src/main.nx"\n\n[frames]\nkind = "app"\ncapabilities = []\nicon = ""\n',encoding="utf-8")
    print(f"✓ created Nexus project: {root}")




FRAMES_FILE_TYPES = {
    ".fex":      {"id":"frames.executable","description":"Frames Native Executable","icon":"fex","handler":"frames.loader","mime":"application/x-frames-fex"},
    ".fkrn":     {"id":"frames.kernel","description":"Frames Kernel Image","icon":"fkrn","handler":"frames.boot-loader","mime":"application/x-frames-kernel"},
    ".fapp":     {"id":"frames.application","description":"Frames Application Bundle","icon":"fapp","handler":"frames.apps","mime":"application/x-frames-app"},
    ".fsetup":   {"id":"frames.setup","description":"Frames Installer Bundle","icon":"fsetup","handler":"frames.installer","mime":"application/x-frames-setup"},
    ".fpkg":     {"id":"frames.package","description":"Frames Software Package","icon":"fpkg","handler":"frames.packages","mime":"application/x-frames-package"},
    ".flib":     {"id":"frames.library","description":"Frames Native Library","icon":"flib","handler":"frames.loader","mime":"application/x-frames-library"},
    ".fdrv":     {"id":"frames.driver","description":"Frames Hardware Driver","icon":"fdrv","handler":"frames.driver-manager","mime":"application/x-frames-driver"},
    ".fsvc":     {"id":"frames.service","description":"Frames System Service","icon":"fsvc","handler":"frames.service-manager","mime":"application/x-frames-service"},
    ".fmod":     {"id":"frames.module","description":"Frames Loadable Module","icon":"fmod","handler":"frames.module-loader","mime":"application/x-frames-module"},
    ".ftheme":   {"id":"frames.theme","description":"Frames Theme","icon":"ftheme","handler":"frames.personalization","mime":"application/x-frames-theme"},
    ".ficon":    {"id":"frames.iconpack","description":"Frames Icon Pack","icon":"ficon","handler":"frames.personalization","mime":"application/x-frames-iconpack"},
    ".ffont":    {"id":"frames.fontpack","description":"Frames Font Package","icon":"ffont","handler":"frames.font-manager","mime":"application/x-frames-font"},
    ".fmanifest":{"id":"frames.manifest","description":"Frames Manifest","icon":"fmanifest","handler":"frames.manifest-viewer","mime":"application/x-frames-manifest"},
    ".fupdate":  {"id":"frames.update","description":"Frames System Update","icon":"fupdate","handler":"frames.update","mime":"application/x-frames-update"},
    ".fbackup":  {"id":"frames.backup","description":"Frames Backup Archive","icon":"fbackup","handler":"frames.backup","mime":"application/x-frames-backup"},
    ".frecovery":{"id":"frames.recovery","description":"Frames Recovery Package","icon":"frecovery","handler":"frames.recovery","mime":"application/x-frames-recovery"},
    ".nx":       {"id":"nexus.source","description":"Nexus Source File","icon":"nx","handler":"nexus.studio","mime":"text/x-nexus"},
}

BUNDLE_EXTENSIONS={"app":".fapp","setup":".fsetup","package":".fpkg"}

def _read_project_manifest(root:Path):
    mf=root/"nexus.toml"
    if not mf.exists(): raise NexusError(f"nexus.toml not found in {root.resolve()}", code="NX5101")
    try: return tomllib.loads(mf.read_text(encoding="utf-8"))
    except Exception as e: raise NexusError(f"invalid nexus.toml: {e}", code="NX5102")

def _zip_write_bytes(zf:zipfile.ZipFile,name:str,data:bytes):
    zi=zipfile.ZipInfo(name,(1980,1,1,0,0,0)); zi.compress_type=zipfile.ZIP_DEFLATED; zi.external_attr=0o644 << 16
    zf.writestr(zi,data)

def _zip_write_file(zf:zipfile.ZipFile,name:str,path:Path):
    _zip_write_bytes(zf,name,path.read_bytes())

def _bundle_manifest(root:Path,kind:str,exe_name:str,source_sha:str):
    data=_read_project_manifest(root); pkg=data.get("package",{}); fr=data.get("frames",{})
    name=str(pkg.get("name",root.name)); version=str(pkg.get("version","0.1.0")); publisher=str(pkg.get("publisher","Unknown"))
    caps=fr.get("capabilities",[]) or []
    if not isinstance(caps,list) or not all(isinstance(x,str) for x in caps): raise NexusError("[frames].capabilities must be an array of strings", code="NX5103")
    return {
        "format":"FramesBundle/1",
        "kind":kind,
        "name":name,
        "version":version,
        "publisher":publisher,
        "architecture":"x86_64",
        "abi":"frames-1",
        "entry":f"Payload/{exe_name}",
        "native_format":"FEX64/1",
        "capabilities":caps,
        "icon":fr.get("icon","") or None,
        "source_sha256":source_sha,
        "created_by":f"Nexus {VERSION}",
    }

def _canonical_json_bytes(value):
    return (json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False)+"\n").encode("utf-8")

def _load_ed25519():
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
        from cryptography.hazmat.primitives.serialization import Encoding, PrivateFormat, PublicFormat, NoEncryption
        return Ed25519PrivateKey,Ed25519PublicKey,Encoding,PrivateFormat,PublicFormat,NoEncryption
    except Exception as e:
        raise NexusError(f"Ed25519 support requires the Python cryptography package: {e}", code="NX5201")

def _key_fingerprint(public_raw:bytes): return "SHA256:"+hashlib.sha256(public_raw).hexdigest()

def cmd_keygen(output,publisher="Unknown"):
    EdPriv,_,Encoding,PrivateFormat,PublicFormat,NoEncryption=_load_ed25519()
    key=EdPriv.generate(); pub=key.public_key()
    priv_raw=key.private_bytes(Encoding.Raw,PrivateFormat.Raw,NoEncryption())
    pub_raw=pub.public_bytes(Encoding.Raw,PublicFormat.Raw)
    payload={"format":"NexusEd25519Key/1","publisher":publisher,"private_key":base64.b64encode(priv_raw).decode("ascii"),"public_key":base64.b64encode(pub_raw).decode("ascii"),"fingerprint":_key_fingerprint(pub_raw)}
    out=Path(output); out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    try: os.chmod(out,0o600)
    except OSError: pass
    print(f"✓ generated Ed25519 publisher key: {out}")
    print(f"publisher: {publisher}")
    print(f"fingerprint: {payload['fingerprint']}")
    return out

def _read_signing_key(path):
    try: data=json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception as e: raise NexusError(f"cannot read signing key: {e}", code="NX5202")
    if data.get("format")!="NexusEd25519Key/1" or not data.get("private_key") or not data.get("public_key"):
        raise NexusError("invalid Nexus Ed25519 signing key", code="NX5203")
    try:
        priv=base64.b64decode(data["private_key"],validate=True); pub=base64.b64decode(data["public_key"],validate=True)
    except Exception: raise NexusError("invalid base64 in signing key", code="NX5204")
    if len(priv)!=32 or len(pub)!=32: raise NexusError("invalid Ed25519 raw key length", code="NX5205")
    return data,priv,pub

def _bundle_signature_payload(manifest,integrity):
    return b"FramesBundleSignature/1\0"+_canonical_json_bytes(manifest)+b"\0"+_canonical_json_bytes(integrity)

def _sign_bundle(manifest,integrity,key_path):
    EdPriv,_,_,_,_,_=_load_ed25519(); keymeta,priv_raw,pub_raw=_read_signing_key(key_path)
    signature=EdPriv.from_private_bytes(priv_raw).sign(_bundle_signature_payload(manifest,integrity))
    return {"format":"FramesPublisherSignature/1","algorithm":"Ed25519","publisher":keymeta.get("publisher","Unknown"),"public_key":base64.b64encode(pub_raw).decode("ascii"),"fingerprint":_key_fingerprint(pub_raw),"signature":base64.b64encode(signature).decode("ascii")}

def _verify_bundle_signature(manifest,integrity,sigdoc):
    if not sigdoc: return "unsigned",None
    if sigdoc.get("format")!="FramesPublisherSignature/1" or sigdoc.get("algorithm")!="Ed25519": return "unsupported",None
    try:
        _,EdPub,_,_,_,_=_load_ed25519()
        pub=base64.b64decode(sigdoc["public_key"],validate=True); sig=base64.b64decode(sigdoc["signature"],validate=True)
        if _key_fingerprint(pub)!=sigdoc.get("fingerprint"): return "invalid",None
        EdPub.from_public_bytes(pub).verify(sig,_bundle_signature_payload(manifest,integrity))
        return "verified",sigdoc.get("fingerprint")
    except Exception:
        return "invalid",None

def cmd_package(root=".",kind=None,output=None,locked=False,sign_key=None):
    root=Path(root).resolve(); data=_read_project_manifest(root); fr=data.get("frames",{})
    kind=kind or fr.get("kind","app")
    if kind not in BUNDLE_EXTENSIONS: raise NexusError("package kind must be app, setup, or package", code="NX5104")
    if locked: verify_lock(root)
    entry=project_entry(root); pkg=data.get("package",{}); name=str(pkg.get("name",root.name))
    with tempfile.TemporaryDirectory() as td:
        fex=Path(td)/(name+".fex"); build_frames_fex64(entry,fex)
        digest,_=lock_digest(root)
        manifest=_bundle_manifest(root,kind,fex.name,digest)
        ext=BUNDLE_EXTENSIONS[kind]; out=Path(output) if output else root/"dist"/(name+ext); out.parent.mkdir(parents=True,exist_ok=True)
        icon_setting=fr.get("icon","") or ""; icon_path=(root/icon_setting).resolve() if icon_setting else None
        hashes={f"Payload/{fex.name}":hashlib.sha256(fex.read_bytes()).hexdigest()}
        with zipfile.ZipFile(out,"w") as zf:
            _zip_write_bytes(zf,"frames.json",(json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode())
            _zip_write_file(zf,f"Payload/{fex.name}",fex)
            if icon_path and icon_path.exists():
                iname="Resources/Icon"+icon_path.suffix.lower(); _zip_write_file(zf,iname,icon_path); hashes[iname]=hashlib.sha256(icon_path.read_bytes()).hexdigest()
            integrity={"algorithm":"SHA-256","files":dict(sorted(hashes.items()))}
            _zip_write_bytes(zf,"Signatures/integrity.json",(json.dumps(integrity,indent=2,sort_keys=True)+"\n").encode())
            if sign_key:
                sigdoc=_sign_bundle(manifest,integrity,sign_key)
                if manifest.get("publisher") not in {"Unknown",sigdoc.get("publisher")}:
                    raise NexusError(f"manifest publisher '{manifest.get('publisher')}' does not match signing key publisher '{sigdoc.get('publisher')}'", code="NX5206")
                _zip_write_bytes(zf,"Signatures/publisher.json",(json.dumps(sigdoc,indent=2,sort_keys=True)+"\n").encode())
        print(f"✓ packaged Frames {kind}: {out}")
        if sign_key: print(f"✓ signed with {sigdoc['fingerprint']}")
        return out

def inspect_bundle(path:Path):
    try:
        with zipfile.ZipFile(path,"r") as zf:
            names=set(zf.namelist())
            if "frames.json" not in names: raise NexusError("bundle is missing frames.json", code="NX6101")
            manifest=json.loads(zf.read("frames.json"))
            integ=json.loads(zf.read("Signatures/integrity.json")) if "Signatures/integrity.json" in names else None
            checked=[]; bad=[]
            if integ:
                for name,expected in integ.get("files",{}).items():
                    if name not in names: bad.append(name); continue
                    actual=hashlib.sha256(zf.read(name)).hexdigest(); checked.append(name)
                    if actual!=expected: bad.append(name)
            sigdoc=json.loads(zf.read("Signatures/publisher.json")) if "Signatures/publisher.json" in names else None
            sig_status,fingerprint=_verify_bundle_signature(manifest,integ or {},sigdoc)
            return manifest,checked,bad,names,sig_status,fingerprint,sigdoc
    except zipfile.BadZipFile:
        raise NexusError("not a valid Frames bundle container", code="NX6102")

def cmd_filetypes(json_output=False):
    if json_output:
        print(json.dumps({"registry_version":1,"types":FRAMES_FILE_TYPES},indent=2,sort_keys=True)); return
    for ext,info in FRAMES_FILE_TYPES.items(): print(f"{ext:<11} {info['description']:<30} icon={info['icon']} handler={info['handler']}")

def inspect_pe(path:Path):
    data=path.read_bytes()
    if len(data)<0x40 or data[:2]!=b"MZ": raise NexusError("not a PE/COFF executable (missing MZ)", code="NX6001")
    pe=int.from_bytes(data[0x3c:0x40],"little")
    if pe+24>len(data) or data[pe:pe+4]!=b"PE\0\0": raise NexusError("invalid PE signature", code="NX6002")
    machine=int.from_bytes(data[pe+4:pe+6],"little"); nsects=int.from_bytes(data[pe+6:pe+8],"little")
    optsz=int.from_bytes(data[pe+20:pe+22],"little"); opt=pe+24
    if opt+optsz>len(data): raise NexusError("truncated PE optional header", code="NX6003")
    magic=int.from_bytes(data[opt:opt+2],"little")
    entry=int.from_bytes(data[opt+16:opt+20],"little") if optsz>=20 else 0
    subsystem=int.from_bytes(data[opt+68:opt+70],"little") if optsz>=70 else -1
    sec=opt+optsz; sections=[]; metadata=None
    for i in range(nsects):
        off=sec+i*40
        if off+40>len(data): break
        name=data[off:off+8].split(b"\0",1)[0].decode("ascii","replace")
        rawsize=int.from_bytes(data[off+16:off+20],"little"); rawptr=int.from_bytes(data[off+20:off+24],"little")
        sections.append(name)
        if name==".nxmeta" and rawptr+rawsize<=len(data):
            metadata=data[rawptr:rawptr+rawsize].split(b"\0",1)[0].decode("utf-8","replace")
    return {"machine":machine,"sections":sections,"magic":magic,"entry_rva":entry,"subsystem":subsystem,"metadata":metadata}

def cmd_inspect(path,trust_key=None,require_signed=False):
    p=Path(path); suffix=p.suffix.lower()
    if suffix in {".fapp",".fsetup",".fpkg"}:
        manifest,checked,bad,names,sig_status,fingerprint,sigdoc=inspect_bundle(p)
        print(f"file: {p}")
        print(f"format: {manifest.get('format','unknown')}")
        print(f"kind: {manifest.get('kind','unknown')}")
        print(f"name: {manifest.get('name','unknown')} {manifest.get('version','')}")
        print(f"publisher: {manifest.get('publisher','Unknown')}")
        print(f"architecture: {manifest.get('architecture','unknown')}")
        print(f"abi: {manifest.get('abi','unknown')}")
        print(f"entry: {manifest.get('entry','unknown')}")
        print("capabilities: "+(", ".join(manifest.get("capabilities",[])) or "none"))
        print(f"integrity: {'FAILED: '+', '.join(bad) if bad else 'verified ('+str(len(checked))+' payload file(s))'}")
        print(f"publisher-signature: {sig_status}"+(f" ({fingerprint})" if fingerprint else ""))
        if sigdoc: print(f"signed-publisher: {sigdoc.get('publisher','Unknown')}")
        if bad: raise NexusError("Frames bundle integrity verification failed", code="NX6103")
        if require_signed and sig_status!="verified": raise NexusError("a verified publisher signature is required", code="NX6104")
        if sig_status in {"invalid","unsupported"}: raise NexusError("Frames bundle publisher signature verification failed", code="NX6105")
        if trust_key:
            keymeta,_,pub_raw=_read_signing_key(trust_key); expected=_key_fingerprint(pub_raw)
            if sig_status!="verified" or fingerprint!=expected: raise NexusError("bundle is not signed by the requested trusted key", code="NX6106")
            print(f"trust: matched {keymeta.get('publisher','Unknown')} ({expected})")
        return
    raw=p.read_bytes()
    if raw.startswith(FKRN_MAGIC):
        info=inspect_fkrn(p); names={1:"x86-64"}
        print(f"format: FKRN64/{info['version']}"); print(f"machine: {names.get(info['arch'],info['arch'])}"); print(f"kernel-abi: frames-{info['abi']}"); print(f"nir: {info['nir']}"); print(f"entry-offset: {info['entry']}"); print(f"code-size: {info['code_size']}"); print(f"build-id: {info['build_id']}"); print(f"integrity: {'verified' if info['integrity'] else 'FAILED'}"); print("nexus: "+str(info['metadata']))
        if not info['integrity']: raise NexusError("FKRN64 integrity verification failed", code="NX4635")
        return
    if raw.startswith(FEX64_MAGIC):
        info=inspect_fex64(p); machine={FEX_ARCH_X64:"x86-64",FEX_ARCH_ARM64:"arm64"}.get(info["arch"],str(info["arch"]))
        print(f"file: {p}")
        print(f"format: FEX64/{info['version']}")
        print(f"machine: {machine}")
        print(f"abi: frames-{info['abi']}")
        print(f"nir: {info['nir']}")
        print(f"entry_offset: 0x{info['entry']:x}")
        print(f"code_size: {info['code_size']}")
        print(f"metadata_size: {info['meta_size']}")
        print(f"integrity: {'verified' if info['integrity'] else 'FAILED'}")
        if not info['integrity']: raise NexusError("FEX64 integrity verification failed", code="NX6204")
        if info["metadata"]:
            print("nexus: "+info["metadata"]); print("verification: native Frames FEX64 payload")
        return
    info=inspect_pe(p)
    machine={0x8664:"x86-64",0xaa64:"arm64"}.get(info["machine"],hex(info["machine"]))
    print(f"file: {p}")
    print(f"format: PE32+" if info["magic"]==0x20b else f"format: PE magic {hex(info['magic'])}")
    print(f"machine: {machine}")
    print(f"subsystem: {info['subsystem']}"+(" (native)" if info["subsystem"]==1 else ""))
    print(f"entry_rva: 0x{info['entry_rva']:x}")
    print("sections: "+", ".join(info["sections"]))
    if info["metadata"]:
        print("nexus: "+info["metadata"])
        if "NEXUS-FRAMES-ABI=1" in info["metadata"]: print("verification: Frames ABI v1 metadata present")
        if "FEX=1" in info["metadata"]: print("verification: native Frames FEX payload")
        if suffix==".exe" and "FEX=1" in info["metadata"]: print("warning: Frames-native payload uses legacy .exe extension; prefer .fex")
    else: print("nexus: no .nxmeta metadata")


def _walk_expr(e,refs):
    if isinstance(e,(VarRef,Move,Borrow)): refs.add(e.name)
    elif isinstance(e,Unary): _walk_expr(e.expr,refs)
    elif isinstance(e,Binary): _walk_expr(e.left,refs); _walk_expr(e.right,refs)
    elif isinstance(e,Call):
        for a in e.args: _walk_expr(a,refs)
    elif isinstance(e,StructInit):
        for _,v in e.fields: _walk_expr(v,refs)
    elif isinstance(e,FieldAccess): _walk_expr(e.obj,refs)
    elif isinstance(e,ArrayLiteral):
        for x in e.items: _walk_expr(x,refs)
    elif isinstance(e,Index): _walk_expr(e.obj,refs); _walk_expr(e.index,refs)

def _walk_stmt(x,decl,mut,assigned,refs):
    if isinstance(x,Let): decl.add(x.name); (mut.add(x.name) if x.mutable else None); _walk_expr(x.expr,refs)
    elif isinstance(x,Assign): assigned.add(x.name); _walk_expr(x.expr,refs)
    elif isinstance(x,DerefAssign): _walk_expr(x.expr,refs); refs.add(x.name)
    elif isinstance(x,Return) and x.expr is not None: _walk_expr(x.expr,refs)
    elif isinstance(x,ExprStmt): _walk_expr(x.expr,refs)
    elif isinstance(x,If):
        _walk_expr(x.cond,refs)
        for y in x.then_body+x.else_body: _walk_stmt(y,decl,mut,assigned,refs)
    elif isinstance(x,While):
        _walk_expr(x.cond,refs)
        for y in x.body: _walk_stmt(y,decl,mut,assigned,refs)
    elif isinstance(x,ForRange):
        decl.add(x.name); _walk_expr(x.start,refs); _walk_expr(x.end,refs)
        for y in x.body: _walk_stmt(y,decl,mut,assigned,refs)
    elif isinstance(x,UnsafeBlock):
        for y in x.body: _walk_stmt(y,decl,mut,assigned,refs)
    elif isinstance(x,MatchStmt):
        _walk_expr(x.expr,refs)
        for a in x.arms:
            for y in a.body: _walk_stmt(y,decl,mut,assigned,refs)

def cmd_lint(src=None,deny_warnings=False):
    srcp=resolve_source(src); p=load_program(srcp); validate_moves(p); warnings=[]
    for f in p.functions:
        decl={x.name for x in f.params}; mut=set(); assigned=set(); refs=set()
        for st in f.body: _walk_stmt(st,decl,mut,assigned,refs)
        for name in sorted(decl-{x.name for x in f.params}-refs): warnings.append(("NXL001",f"unused local '{name}' in {f.name}"))
        for name in sorted(mut-assigned): warnings.append(("NXL002",f"variable '{name}' is never reassigned; prefer let"))
        if f.public and f.effects is None and not f.pure: warnings.append(("NXL003",f"public function '{f.name}' relies on inferred effects; consider an explicit effects(...) contract"))
    for code,msg in warnings: print(f"warning[{code}]: {msg}")
    print(f"✓ lint complete: {len(warnings)} warning(s)")
    return 1 if deny_warnings and warnings else 0

def cmd_doctor():
    import platform
    print(f"Nexus {VERSION}")
    print(f"host: {platform.system()} {platform.machine()}")
    print(f"python: {sys.version.split()[0]}")
    for tool in ("clang","gcc","lld-link","file","objdump"):
        print(f"{tool}: {shutil.which(tool) or 'not found'}")
    print("hosted-c-backend: ready" if any(shutil.which(x) for x in ("clang","gcc","cc")) else "hosted-c-backend: unavailable")
    print("nir3-verifier: ready")
    print("frames-x64-backend: ready (FEX64/1)" if shutil.which("clang") else "frames-x64-backend: unavailable")
    print("frames-kernel-toolchain: ready (FKRN64/1, x86-64)" if shutil.which("clang") else "frames-kernel-toolchain: unavailable")
    print("native-gen1-profile: ready (x64 structs + tagged enums + scalar generics + resource control)" if shutil.which("clang") else "native-gen1-profile: unavailable")
    print("frames-pe-x64-compat: ready" if shutil.which("clang") else "frames-pe-x64-compat: unavailable")
    print("frames-arm64-backend: ready (FEX64/1)" if shutil.which("clang") else "frames-arm64-backend: unavailable")
    print("nexus-pe-linker: ready (single-COFF freestanding profile)")
    print(f"frames-file-registry: {len(FRAMES_FILE_TYPES)} registered extensions")
    try:
        _load_ed25519(); print("frames-ed25519-signing: ready")
    except NexusError: print("frames-ed25519-signing: unavailable")

DIAG_EXPLAIN={
    "NX2601":"A local binding was read after ownership had been transferred with `move`. Reassign a mutable binding or avoid moving it.",
    "NX2151":"The function declared an explicit effect set that does not include an operation it performs.",
    "NX2143":"Raw address access is only legal inside an explicit `unsafe { ... }` block.",
    "NX2210":"A while condition must have type bool.",
    "NX2204":"`let` bindings are immutable. Use `var` when reassignment is intentional.",
}
def cmd_explain(code):
    text=DIAG_EXPLAIN.get(code.upper())
    if not text: raise NexusError(f"no extended explanation is registered for {code}", code="NX7001")
    print(f"{code.upper()}: {text}")

def project_entry(root:Path=Path(".")) -> Path:
    manifest=root/"nexus.toml"
    if not manifest.exists(): raise NexusError(f"nexus.toml not found in {root.resolve()}", code="NX5001")
    try: data=tomllib.loads(manifest.read_text(encoding="utf-8"))
    except Exception as e: raise NexusError(f"invalid nexus.toml: {e}", code="NX5002")
    entry=data.get("build",{}).get("entry","src/main.nx")
    p=(root/entry).resolve()
    if not p.exists(): raise NexusError(f"project entry not found: {p}", code="NX5003")
    return p

def resolve_source(src): return Path(src) if src else project_entry()

def _format_text(text:str)->str:
    # Conservative formatter: indentation/braces/whitespace only; it never renames or reorders code.
    out=[]; indent=0
    for raw in text.splitlines():
        line=raw.strip()
        if not line:
            if out and out[-1] != "": out.append("")
            continue
        if line.startswith("}"): indent=max(0,indent-1)
        out.append("    "*indent+line)
        # Count structural braces outside quoted strings.
        q=False; esc=False; opens=closes=0
        for ch in line:
            if esc: esc=False; continue
            if ch=="\\" and q: esc=True; continue
            if ch=='"': q=not q; continue
            if not q:
                opens += ch=="{"; closes += ch=="}"
        delta=opens-closes
        if line.startswith("}"): delta+=1
        indent=max(0,indent+delta)
    return "\n".join(out).rstrip()+"\n"

def cmd_fmt(path=".",check=False):
    root=Path(path); files=[root] if root.is_file() else sorted(root.rglob("*.nx")); changed=[]
    if not files: raise NexusError(f"no .nx files found in {path}", code="NX5004")
    for f in files:
        old=f.read_text(encoding="utf-8"); new=_format_text(old)
        # validate formatted output before writing
        Parser(Lexer(new,str(f)).tokens()).parse()
        if old!=new:
            changed.append(f)
            if not check: f.write_text(new,encoding="utf-8")
    if check and changed:
        for f in changed: print(f"needs formatting: {f}")
        return 1
    print(f"✓ format {'check ' if check else ''}complete ({len(files)} files, {len(changed)} changed)"); return 0

def cmd_doc(src=None,output=None):
    srcp=resolve_source(src); p=load_program(srcp); lines=[f"# Nexus API — {p.module or srcp.stem}",""]
    if p.structs:
        lines += ["## Structs",""]
        for st in p.structs:
            gen=("<"+", ".join(st.type_params)+">") if st.type_params else ""
            lines += [f"### `{st.name}{gen}`","", "```nexus", f"{'pub ' if st.public else ''}struct {st.name}{gen} {{"]
            lines += [f"    {f.name}: {f.typ}," for f in st.fields]; lines += ["}","```",""]
    if p.enums:
        lines += ["## Enums",""]
        for en in p.enums:
            gen=("<"+", ".join(en.type_params)+">") if en.type_params else ""
            lines += [f"### `{en.name}{gen}`","",f"Variants: {', '.join('`'+v.name+(('('+v.payload+')') if v.payload else '')+'`' for v in en.variants)}",""]
    if p.traits:
        lines += ["## Traits",""]
        for tr in p.traits: lines += [f"### `{tr.name}`","", "Marker trait.", ""]
    if p.impls:
        lines += ["## Trait Implementations",""]
        for imp in p.impls: lines += [f"- `{imp.trait}` for `{imp.typ}`"]
        lines += [""]
    if p.functions:
        lines += ["## Functions",""]
        for f in p.functions:
            suffix="" if f.effects is None or f.pure else " effects("+", ".join(sorted(f.effects))+")"
            if f.type_params:
                gp=[]
                for tp in f.type_params:
                    cs=sorted(f.constraints.get(tp,set())); gp.append(tp + ((": "+" + ".join(cs)) if cs else ""))
                gen="<"+", ".join(gp)+">"
            else: gen=""
            sig=f"{'pub ' if f.public else ''}{'pure ' if f.pure else ''}fn {f.name}{gen}("+", ".join(x.name+": "+x.typ for x in f.params)+f") -> {f.ret}"+suffix
            lines += [f"### `{f.name}`","","```nexus",sig,"```",""]
    text="\n".join(lines).rstrip()+"\n"
    if output: Path(output).write_text(text,encoding="utf-8"); print(f"✓ wrote docs: {output}")
    else: print(text,end="")

def lock_digest(root:Path):
    h=hashlib.sha256(); files=[]
    manifest=root/"nexus.toml"
    if manifest.exists(): files.append(manifest)
    files += sorted((root/"src").rglob("*.nx")) if (root/"src").exists() else []
    for f in files:
        h.update(str(f.relative_to(root)).encode()); h.update(b"\0"); h.update(f.read_bytes()); h.update(b"\0")
    return h.hexdigest(),files

def cmd_lock(root="."):
    root=Path(root); digest,files=lock_digest(root)
    payload={"lock_version":1,"nexus":VERSION,"source_sha256":digest,"files":[str(f.relative_to(root)) for f in files]}
    (root/"nexus.lock").write_text(json.dumps(payload,indent=2)+"\n",encoding="utf-8")
    print(f"✓ wrote {root/'nexus.lock'} ({digest})")

def verify_lock(root=Path(".")):
    lp=root/"nexus.lock"
    if not lp.exists(): raise NexusError("--locked requested but nexus.lock is missing", code="NX5005")
    try: data=json.loads(lp.read_text(encoding="utf-8"))
    except Exception as e: raise NexusError(f"invalid nexus.lock: {e}", code="NX5006")
    digest,_=lock_digest(root)
    if data.get("source_sha256")!=digest: raise NexusError("nexus.lock does not match current project sources", code="NX5007")
    return True

def main(argv=None):
    ap=argparse.ArgumentParser(prog="nexus",description="Nexus programming language compiler")
    ap.add_argument("--version",action="version",version=f"Nexus {VERSION}"); sp=ap.add_subparsers(dest="cmd",required=True)
    p=sp.add_parser("check"); p.add_argument("source",nargs="?")
    p=sp.add_parser("emit-c"); p.add_argument("source",nargs="?"); p.add_argument("-o","--output")
    p=sp.add_parser("emit-ir"); p.add_argument("source",nargs="?"); p.add_argument("-o","--output")
    p=sp.add_parser("verify-ir"); p.add_argument("source",nargs="?")
    p=sp.add_parser("emit-asm"); p.add_argument("source",nargs="?"); p.add_argument("-o","--output")
    p=sp.add_parser("emit-arm64"); p.add_argument("source",nargs="?"); p.add_argument("-o","--output")
    p=sp.add_parser("native-check"); p.add_argument("source",nargs="?"); p.add_argument("--arch",choices=["x64"],default="x64")
    p=sp.add_parser("kernel"); p.add_argument("action",choices=["check","build","inspect"]); p.add_argument("source",nargs="?"); p.add_argument("-o","--output")
    p=sp.add_parser("link-obj"); p.add_argument("object"); p.add_argument("-o","--output"); p.add_argument("--entry",default="main")
    p=sp.add_parser("build"); p.add_argument("source",nargs="?"); p.add_argument("-o","--output"); p.add_argument("-O","--optimize",choices=["0","1","2","3"],default="2"); p.add_argument("--backend",choices=["c","x64"],default="c"); p.add_argument("--target",choices=["host","frames-x64","frames-arm64","frames-pe-x64"],default="host"); p.add_argument("--locked",action="store_true")
    p=sp.add_parser("run"); p.add_argument("source",nargs="?")
    p=sp.add_parser("test"); p.add_argument("path",nargs="?",default="tests")
    p=sp.add_parser("new"); p.add_argument("name")
    p=sp.add_parser("fmt"); p.add_argument("path",nargs="?",default="."); p.add_argument("--check",action="store_true")
    p=sp.add_parser("doc"); p.add_argument("source",nargs="?"); p.add_argument("-o","--output")
    p=sp.add_parser("lock"); p.add_argument("path",nargs="?",default=".")
    p=sp.add_parser("inspect"); p.add_argument("file"); p.add_argument("--trust-key"); p.add_argument("--require-signed",action="store_true")
    p=sp.add_parser("package"); p.add_argument("path",nargs="?",default="."); p.add_argument("--kind",choices=["app","setup","package"]); p.add_argument("-o","--output"); p.add_argument("--locked",action="store_true"); p.add_argument("--sign-key")
    p=sp.add_parser("keygen"); p.add_argument("-o","--output",required=True); p.add_argument("--publisher",default="Unknown")
    p=sp.add_parser("filetypes"); p.add_argument("--json",action="store_true")
    p=sp.add_parser("lint"); p.add_argument("source",nargs="?"); p.add_argument("--deny-warnings",action="store_true")
    sp.add_parser("doctor")
    p=sp.add_parser("explain"); p.add_argument("code")
    a=ap.parse_args(argv)
    try:
        if a.cmd=="check": cmd_check(str(resolve_source(a.source)))
        elif a.cmd=="emit-c": cmd_emit_c(str(resolve_source(a.source)),a.output)
        elif a.cmd=="emit-ir": cmd_emit_ir(str(resolve_source(a.source)),a.output)
        elif a.cmd=="verify-ir": cmd_verify_ir(str(resolve_source(a.source)))
        elif a.cmd=="emit-asm": cmd_emit_asm(str(resolve_source(a.source)),a.output)
        elif a.cmd=="emit-arm64": cmd_emit_arm64(str(resolve_source(a.source)),a.output)
        elif a.cmd=="native-check": cmd_native_check(str(resolve_source(a.source)),a.arch)
        elif a.cmd=="kernel": return cmd_kernel(a.action,a.source,a.output)
        elif a.cmd=="link-obj": cmd_link_obj(a.object,a.output,a.entry)
        elif a.cmd=="build":
            if a.locked: verify_lock(Path("."))
            cmd_build(str(resolve_source(a.source)),a.output,a.optimize,a.backend,a.target)
        elif a.cmd=="run": return cmd_run(str(resolve_source(a.source)))
        elif a.cmd=="test": return cmd_test(a.path)
        elif a.cmd=="new": cmd_new(a.name)
        elif a.cmd=="fmt": return cmd_fmt(a.path,a.check)
        elif a.cmd=="doc": cmd_doc(a.source,a.output)
        elif a.cmd=="lock": cmd_lock(a.path)
        elif a.cmd=="inspect": cmd_inspect(a.file,a.trust_key,a.require_signed)
        elif a.cmd=="package": cmd_package(a.path,a.kind,a.output,a.locked,a.sign_key)
        elif a.cmd=="keygen": cmd_keygen(a.output,a.publisher)
        elif a.cmd=="filetypes": cmd_filetypes(a.json)
        elif a.cmd=="lint": return cmd_lint(a.source,a.deny_warnings)
        elif a.cmd=="doctor": cmd_doctor()
        elif a.cmd=="explain": cmd_explain(a.code)
    except NexusError as e:
        print(e.render(),file=sys.stderr); return 1
    return 0

if __name__=="__main__": raise SystemExit(main())
