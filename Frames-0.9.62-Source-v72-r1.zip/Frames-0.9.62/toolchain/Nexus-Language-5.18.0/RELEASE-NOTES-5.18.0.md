# Nexus 5.18.0 — Kernel Code-Segment Reload Primitive

- Adds kernel-profile builtin `reload_cs(selector)`.
- On x86-64 it performs a same-privilege far return through the requested selector, reloading the live CS descriptor cache after a GDT replacement.
- Intended for SMP/AP descriptor-table handoff where an AP begins under a trampoline GDT and then adopts the shared kernel GDT.
- Existing 5.17.0 ring-3 continuation and unsigned semantics are unchanged.
