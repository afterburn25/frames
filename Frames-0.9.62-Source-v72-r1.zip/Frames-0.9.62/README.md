# Frames 0.9.62 — First Native GUI FAPP

Connects the verified FAPP/FEX application pipeline to the native desktop window manager. FAPP1 now carries a windowed UI role and the desktop hosts the verified app in a managed native window.
