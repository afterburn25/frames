# Frames 0.9.54 — Desktop Shell Phase 1

Introduces a native taskbar, launcher surface, task buttons, status area, and shell pointer routing.
