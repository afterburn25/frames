# Frames 0.9.60 — Notifications, Status Area & System UI

- Adds native notification toast, notification-center panel, status badge and deterministic system UI state.
- System UI remains isolated in diagnostic Desktop mode.

Next: Frames 0.9.61 — Login / Lock Screen & Session Shell.
