# Frames 0.9.41 v47 — USB MSC Unit Attention Recovery

The external v46 run proved the SuperSpeed xHCI repair works through endpoint
configuration and SCSI INQUIRY. The first TEST UNIT READY then returned BOT command
failure at tag 2.

QEMU's SCSI core allows INQUIRY through a pending Unit Attention, but the next
TEST UNIT READY reports CHECK CONDITION. REQUEST SENSE retrieves/clears that
Unit Attention before a subsequent TUR may succeed.

v47 adds a read-only REQUEST SENSE (0x03) recovery path:
- first TUR success continues normally;
- first TUR failure issues REQUEST SENSE;
- only NO SENSE (0x0) or UNIT ATTENTION (0x6) is accepted;
- a second TUR is required to pass;
- unexpected sense keys fail closed;
- `FRAMES_USB_MSC_UNIT_ATTENTION_OK` records the recovery;
- SCSI WRITE(10) remains absent.

Physical boot remains blocked. Frames 0.9.41 remains unpromoted pending external
v47 QEMU/OVMF evidence.
