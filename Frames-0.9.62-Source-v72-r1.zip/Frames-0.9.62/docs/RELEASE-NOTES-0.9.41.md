# Frames 0.9.41 — Native USB Mass-Storage Runtime Phase 2

Frames 0.9.41 closes the next hardware-readiness gap after the externally certified 0.9.40 compatibility matrix.

## Implemented

- Dedicated `USBMSC.CFG` certification challenge carried only by the native-USB-storage certification boot image.
- Boot-policy bit 256 can arm the native post-ExitBootServices USB mass-storage lane only when the already-certified diagnostic physical-preview + USB boot proof is present.
- Native xHCI discovery of USB Mass Storage class 08/06/50 and bulk IN/OUT endpoints.
- xHCI bulk endpoint contexts and transfer rings.
- USB Mass Storage Bulk-Only Transport CBW/data/CSW sequencing.
- Read-only SCSI commands: INQUIRY, TEST UNIT READY, READ CAPACITY(10), READ(10).
- Deterministic two-block challenge at LBA 128 with checksum proof.
- No SCSI WRITE command is implemented.
- Normal and hot-unplug-survival certification lanes use a separate writable-at-QEMU-layer USB data image which must remain byte-identical.
- The certification boot image uses EHCI for firmware boot while a separate xHCI controller owns the native data device, proving the post-ExitBootServices xHCI path is Frames-owned rather than firmware Block I/O.

## Scope

This phase certifies a bounded read-only BOT/SCSI path on the QEMU xHCI + usb-storage profile. It does not claim UAS, hubs, broad physical controller compatibility, or USB mass-storage writes.

Frames 1.0 remains NOT promoted.
