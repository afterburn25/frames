# Frames 0.9.52 — Native Window Manager Phase 1

Development increment built from Frames 0.9.51 v61. External GitHub/QEMU promotion is intentionally deferred until the integrated GUI/Desktop train is complete.

## Added
- Native top-level window records (up to 8 in Phase 1).
- Deterministic create/focus/z-order/move/resize operations.
- Native window decorations with title bars, borders, shadows and window controls.
- Two overlapping managed windows in the Desktop Preview development scene.
- Focused-window visual state and deterministic repaint/presentation.
- Window-manager diagnostics and evidence markers retained for the future integrated GUI certification gate.

## Safety
- Desktop mode remains diagnostic-only.
- Physical-media writes remain locked.
- No physical boot approval is granted.
