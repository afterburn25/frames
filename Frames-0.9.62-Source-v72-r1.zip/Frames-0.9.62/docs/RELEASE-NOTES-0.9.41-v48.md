# Frames 0.9.41 v48 — USB MSC Diagnostic Parser Hex-Prefix Repair

v48 does not change the Frames kernel or shipped boot media.

The external v47 run completed the native USB mass-storage runtime successfully,
including configuration, INQUIRY, Unit Attention recovery, TEST UNIT READY,
READ CAPACITY(10), deterministic READ(10), readonly proof, certification, detach
window, resident proof, and kernel-ready. QEMU exited 0.

The host evidence parser nevertheless marked the deterministic challenge checksum
as FAIL because its regular expression accepted only bare hexadecimal digits after
`stage=` and `value=`, while the kernel emits `0x`-prefixed values.

v48 accepts an optional `0x` prefix for both diagnostic fields, retains the exact
integer checksum comparison, records diagnostic cardinality, and fails closed on
duplicate diagnostics.

The source verifier is updated to require this hardened parser contract.
The v47 kernel and boot media remain unchanged.
