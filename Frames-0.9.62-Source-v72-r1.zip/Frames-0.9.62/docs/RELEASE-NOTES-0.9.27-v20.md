# Frames 0.9.27 v20 — USB/Input DMA-Lifetime Repair Candidate

## Why v20 exists

The v19 GitHub/QEMU evidence preserved 70/70 base runtime markers and all prior stress PASS results, but USB/input remained NOT-EXECUTED. New diagnostics emitted:

`FRAMES_USB_CONFIGURE_DIAG stage=0x0000000000000005 detail=0x0000000000000000`

Stage 0x5 is the allocation of the xHCI HID input context and interrupt transfer ring.

Inspection of the accepted source showed that `nvme_io_read_block()` allocated and permanently recorded a fresh DMA page for every synchronous block read. GPT/FAT boot discovery performs many reads, eventually consuming the DMA ledger's fixed 64-record capacity before USB HID configuration.

## v20 repair

- Allocate one persistent NVMe read DMA page when the NVMe I/O queue is created.
- Store that page in the NVMe runtime state.
- Reuse and zero that page for each synchronous `nvme_io_read_block()` operation.
- Preserve caller-buffer propagation semantics.
- Preserve the dedicated storage stress read-reuse path.
- Preserve the 64-record DMA ledger rather than masking the lifetime bug by enlarging it.
- Enhance USB diagnostic stage 0x5 detail to report the DMA-ledger record count on allocation failure.
- Preserve deterministic QMP keyboard event injection and all v19 xHCI command/transfer diagnostics.
- Preserve the fail-closed Phase-4 requirement: exactly 4 executed, 4 passed, 0 failed.

Frames 1.0 and physical boot remain blocked.
