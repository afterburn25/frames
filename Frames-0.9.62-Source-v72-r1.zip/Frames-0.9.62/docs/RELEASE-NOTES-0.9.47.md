# Frames 0.9.47 — Developer Preview Phase 3: Continuous USB Input & System Inspection

Built from externally certified Frames 0.9.46 v56.

- Adds continuous xHCI boot-HID interrupt-IN re-arming while Developer Preview is active.
- Routes USB keyboard HID keycodes through the existing input queue and preview command line, with PS/2 retained as fallback.
- Adds `processes` inspection backed by the live process registry and thread table.
- Adds `filesystems` inspection backed by live VFS mount, vnode, ramfs, devfs, and procfs state.
- Adds runtime markers and diagnostics for USB continuous polling and both inspection commands.
- Keeps the certified `sdk`, `app`, and `run` paths intact.
- Keeps `reboot` and `shutdown` recognized but blocked.
- Does not add SCSI WRITE(10) or unlock persistent physical-media writes.
- Physical hardware boot remains diagnostic-only and blocked.
