# Frames Physical Boot Gate — 0.9.62

PHYSICAL_BOOT_APPROVED = false

Frames 0.9.62 remains a diagnostic GUI development build. Physical boot is blocked and physical-media writes remain locked.
