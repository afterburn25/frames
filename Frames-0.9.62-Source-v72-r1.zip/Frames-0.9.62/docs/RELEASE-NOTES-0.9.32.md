# Frames 0.9.32 — Persistent Storage Write & Integrity Certification Gate 1

- Retains the externally accepted Frames 0.9.31 baseline: 70/70 base runtime markers and 8/8 stress/fault categories PASS.
- Keeps the boot/system NVMe read-only in the QEMU certification topology.
- Adds a second writable sacrificial NVMe image created specifically for certification.
- Requires the second controller Identify serial to be exactly `FRAMESWRITE0932`.
- Requires the sacrificial namespace to be exactly 32,768 logical blocks of 512 bytes and to carry the `FRAMES_WRITE_CERT_V1` identity header.
- Arms writes only for LBAs 4096..4111; primary/boot-NVMe writes and out-of-window writes fail closed before a command is submitted.
- Adds NVM Write (opcode 01h) and Flush (opcode 00h) completion handling for the bounded certification target.
- Executes 16 blocks x three write phases = 48 media writes, each followed by Flush and read-back verification.
- Detects stale/mismatched content and 16 injected read-back corruptions.
- Restores every certification block to pristine zero and revalidates three guard LBAs.
- Requires exact post-certification command accounting.
- Adds a host-side full-image before/after SHA-256 verifier; certification fails if the sacrificial image is not byte-identical after restoration.
- Upgrades `STORAGE-RUNTIME-CERT.json` to report read/write certification separately while explicitly retaining `boot_volume_write_certified=false`.
- Preserves the 8/8 stress matrix as a separate already-closed certification surface.
- Physical boot, boot-volume filesystem mutation, physical persistent writes, and Frames 1.0 remain blocked.
