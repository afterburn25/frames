# Frames 0.9.48 — HelixFS Read-Only Integration Phase 1

- Defines HelixFS v1 read-only on-disk superblock, inode, and directory-entry layouts.
- Seeds an immutable one-page Phase 1 image and parses it through the same on-disk layout contracts used by the mount backend.
- Mounts HelixFS as VFS filesystem kind 5 with read-only flags.
- Adds read-only path/security records for the HelixFS root and sample files.
- Reads a known file payload through the HelixFS inode/directory parser.
- Explicitly rejects HelixFS mutation and records the denial.
- Extends Developer Preview `filesystems` inspection with HelixFS version/inode/directory/read-only diagnostics.
- Adds dedicated HelixFS Phase 1 runtime evidence.
- Physical boot and physical-media writes remain blocked.
