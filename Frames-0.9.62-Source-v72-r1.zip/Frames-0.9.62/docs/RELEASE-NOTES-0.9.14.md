# Frames 0.9.14 — AP Scheduler State Preservation

Frames 0.9.14 is a runtime repair release built from 0.9.13 after real QEMU/OVMF evidence showed the first AP reached `FRAMES_AP_ONLINE_OK` but never progressed into AP timer/worker/runqueue certification.

## Runtime defect fixed

The BSP initialized the AP scheduler before startup, including the prepared AP worker stack, runnable state, peer scheduler pointer, logical CPU id, and affinity metadata. `kernel_ap_entry()` then zeroed the first 256 bytes of that same scheduler, erasing the prepared state immediately before enabling the AP periodic LAPIC timer.

0.9.14 preserves the BSP-seeded AP scheduler and only fills AP-local runtime fields (LAPIC base, quantum, AP mode, SMP-state pointer).

## SMP certification sequencing

The BSP now confirms AP timer delivery, AP worker entry, and AP runqueue progress before sending the reschedule IPI. Reschedule acknowledgement is confirmed in a separate bounded stage. All waits remain bounded and all normal certification output remains BSP-owned.

## Safety status

Physical boot remains BLOCKED. Persistent media writes remain absent. This release is diagnostic-only until fresh external runtime evidence is imported.
