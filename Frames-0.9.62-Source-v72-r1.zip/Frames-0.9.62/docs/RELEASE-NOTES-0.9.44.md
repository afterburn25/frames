# Frames 0.9.44 — Nexus SDK / Developer Tooling Phase 1

Built from the externally certified Frames 0.9.43 v52 baseline.

Phase 1 introduces a packaged host-side Frames SDK CLI around Nexus 5.20.0 for
`frames-x64` FEX development. The SDK can doctor the environment, create a
starter Nexus app, build it to FEX64, and inspect the result.

The Interactive Developer Preview adds an `sdk` command that exposes the matching
Frames syscall/FEX ABI contract and is externally certifiable alongside the
existing native `run` command.

This milestone does not add physical-media write capability. Reboot/shutdown
remain blocked in the preview, SCSI WRITE(10) remains absent, and physical boot
remains blocked pending external v53 certification.
