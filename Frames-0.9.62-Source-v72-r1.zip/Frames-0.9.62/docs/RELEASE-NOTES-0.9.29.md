# Frames 0.9.29 — Display Stress/Fault Certification Phase 6

- Adds fail-closed display stress category 6.
- Requires a validated real UEFI GOP framebuffer and emits `FRAMES_DISPLAY_FRAMEBUFFER_FOUND`.
- Saves/restores an 8x8 framebuffer patch and performs 256 alternating-color clipped rectangle writes with direct memory readback verification.
- Saturates the 64-record dirty-region ring with 80 records and verifies bounded wrap behavior.
- Fills the 32-record presentation queue, requires the 33rd enqueue to fail closed, flushes exactly 32 records, and verifies timing/accounting.
- Performs 128 cursor moves including clipping at framebuffer boundaries.
- Revalidates live output registry, topology, dirty/cursor self-test state and the display core gate after stress.
- Adds `FRAMES_STRESS_DISPLAY_OK` / `FRAMES_STRESS_DISPLAY_FAIL` and stage/detail diagnostics.
- Phase-6 evidence requires exactly 6 executed / 6 passed / 0 failed categories.
- No native GPU driver, hardware acceleration, VSync, page-flip ownership or modesetting certification is claimed.
- Physical boot, persistent-media writes, and Frames 1.0 remain blocked.
