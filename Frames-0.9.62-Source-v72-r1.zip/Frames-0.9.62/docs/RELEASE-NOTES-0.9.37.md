# Frames 0.9.37 — Scalable SMP & Multi-Core Certification

Built from the accepted Frames 0.9.36 v34 baseline.

## Added
- MADT/per-CPU topology capacity expanded from 64 to 128 logical CPUs.
- Bootstrap heap expanded for scalable per-CPU state and stacks.
- Independent 16 KiB AP bootstrap stacks and 16 KiB worker stacks for up to 128 CPU slots.
- Independent 512-byte scheduler slots for every logical AP.
- Sequential INIT/SIPI bring-up for every enabled AP.
- Per-AP LAPIC timer and timer-driven worker-dispatch proof.
- Per-AP fixed-vector reschedule IPI acknowledgement.
- Two-word 128-bit CPU affinity masks, including explicit high-word proof above CPU 63.
- Fail-closed scalable SMP evidence markers and diagnostics.
- QEMU/OVMF certification matrix for 2, 4, 8, 16, 32, 64 and 96 logical CPUs.

## Preserved
All accepted Frames 0.9.36 Gate-5 runtime/storage/lifecycle/filesystem/system-volume/FAT-lifecycle requirements remain fail-closed and are re-proved by the external workflow.

Physical boot remains blocked and Frames 1.0 remains unpromoted.

## v36 high-core-count serial atomicity hotfix

The first v35 96-vCPU run proved the full numeric SMP state (95 APs online/timer/worker/IPI and 32 high-word affinity CPUs) but a concurrent `FRAMES_SCHEDULER_SUSTAINED` line split the literal `FRAMES_SMP_SCALE_APS_ONLINE_OK` serial marker. v36 quiesces AP progress-marker output only while the BSP emits the Gate-6 certification marker block. Evidence requirements are unchanged; no parser relaxation is used.
