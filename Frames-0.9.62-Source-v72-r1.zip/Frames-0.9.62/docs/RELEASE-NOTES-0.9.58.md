# Frames 0.9.58 — File Manager & Desktop Files Integration

- Adds first native File Manager window backed by Frames VFS + read-only HelixFS path reads.
- Displays deterministic navigation rail and file rows; persistent writes remain disabled.

Next: Frames 0.9.59 — Settings / Control Center Foundation.
