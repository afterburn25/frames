# Frames 0.9.13 — SMP Serial Ownership & AP Runtime Evidence

Frames 0.9.13 repairs the first SMP-runtime logging defect exposed by the real 0.9.12 QEMU/OVMF certification run.

## Runtime evidence behind this release

The 0.9.12 run proved the full platform, storage, safety, and userspace groups, including a clean FEX syscall/exit/return sequence. The AP also visibly reached its entry/runtime path, but AP and BSP writes to COM1 interleaved and the AP reinitialized the shared UART while the BSP was transmitting.

## Changes

- COM1 initialization is now BSP-only during normal SMP certification.
- `serial_putc` waits for the UART transmitter-holding-register-empty indication before writing a byte.
- AP startup, timer, worker, runqueue, and reschedule acknowledgements are recorded in shared SMP/scheduler state instead of being written directly by the AP.
- The BSP emits AP certification markers only after observing the corresponding shared-state transitions.
- SMP scheduler/affinity certification output is restricted to the BSP.
- No persistent-media write path is introduced.
- Physical boot remains explicitly BLOCKED.
