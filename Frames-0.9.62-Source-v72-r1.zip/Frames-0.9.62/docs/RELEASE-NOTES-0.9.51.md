# Frames 0.9.51 — Native Graphics & Desktop Surface Phase 1

- Adds a dedicated diagnostic-only Desktop Preview boot policy and image.
- Composes a native framebuffer desktop using Frames display primitives.
- Renders deterministic wallpaper bands, a shell panel, launcher tile, center surface card, Frames-style mark, status indicators, and native cursor glyph.
- Integrates dirty-region tracking, cursor state, presentation queue, and frame timing.
- Adds desktop composition state exported through process state.
- Adds Desktop Phase 1 serial diagnostics and fail-closed gate.
- Adds QMP framebuffer capture and PPM pixel verification in QEMU/OVMF certification.
- Retains the interactive Developer Preview as a separate regression lane.
- No top-level application windows yet; window management is planned for 0.9.52.
- Physical boot remains blocked; physical-media writes remain locked.
