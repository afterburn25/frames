# Frames 0.9.22 — AP IRET Protection-Fault Capture & Segment-State Coherency

## Runtime evidence entering this build
Frames 0.9.21 externally proved canonical AP CS normalization and LAPIC timer handler entry, but the scheduler-free first timer interrupt did not return to `kernel_ap_entry`. Required runtime markers were 64/70 with no fatal marker.

## Changes
- Nexus 5.19.0 adds `reload_data_segments(selector)` and dedicated #TS/#NP/#SS/#GP kernel stub-address builtins.
- Shared GDT slot 2 / selector 0x10 is populated with a present ring-0 writable data descriptor.
- AP reloads DS/ES/SS to 0x10 after loading the shared GDT and canonical kernel CS.
- LAPIC timer stub snapshots hardware RIP/CS/RFLAGS immediately before IRETQ into AP scheduler evidence.
- Protection-fault stubs record vector, error code, fault RIP, and CS, then halt the faulting AP fail-closed.
- BSP emits supplemental diagnostics if the bare IRET proof remains absent.
- No required runtime marker is removed, synthesized, or weakened.
