# Frames Status — 0.9.62

Current GUI development candidate: **Frames 0.9.62 — Desktop Polish, Accessibility & Integrated GUI Regression**.

External GUI certification is deferred until the integrated desktop train is complete. Physical boot remains blocked and physical-media writes remain locked.
