# Frames 0.9.50 — HelixFS Read-Only Integration Phase 3

- 8 KiB immutable HelixFS image / 16 logical 512-byte blocks.
- Five inodes and four directory records with nested directory token 403.
- 1 KiB multi-block file with deterministic checksum 8256.
- Two-level traversal root token 400 → directory token 403 → file token 404.
- Read-only enforcement retained; physical-media writes remain locked.
