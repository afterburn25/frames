# Frames 0.9.53 — Native Input Routing & Desktop Interaction

Adds native pointer hit-testing, click focus, pointer capture, drag/resize routing, keyboard focus, per-window event delivery, and a live desktop HID event loop. External certification is deferred to the integrated GUI gate.
