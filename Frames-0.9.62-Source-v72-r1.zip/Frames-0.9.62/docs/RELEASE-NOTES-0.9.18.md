# Frames 0.9.18 — Asserted Cross-Priority Reschedule IPI

## Runtime evidence leading to this release

Frames 0.9.17 v8 reached 67 of 70 required QEMU runtime markers. It proved the full read-only GPT/FAT32/VFS path, all downstream consolidated subsystem gates, AP LAPIC timer delivery, AP worker dispatch-and-return, and `FRAMES_KERNEL_READY`.

The only missing markers were:
- `FRAMES_RESCHED_IPI_OK`
- `FRAMES_CPU_AFFINITY_OK`
- `FRAMES_SMP_SCHEDULER_OK`

The BSP emitted `FRAMES_RESCHED_IPI_SENT`, while the AP's reschedule receipt counter remained zero.

## Root cause

The BSP programmed the xAPIC ICR low dword with decimal 50 (`0x32`) for a fixed reschedule IPI. This selected vector 0x32 but left the ICR Level/Assert bit clear. Intel's APIC programming contract requires the Level flag to be asserted for normal delivery modes other than INIT level-deassert.

Vector 0x32 also shared APIC priority class 3 with the scheduler timer at vector 0x30.

## Repair

- Reschedule interrupt IDT vector moved from 0x32 to 0x50.
- Fixed IPI ICR low value changed to `0x4050`: vector 0x50 + Level/Assert bit.
- This places reschedule delivery in APIC priority class 5, above the scheduler timer's class 3.
- BSP publishes the chosen vector and ICR low value in supplemental SMP-state fields for post-run diagnostics.
- Bounded acknowledgement wait increased from 10,000,000 to 20,000,000 pause iterations.
- No required certification marker was relaxed or removed.

## Safety

- Persistent media writes remain absent.
- Physical boot remains blocked.
- Frames 1.0 remains unpromoted pending fresh runtime, stress/fault, and physical evidence.
