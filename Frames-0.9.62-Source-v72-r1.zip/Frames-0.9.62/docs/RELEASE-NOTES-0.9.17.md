# Frames 0.9.17 — Runtime Convergence: AP Runqueue + Read-Only Block Propagation

## Runtime evidence that triggered this build
Frames 0.9.16 under GitHub Actions QEMU/OVMF reached `FRAMES_KERNEL_READY`. Platform, userspace, storage-NVMe, safety, and core evidence groups passed. The AP reached GDT install, APIC enable, LAPIC countdown, first timer delivery, and worker entry. Eleven required markers remained: AP runqueue/reschedule/affinity/SMP plus filesystem and its downstream consolidated network/display/audio/driver/security gates.

## Repairs
- Preserve DMA ownership for NVMe reads but propagate the completed logical block into `requested_buffer` when the block layer supplies one.
- AP runqueue proof is recorded only after a real first worker dispatch returns to the timer interrupt handler.
- Cross-CPU scheduler certification requires: correct BSP/AP affinities, sustained BSP dispatches, a real AP dispatch-and-return cycle, and a received BSP→AP reschedule IPI.
- Add supplemental `FRAMES_FS_DIAG=` stage output for GPT/FAT/VFS/filesystem convergence.

## Safety
- Read-only storage behavior is unchanged.
- No namespace write opcode or persistent filesystem mutation path is added.
- Physical boot remains explicitly blocked.
- Frames 1.0 is not promoted by this source build; fresh runtime evidence is required.
