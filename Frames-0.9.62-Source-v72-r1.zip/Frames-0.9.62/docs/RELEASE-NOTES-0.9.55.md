# Frames 0.9.55 — First Native GUI FAPP

Adds FAPP1 windowed UI metadata, launches the verified app FEX through the native ring-3 path, and binds it to a managed native Frames window.
