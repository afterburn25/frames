# Frames 0.9.38 — Removable USB Boot Certification Gate 7

Built from the accepted Frames 0.9.37 v36 scalable-SMP baseline.

## Added
- Dedicated UEFI removable-media certification challenge `\Frames\USBBOOT.CFG`.
- Loader-side verification that the loaded-image device path contains a USB messaging node.
- Loader-side Block I/O media-presence proof on the same loaded-image device handle.
- Verified FKRN64 and System FEX reads from the challenged USB filesystem before ExitBootServices.
- Kernel-visible fail-closed USB boot policy markers without changing Kernel ABI 4.
- QEMU/OVMF USB mass-storage boot lane using the standard `EFI/BOOT/BOOTX64.EFI` removable path.
- Writable internal-NVMe sentinel image that must remain byte-identical, proving Frames does not write the internal disk during the USB boot certification lane.
- Post-load USB detach lane: once the USB boot proof is in memory, the boot device is hot-unplugged and the resident kernel must continue to its required proof marker.

## Scope
This gate certifies the UEFI removable USB boot path and post-load survivability under QEMU. It does not claim a native USB mass-storage filesystem driver after ExitBootServices, physical USB controller compatibility, physical-machine disk writes, or physical boot.

Physical boot remains BLOCKED. Frames 1.0 remains unpromoted.
