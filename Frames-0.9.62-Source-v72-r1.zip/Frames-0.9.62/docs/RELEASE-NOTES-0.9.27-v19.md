# Frames 0.9.27 v19 — USB/Input Phase-4 Diagnostic & Deterministic Input Repair

- Keeps Frames 0.9.27 at Phase 4; no 0.9.28 advancement is claimed.
- Records xHCI command-completion and transfer-event completion diagnostics in previously unused xHCI state fields.
- Emits `FRAMES_USB_CONFIGURE_DIAG` stage/detail lines around every fail-closed USB HID configuration gate.
- Adds deterministic QMP keyboard event injection during QEMU certification so QEMU `usb-kbd` has real input activity available for the first interrupt-IN report.
- Captures `qemu-debug.log` and `qmp-input.log` in the build for evidence diagnosis.
- Retains the unchanged 70-marker base contract and the Phase-4 requirement of exactly 4/4 executed/passed stress categories.
- Does not alter the physical-boot block or promote Frames 1.0.
- 0.9.27 v18 evidence remains rejected for Phase 4 because USB/input was NOT-EXECUTED.
