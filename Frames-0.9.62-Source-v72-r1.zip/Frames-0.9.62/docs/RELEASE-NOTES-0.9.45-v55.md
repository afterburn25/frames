# Frames 0.9.45 v55 — Filesystem QEMU Watchdog Hardening

v55 is a certification-harness repair for the 0.9.45 FEX Application Packaging candidate.
The kernel, FEX payload, UEFI loader, application-package format, and shipped media are
unchanged from v54.

The v54 sacrificial filesystem crash/recovery script exposed `FRAMES_FILESYSTEM_TIMEOUT=300`
but did not apply that timeout to the QEMU process. If a marker/QMP helper failed or timed
out, the shell waited on QEMU first and could block indefinitely.

v55 adds a per-lane watchdog. If a filesystem QEMU instance is still alive after the
configured timeout, the watchdog records `FILESYSTEM_QEMU_WATCHDOG_TIMEOUT`, sends TERM,
then KILL if required, and the lane fails closed with exit 124 instead of hanging forever.
Normal marker-driven exits and intentional crash-lane exit 137 behavior remain unchanged.
