# Frames 0.9.40 Hardware Readiness

Physical diagnostic boot is approved from 0.9.39, but the user's real-hardware run is deferred until spare/test hardware is available. Frames 0.9.40 expands compatibility reporting and alternative read-only hardware paths in QEMU/OVMF. Internal persistent/destructive writes remain locked in physical-preview mode.
