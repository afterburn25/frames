# Frames 0.9.19 — One-AP Fixed-IPI Shorthand Fallback & Live AP Diagnostics

## Runtime evidence driving this release

Frames 0.9.18 under GitHub Actions QEMU/OVMF produced 67 of 70 required markers with zero fatal markers. `FRAMES_KERNEL_READY`, the full storage/filesystem chain, all consolidated subsystem gates, AP timer delivery, AP worker entry, AP runqueue proof, and `FRAMES_RESCHED_IPI_SENT` all passed.

The only missing markers were:
- `FRAMES_RESCHED_IPI_OK`
- `FRAMES_CPU_AFFINITY_OK`
- `FRAMES_SMP_SCHEDULER_OK`

The asserted higher-priority targeted fixed IPI (`ICR low 0x4050`, vector `0x50`) still did not increment the AP receipt counter.

## 0.9.19 changes

1. **Targeted attempt remains first and fail-closed**
   - BSP still first sends the asserted fixed vector `0x50` to the AP's physical APIC ID.
   - `FRAMES_RESCHED_IPI_SENT` continues to mean the targeted ICR transaction completed, not that the AP received it.

2. **Live AP timer diagnostics during acknowledgement wait**
   - The BSP samples the AP LAPIC timer interrupt counter before and after the bounded acknowledgement wait.
   - If the counter advances while the targeted IPI is unacknowledged, `FRAMES_RESCHED_TIMER_ALIVE` is emitted.
   - `FRAMES_RESCHED_TARGET_TIMEOUT` identifies a targeted delivery timeout.

3. **Exactly-one-AP architectural fallback**
   - Only when `smp_state.ap_count == 1`, a failed targeted attempt may be retried using destination shorthand `all excluding self`.
   - ICR low is `0xC4050`: fixed vector `0x50`, Level/Assert set, edge trigger, destination shorthand `11b`.
   - `FRAMES_RESCHED_FALLBACK_SENT` is supplemental evidence only.

4. **Real AP acknowledgement remains mandatory**
   - The same AP interrupt handler must increment `ap_scheduler+208`.
   - Only that receipt can emit `FRAMES_RESCHED_IPI_OK`.
   - `FRAMES_CPU_AFFINITY_OK` and `FRAMES_SMP_SCHEDULER_OK` still depend on that received IPI plus the existing dispatch/affinity proofs.
   - The 70-marker required runtime contract is unchanged.

5. **Fallback failure remains visible**
   - `FRAMES_RESCHED_FALLBACK_TIMEOUT` is emitted if the shorthand retry also fails.
   - No runtime gate is relaxed.

Physical boot remains blocked. Persistent media writes remain absent. Frames 1.0 remains unpromoted.
