# Frames 0.9.26 — Storage-Read Stress/Fault Certification Phase 3

- Preserves the externally verified Frames 0.9.25 70/70 QEMU runtime baseline and allocator+scheduler stress passes.
- Adds a no-allocation reusable-DMA NVMe stress read primitive that reuses an already-owned 4 KiB DMA page instead of consuming the bounded DMA ledger.
- Repeats real NVMe reads across LBA0 protective MBR, GPT header, FAT32 ESP boot sector, and the first System.fex block with stable per-block checksums and signature validation.
- Cross-checks the directly read System.fex bytes against the existing VFS/open-file read buffer.
- Replays cached LBA0/LBA1 reads and requires cache-hit growth without cache-miss growth.
- Requires out-of-range NVMe/block requests to fail before submission and requires the global DMA ledger entry count to remain unchanged throughout the stress loop.
- Retains fail-closed source verification that no NVMe namespace-write, block-write, FAT32-write, or filesystem-write path exists.
- Emits `FRAMES_STRESS_STORAGE_READ_OK` only after every storage invariant passes; otherwise emits `FRAMES_STRESS_STORAGE_READ_FAIL`.
- Stress evidence phase 3 requires exactly allocator, scheduler, and storage-read PASS; USB/input, network, display, recovery and power remain NOT-EXECUTED.
- Physical boot remains BLOCKED. Persistent-media writes remain absent/uncertified. Frames 1.0 is not promoted.
