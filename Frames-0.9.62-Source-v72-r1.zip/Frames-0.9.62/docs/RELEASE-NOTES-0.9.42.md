# Frames 0.9.42 — Interactive Developer Preview Phase 1

Source baseline: externally certified Frames 0.9.41 v48.

## Added

- Dedicated `DEVPREV.CFG` boot challenge and boot-policy bit 9 (value 512).
- VM/certification-only interactive developer-preview policy, isolated from physical-preview and USB-MSC certification policies.
- Framebuffer console surface with a compact built-in 5x7 glyph renderer.
- Real keyboard-backed command input through the existing kernel input queue and PS/2 polling fallback.
- Commands: `help`, `version`, `cpu`, `memory`, `devices`, `reboot`, `shutdown`, `exit`.
- Deterministic developer-preview serial evidence markers and command diagnostics.
- Dedicated developer-preview boot-image generator, verifier, QMP command injector, QEMU certifier, and evidence parser.

## Safety

- `reboot` and `shutdown` are recognized but blocked in Phase 1.
- No physical-media write path is enabled.
- SCSI WRITE(10) remains absent.
- Physical hardware boot remains blocked.
- Frames 1.0 remains unpromoted.

## Promotion requirement

External v49 QEMU/OVMF evidence must pass all inherited gates plus the new interactive developer-preview lane before 0.9.42 may supersede 0.9.41 v48.
