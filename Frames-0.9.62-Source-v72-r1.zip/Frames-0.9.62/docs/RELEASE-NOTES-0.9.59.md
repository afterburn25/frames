# Frames 0.9.59 — Settings / Control Center Foundation

- Adds native Settings/Control Center window, display geometry state, theme selection and UI scale/accessibility preference foundation.
- Settings are in-memory only; persistent-media writes remain locked.

Next: Frames 0.9.60 — Notifications, Status Area & System UI.
