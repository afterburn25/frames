# Frames 0.9.16 — AP Descriptor-Table Coherency

## Evidence driving this release
The real Frames 0.9.15 QEMU/OVMF run reached:
- `FRAMES_AP_ONLINE_OK`
- `FRAMES_AP_APIC_ENABLE_OK`
- `FRAMES_AP_TIMER_COUNTING_OK`
- `FRAMES_AP_TIMER_DIAG=0x...,...,0x0`

The AP LAPIC current-count value decreased, but the AP timer interrupt count remained zero. Platform, userspace, read-only NVMe storage, and safety groups remained PASS.

## Root cause addressed
The AP entered 64-bit kernel code using the low-memory trampoline GDT (kernel code selector `0x18`) and then loaded the BSP-owned shared IDT. The shared IDT gates were built using the BSP kernel code selector. The AP had not loaded the BSP kernel GDT, leaving interrupt-gate selector resolution inconsistent on the AP.

## Repair
- Publish the kernel GDT pointer at SMP-state offset `+208`.
- AP loads the shared kernel GDT before loading the shared IDT.
- Publish an AP GDT-installed flag at SMP-state offset `+216`.
- BSP emits supplemental `FRAMES_AP_GDT_OK` when that flag is observed.
- Retain 0.9.15 APIC enable, timer-countdown, and pre-scheduler first-interrupt diagnostics.
- Required runtime certification markers remain fail-closed and unchanged.

## Safety
- Diagnostic-only.
- Physical boot remains BLOCKED.
- Persistent-media writes remain absent.
- No SMP runtime PASS is claimed until external QEMU/OVMF evidence proves timer delivery and scheduler progression.
