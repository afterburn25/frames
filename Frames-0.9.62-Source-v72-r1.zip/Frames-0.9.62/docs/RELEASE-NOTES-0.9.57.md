# Frames 0.9.57 — Desktop Themes, Fonts & Icon Runtime

- Adds native theme palette state, procedural bitmap font sample runtime and reusable icon drawing primitives.
- Theme/font/icon state is exported to the GUI process context.

Next: Frames 0.9.58 — File Manager & Desktop Files Integration.
