# Frames 0.9.56 — Window Decorations, Menus & Dialog Primitives

- Adds native window control action state, context/application menu primitives and modal dialog composition.
- Keeps app window and shell fully Frames-native.

Next: Frames 0.9.57 — Desktop Themes, Fonts & Icon Runtime.
