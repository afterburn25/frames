# Frames 0.9.20 — AP Interrupt-Return Selector Preservation

## Root cause isolated by 0.9.19 evidence
The AP completed one LAPIC timer handler and one worker dispatch/return but then stopped accumulating timer interrupts. Both targeted and one-AP all-excluding-self fixed reschedule IPIs timed out. The shared GDT did not guarantee that the AP trampoline's saved `CS=0x18` remained valid for `iretq` after the AP loaded the BSP GDT.

## Repair
- Install a valid 64-bit kernel code descriptor at shared GDT slot 3 / selector 0x18.
- Record AP CS after shared-GDT load.
- Publish post-first-interrupt-return state only after execution returns to `kernel_ap_entry`.
- Reassert interrupts and require this proof before BSP reschedule injection.
- Add supplemental `FRAMES_AP_IRQ_RETURN_OK`.
- Keep the required 70-marker certification contract unchanged.
