# Frames 0.9.33 — Destructive Reboot & Shutdown Certification Gate 2

- Preserves the accepted 70/70 runtime marker contract, 8/8 stress/fault matrix, and sacrificial NVMe write/integrity certification.
- Adds exact lifecycle target identities `FRAMESREBOOT0933` and `FRAMESSHUTDOWN0933`.
- Requires a separate 16 MiB `FRAMES_LIFECYCLE_V1` namespace; normal boot and storage-write targets cannot arm lifecycle execution.
- Reboot mode persists a one-time state token to LBA 1, flushes/read-backs it, executes the real ACPI reset path, and on the next boot emits `FRAMES_LIFECYCLE_REBOOT_RETURNED` instead of resetting again.
- Shutdown mode persists its state token, flushes/read-backs it, then executes real ACPI S5; successful certification requires natural QEMU exit.
- Adds host media validation, reboot/shutdown serial evidence validation, QMP quit-after-return for the second reboot boot, and fail-closed `FRAMES_LIFECYCLE_DESTRUCTIVE_FAIL`.
- No destructive action is executed unless the exact lifecycle controller serial, media header, geometry, and mode all match.
- Physical-machine power, boot-volume writes, physical boot, and Frames 1.0 remain blocked.
