# Frames 0.9.46 — FAPP Native Application Loader Phase 1

Built from externally certified Frames 0.9.45 v55.

- Keeps the FAPP1 manifest + APP.FEX contract and switches deterministic entries to ZIP stored mode for bounded native parsing.
- Developer Preview UEFI loader reads `HELLO.FAP`, validates FAPP1 manifest fields, target, minimum Frames version, FEX ABI, whole-file FEX SHA-256, FEX64 header, and internal FEX digest.
- A verified packaged FEX is handed to the kernel as boot module kind 2 with verification flags.
- Kernel independently requires verified FAPP module flags and FEX ABI, maps the packaged FEX through the existing ring-3 loader, executes the same 3-syscall proof, and returns to the preview shell.
- New `app` command certifies the packaged application launch before the existing `run` command.
- Developer Preview now requires three complete userspace cycles: initial System.fex, packaged HelloFrames FEX, then System.fex relaunch.
- Persistent target-media writes remain disabled; preview media stays read-only; physical boot remains blocked.
