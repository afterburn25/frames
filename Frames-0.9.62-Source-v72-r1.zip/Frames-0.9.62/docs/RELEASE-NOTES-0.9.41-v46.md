# Frames 0.9.41 v46 — SMP UART Evidence Parser Hardening

v46 does not change the Frames kernel or shipped boot media.

The external v45 run showed a valid 8-CPU SMP sequence where one diagnostic line
lost the first four UART characters (`ES_SMP_SCALE_DIAG` instead of
`FRAMES_SMP_SCALE_DIAG`). All functional SMP success markers and the expected
detail value 8 were present, but the host evidence parser rejected the lane.

v46 hardens `tools/smp_scale_evidence.py` to accept only a bounded truncated
alphanumeric diagnostic prefix while retaining exact stage/detail validation.
It additionally requires each diagnostic stage 1 through 6 to appear exactly once,
so duplicate or ambiguous diagnostics remain a failure.

The native USB MSC SuperSpeed kernel repair from v45 is unchanged.
Physical boot remains blocked and Frames 0.9.41 remains unpromoted pending
external v46 QEMU/OVMF evidence.
