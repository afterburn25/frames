# Frames 0.9.41 v45 — Native USB MSC SuperSpeed Gate Repair

Status: certification candidate; not promoted.

## Root cause corrected

The failed external v42 USB-MSC evidence reached endpoint discovery and then emitted:

- `FRAMES_USB_MSC_DIAG stage=0x1 value=0x304`
- `FRAMES_USB_MSC_DIAG stage=0x2 value=0x4`

The `usb_msc_configure()` path treated xHCI speed ID 4 as unsupported and returned before
Configure Endpoint. The same source already uses speed ID 4 as the SuperSpeed class when
building EP0 (512-byte packet size).

v45 changes the MSC configuration gate from rejecting `speed >= 4` to rejecting only invalid/unhandled or Low-Speed values (`speed == 0 || speed == 2 || speed > 4`).
Full-Speed, High-Speed, and SuperSpeed are accepted; xHCI Low-Speed cannot carry bulk transfers.

## Scope retained

- Frames product version remains 0.9.41.
- Read-only USB MSC certification scope remains unchanged.
- BOT/SCSI commands remain INQUIRY, TEST UNIT READY, READ CAPACITY(10), and READ(10).
- SCSI WRITE(10) remains absent.
- Physical boot remains blocked pending external v45 evidence.
- Frames 0.9.40 v41 remains the approved externally certified fallback.

This source change clears the exact runtime blocker observed in v42; it does not claim
external certification until the v45 QEMU/OVMF workflow passes.
