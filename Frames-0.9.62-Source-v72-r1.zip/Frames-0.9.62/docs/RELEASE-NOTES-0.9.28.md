# Frames 0.9.28 — Network Stress/Fault Certification Phase 5

- Builds directly from the externally accepted Frames 0.9.27 v20 Phase-4 baseline.
- Preserves the 70-marker base QEMU runtime contract and allocator, scheduler, storage-read, and USB/input stress gates.
- Adds stress category 5 for the Frames network core.
- Requires a real PCI class-2 network adapter to be discovered at runtime under QEMU; the v21 certifier explicitly supplies an e1000e device.
- Emits `FRAMES_NETWORK_ADAPTER_FOUND` only after the discovered BDF re-reads as PCI network class 2.
- Exercises 512 Ethernet + IPv4 + ICMP loopback frames with IPv4 and ICMP checksum verification on every cycle.
- Exercises packet-pool malformed-length rejection, full 8-slot exhaustion, fail-closed ninth allocation, complete release, and post-exhaustion recovery.
- Exercises all 32 TCP table entries through invalid-transition rejection and the SYN/established/closed state path, then requires the 33rd open to fail closed.
- Exercises truncated DHCP and DNS response rejection plus a corrupted DNS response rejection.
- Verifies the live network-core TX/RX counters and network gate are unchanged by the isolated scratch stress state.
- Emits `FRAMES_STRESS_NETWORK_OK` only after all Phase-5 invariants pass; otherwise emits `FRAMES_STRESS_NETWORK_FAIL` with stage/detail diagnostics.
- Phase-5 evidence requires exactly five executed categories: allocator, scheduler, storage-read, USB/input, and network; all five must PASS with zero failures.
- This phase certifies network-core stress/fault behavior plus real PCI NIC discovery. It does **not** claim physical NIC TX/RX, real DHCP leasing, external DNS, or real TCP peer communication.
- Cleans up the prior literal `\n` USB stress marker formatting defect.
- Physical boot remains BLOCKED. Persistent-media writes remain uncertified. Frames 1.0 remains NOT promoted.
