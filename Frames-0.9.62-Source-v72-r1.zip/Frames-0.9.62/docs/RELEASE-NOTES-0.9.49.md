# Frames 0.9.49 — HelixFS Read-Only Integration Phase 2

- Adds immutable HelixFS block-image adapter with 512-byte logical blocks.
- Superblock, inode, directory, and data reads go through the block adapter.
- Adds VFS/path-token read proof through mount 5 with filesystem read-right enforcement.
- Adds block-read/write-denial/path-read diagnostics to Developer Preview.
- Retains HelixFS Phase 1 format, read-only semantics, FAPP/FEX developer tooling, and continuous USB input.
- Physical boot remains blocked and physical-media mutation remains locked.
