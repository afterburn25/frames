# Frames 0.9.61 — Login / Lock Screen & Session Shell

- Adds session identity, lock-state transition, unlock transition and native session-shell composition.
- No persistent credential storage is enabled; this is a deterministic session-shell foundation.

Next: Frames 0.9.62 — Desktop Polish, Accessibility & Integrated GUI Regression.
