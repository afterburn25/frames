# Frames 0.9.15 — AP LAPIC First-Tick Isolation

Frames 0.9.15 is a runtime-repair release driven by the real QEMU/OVMF evidence from Frames 0.9.14.

## Evidence that triggered this build
- Frames 0.9.14 was genuinely selected and booted under GitHub Actions/QEMU/OVMF.
- Platform, userspace, read-only NVMe storage, and safety groups remained PASS.
- The AP reached `FRAMES_AP_ENTER`, `FRAMES_AP_RUNTIME_OK`, and `FRAMES_AP_ONLINE_OK` cleanly.
- No AP timer/worker/runqueue marker followed. The serial log stopped at `FRAMES_AP_ONLINE_OK` until the runtime harness timed out.

## Repair
- Reassert IA32_APIC_BASE global enable on the AP after INIT/SIPI before programming xAPIC MMIO.
- Explicitly reset AP TPR to 0 and re-enable the spurious vector register.
- Re-arm AP divide configuration, periodic LVT timer, and initial count.
- Poll the AP current-count register before STI and retain first/second counter samples.
- Record `FRAMES_AP_APIC_ENABLE_OK` and `FRAMES_AP_TIMER_COUNTING_OK` through BSP-owned serial diagnostics when applicable.
- Record AP timer interrupt arrival at the start of `kernel_lapic_timer_tick()` before any scheduler context switch.
- Keep the AP in a bounded active-pause bootstrap loop until first timer-interrupt evidence is visible, then return to HLT idle behavior.

## Safety
- Diagnostic-only policy remains unchanged.
- Physical boot remains BLOCKED.
- Persistent media write support remains absent.
- No SMP runtime PASS is claimed until external evidence proves it.
