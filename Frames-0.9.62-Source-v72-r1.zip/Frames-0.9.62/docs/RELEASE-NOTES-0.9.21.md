# Frames 0.9.21 — AP Bare-IRET Isolation & Canonical Kernel CS

Frames 0.9.21 isolates and hardens the remaining AP interrupt-return path after the real 0.9.20 QEMU run proved that the AP timer handler and worker cycle completed but execution did not resume in `kernel_ap_entry`.

## Changes

- Bundles Nexus 5.18.0 with kernel builtin `reload_cs(selector)`.
- After adopting the shared BSP GDT, the AP explicitly reloads live CS onto the shared kernel selector before loading the shared IDT.
- Preserves the trampoline selector 0x18 as a valid shared-GDT code descriptor during the handoff.
- Splits AP timer certification into two stages:
  1. first LAPIC timer IRQ is acknowledged and returned with scheduler dispatch disabled;
  2. only after that bare IRETQ return is proven does the AP enable normal timer-driven worker dispatch.
- Adds supplemental `FRAMES_AP_CS_NORMALIZED_OK` and `FRAMES_AP_BARE_IRQ_RETURN_OK`.
- Existing `FRAMES_AP_IRQ_RETURN_OK` is strengthened to mean the scheduled timer IRQ returned all the way back to `kernel_ap_entry` after the worker dispatch/yield cycle.
- Reschedule IPI injection remains blocked until both return stages have passed.
- The authoritative 70 required runtime markers are unchanged.
- Persistent-media write support remains absent.
- Physical boot remains fail-closed.
