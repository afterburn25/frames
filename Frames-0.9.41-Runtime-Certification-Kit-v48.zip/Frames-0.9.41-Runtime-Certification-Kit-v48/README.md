# Frames 0.9.41 Runtime Certification Kit v48

v48 keeps the v47 Frames kernel unchanged and repairs only the USB-MSC host
evidence parser plus its structural verifier contract.

Install `Frames-0.9.41-GitHub-Native-USB-Mass-Storage-Certification-v48.yml` as:
`.github/workflows/frames-0.9.41-native-usb-msc-v48.yml`

Keep `Frames-0.9.41-Source-v48.zip` available to the workflow.
Pinned source SHA-256:
`b144c93f25f720eb358a943aabb881c56393442b2e74fd4d870b0f96d49af913`

Run it and upload:
`frames-0.9.41-native-usb-storage-evidence-v48.zip`
