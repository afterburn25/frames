# Frames 0.0.88 — IOMMU Description Discovery

- Extends ACPI root-table inventory to detect Intel DMAR and AMD IVRS tables.
- Bounds and checksum-validates discovered IOMMU description tables before exposing their addresses.
- Records validated DMAR/IVRS pointers in the ACPI state and emits a diagnostic marker when present.
- Does not program DMA remapping, translation tables or interrupt remapping yet.
- Runtime/physical promotion remains BLOCKED.
