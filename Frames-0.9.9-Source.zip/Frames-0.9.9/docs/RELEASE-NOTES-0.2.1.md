# Frames 0.2.1 — FAT32 Boot Vnode Import

- Captures BOOTSTAT.TXT cluster and size during FAT32 discovery.
- Adds a 64-record vnode table.
- Imports root, Frames directory, System.fex, and BOOTSTAT.TXT as read-only vnodes.
- Records parent, kind, backend cluster, size, flags, and timestamp.
- Syscall 19 returns vnode count.
