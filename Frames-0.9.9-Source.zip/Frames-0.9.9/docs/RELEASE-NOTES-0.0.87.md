# Frames 0.0.87 — Kernel Heap Redzones & Canary Audit

- Reserves 16-byte redzones at both ends of the 16 KiB early kernel heap.
- Installs paired 64-bit canaries in both redzones.
- Restricts allocations to the interior usable range.
- Extends heap audit to reject boundary/canary corruption.
- Runtime/physical promotion remains BLOCKED.
