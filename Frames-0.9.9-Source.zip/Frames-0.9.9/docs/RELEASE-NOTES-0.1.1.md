# Frames 0.1.1 — SMAP-Aware User Copy

- Moves Frames to Nexus 5.15.0 with freestanding STAC/CLAC intrinsics.
- Detects SMAP with CPUID leaf 7 and enables CR4.SMAP only when supported.
- Brackets validated `copy_from_user` and `copy_to_user` accesses with STAC/CLAC when SMAP is active.
- Keeps the 4 KiB single-page validation cap and rejects non-user mappings before access.
- Runtime/physical certification remains BLOCKED.
