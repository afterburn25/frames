# Frames 0.0.47 — AHCI/SATA Read-Only Fallback Proof

- Enables PCI MMIO and bus mastering for the first AHCI controller.
- Enables AHCI mode and selects the first bounded active SATA port.
- Stops/starts the AHCI command engine with bounded waits.
- Allocates command list, received-FIS, command-table and DMA pages.
- Builds a one-entry PRDT and ATA READ DMA EXT command for LBA 0, one 512-byte sector.
- W/read bit remains clear; no ATA write command is implemented.
- Polls CI/TFES completion and records a deterministic checksum.
- Adds `FRAMES_AHCI_READ_OK`.

This is a structural diagnostic read proof, not a certified general AHCI block backend.
