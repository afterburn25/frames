# Frames 0.1.7 — Native Service Lifecycle & Heartbeats

- Adds explicit REGISTERED, RUNNING, and STOPPED service states.
- Adds start, stop, heartbeat, and active-count primitives.
- Starts the PID 1 System service.
- Executes a deterministic PID 2 start/heartbeat/stop self-test and leaves PID 2 stopped.
- Syscall 15 returns active service count.
