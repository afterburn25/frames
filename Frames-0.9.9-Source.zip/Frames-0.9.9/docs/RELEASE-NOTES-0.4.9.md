# Frames 0.4.9 — Bootstrap Display Core Gate

- Consolidates the GOP/software display lane behind nine required signals.
- Requires the earlier network/filesystem/userspace runtime chain before the display runtime marker can be earned.
- Requires rectangle rendering, dirty regions, software tile presentation, cursor metadata, output registry, topology, timing and presentation queue proofs.
- Adds `FRAMES_DISPLAY_CORE_OK` only when all nine signals are satisfied at runtime.
- Syscall 89 reports the display gate result to graphics-capable callers.
- GOP remains a bootstrap path; this release does not claim a production GPU driver, VSync or hardware acceleration.
