# Frames 0.5.1 — PCM Format & Frame Geometry

- Adds explicit PCM format state for 48 kHz, stereo, signed 16-bit little-endian frame geometry.
- Rejects zero/unsupported rate, channel, bit-width and frame-size combinations.
- Self-test verifies 4-byte stereo frame geometry.
- Syscall 97 returns configured sample rate.
- Format support is software metadata only; no audio controller is programmed.
