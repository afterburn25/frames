# Frames 0.5.6 — Audio Frame Clock Accounting

- Adds software audio frame-clock accounting tied to TSC samples without assuming a hardware sample clock.
- Tracks frame sequence, last TSC and accumulated frames.
- Self-test advances two 480-frame periods.
- Syscall 102 reports accumulated frames.
- No hardware timing interrupt or DMA position-buffer claim.
