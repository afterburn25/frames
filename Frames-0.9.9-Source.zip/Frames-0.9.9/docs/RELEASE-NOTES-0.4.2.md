# Frames 0.4.2 — Dirty Region Tracker

- Adds a 64-record dirty-region ring.
- Stores packed position/size, flags, sequence and timestamp.
- Coalesces an immediately repeated identical region by updating its flags/timestamp.
- Performs a deterministic two-region self-test.
- Syscall 82 reports current dirty-region count to graphics-capable callers.
