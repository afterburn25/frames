# Frames 0.0.58 — First USB Boot-HID Interrupt Report

- Posts one bounded Normal TRB on the configured boot-HID interrupt-IN Transfer Ring.
- Sets ISP and IOC for deterministic full/short packet completion reporting.
- Rings the device-slot doorbell for the discovered endpoint DCI.
- Validates Transfer Event slot, endpoint, completion code and residue.
- Captures one boot keyboard (minimum 8 bytes) or boot mouse (minimum 3 bytes) report and a deterministic checksum.
- Adds `FRAMES_USB_HID_REPORT_OK`.
- Keyboard and pointing gates advance from blocked to structural only; runtime hardware certification is still absent and physical boot remains BLOCKED.
