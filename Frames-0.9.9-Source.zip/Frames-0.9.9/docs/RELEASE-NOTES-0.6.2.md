# Frames 0.6.2 — Driver-to-Device Binding Policy

- Adds a 64-record binding table linking typed driver identities to matching device kinds.
- Binding is policy metadata only; it does not invoke hardware start callbacks.
- Bootstrap display virtual device can bind to the built-in display driver deterministically.
- Duplicate device bindings are rejected.
- Syscall 114 returns binding count.
