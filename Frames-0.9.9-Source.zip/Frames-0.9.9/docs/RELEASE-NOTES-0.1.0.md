# Frames 0.1.0 — Validated User-Copy Boundary

- Adds a four-level user page-table walk that requires Present+User at every paging level and rejects huge-page ambiguity.
- Adds bounded single-page `copy_from_user` and `copy_to_user` primitives capped at 4096 bytes.
- Write copies require a writable user PTE; the FEX code page is verified non-writable while the stack is verified writable.
- Records a user-copy contract audit before the ring-3 probe is eligible to run.
- SMAP remains disabled until the Nexus kernel profile has explicit STAC/CLAC support.
- Runtime/physical certification remains BLOCKED.
