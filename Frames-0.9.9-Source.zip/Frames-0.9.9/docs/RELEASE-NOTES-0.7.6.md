# Frames 0.7.6 — Trust-Domain Policy Metadata

- Adds 32 bounded trust-domain metadata records.
- Seeds one built-in Frames system trust domain and records Ed25519 as an allowed future signature algorithm identifier only.
- No public/private key bytes are fabricated or stored.
- External trust domains remain absent and therefore untrusted.
- Syscall 134 reports trust-domain count.
