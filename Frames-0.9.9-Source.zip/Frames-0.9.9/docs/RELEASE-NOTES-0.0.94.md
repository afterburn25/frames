# Frames 0.0.94 — Event & Wait Object Foundation

- Adds a bounded 64-object event table with owner, signal state and manual/auto-reset policy.
- Implements event signal, reset and non-blocking wait polling.
- Runs a deterministic signal/poll/reset kernel self-check and adds a typed event handle to Process 1.
- Scheduler-blocking waits are deliberately deferred.
- Syscall 6 reports event count. Runtime/physical certification remains BLOCKED.
