# Frames 0.1.8 — Validated FEX Image Registry

- Extracts FEX64 structural validation into a shared loader validator.
- Adds a bounded 64-image kernel-private FEX registry.
- Records size, entry/code offsets, code size, reference count, and first owner PID.
- PID 1 and PID 2 references to the same System.fex coalesce into one record with refcount 2.
- Syscall 16 exposes only the number of registered image identities.
