# Frames 0.0.89 — Pre-Certification Hardening Gate

- Consolidates six mandatory structural hardening signals: physical allocator ledger, supervisor-only inherited process mappings, user-stack guards, CR0.WP, kernel-heap canary audit, and DMA ownership audit.
- Records NX and SMEP as optional CPU-dependent signals.
- Produces a fail-closed in-memory hardening snapshot; it does not approve physical boot.
- IOMMU description discovery remains informational until translation is implemented.
- External QEMU/OVMF and physical-machine certification remain mandatory.
