# Frames 0.0.55 — USB Address State & Full Device Descriptor

- Converts bMaxPacketSize0 to the appropriate EP0 packet size for USB 2.x/3.x speed semantics.
- Updates the EP0 Input Context and issues Address Device with BSR=0.
- Adds a reusable bounded EP0 GET control-transfer helper.
- Retrieves and validates the complete 18-byte Device Descriptor.
- Captures VID, PID and configuration count.
- Adds `FRAMES_XHCI_ADDRESSED_OK` and `FRAMES_XHCI_DEVICE_DESCRIPTOR_OK`.
- Does not configure interfaces or claim HID input. Physical boot remains BLOCKED.
