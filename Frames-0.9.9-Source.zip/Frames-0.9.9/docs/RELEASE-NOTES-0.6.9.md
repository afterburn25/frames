# Frames 0.6.9 — Driver Platform Runtime Gate

- Adds a fail-closed driver platform gate.
- Requires the earlier audio/display runtime chain plus the driver-manager snapshot.
- Emits `FRAMES_DRIVER_PLATFORM_OK` only when that chain is genuinely satisfied at runtime.
- Adds marker to QEMU certification contract.
- Syscall 121 reports the gate to driver-capable callers.
- External driver loading remains disabled.
