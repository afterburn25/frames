# Frames 0.0.66 — Panic Snapshot Foundation

- Adds a bounded in-memory panic snapshot record containing reason, address, detail and TSC.
- The capture path is callable but not wired to force a new panic or persistence write.
- Adds `FRAMES_PANIC_SNAPSHOT_READY`. Physical boot remains BLOCKED.
