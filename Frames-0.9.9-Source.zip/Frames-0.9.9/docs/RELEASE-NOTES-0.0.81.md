# Frames 0.0.81 — Supervisor-Only Process Kernel Inheritance

- Hardens cloned process PML4 entries by clearing the U/S bit from every inherited kernel mapping.
- Audits the clone before Process 1 is accepted.
- The explicit user PML4 slot is still installed later by the FEX loader.
- Runtime/physical promotion remains BLOCKED pending external evidence.
