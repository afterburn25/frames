# Frames 0.0.95 — Shared Memory Ownership Objects

- Adds a bounded 32-object shared-memory table.
- Creates a zeroed one-page shared-memory object with owner, reference count and rights metadata.
- Gives Process 1 a typed shared-memory handle while keeping the physical page address kernel-private.
- Cross-process virtual mapping and user-copy APIs remain deliberately deferred.
- Syscall 7 reports object count. Runtime/physical certification remains BLOCKED.
