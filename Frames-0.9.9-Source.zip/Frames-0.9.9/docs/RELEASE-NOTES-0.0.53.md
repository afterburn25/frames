# Frames 0.0.53 — xHCI Address Device Context Foundation

- Detects xHCI context size (32/64 bytes).
- Allocates a page-contained Input Context, Output Device Context and EP0 transfer ring.
- Installs the Output Device Context in DCBAA[Slot ID].
- Sets Input Control Add flags A0/A1.
- Initializes Slot Context speed/root-port/context-entries fields.
- Initializes EP0 as Control with CErr=3, default speed-derived MPS, DCS=1, TR dequeue pointer and Average TRB Length=8.
- Issues Address Device with BSR=1 and validates the Command Completion Event.
- Adds `FRAMES_XHCI_DEFAULT_EP_READY`.

The device remains in USB Default state; descriptor reading is next.
