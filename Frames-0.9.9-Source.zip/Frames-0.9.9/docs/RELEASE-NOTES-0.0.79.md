# Frames 0.0.79 — External Runtime & Hardware Certification Candidate

- Packages the runtime preflight, QEMU firmware test, marker evidence importer, storage profile, and immutable evidence manifest into one external certification flow.
- A separate physical-machine certification record remains required before promotion.
- Current environment remains BLOCKED because QEMU/OVMF execution evidence is unavailable.
