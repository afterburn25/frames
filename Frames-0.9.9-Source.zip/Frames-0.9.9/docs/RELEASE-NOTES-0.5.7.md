# Frames 0.5.7 — Bounded Audio Event Ring

- Adds a 32-record bounded audio event ring for stream lifecycle/status events.
- Self-test emits START and STOP events for the software stream.
- Event records carry sequence, stream, kind and TSC only.
- Syscall 103 reports audio event count.
- No hardware interrupt is claimed.
