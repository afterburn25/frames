# Frames 0.8.0 — RAM-Only Update Transaction State

- Adds an in-memory update transaction state machine: IDLE, STAGED, VERIFIED, ABORTED.
- Transaction metadata includes generation, target version token, payload length and verification-required flags.
- No persistent storage write or update application path is introduced.
- Adds update/recovery syscall family 144–159 behind capability bit 512.
- Self-test stages then aborts a transaction; syscall 144 reports state.
