# Frames 0.0.51 — xHCI Runtime Event Ring & Root-Port Reset

- Maps/programs the xHCI runtime interrupter-0 ERST/ERDP state.
- Maps the doorbell register page for subsequent command submission.
- Discovers bounded root ports from HCSPARAMS1.
- Finds the first connected root port and performs a bounded Port Reset without clearing W1C status bits accidentally.
- Records the selected port and PortSC state.
- Adds `FRAMES_XHCI_PORT_READY`.

USB slot/address/device-descriptor work remains next.
