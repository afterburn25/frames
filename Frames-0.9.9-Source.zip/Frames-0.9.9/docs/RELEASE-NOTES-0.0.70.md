# Frames 0.0.70 — Runtime Certification Harness & External Promotion Gate

- Adds an explicit runtime preflight that discovers QEMU and OVMF availability and writes machine-readable certification state.
- Carries the QEMU/OVMF certification script forward as the required next execution gate.
- Does not convert source/structural verification into runtime certification.
- In the current build environment both QEMU and OVMF are unavailable, so VM runtime certification remains BLOCKED.
- Physical boot remains diagnostic-only and BLOCKED.
