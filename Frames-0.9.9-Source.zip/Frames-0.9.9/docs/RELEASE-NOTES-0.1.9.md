# Frames 0.1.9 — Native Userspace Platform Gate

- Adds a service-manager readiness snapshot over System/child service state, structured log, configuration, and FEX registry.
- Adds a fail-closed userspace platform gate requiring the runtime process-platform marker state plus user-copy, event-wait, child-FEX and service-manager readiness.
- Emits `FRAMES_USERSPACE_PLATFORM_OK` only if all required runtime and structural signals pass.
- Adds the new marker to the QEMU certification contract.
- No physical-boot approval is granted by this milestone.
