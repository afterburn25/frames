# Frames 0.7.4 — Sandbox Profile Registry

- Adds 16 sandbox profiles with capability, device, network and persistent-write policy fields.
- Default application profile has zero capabilities, no device access, no network access and no persistent-media write access.
- Profiles are metadata for future process launch enforcement; this milestone does not claim complete sandbox mediation.
- Syscall 132 reports sandbox self-test state.
