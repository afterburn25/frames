# Frames 0.0.93 — Process-Owned Thread Records

- Adds a bounded 64-record thread registry.
- Registers a Process 1 thread bound to the FEX entry point.
- Adds a dormant Process 2 thread record without making PID 2 runnable.
- Records TID, PID, state, entry, flags and creation timestamp.
- Syscall 5 reports thread count. Runtime/physical certification remains BLOCKED.
