# Frames 0.0.67 — Software Watchdog Heartbeat Foundation

- Adds a TSC-backed watchdog state, heartbeat counter and elapsed-time query.
- Deliberately does not reset/reboot the machine automatically.
- Adds `FRAMES_WATCHDOG_READY`. Hardware watchdog integration remains future work.
