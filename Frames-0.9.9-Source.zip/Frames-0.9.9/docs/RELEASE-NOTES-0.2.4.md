# Frames 0.2.4 — Virtual Device Namespace

- Adds 32-entry virtual device namespace.
- Registers null/pseudo, structured-log, storage-diagnostic and input identities when their backends exist.
- Device records expose kind/rights/status, not raw hardware addresses.
- Mounts devfs as a virtual VFS mount.
- Syscall 22 returns device-node count.
