# Frames 0.0.61 — ACPI S5 Sleep-Type Discovery

- Moves the Frames build to Nexus 5.12.0.
- Validates the DSDT header/checksum from FADT DSDT/X_DSDT.
- Adds a deliberately bounded AML scanner for a static root `_S5_` Name/Package object.
- Decodes only AML integer encodings needed for static SLP_TYPa/SLP_TYPb values and rejects values outside 0..7.
- Adds `FRAMES_ACPI_S5_READY`.
- Does not execute `_PTS`, arbitrary AML, or enter S5. Shutdown remains non-operational and physical boot remains BLOCKED.
