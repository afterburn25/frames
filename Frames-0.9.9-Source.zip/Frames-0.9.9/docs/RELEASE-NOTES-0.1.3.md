# Frames 0.1.3 — Prepared Child FEX Process

- Creates a dedicated child process-state page for PID 2.
- Reuses PID 2's isolated cloned PML4 and maps a separate copy of System.fex plus its own guarded user stack.
- Inherits CPU page-protection state and runs the same user-copy contract audit as Process 1.
- Updates the process registry to PREPARED and records the child state.
- PID 2 remains deliberately unscheduled, so no second-process execution claim is made.
- Runtime/physical certification remains BLOCKED.
