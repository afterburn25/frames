# Frames 0.0.62 — Bounded Legacy ACPI S5 Shutdown Primitive

- Uses Nexus 5.12.0 16-bit kernel port-I/O builtins.
- Validates legacy FADT PM1a/optional PM1b control-block ports and PM1 control length.
- Builds a 16-bit PM1 control value preserving unrelated fields while programming SLP_TYP and SLP_EN.
- Exposes callable `acpi_shutdown_execute`; it is never invoked automatically.
- Adds `FRAMES_ACPI_SHUTDOWN_READY`.
- Full AML execution such as `_PTS` is not implemented, so this remains a structural lab primitive, not production shutdown support. Physical boot remains BLOCKED.
