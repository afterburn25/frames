# Frames 0.3.0 — Packet Pool & Loopback Foundation

- Adds eight page-backed packet buffers with ownership/status accounting.
- Adds bounded packet allocate/release operations.
- Adds an internal loopback send path with TX/RX counters.
- Performs a deterministic in-kernel loopback payload self-test.
- No PCI NIC is initialized or programmed in this milestone.
- Syscall 28 returns loopback RX count.
