# Frames 0.0.46 — Read-Only Block Cache & Sequential Reader

- Adds a two-page bounded read cache over the read-only block interface.
- Tracks cache hits/misses and deterministic replacement.
- Adds bounded sequential multi-block reading with a streaming checksum.
- Exercises the cache against LBAs 0-1 during the diagnostic storage path.
- No storage write path exists.
