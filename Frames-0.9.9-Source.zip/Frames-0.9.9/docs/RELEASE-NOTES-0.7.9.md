# Frames 0.7.9 — Security Platform Runtime Gate

- Adds a fail-closed security platform gate.
- Requires the earlier driver/audio/display runtime chain plus the security-manager snapshot.
- Emits `FRAMES_SECURITY_PLATFORM_OK` only when genuinely satisfied at runtime.
- Adds the marker to QEMU certification contract.
- Syscall 137 reports gate state to security-capable callers.
- CSPRNG, kernel signature verification and persistent audit/update writes remain unimplemented.
