# Frames 0.4.0 — Bootstrap Display Surface Abstraction

- Adds a validated display-surface record for the UEFI GOP framebuffer.
- Tracks base, width, height, stride, pixel format, bootstrap flag and present count.
- Adds graphics capability bit 32 for syscall range 80-95.
- Process 1 still has capability mask 0, so graphics syscalls are denied by default.
- Syscall 80 reports display width only to graphics-capable callers.
- This milestone does not claim a native GPU driver or hardware acceleration.
