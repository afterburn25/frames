# Frames 0.5.5 — Software Audio Route Graph

- Adds 32 bounded software routes from stream IDs to logical output IDs.
- Route records carry enabled state and gain policy only.
- One Process-1 stream is routed to logical output 1 for deterministic self-test.
- No physical codec node/path is selected.
- Syscall 101 reports route count.
