Frames 0.9.9: Final Pre-1.0 Promotion Gate. Physical boot remains BLOCKED.
