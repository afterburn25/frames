# Frames 0.6.7 — Built-In Driver Trust Policy

- Adds a trust registry for the six built-in driver identities.
- Every built-in record is tagged kernel-builtin/trusted; no external publisher or signature is synthesized.
- External driver loading remains disabled and untrusted by default.
- Syscall 119 reports trusted built-in count.
