# Frames 0.0.73 — QEMU xHCI Keyboard & Mouse Certification Profiles

- Adds separate q35/xHCI USB keyboard and mouse runtime profiles.
- Boot media remains read-only during certification.
- Profiles produce serial evidence only; they do not approve physical boot themselves.
