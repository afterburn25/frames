# Frames 0.4.5 — Display Output Registry

- Adds a 16-output display registry.
- Registers the active GOP surface as a bootstrap output.
- Registers the first PCI display-controller BDF as a discovered candidate when present.
- Candidate status does not imply a native driver or modeset capability.
- Syscall 85 returns output count to graphics-capable callers.
