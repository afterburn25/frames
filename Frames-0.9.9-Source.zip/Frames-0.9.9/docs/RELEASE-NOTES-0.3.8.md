# Frames 0.3.8 — DHCP Codec & Client State

- Adds bounded DHCP client state.
- Builds a BOOTREQUEST/DHCPDISCOVER with deterministic xid, broadcast flag, chaddr, magic cookie and message-type option.
- Builds/parses a synthetic DHCPOFFER for 10.0.2.15.
- Validates xid, op, offered address, cookie and message type.
- Returns client state to INIT after codec self-test; no real lease is marked BOUND.
- Syscall 67 is network-capability-gated.
