# Frames 0.6.4 — Bounded Device Event Queue

- Adds a 64-record device/driver event ring.
- Events carry sequence, device ID, event kind and TSC.
- Self-test emits discovery/change events for the bootstrap device when present, otherwise a framework event.
- No hotplug interrupt ownership is claimed.
- Syscall 116 returns device-event count.
