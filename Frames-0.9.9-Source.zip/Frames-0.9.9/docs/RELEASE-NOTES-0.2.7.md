# Frames 0.2.7 — Filesystem Rights Metadata

- Adds a 64-record filesystem security metadata table.
- Records mount/object identity, owner id, rights and object kind.
- Seeds read-only boot objects, writable RAMFS test object, devfs null/log and procfs root.
- Access checks require requested rights to be a subset of granted rights.
- Self-test proves System.fex write denial and RAMFS write allowance.
- Syscall 25 returns security-record count.
