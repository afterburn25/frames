# Frames 0.0.60 — FADT Reset Register & Bounded Reboot Primitive

- Discovers the ACPI FADT reset capability only when RESET_REG_SUP is set.
- Validates a byte-wide, zero-bit-offset RESET_REG Generic Address Structure in System Memory or System I/O space.
- Captures RESET_VALUE and exposes a callable `acpi_reset_execute` primitive.
- The reboot primitive is never invoked automatically by this diagnostic build.
- Adds `FRAMES_ACPI_RESET_READY`.
- `power_reboot` advances to structural only; runtime reboot certification remains required. Physical boot remains BLOCKED.
