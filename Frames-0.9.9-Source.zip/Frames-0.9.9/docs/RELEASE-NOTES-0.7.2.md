# Frames 0.7.2 — Secret-Free Credential Object Registry

- Adds 32 credential identity objects containing only ID, owner, kind, flags, generation and timestamps.
- No password, hash, token, private key or plaintext secret material is stored by this milestone.
- Self-test creates one locked bootstrap credential identity.
- Syscall 130 reports credential-object count.
