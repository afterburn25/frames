# Frames 0.2.5 — Read-Only System Statistics Namespace

- Adds a 16-record read-only system statistics namespace.
- Snapshots process, thread, handle, service, syscall, physical-page, heap-allocation and DMA-record counts.
- Mounts the namespace as a read-only virtual VFS mount.
- No raw kernel pointers are published in statistic records.
- Syscall 23 returns statistic-record count.
