# Frames 0.9.3 — Stress & Fault-Test Plan State

- Adds eight required stress/fault categories: allocator, scheduler, storage-read, USB/input, network, display, recovery and power.
- Every test initializes as NOT-EXECUTED.
- Source builds cannot mark these categories passed.
- Syscall 161 reports required stress-test count.
