# Frames 0.0.91 — Typed Process Handle Table

- Adds a bounded 64-entry handle table for Process 1.
- Each handle records ID, object type, object reference, rights, live state and creation timestamp.
- Installs a self-process handle and provides type/rights-checked lookup.
- Syscall 3 exposes only the handle count, not kernel addresses.
- Runtime/physical certification remains BLOCKED.
