# Frames 0.4.7 — Frame Timing & Presentation Sequence

- Adds frame timing state with presentation sequence, current/previous TSC and delta.
- Presentation accounting is independent of any assumed refresh rate.
- Self-test records two presentation samples.
- This does not claim VSync or scanout interrupt ownership.
- Syscall 87 returns presentation sequence to graphics-capable callers.
