# Frames 0.4.3 — Offscreen Software Tile Compositor

- Allocates and verifies 16 contiguous 4 KiB pages for a 128x128x32bpp software tile.
- Adds tile fill and clipped tile-to-surface presentation.
- Presentation increments the surface present counter and adds a dirty-region record.
- Performs a deterministic pixel-copy self-test.
- Remains software-only; no GPU command submission is implemented.
