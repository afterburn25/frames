# Frames 0.0.98 — Process Resource Accounting

- Adds a per-process accounting snapshot for syscall count, capability denials, handles, processes, threads, events, shared-memory objects and IPC backlog.
- Includes physical-page allocation count, early-kernel-heap allocation count and DMA-page record count.
- Refreshes once during initialization and again after the ring-3 FEX probe returns.
- Syscall 10 returns the caller's syscall count and refreshes the snapshot first.
- Runtime/physical certification remains BLOCKED.
