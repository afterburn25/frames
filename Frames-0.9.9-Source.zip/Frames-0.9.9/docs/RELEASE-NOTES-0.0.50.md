# Frames 0.0.50 — xHCI Controller Reset & Ring Foundation

- Enables PCI MMIO/bus mastering for the first xHCI function.
- Performs bounded halt/reset/CNR waits and verifies 4 KiB page support.
- Allocates command ring, event ring, ERST and DCBAA pages.
- Installs a command-ring Link TRB with cycle/toggle-cycle semantics.
- Programs CRCR/DCBAAP/MaxSlots and starts the host controller.
- Adds `FRAMES_XHCI_RING_READY`.

No USB device is addressed yet and no HID input is claimed.
