# Frames 0.3.3 — IPv4 Header & Checksum Core

- Adds big-endian 32-bit network helpers.
- Adds a 20-byte IPv4 header checksum implementation.
- Builds a version-4/IHL-5 loopback IPv4 packet with 127.0.0.1 source/destination.
- Validates total length, protocol and complete-header checksum.
- Sends the test packet through internal loopback only.
