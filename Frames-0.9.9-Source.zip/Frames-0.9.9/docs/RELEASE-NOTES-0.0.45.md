# Frames 0.0.45 — Read-Only FAT32 Boot Volume Reader

- Validates the discovered ESP FAT32 BPB and bounds.
- Maps FAT/data regions and follows bounded FAT32 cluster chains.
- Finds the `FRAMES` root directory using the on-disk short entry.
- Finds `SYSTEM~1.FEX` and `BOOTSTAT.TXT` without writable mounting.
- Reads the first System.fex data block and validates the FEX64 magic.
- Adds `FRAMES_FAT32_OK` and `FRAMES_BOOT_FILES_OK`.
- No FAT or filesystem write path exists.
