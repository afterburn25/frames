# Frames 0.5.0 — Bounded Software PCM Buffer Pool

- Adds four page-backed software PCM buffers owned by the kernel allocator.
- Provides bounded scalar sample enqueue/dequeue accounting and a deterministic loopback self-test.
- Adds audio capability family bit 64 for syscalls 96–111; Process 1 remains capability-empty.
- Syscall 96 reports PCM buffer count to audio-capable callers.
- No HDA MMIO, codec verbs, DMA stream programming, or speaker output is claimed.
