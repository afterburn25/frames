# Frames 0.9.9 — Final Pre-1.0 Promotion Gate

- Adds the final pre-1.0 fail-closed promotion gate.
- Requires: recovery/update runtime chain PASS, all 8 external certification categories PASS, and all 8 stress/fault categories PASS.
- In this build those external/stress records intentionally initialize to zero passes, so promotion cannot occur from source checks alone.
- Emits `FRAMES_PRE1_PROMOTION_OK` only if all evidence exists; otherwise emits `FRAMES_PRE1_PROMOTION_BLOCKED`.
- Syscall 163 reports promotion state.
- Frames 1.0 is intentionally NOT declared by this release.

## Runtime certification handoff
- QEMU harness now attaches an explicit emulated XHCI controller plus USB boot keyboard.
- Optional OVMF VARS templates are copied to a per-run writable image.
- A GitHub Actions Ubuntu 24.04 runtime-certification workflow is included.
- Source builds prefer the bundled Nexus 5.15.0 toolchain when present.
