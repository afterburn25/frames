# Frames 0.5.9 — Audio Core Runtime Gate

- Adds a fail-closed audio core gate.
- Requires the earlier display runtime gate plus the eight-signal audio manager snapshot.
- Emits `FRAMES_AUDIO_CORE_OK` only when that runtime chain is genuinely satisfied.
- Adds the marker to the QEMU certification contract.
- Syscall 105 reports the audio core gate to audio-capable callers.
- Physical HDA controller/codec/stream output remains unimplemented and unclaimed.
