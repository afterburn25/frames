# Frames 0.0.76 — Immutable Runtime Evidence Manifest

- Adds SHA-256 and size manifests for imported runtime evidence.
- Keeps evidence provenance separate from source/build checks.
- No evidence file is treated as trusted merely because it exists.
