# Frames 0.2.6 — Canonical VFS Path Tokens

- Adds a 64-entry canonical path-token registry.
- Resolves stable namespace tokens to mount/object identities without exposing kernel pointers.
- Seeds boot root/Frames/System.fex/BOOTSTAT, RAMFS test, devfs null/log, and procfs root identities.
- Includes deterministic System.fex resolution self-test.
- Syscall 24 returns path-token count.
