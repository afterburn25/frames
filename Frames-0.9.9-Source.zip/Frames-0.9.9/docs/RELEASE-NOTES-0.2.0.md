# Frames 0.2.0 — Read-Only VFS Mount Foundation

- Adds a 32-entry VFS mount registry.
- Registers the validated FAT32 Frames boot volume as mount 1 when storage discovery succeeds.
- Mount records carry filesystem kind, backend state, flags, root object id, and timestamps.
- The FAT32 mount is explicitly read-only.
- Syscall 18 returns VFS mount count only.
