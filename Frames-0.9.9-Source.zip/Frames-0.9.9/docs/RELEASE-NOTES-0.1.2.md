# Frames 0.1.2 — Event Wait/Wake Records

- Adds a bounded 32-record wait table linked to event IDs and thread IDs.
- A pending wait moves the thread record to WAITING; event wake moves it back to READY.
- Runs a deterministic dormant-thread wait/signal/wake self-check and restores that thread to dormant state afterward.
- This is scheduler-visible state, not yet a context-switching blocking wait primitive.
- Syscall 11 reports wait-record count. Runtime/physical certification remains BLOCKED.
