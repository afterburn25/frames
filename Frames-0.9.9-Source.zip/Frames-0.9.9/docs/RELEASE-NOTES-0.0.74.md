# Frames 0.0.74 — Recovery & Power Runtime Evidence Policy

- Defines recovery runtime evidence requirements while requiring the physical-boot-blocked marker.
- Separates power discovery certification from destructive reboot/shutdown action tests.
- Automatic reboot and shutdown remain forbidden in the default certification profile.
