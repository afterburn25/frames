# Frames 0.4.1 — Clipped Software Rectangle Rendering

- Adds packed-coordinate clipped rectangle fills.
- Rejects empty/out-of-range surfaces and clips width/height at the framebuffer boundary.
- Uses the display-surface stride rather than assuming packed scanlines.
- Performs a deterministic small-rectangle pixel verification.
- Remains software-rendered over UEFI GOP; no GPU acceleration is claimed.
