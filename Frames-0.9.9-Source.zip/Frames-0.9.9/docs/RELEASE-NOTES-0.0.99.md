# Frames 0.0.99 — Pre-1.0 Process Platform Gate

- Consolidates nine process-platform signals: hardening gate, process registry, typed handles, thread registry, event self-test, shared-memory ownership, IPC self-test, resource accounting, and a successful runtime Syscall ABI 1.0 query.
- Emits `FRAMES_PROCESS_PLATFORM_OK` only when all nine signals pass at runtime.
- Adds this marker to the QEMU/runtime evidence contract.
- A version label cannot satisfy this gate; missing ring-3/runtime evidence leaves it failed.
- Physical boot remains explicitly BLOCKED until the separate runtime/hardware promotion system passes.
