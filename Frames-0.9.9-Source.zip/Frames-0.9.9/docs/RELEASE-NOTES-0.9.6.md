# Frames 0.9.6 — Pre-1.0 Readiness Snapshot

- Consolidates recovery/update chain state plus external certification and stress-plan execution counters.
- Snapshot is valid even when readiness is zero; it never converts unexecuted tests into passes.
- Records the current required/pass counts for diagnostics.
- Syscall 162 reports current readiness score.
