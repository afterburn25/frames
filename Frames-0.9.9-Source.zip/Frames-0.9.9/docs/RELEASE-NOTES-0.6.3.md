# Frames 0.6.3 — Driver Lifecycle State Machine

- Adds explicit REGISTERED, RUNNING and STOPPED lifecycle transitions for built-in software-safe drivers.
- Deterministic self-test transitions the loopback-network driver without touching PCI hardware.
- Hardware driver objects are not auto-started by this milestone.
- Syscall 115 returns lifecycle self-test state.
