# Frames 0.2.3 — Writable RAMFS Foundation

- Adds a bounded 32-file RAM-backed filesystem.
- Each file owns a zeroed physical page and tracks parent/name identity, size, capacity, flags, and timestamp.
- Adds create, scalar write, and scalar read primitives.
- Mounts RAMFS as a second VFS mount with writable-memory semantics.
- Performs a deterministic write/read self-test entirely in RAM.
- Persistent FAT32/NVMe/AHCI write paths remain absent.
