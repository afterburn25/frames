# Hardware readiness — Frames 0.0.53

Status: **PHYSICAL BOOT BLOCKED**

| Category | Status |
|---|---|
| UEFI x86-64 | structural build complete; runtime certification pending |
| ACPI/MADT | parser foundation implemented |
| SMP/APIC/I/O APIC | foundation implemented |
| PCI inventory | implemented |
| NVMe | reset/enable + admin SQ/CQ + Identify + namespace geometry + one I/O SQ/CQ pair + bounded one-block read implemented structurally; runtime certification pending; no write path |
| AHCI/SATA | read-only capability probe only |
| USB/xHCI | read-only capability probe only; HID not implemented |
| Keyboard/mouse HID | not implemented |
| Network | discovered only |
| Audio | discovered only |
| GPU acceleration | UEFI framebuffer only |
| Filesystem/VFS | not implemented; next storage step is bounded read-only GPT discovery |
| Power/reboot | not finalized |
| Recovery mode | not implemented |
| GUI | intentionally deferred until hardware gates improve |
