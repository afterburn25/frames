# Frames 0.5.3 — Bounded Audio Stream Registry

- Adds a 32-record audio stream registry with owner, format identity, state and frame counters.
- Creates one deterministic software playback stream for Process 1.
- No hardware stream descriptor or DMA engine is programmed.
- Syscall 99 reports stream count.
