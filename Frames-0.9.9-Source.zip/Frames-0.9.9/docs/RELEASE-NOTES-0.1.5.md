# Frames 0.1.5 — Structured Kernel & Service Log Ring

- Adds a bounded 96-record in-memory kernel/service log ring.
- Each record carries facility, code, scalar value, timestamp, and sequence.
- Exposes only the log count through syscall 13; raw kernel log memory is not exposed.
- No persistence writes are introduced.
- Physical boot remains diagnostic-only / BLOCKED pending runtime evidence.
