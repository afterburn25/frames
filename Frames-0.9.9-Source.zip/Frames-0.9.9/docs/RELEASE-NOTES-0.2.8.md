# Frames 0.2.8 — Filesystem Change Events

- Adds a 64-record filesystem event ring.
- Records operation, mount, object, sequence and timestamp.
- Emits deterministic RAMFS create/write events during self-test.
- Persistent boot-volume media remains read-only and emits no write events.
- Syscall 26 returns pending filesystem event count.
