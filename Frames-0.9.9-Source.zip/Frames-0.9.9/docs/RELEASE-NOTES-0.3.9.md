# Frames 0.3.9 — Networking Core Gate

- Consolidates filesystem/userspace readiness with loopback, Ethernet, IPv4, ICMP, ARP, UDP, DNS, TCP and DHCP-codec signals.
- Emits `FRAMES_NETWORK_CORE_OK` only when all ten required signals pass at runtime.
- The network capability remains default-deny for Process 1.
- Physical NIC TX/RX, real DHCP leasing, external DNS and real TCP peers remain unclaimed.
- Physical boot remains diagnostic-only / BLOCKED.
