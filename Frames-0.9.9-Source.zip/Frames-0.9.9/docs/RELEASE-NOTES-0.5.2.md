# Frames 0.5.2 — Deterministic Software Mixer

- Adds a software mixer with two bounded unsigned sample inputs and per-input gain percentages.
- Mix output is clamped to 16-bit range.
- Deterministic self-test mixes two midpoint values at 50/50 gain.
- Syscall 98 exposes mixer self-test state.
- This is a software arithmetic path only and does not imply audible output.
