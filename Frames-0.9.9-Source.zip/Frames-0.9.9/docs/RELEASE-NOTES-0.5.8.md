# Frames 0.5.8 — Software Audio Manager Snapshot

- Consolidates eight software/discovery audio signals into one manager snapshot.
- Requires PCM pool, format, mixer, stream, PCI-audio inventory, route, timing and event states.
- The inventory signal requires only a valid inventory object, not the presence of audio hardware.
- Syscall 104 returns manager pass state.
- This is not a hardware-audio certification.
