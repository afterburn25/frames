# Frames 0.9.0 — External Certification Requirement Matrix

- Adds eight explicit external certification requirement records: VM runtime, NVMe, AHCI, input, power, recovery, display and network.
- Every external status initializes to NOT-CERTIFIED; no result is inferred from source checks.
- Adds certification syscall family 160–175 behind capability bit 1024.
- Syscall 160 reports number of required external certification categories.
