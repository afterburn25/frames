# Frames 0.0.63 — Recovery Diagnostic State & Reason Codes

- Adds a kernel-owned recovery state block with bounded readiness flags and timestamps.
- Captures storage, input, and power readiness into a deterministic recovery snapshot/checksum.
- Adds a callable `recovery_request(reason)` path with bounded reason codes.
- Does not automatically enter recovery and performs no media or firmware writes.
- Adds `FRAMES_RECOVERY_READY` and `FRAMES_RECOVERY_REQUESTED`.
- `recovery_mode` advances to structural diagnostic state; runtime recovery UX remains unimplemented. Physical boot remains BLOCKED.
