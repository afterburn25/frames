# Frames 0.0.85 — DMA Ownership Ledger

- Adds a bounded 64-record DMA page ownership ledger.
- Routes NVMe queue/data pages, AHCI command/FIS/table/data pages, and xHCI ring/context/report pages through owner-tagged DMA allocation.
- Records physical page, size, owner class, state and allocation timestamp.
- Audits the bounded ledger before the final hardware preflight stage.
- No IOMMU programming is claimed yet. Runtime/physical promotion remains BLOCKED.
