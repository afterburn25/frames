# Frames 0.6.1 — Stable Device Identity Registry

- Adds a 64-record device registry independent of driver objects.
- Imports discovered PCI BDF/ID records for NVMe, AHCI, xHCI, network, display and audio when present.
- Always registers the validated bootstrap display surface as a virtual device identity when available.
- Device records expose identity metadata only; no new controller programming occurs.
- Syscall 113 returns device count.
