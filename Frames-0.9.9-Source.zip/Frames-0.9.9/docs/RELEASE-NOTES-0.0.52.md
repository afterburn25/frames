# Frames 0.0.52 — xHCI Enable-Slot Command & Completion Event

- Adds bounded command-ring producer state.
- Submits an xHCI Enable Slot Command TRB through doorbell 0.
- Polls the event ring with cycle-state handling.
- Decodes Command Completion Event type/completion-code/slot ID.
- Advances ERDP with Event Handler Busy acknowledgement.
- Records the allocated USB slot and adds `FRAMES_XHCI_SLOT_READY`.

Address Device and descriptor transfers remain deferred.
