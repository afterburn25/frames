# Frames 0.6.5 — Device Power-State Policy Metadata

- Adds per-device software power-state records with D0/D3-style policy values.
- Initializes all discovered devices to logical D0 and performs a metadata-only D3→D0 round trip on one record.
- Does not write PCI PMCSR, ACPI power resources, or controller power registers.
- Syscall 117 returns power-policy self-test state.
