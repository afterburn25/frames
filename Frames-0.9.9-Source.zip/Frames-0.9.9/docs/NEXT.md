Frames 1.0 is BLOCKED until VM runtime certification, required stress categories and physical hardware evidence are real—not inferred.
