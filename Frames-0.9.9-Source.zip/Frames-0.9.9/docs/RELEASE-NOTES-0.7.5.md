# Frames 0.7.5 — Bounded Security Audit Ring

- Adds a 64-record in-memory security audit ring.
- Records sequence, principal, event kind, result and TSC.
- Self-test records one allowed and one denied policy decision.
- Audit is volatile and is not yet persisted.
- Syscall 133 reports audit-record count.
