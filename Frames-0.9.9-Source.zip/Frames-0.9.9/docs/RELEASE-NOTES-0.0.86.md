# Frames 0.0.86 — Bounded Kernel Heap

- Reserves a verified four-page contiguous physical run from the Frames allocator.
- Adds a 16-byte-aligned, bounds-checked kernel bump allocator with allocation accounting.
- Zeroes all heap pages before use and audits the region geometry.
- Does not yet implement general free/reuse; this is an early deterministic kernel heap.
- Runtime/physical promotion remains BLOCKED.
