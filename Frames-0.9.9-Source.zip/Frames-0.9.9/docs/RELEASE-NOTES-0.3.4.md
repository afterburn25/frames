# Frames 0.3.4 — ICMP Echo Loopback Core

- Adds a bounded Internet checksum helper.
- Builds and validates an 8-byte ICMP Echo Request.
- Synthesizes an Echo Reply and recomputes/validates checksum.
- Exercises request and reply through internal loopback packet memory only.
- No external network transmission is claimed.
