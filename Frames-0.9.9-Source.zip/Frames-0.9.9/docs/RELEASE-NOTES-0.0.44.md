# Frames 0.0.44 — Read-Only Block Interface & GPT Boot-Volume Discovery

## Implemented
- Reusable read-only block-device wrapper over the 0.0.43 NVMe namespace Read path.
- Caller-supplied DMA page support for bounded block reads.
- GPT primary-header discovery at LBA 1.
- GPT signature, revision, size, disk-bound, usable-LBA and partition-array bound checks.
- IEEE CRC32 validation of the primary GPT header with the header CRC field zeroed during calculation.
- Streaming CRC32 validation of the complete bounded partition-entry array (up to 4096 entries, 1024-byte entries).
- EFI System Partition type-GUID discovery and usable-LBA validation.
- Serial milestones: `FRAMES_BLOCK_READ_OK`, `FRAMES_GPT_OK`, `FRAMES_BOOT_VOLUME_OK`.

## Safety gate
The implementation remains read-only. No GPT, partition, FAT, filesystem or namespace write operation exists. Runtime QEMU/OVMF and physical hardware certification remain required before promotion.
