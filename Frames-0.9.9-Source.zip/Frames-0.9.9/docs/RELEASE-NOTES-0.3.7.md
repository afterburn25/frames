# Frames 0.3.7 — TCP Connection State Foundation

- Adds a 32-record TCP connection table.
- Tracks local/remote ports, remote IPv4, sequence, acknowledgement, TX/RX accounting and timestamps.
- Adds CLOSED -> SYN-SENT -> ESTABLISHED -> FIN-WAIT -> CLOSED transition validation.
- Uses a synthetic loopback peer for deterministic state-machine proof only.
- Syscall 66 is network-capability-gated and returns connection count.
