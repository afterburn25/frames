# Frames 0.0.82 — User Stack Guard Pages

- Moves the initial Process 1 user stack to PT index 1.
- Leaves PT index 0 and PT index 2 unmapped as lower and upper guard pages.
- Adjusts the initial RSP to the top of the relocated mapped page.
- Audits both guard entries before userspace is accepted.
- Physical/runtime promotion remains BLOCKED.
