# Frames 0.3.1 — Ethernet II Core

- Adds big-endian 16-bit network field helpers.
- Builds and parses a bounded Ethernet II IPv4 frame.
- Validates source/destination MAC bytes, EtherType and payload identity.
- Sends the test frame through the internal loopback interface.
- Physical NIC transmit/receive remains unimplemented.
