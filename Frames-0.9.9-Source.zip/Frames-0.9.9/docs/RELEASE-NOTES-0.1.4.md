# Frames 0.1.4 — Native Service Registry

- Adds a bounded 32-record native Frames service registry.
- Registers PID 1 as the System service and PID 2 as a dormant child service identity.
- Records service ID, PID, status, kind, policy and lifecycle timestamp.
- Syscall 12 reports registered service count.
- This is service identity/lifecycle metadata; no claim of PID 2 execution is made.
- Runtime/physical certification remains BLOCKED.
