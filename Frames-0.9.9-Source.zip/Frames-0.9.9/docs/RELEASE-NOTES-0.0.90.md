# Frames 0.0.90 — Versioned Syscall ABI v1

- Moves Frames to Nexus 5.14.0's four-input/u64-return ring-3 syscall bridge.
- Defines syscall 0 as ABI query, returning `0x00010000` for ABI 1.0.
- Preserves syscall 2 as the controlled Process 1 exit path.
- The injected FEX return thunk queries ABI 1.0 and then exits, so runtime exit evidence also proves the query returned to ring 3.
- Records the most recent syscall number and three arguments in the process record.
- Runtime/physical certification remains BLOCKED until external evidence exists.
