# Frames 0.0.57 — Configured USB Boot-HID Interrupt Endpoint

- Translates USB polling intervals to xHCI Endpoint Context intervals.
- Builds a bounded Input Context with A0 plus the discovered interrupt-IN DCI.
- Copies the existing output Slot Context and raises Context Entries to the HID endpoint DCI.
- Creates an interrupt-IN Transfer Ring and valid disabled Endpoint Context.
- Issues Configure Endpoint and waits for Command Completion before USB SET_CONFIGURATION.
- Issues a no-data SET_CONFIGURATION control transfer and waits for its Transfer Event.
- Adds `FRAMES_USB_CONFIGURED_OK`.
- First configuration gate intentionally targets USB2-speed boot HID; SuperSpeed companion parsing remains future work.
- No input report has been consumed yet. Physical boot remains BLOCKED.
