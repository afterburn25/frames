# Frames 0.7.0 — Entropy Collection Boundary

- Adds a bounded boot-time seed mixer from TSC, CPUID identity data and ACPI pointer metadata when available.
- Explicitly records `cryptographic = false`; this is not a CSPRNG and is not used for key generation.
- Adds security syscall family 128–143 behind capability bit 256; Process 1 remains capability-empty.
- Syscall 128 reports source count.
