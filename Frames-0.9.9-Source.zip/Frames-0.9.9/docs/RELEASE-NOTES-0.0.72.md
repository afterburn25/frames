# Frames 0.0.72 — Read-Only Storage Runtime Certification Profile

- Adds an evidence profile for controller BAR, NVMe probe/admin/Identify/I/O queue and namespace Read milestones.
- Records that no write path is certified by this profile.
- Missing serial evidence remains BLOCKED rather than inferred from source gates.
