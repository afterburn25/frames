# Frames 0.0.56 — USB Configuration & Boot-HID Discovery

- Reads the 9-byte Configuration Descriptor header, validates wTotalLength and then retrieves the complete bounded configuration descriptor set.
- Walks Configuration/Interface/Endpoint descriptors without trusting descriptor lengths.
- Locates a USB HID boot-subclass keyboard or mouse interface and its first interrupt-IN endpoint.
- Captures configuration value, interface number, HID boot protocol, endpoint address/DCI, packet size, interval and USB2 high-bandwidth burst bits.
- Adds `FRAMES_USB_HID_FOUND`.
- Does not yet issue Configure Endpoint or SET_CONFIGURATION. Physical boot remains BLOCKED.
