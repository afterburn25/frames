# Frames 0.0.68 — Recovery/Power Action Coordinator

- Adds a bounded action queue for reboot, shutdown, or recovery requests.
- Execution is explicitly callable and never triggered automatically during boot.
- Adds `FRAMES_SYSTEM_ACTION_READY`. Physical boot remains BLOCKED.
