# Frames 0.4.8 — Bounded Software Presentation Queue

- Adds a 32-record in-kernel presentation command queue.
- Enqueue stores clipped presentation metadata only; it does not submit GPU commands.
- Batch flush consumes pending records and records one frame-timing presentation sequence for the batch.
- Deterministic self-test enqueues two records and verifies one batch flush.
- Syscall 88 exposes pending presentation count to graphics-capable callers.
- This does not claim VSync, hardware scanout scheduling, page flip ownership, or GPU acceleration.
