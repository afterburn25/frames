# Frames 0.6.0 — Typed Built-In Driver Registry

- Adds a 64-record typed built-in driver registry.
- Seeds NVMe, AHCI, xHCI, bootstrap display, software audio and loopback-network driver identities.
- Driver records contain ID, kind, trust class, lifecycle state and capability mask metadata.
- Third-party driver loading remains disabled.
- Adds driver/device syscall family 112–127 behind capability bit 128; Process 1 remains capability-empty.
- Syscall 112 returns driver count.
