# Frames 0.3.2 — ARP Cache & IPv4 Identity

- Adds a 32-record ARP cache.
- Tracks interface IPv4 identity and synthetic MAC identity separately from physical NIC discovery.
- Adds ARP insert/lookup and deterministic cache self-test.
- Uses loopback IPv4 127.0.0.1 as the active protocol-core identity.
- Syscall 30 returns ARP cache entry count.
