# Frames 0.0.84 — Supervisor Write Protect & SMEP

- Uses Nexus 5.13 control-register intrinsics.
- Sets and verifies CR0.WP so supervisor writes respect read-only page permissions.
- Detects SMEP with CPUID leaf 7 and sets CR4.SMEP only when supported.
- Deliberately defers SMAP until Frames has explicit safe user-copy primitives.
- Runtime/physical certification remains BLOCKED.
