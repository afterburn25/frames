# Frames 0.6.6 — Driver Fault & Quarantine Records

- Adds a 32-record bounded driver fault ledger with driver ID, reason, severity and TSC.
- Adds metadata-only quarantine state; it does not tear down hardware behind a running controller.
- Self-test records and clears a synthetic loopback-driver quarantine.
- Syscall 118 returns fault-record count.
