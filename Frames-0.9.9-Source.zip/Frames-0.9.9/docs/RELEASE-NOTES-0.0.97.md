# Frames 0.0.97 — Bounded Kernel IPC Queue

- Adds a 32-message ring queue with sender PID, receiver PID, scalar payload, sequence and timestamp.
- Implements bounded send/receive and wrap-around accounting.
- Runs a deterministic PID 1 → PID 2 scalar-message self-check at initialization.
- Does not copy arbitrary user buffers or expose kernel queue addresses.
- Syscall 9 reports pending message count. Runtime/physical certification remains BLOCKED.
