# Frames 0.7.7 — Secure Update Policy Boundary

- Adds update policy state requiring signature verification, rollback support and runtime certification before any production update path.
- Persistent-media write permission remains disabled in the policy.
- No update payload is applied by this milestone.
- Syscall 135 reports update-policy readiness.
