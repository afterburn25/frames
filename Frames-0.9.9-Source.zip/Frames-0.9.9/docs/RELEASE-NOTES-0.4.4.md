# Frames 0.4.4 — Software Cursor Plane State

- Adds software cursor-plane metadata with position, dimensions, visibility and movement count.
- Cursor moves are clipped to the active display surface.
- Cursor state is separated from HID report decoding.
- This milestone manages cursor geometry only; it does not claim a hardware cursor plane.
- Syscall 84 returns packed cursor position to graphics-capable callers.
