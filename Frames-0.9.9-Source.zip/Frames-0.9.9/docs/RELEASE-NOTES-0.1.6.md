# Frames 0.1.6 — In-Memory Configuration Registry

- Adds 64-entry numeric configuration registry.
- Records key, value, flags, update sequence, and timestamp.
- Seeds diagnostic boot policy and required hardware-gate mask.
- Exposes only configuration entry count through syscall 14.
- No storage persistence is enabled.
