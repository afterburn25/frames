# Frames 0.0.78 — Fail-Closed Runtime & Hardware Promotion Engine

- Requires both PASS runtime evidence and a PASS hardware certification record.
- Missing or malformed evidence remains BLOCKED.
- The decision engine cannot promote from source verification alone.
