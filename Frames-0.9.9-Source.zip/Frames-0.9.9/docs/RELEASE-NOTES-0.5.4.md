# Frames 0.5.4 — PCI HDA Candidate Inventory

- Adds read-only PCI metadata inventory for the first multimedia audio candidate.
- Validates PCI class 0x04 and records subclass/prog-if, BDF, vendor/device ID and BAR0 metadata.
- HDA-like subclass 0x03 is classified as a discovered candidate only.
- Does not map/program HDA registers, issue codec verbs, create BDL DMA, or start an output stream.
- Syscall 100 reports candidate classification.
