# Frames 0.0.96 — Syscall Capability Enforcement

- Adds fail-closed capability checks at the syscall dispatcher before privileged syscall families execute.
- Reserves capability bits for device, storage, system and boot service families.
- Process 1 currently starts with no privileged capability bits; unprivileged ABI/object queries remain available.
- Denials are counted and record the required capability without exposing kernel pointers.
- Syscall 8 reports the caller's capability mask. Runtime/physical certification remains BLOCKED.
