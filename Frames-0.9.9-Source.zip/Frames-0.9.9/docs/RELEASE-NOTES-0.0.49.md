# Frames 0.0.49 — Storage Diagnostics & Error Containment

- Adds bounded storage diagnostic state covering block, GPT and FAT32 readiness.
- Records read counts and block-layer errors without retry storms or media mutation.
- Adds a bounded sequential-reader limit and explicit diagnostic readiness score.
- Adds `FRAMES_STORAGE_DIAG_OK`.
- Completes the initial read-only storage foundation train; runtime certification remains outstanding.
