# Frames 0.0.43 — Bounded Read-Only NVMe Namespace Read

## Implemented
- Carries forward the complete 0.0.42 NVMe admin/Identify and namespace geometry stage.
- Negotiates one I/O SQ and one I/O CQ through Set Features / Number of Queues.
- Creates physically contiguous I/O Completion Queue 1 and I/O Submission Queue 1.
- Tracks independent I/O SQ tail, CQ head and completion phase state.
- Issues exactly one NVM Read for LBA 0 of the first active namespace in the milestone proof path.
- Uses a kernel-owned, page-aligned 4 KiB DMA buffer and rejects logical blocks larger than that bounded buffer.
- Rejects metadata-bearing selected LBA formats for this initial one-PRP proof.
- Validates completion phase, command identifier and completion status.
- Records read buffer, LBA, logical block count, byte count and deterministic checksum.
- Adds `FRAMES_NVME_IOQ_READY` and `FRAMES_NVME_READ_OK` serial milestones.
- Adds source gates that require the read path and reject any implemented namespace-write routine/marker.

## Safety / release gate
Frames 0.0.43 remains read-only. It does not mount a filesystem and implements no namespace media-write path. The storage read path is **structurally implemented**, not runtime-certified in this environment. Physical boot therefore remains explicitly **BLOCKED** and the image remains diagnostic-only.
