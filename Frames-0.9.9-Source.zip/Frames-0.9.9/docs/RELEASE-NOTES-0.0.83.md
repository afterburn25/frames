# Frames 0.0.83 — NX & Initial W^X Enforcement

- Detects AMD64/Intel execute-disable support through extended CPUID.
- Enables EFER.NXE only when supported and verifies the MSR state.
- Keeps the FEX code page user-readable/executable but non-writable.
- Marks the initial user stack writable but non-executable when NXE is available.
- Retains unmapped stack guard pages from 0.0.82.
- Runtime and physical promotion remain BLOCKED.
