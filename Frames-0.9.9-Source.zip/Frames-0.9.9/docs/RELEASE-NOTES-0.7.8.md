# Frames 0.7.8 — Security Manager Snapshot

- Consolidates eight security signals: entropy boundary, policy, credential identities, ACL, sandbox profiles, audit ring, trust-domain metadata and update policy.
- Manager snapshot does not upgrade non-cryptographic entropy into a CSPRNG and does not fabricate signing keys.
- Syscall 136 reports manager pass state.
