# Frames 0.8.9 — Recovery & Update Runtime Gate

- Adds a fail-closed recovery/update platform gate.
- Requires the earlier security/driver/audio/display runtime chain plus the recovery/update coordinator.
- Emits `FRAMES_RECOVERY_UPDATE_OK` only when genuinely satisfied at runtime.
- Adds marker to QEMU certification contract.
- Syscall 147 reports gate state.
- Persistent update apply, boot-variable mutation and automatic rollback remain disabled.
