# Frames 0.0.71 — Runtime Evidence Import & Marker Manifest

- Adds a machine-readable required serial-marker manifest grouped by subsystem.
- Adds an evidence importer that hashes serial logs and refuses promotion when evidence is missing/incomplete.
- Physical boot remains BLOCKED; no synthetic runtime PASS can be created from source verification.
