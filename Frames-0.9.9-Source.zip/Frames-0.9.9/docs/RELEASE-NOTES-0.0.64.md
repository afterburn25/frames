# Frames 0.0.64 — Boot Health Assessment

- Adds a deterministic pre-certification health score across storage, input, power and core runtime readiness.
- Records a safe-mode recommendation without changing boot flow.
- Adds `FRAMES_BOOT_HEALTH_OK`. Physical boot remains BLOCKED.
