# Frames 0.7.3 — Object ACL & Rights Checks

- Adds a 64-record ACL table with object, principal and rights mask metadata.
- Rights check is exact-mask bounded and deny-by-default when no matching record exists.
- Self-test grants read-only rights and proves write denial.
- Syscall 131 reports ACL self-test state.
