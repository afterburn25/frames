# Frames 0.4.6 — Display Topology Snapshot

- Adds display topology state with generation, output count, primary output and change count.
- GOP bootstrap output is the initial primary output.
- Topology refresh detects output-count changes and increments generation.
- No hardware hotplug interrupt is claimed; this is topology bookkeeping.
- Syscall 86 returns topology generation to graphics-capable callers.
