# Frames 0.2.2 — Read-Only Open File Objects

- Adds 64-entry open-file object table.
- Vnode state now retains FAT32 and block-device backend references.
- Adds bounded one-sector file reads from a vnode's first FAT32 cluster.
- Performs a deterministic System.fex read self-test and validates FEX64 magic.
- File offsets and per-open read accounting are tracked.
- No write operation exists for the FAT32-backed open-file path.
