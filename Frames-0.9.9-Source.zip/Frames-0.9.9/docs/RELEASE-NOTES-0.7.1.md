# Frames 0.7.1 — Fail-Closed Security Policy Registry

- Adds 32 bounded security policy rules.
- Seeds deny-external-driver, deny-persistent-media-write, require-signed-update and require-runtime-certification rules.
- No policy silently enables blocked hardware capabilities.
- Syscall 129 reports policy-rule count.
