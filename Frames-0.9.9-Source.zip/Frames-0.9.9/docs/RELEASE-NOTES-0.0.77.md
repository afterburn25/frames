# Frames 0.0.77 — Hardware Certification Record Schema

- Defines per-machine certification records with firmware/CPU/storage/USB/display identity.
- Requires an evidence-manifest SHA-256 for provenance.
- Enumerates the seven physical boot promotion gates explicitly.
