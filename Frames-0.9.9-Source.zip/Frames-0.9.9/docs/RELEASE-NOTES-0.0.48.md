# Frames 0.0.48 — Storage Device Identity & Registry

- Adds a kernel storage-device registry with stable driver-kind, BDF, vendor/device, namespace/port and geometry fields.
- Records NVMe namespace identity and AHCI port identity without media writes.
- Computes a deterministic storage topology fingerprint for diagnostics/reproducibility.
- Adds `FRAMES_STORAGE_REGISTRY_OK`.
