# Frames 0.3.6 — DNS Codec Foundation

- Builds a bounded DNS A query for `frames.local`.
- Builds and parses a deterministic synthetic A response for 127.0.0.1.
- Validates transaction id, flags, QD/AN counts and A-record address.
- Tracks query/answer codec counters.
- Syscall 65 is network-capability-gated and returns answer count.
- No external DNS server is contacted.
