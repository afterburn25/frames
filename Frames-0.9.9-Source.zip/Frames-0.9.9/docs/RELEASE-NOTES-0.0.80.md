# Frames 0.0.80 — Physical Memory Ownership Ledger

- Moves the kernel build to Nexus 5.13.0 with CR0/CR4 hardening intrinsics.
- Extends the physical-page allocator state with immutable initial range/page totals, last allocation, and allocation watermark.
- Adds a bounded allocator self-audit requiring free+used pages to match the initial page count and the cursor to remain inside the managed range.
- Emits `FRAMES_PHYS_LEDGER_OK` when the structural allocator ledger is consistent at runtime.
- This is pre-certification hardening; physical boot remains BLOCKED.
