# Frames 0.3.5 — UDP Sockets & Network Capability

- Adds network capability bit 16 for syscall range 64-79.
- Process 1 remains capability mask 0, so network syscalls are denied by default.
- Adds 32-entry UDP socket table with local port, state and TX/RX accounting.
- Builds/validates a bounded UDP loopback datagram on port 6060.
- Syscall 64 returns socket count only when the caller has network capability.
- No external NIC transmission is performed.
