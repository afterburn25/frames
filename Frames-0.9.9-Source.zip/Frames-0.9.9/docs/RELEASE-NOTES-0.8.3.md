# Frames 0.8.3 — Known-Good & Rollback Slot Metadata

- Adds two-slot known-good metadata with active slot, candidate slot, generation and boot-attempt counters.
- Rollback selection is an in-memory policy decision only.
- Self-test marks slot 1 known-good, proposes slot 2, records three failed attempts and selects slot 1.
- Does not modify GPT, filesystem contents, firmware variables or boot order.
- Syscall 145 reports selected recovery slot.
