# Frames 0.0.54 — USB Device Descriptor Control-Transfer Proof

- Builds directly on the 0.0.53 xHCI Default-state EP0 context.
- Submits a three-stage EP0 control transfer: Setup, IN Data, OUT Status.
- Requests the first 8 bytes of the USB Device Descriptor using GET_DESCRIPTOR.
- Polls xHCI Transfer Events and accepts Success or Short Packet completion for the bounded descriptor read.
- Validates descriptor length/type and captures bMaxPacketSize0.
- Adds `FRAMES_XHCI_DESCRIPTOR8_OK`.
- Does not configure a USB device or claim keyboard/mouse input. Physical boot remains BLOCKED.
