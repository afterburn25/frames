# Frames 0.0.75 — SMP, Ring-3 & FEX Runtime Evidence Profile

- Makes AP bring-up/SMP scheduling markers explicit certification inputs.
- Requires Process 1, address-space, ring-3 syscall/return and FEX load/exit evidence.
- Source verification cannot satisfy this runtime profile.
