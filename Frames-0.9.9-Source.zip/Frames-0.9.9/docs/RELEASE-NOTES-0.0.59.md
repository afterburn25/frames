# Frames 0.0.59 — Unified Early Input Event Queue

- Adds a 64-entry bounded kernel input event queue with overwrite-oldest containment.
- Decodes USB boot-keyboard modifier/key usage data into events.
- Decodes USB boot-mouse buttons and raw signed-byte X/Y payloads into events for later semantic translation.
- Adds a non-intrusive PS/2 output-buffer poll fallback; it does not reset or seize the controller.
- Adds `FRAMES_INPUT_QUEUE_OK`.
- Keyboard and pointing gates remain structural, not runtime-certified. Physical boot remains BLOCKED.
