# Frames 0.8.6 — Recovery & Update Action Coordinator

- Adds an in-memory recovery/update coordinator that reads transaction and known-good state.
- Produces a bounded recommended action code without executing reboot, shutdown, boot-variable changes or storage writes.
- Self-test recommends rollback after the synthetic failed candidate attempts.
- Syscall 146 reports recommended action.
