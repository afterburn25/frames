# Frames 0.0.92 — Process Registry & Dormant Child

- Adds a bounded 32-record process registry.
- Registers Process 1 and creates dormant PID 2 as a child of PID 1.
- PID 2 receives its own cloned PML4 with inherited kernel mappings forced supervisor-only.
- The child is deliberately not scheduled or given user code yet.
- Syscall 4 reports process count. Runtime/physical certification remains BLOCKED.
