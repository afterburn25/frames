#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n in ["fn init_storage_registry(","storage_identity_mix","serial_marker_storage_registry_ok","volatile_write64(rec+0,1)","volatile_write64(rec+0,2)"]:
    if n not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.48 storage registry source gates")
