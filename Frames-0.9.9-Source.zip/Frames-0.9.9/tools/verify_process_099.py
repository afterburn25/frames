#!/usr/bin/env python3
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); q=(r/'tools/qemu_certify.sh').read_text(); m=json.loads((r/'docs/HARDWARE-MATRIX.json').read_text())
for t in ['fn process_platform_gate','if score==9 { passed=1; }','volatile_read64(process+232)==65536','volatile_read64(ipc+56)==1','serial_marker_process_platform_ok','process_gate_ready=process_platform_gate']: assert t in s
assert 'FRAMES_PROCESS_PLATFORM_OK' in q
assert m['physical_boot_approved'] is False
print('PASS Frames 0.0.99 pre-1.0 process platform gate source gates')
