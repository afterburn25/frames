#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn fex_validate_image','if fex_validate_image(fex,fex_size)==0','fn fex_registry_init','fn fex_registry_register','count>=64','volatile_write64(rec+40,volatile_read64(rec+40)+1)','fex_registry_register(fex_state,fex,fsize,1)','volatile_read64(fex_state+8)!=1','volatile_read64(rec+40)!=2','volatile_write64(process_state+408,fex_state)','if number==16']:
 assert t in s,t
print('PASS Frames 0.1.8 FEX registry source gates')
