#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); b=(r/'tools/build.sh').read_text()
for t in ['fn kernel_user_syscall(number:u64,arg0:u64,arg1:u64,arg2:u64) -> u64','if number==0','return 65536','serial_marker_syscall_abi_ok','volatile_write64(process_state+224,arg2)','code_page+2064,205']: assert t in s
assert 'Nexus-Language-5.14.0' in b
print('PASS Frames 0.0.90 syscall ABI v1 source gates')
