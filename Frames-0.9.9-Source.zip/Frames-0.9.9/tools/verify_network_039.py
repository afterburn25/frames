#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); q=(r/'tools/qemu_certify.sh').read_text()
for t in ['fn network_core_gate','volatile_read64(fsg+24)==1','volatile_read64(net+40)==1','volatile_read64(net+64)==1','volatile_read64(arp+40)==1','volatile_read64(udp+32)==1','volatile_read64(dns+24)==1','volatile_read64(tcp+32)==1','volatile_read64(dhcp+32)==1','score==10','volatile_write64(process_state+608,network_gate_state)','network_gate_ready=network_core_gate','if number==68']:
 assert t in s,t
assert 'FRAMES_NETWORK_CORE_OK' in q
print('PASS Frames 0.3.9 network-core gate source gates')
