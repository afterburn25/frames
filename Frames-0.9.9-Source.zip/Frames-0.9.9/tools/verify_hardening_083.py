#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn enable_nx','cpuid_edx(2147483649,0)','read_msr(3221225600)','write_msr(3221225600,next)','9223372036854775808','code_page + 5','nx_ready=enable_nx(process_state)']: assert t in s
print('PASS Frames 0.0.83 NX/W^X source gates')
