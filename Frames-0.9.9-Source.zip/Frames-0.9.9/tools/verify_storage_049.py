#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n in ["fn init_storage_diagnostics(","serial_marker_storage_diag_ok","block_errors","score>=2"]:
    if n not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.49 storage diagnostics source gates")
