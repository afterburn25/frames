#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn present_queue_init','fn present_enqueue','count>=32','fn present_flush','frame_timing_present(timing,surface)','fn present_queue_selftest','present_flush(state,surface,timing)!=2','volatile_write64(process_state+672,presentation_state)','if number==88']:
 assert t in s,t
print('PASS Frames 0.4.8 presentation queue source gates')
