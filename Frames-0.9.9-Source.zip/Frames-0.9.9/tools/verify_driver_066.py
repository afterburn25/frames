#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn driver_faults_init', 'fn driver_fault_record', 'count>=32', 'driver_fault_selftest', 'volatile_write64(process_state+816,driver_fault_state)', 'if number==118']:assert t in s,t
print('PASS verify_driver_066.py source gates')
