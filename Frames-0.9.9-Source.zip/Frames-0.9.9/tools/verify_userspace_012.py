#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn wait_table_init','fn event_wait_register','volatile_write64(tr+16,2)','fn event_wake_waiters','volatile_write64(tr+16,1)','wait_table_selftest','volatile_write64(process_state+368,wait_state)','if number==11']: assert t in s
print('PASS Frames 0.1.2 wait/wake source gates')
