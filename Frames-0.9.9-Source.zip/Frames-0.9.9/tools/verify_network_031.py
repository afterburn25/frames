#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn net_write_be16','fn net_read_be16','fn ethernet_loopback_selftest','net_write_be16(page+12,2048)','volatile_write64(rec+16,22)','net_loopback_send(state,id)!=22','volatile_write64(state+48,1)','if number==29']:
 assert t in s,t
print('PASS Frames 0.3.1 Ethernet II source gates')
