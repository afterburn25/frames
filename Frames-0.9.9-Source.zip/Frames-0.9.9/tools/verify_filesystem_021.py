#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['bootstat_cluster=fat32_entry_cluster','volatile_write64(fat_state+128,bootstat_cluster)','fn vnode_table_init','fn vnode_add','fn vnode_set_size','fn vnode_import_boot','vnode_add(state,frames,1,volatile_read64(fat+96))','vnode_add(state,frames,1,volatile_read64(fat+128))','volatile_write64(process_state+472,vnode_state)','if number==19']:
 assert t in s,t
print('PASS Frames 0.2.1 FAT32 vnode import source gates')
