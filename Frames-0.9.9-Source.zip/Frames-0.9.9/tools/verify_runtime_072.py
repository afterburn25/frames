#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'tools/runtime_storage_cert.py').read_text()
for t in ['FRAMES_NVME_READ_OK','write_path_certified','STORAGE-RUNTIME-CERT.json','--require-pass']: assert t in s
print('PASS Frames 0.0.72 storage-runtime profile source gates')
