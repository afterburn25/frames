#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn arp_cache_init','volatile_write64(state+24,2130706433)','fn arp_cache_add','fn arp_cache_lookup','fn arp_cache_selftest','arp_cache_add(state,167772161,73588229205,1)','volatile_write64(process_state+568,arp_state)','if number==30']:
 assert t in s,t
print('PASS Frames 0.3.2 ARP/IPv4 identity source gates')
