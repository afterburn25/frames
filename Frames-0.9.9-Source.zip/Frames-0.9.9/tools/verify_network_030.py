#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn net_packet_pool_init','while i<8','alloc_phys_page(phys)','fn net_packet_alloc','fn net_packet_release','fn net_loopback_send','fn net_loopback_selftest','volatile_write64(state+40,1)','volatile_write64(process_state+552,network_state)','if number==28']:
 assert t in s,t
print('PASS Frames 0.3.0 packet pool/loopback source gates')
