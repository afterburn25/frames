#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn pre1_promotion_gate', 'score==3 && cert_pass==8 && stress_pass==8', 'serial_marker_pre1_promotion_blocked', 'volatile_write64(process_state+984,pre1_gate_state)', 'if number==163']:assert t in s,t
print('PASS verify_cert_099.py source gates')
