#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn event_table_init','fn event_create','fn event_signal','fn event_reset','fn event_wait_poll','fn event_selftest','volatile_write64(process_state+272,event_state)','handle_create(handle_state,3,eid,3)','if number==6']: assert t in s
print('PASS Frames 0.0.94 event object source gates')
