#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn certification_matrix_init', 'while i<8', 'volatile_write64(item+16,0)', 'number>=160 && number<=175', 'volatile_write64(process_state+960,certification_state)', 'if number==160']:assert t in s,t
print('PASS verify_cert_090.py source gates')
