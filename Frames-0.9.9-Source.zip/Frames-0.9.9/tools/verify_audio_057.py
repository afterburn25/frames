#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn audio_events_init', 'fn audio_event_emit', 'count>=32', 'audio_event_selftest', 'volatile_write64(process_state+744,audio_event_state)', 'if number==103']: assert t in s,t
print('PASS verify_audio_057.py source gates')
