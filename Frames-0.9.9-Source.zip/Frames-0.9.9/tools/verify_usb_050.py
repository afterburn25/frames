#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n in ["fn xhci_controller_init(","xhci_wait_halted","command_ring+4080","6147","volatile_write32(op+24","volatile_write32(op+48","serial_marker_xhci_ring_ready"]:
    if n not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.50 xHCI controller/ring source gates")
