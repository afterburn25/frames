#!/usr/bin/env python3
from pathlib import Path
import json, argparse, sys
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'docs/HARDWARE-MATRIX.json').read_text())
blocking={k:v for k,v in data['required_gates'].items() if v not in {'operational','certified'}}
approved=bool(data.get('physical_boot_approved')) and not blocking
lines=[f"Frames {data['version']} Physical Boot Gate", f"policy: {data['policy']}", f"decision: {'APPROVED' if approved else 'BLOCKED'}"]
for k,v in data['required_gates'].items(): lines.append(f"{k}: {v}")
report='\n'.join(lines)+'\n'
(ROOT/'build').mkdir(exist_ok=True); (ROOT/'build/BOOTSTAT.TXT').write_text(report)
print(report,end='')
parser=argparse.ArgumentParser(); parser.add_argument('--require-approved',action='store_true'); a=parser.parse_args()
if a.require_approved and not approved: sys.exit(2)
