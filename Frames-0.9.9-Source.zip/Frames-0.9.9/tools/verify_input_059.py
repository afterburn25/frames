#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n,t in {"queue":"fn input_queue_init","push":"fn input_push","keyboard":"input_push(input_state,1,key,1)","mouse":"input_push(input_state,5,0,volatile_read8(buffer+1))","ps2":"fn ps2_poll_fallback","marker":"serial_marker_input_queue_ok"}.items():
    if t not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.59 early input queue source gates")
