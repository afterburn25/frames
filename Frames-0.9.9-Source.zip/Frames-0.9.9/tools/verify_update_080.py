#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn update_transaction_init', 'fn update_transaction_stage', 'length>16777216', 'fn update_transaction_abort', 'number>=144 && number<=159', 'volatile_write64(process_state+928,update_transaction_state)', 'if number==144']:assert t in s,t
print('PASS verify_update_080.py source gates')
