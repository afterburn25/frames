#!/usr/bin/env python3
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]; s=(r/"kernel/main.nx").read_text(); m=json.loads((r/"docs/HARDWARE-MATRIX.json").read_text())
for t in ["fn hardware_gate_snapshot","serial_marker_hardware_gate_ready","volatile_write64(state+24,0)"]: assert t in s,t
assert m["physical_boot_approved"] is False
print("PASS Frames 0.0.69 hardware preflight source gates")
