#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn audio_routes_init', 'fn audio_route_add', 'count>=32', 'audio_route_selftest', 'volatile_write64(process_state+728,audio_route_state)', 'if number==101']: assert t in s,t
print('PASS verify_audio_055.py source gates')
