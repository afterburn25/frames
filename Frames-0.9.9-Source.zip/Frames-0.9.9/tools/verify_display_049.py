#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); q=(r/'tools/qemu_certify.sh').read_text()
for t in ['fn display_core_gate','let ngate=volatile_read64(process+608)','volatile_read64(surface+80)==1','volatile_read64(queue+56)==1','if score==9','serial_marker_display_core_ok','volatile_write64(process_state+680,display_gate_state)','if number==89']:
 assert t in s,t
assert 'FRAMES_DISPLAY_CORE_OK' in q
print('PASS Frames 0.4.9 display core gate source gates')
