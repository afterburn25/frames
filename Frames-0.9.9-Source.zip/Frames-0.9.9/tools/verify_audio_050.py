#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn audio_pcm_pool_init', 'while i<4', 'fn audio_pcm_selftest', 'volatile_write64(process_state+688,audio_pcm_state)', 'number>=96 && number<=111', 'if number==96']: assert t in s,t
print('PASS verify_audio_050.py source gates')
