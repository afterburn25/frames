#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn procfs_init','fn procfs_put','fn procfs_refresh','procfs_put(state,1,pc)','procfs_put(state,8,dma)','vfs_mount_register(vfs_state,4,procfs_state,1)','volatile_write64(process_state+512,procfs_state)','if number==23']:
 assert t in s,t
print('PASS Frames 0.2.5 procfs source gates')
