#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n in ["fn xhci_enable_slot(","(9*1024)+cycle","fn xhci_wait_command_completion(","typ==33","code==1","serial_marker_xhci_slot_ready"]:
    if n not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.52 xHCI enable-slot source gates")
