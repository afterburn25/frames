#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn driver_trust_init', 'count!=6', 'volatile_write64(trec+8,1)', 'volatile_write64(process_state+824,driver_trust_state)', 'if number==119']:assert t in s,t
print('PASS verify_driver_067.py source gates')
