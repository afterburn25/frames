#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n,t in {"dsdt":"fadt+140","checksum":"acpi_checksum(dsdt,dlen)","s5":"1597330271","pkg":"fn aml_pkg_length","integer":"fn aml_integer","marker":"serial_marker_acpi_s5_ready"}.items():
    if t not in s: raise SystemExit("FAIL "+n)
if "acpi_s5_discover(acpi_state,power_state)" not in s: raise SystemExit("FAIL call")
print("PASS Frames 0.0.61 ACPI S5 source gates")
