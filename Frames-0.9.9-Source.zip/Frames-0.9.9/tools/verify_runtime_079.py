#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'tools/external_certification.sh').read_text()
for t in ['--require-ready','qemu_certify.sh','--require-pass','evidence_manifest.py','Physical-machine record']: assert t in s
print('PASS Frames 0.0.79 external-certification candidate source gates')
