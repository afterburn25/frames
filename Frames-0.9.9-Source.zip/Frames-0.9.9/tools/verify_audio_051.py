#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn audio_format_init', 'rate!=48000', 'frame!=4', 'volatile_write64(process_state+696,audio_format_state)', 'if number==97']: assert t in s,t
print('PASS verify_audio_051.py source gates')
