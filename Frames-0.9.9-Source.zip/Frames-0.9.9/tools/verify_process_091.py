#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn handle_table_init','fn handle_create','fn handle_lookup','count>=64','volatile_write64(process_state+248,handle_state)','handle_create(handle_state,1,process_state,1)','if number==3']: assert t in s
print('PASS Frames 0.0.91 handle table source gates')
