#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn security_policy_init', 'volatile_write64(state+8,4)', 'volatile_write64(process_state+856,security_policy_state)', 'if number==129']:assert t in s,t
print('PASS verify_security_071.py source gates')
