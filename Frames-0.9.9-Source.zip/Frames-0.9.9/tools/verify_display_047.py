#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn frame_timing_init','fn frame_timing_present','if previous!=0 && now>=previous','volatile_write64(state+8,seq)','fn frame_timing_selftest','frame_timing_present(state,surface)!=2','volatile_write64(process_state+664,frame_timing_state)','if number==87']:
 assert t in s,t
print('PASS Frames 0.4.7 frame timing source gates')
