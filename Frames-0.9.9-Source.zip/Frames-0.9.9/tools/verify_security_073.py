#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn security_acl_init', 'fn security_acl_check', 'security_acl_check(state,1,1,2)!=0', 'volatile_write64(process_state+872,security_acl_state)', 'if number==131']:assert t in s,t
print('PASS verify_security_073.py source gates')
