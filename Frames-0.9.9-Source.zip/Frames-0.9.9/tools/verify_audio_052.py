#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn audio_mixer_init', 'fn audio_mix_pair', 'mixed>65535', 'audio_mix_pair(state,20000,20000)!=20000', 'volatile_write64(process_state+704,audio_mixer_state)', 'if number==98']: assert t in s,t
print('PASS verify_audio_052.py source gates')
