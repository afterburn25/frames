#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn update_policy_init', 'volatile_write64(state+8,1)', 'volatile_write64(state+32,0)', 'volatile_write64(process_state+904,update_policy_state)', 'if number==135']:assert t in s,t
print('PASS verify_security_077.py source gates')
