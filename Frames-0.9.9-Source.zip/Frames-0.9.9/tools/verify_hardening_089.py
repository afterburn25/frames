#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); m=(r/'docs/HARDWARE-MATRIX.json').read_text()
for t in ['volatile_write64(process_state+160,1)','fn hardening_gate_snapshot','if score==6 { passed=1; }','volatile_read64(process+168)','volatile_read64(process+184)','volatile_read64(heap+48)','volatile_read64(dma+24)','hardening_gate_ready=hardening_gate_snapshot']: assert t in s
assert '"physical_boot_approved": false' in m
print('PASS Frames 0.0.89 consolidated hardening gate source gates')
