#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,time
root=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser(); a.add_argument('--serial',default=str(root/'build/serial.log')); a.add_argument('--require-pass',action='store_true'); ns=a.parse_args()
path=Path(ns.serial); spec=json.loads((root/'docs/RUNTIME-MARKERS.json').read_text()); groups={k:v for k,v in spec.items() if k!='version'}
data={'frames_version':(root/'VERSION').read_text().strip(),'status':'BLOCKED','source':str(path),'source_sha256':None,'groups':{},'physical_boot_approved':False,'reasons':[]}
if not path.is_file(): data['reasons'].append('serial runtime evidence unavailable')
else:
 raw=path.read_bytes(); text=raw.decode('utf-8','replace'); data['source_sha256']=hashlib.sha256(raw).hexdigest()
 all_ok=True
 for name,req in groups.items():
  missing=[m for m in req if m not in text]; passed=not missing; data['groups'][name]={'pass':passed,'missing':missing}; all_ok=all_ok and passed
 if all_ok: data['status']='PASS'
 else: data['reasons'].append('one or more required runtime marker groups failed')
(root/'build').mkdir(exist_ok=True); (root/'build/RUNTIME-EVIDENCE.json').write_text(json.dumps(data,indent=2)+'\n'); print(json.dumps(data,indent=2))
if ns.require_pass and data['status']!='PASS': raise SystemExit(2)
