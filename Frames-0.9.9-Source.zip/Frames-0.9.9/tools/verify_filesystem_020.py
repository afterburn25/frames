#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn vfs_mount_init','fn vfs_mount_register','count>=32','vfs_mount_register(vfs_state,1,fat_state,1)','volatile_write64(process_state+464,vfs_state)','if number==18']:
 assert t in s,t
seg=s[s.index('fn vfs_mount_init'):s.index('fn serial_marker_fat32_ok')]
for bad in ['block_write','nvme_write','ahci_write']: assert bad not in seg
print('PASS Frames 0.2.0 read-only VFS mount source gates')
