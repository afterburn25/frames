#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn pre1_readiness_snapshot', 'if cert_pass==8', 'if stress_pass==8', 'volatile_write64(state+16,3)', 'volatile_write64(process_state+976,pre1_snapshot_state)', 'if number==162']:assert t in s,t
print('PASS verify_cert_096.py source gates')
