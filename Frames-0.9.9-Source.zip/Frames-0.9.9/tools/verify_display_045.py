#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn display_outputs_init','volatile_write64(state+8,1)','volatile_write64(rec+8,1)','volatile_write64(rec+16,2)','volatile_read64(hardware+48)>0','volatile_write64(rec+8,2)','volatile_write64(rec+16,1)','volatile_write64(process_state+648,output_state)','if number==85']:
 assert t in s,t
print('PASS Frames 0.4.5 output registry source gates')
