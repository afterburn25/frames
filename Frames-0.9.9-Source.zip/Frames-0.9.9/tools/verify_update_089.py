#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn recovery_update_gate', 'volatile_read64(process+920)', 'volatile_read64(process+944)', 'if score==2', 'volatile_write64(process_state+952,recovery_update_gate_state)', 'if number==147']:assert t in s,t
print('PASS verify_update_089.py source gates')
