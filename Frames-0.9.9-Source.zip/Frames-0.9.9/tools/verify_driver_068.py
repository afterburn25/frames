#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn driver_manager_snapshot', 'if score==8', 'volatile_read64(process+824)', 'volatile_write64(process_state+832,driver_manager_state)', 'if number==120']:assert t in s,t
print('PASS verify_driver_068.py source gates')
