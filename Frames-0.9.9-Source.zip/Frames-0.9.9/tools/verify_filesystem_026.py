#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn path_table_init','fn path_add','fn path_resolve','fn path_seed','path_add(state,3,1,3)','path_add(state,101,2,1)','path_add(state,201,3,2)','path_add(state,300,4,0)','path_resolve(state,3)!=(1*65536)+3','volatile_write64(process_state+520,path_state)','if number==24']:
 assert t in s,t
print('PASS Frames 0.2.6 path resolution source gates')
