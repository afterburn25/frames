#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json
root=Path(__file__).resolve().parents[1]; a=argparse.ArgumentParser(); a.add_argument('--serial',default=str(root/'build/serial.log')); a.add_argument('--require-pass',action='store_true'); n=a.parse_args(); p=Path(n.serial)
req=['FRAMES_CONTROLLER_BAR_OK','FRAMES_NVME_PROBE_OK','FRAMES_NVME_ADMIN_READY','FRAMES_NVME_IDENTIFY_OK','FRAMES_NVME_IOQ_READY','FRAMES_NVME_READ_OK']
data={'frames_version':(root/'VERSION').read_text().strip(),'profile':'storage-nvme-read-only','status':'BLOCKED','sha256':None,'missing':req,'write_path_certified':False}
if p.is_file():
 raw=p.read_bytes(); t=raw.decode('utf-8','replace'); data['sha256']=hashlib.sha256(raw).hexdigest(); data['missing']=[x for x in req if x not in t]; data['status']='PASS' if not data['missing'] else 'FAIL'
(root/'build/STORAGE-RUNTIME-CERT.json').write_text(json.dumps(data,indent=2)+'\n'); print(json.dumps(data,indent=2))
if n.require_pass and data['status']!='PASS': raise SystemExit(2)
