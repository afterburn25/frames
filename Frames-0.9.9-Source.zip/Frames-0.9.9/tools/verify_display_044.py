#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn cursor_init','fn cursor_move','if x>=width { x=width-1; }','if y>=height { y=height-1; }','fn cursor_selftest','volatile_read64(state+48)!=2','volatile_write64(process_state+640,cursor_state)','if number==84']:
 assert t in s,t
print('PASS Frames 0.4.4 cursor-plane source gates')
