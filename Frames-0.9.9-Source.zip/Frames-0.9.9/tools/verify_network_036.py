#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn dns_build_query','volatile_write8(buffer+12,6)','fn dns_build_test_response','net_write_be16(buffer+2,33152)','net_write_be32(buffer+42,2130706433)','fn dns_parse_test_response','fn dns_selftest','volatile_write64(process_state+584,dns_state)','if number==65']:
 assert t in s,t
print('PASS Frames 0.3.6 DNS codec source gates')
