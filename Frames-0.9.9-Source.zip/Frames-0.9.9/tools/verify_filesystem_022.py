#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn vnode_find','fn open_file_init','fn file_open','fn file_find','fn file_read_sector','sector>=spc','block_read(block,lba,out)','file_open(open_file_state,vnode_state,3,1)','volatile_read64(read_page)!=224250053958','volatile_write64(process_state+480,open_file_state)','if number==20']:
 assert t in s,t
seg=s[s.index('fn open_file_init'):s.index('fn serial_marker_vfs_mount_ok')]
for bad in ['block_write','nvme_write','ahci_write']: assert bad not in seg
print('PASS Frames 0.2.2 read-only open-file source gates')
