#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn device_record_add', 'fn device_registry_init', 'device_record_add(state,7,0', 'volatile_write64(process_state+776,device_object_state)', 'if number==113']:assert t in s,t
print('PASS verify_driver_061.py source gates')
