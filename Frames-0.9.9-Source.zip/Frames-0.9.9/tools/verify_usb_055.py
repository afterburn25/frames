#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n,t in {"mps":"fn usb_ep0_packet_bytes","generic control":"fn xhci_control_get","address BSR0":"xhci_command_submit_address(xhci_state,input,slot,0)","full descriptor":"5066549597570688","vid":"volatile_read8(full+8)","address marker":"serial_marker_xhci_addressed_ok","device marker":"serial_marker_xhci_device_descriptor_ok"}.items():
    if t not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.55 USB address/full descriptor source gates")
