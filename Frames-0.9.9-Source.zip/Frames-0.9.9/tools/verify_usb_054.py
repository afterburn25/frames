#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
checks={
"transfer event":"fn xhci_wait_transfer_event",
"get descriptor8":"fn xhci_get_device_descriptor8",
"setup trb":"2251799830464128",
"transfer event type":"typ==32",
"descriptor marker":"FRAMES_XHCI_DESCRIPTOR8_OK" if False else "serial_marker_xhci_descriptor8_ok",
"descriptor validation":"dtype!=1",
}
for n,t in checks.items():
    if t not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.54 USB Device Descriptor control-transfer source gates")
