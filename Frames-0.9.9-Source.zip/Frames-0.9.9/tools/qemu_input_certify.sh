#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; QEMU="${QEMU:-qemu-system-x86_64}"; OVMF_CODE="${OVMF_CODE:-}"; MODE="${1:-keyboard}"; LOG="$ROOT/build/input-${MODE}.serial.log"
command -v "$QEMU" >/dev/null || { echo 'qemu unavailable' >&2; exit 2; }; [[ -f "$OVMF_CODE" ]] || { echo 'OVMF unavailable' >&2; exit 2; }
case "$MODE" in keyboard) USB='usb-kbd';; mouse) USB='usb-mouse';; *) echo 'mode must be keyboard or mouse' >&2; exit 2;; esac
"$ROOT/tools/build.sh"; python3 "$ROOT/tools/make_esp.py"; rm -f "$LOG"
set +e; timeout "${FRAMES_BOOT_TIMEOUT:-20}" "$QEMU" -machine q35 -m 512M -smp 2 -cpu max -display none -serial file:"$LOG" -no-reboot -no-shutdown -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" -drive if=none,id=framesnvme,format=raw,readonly=on,file="$ROOT/build/Frames-$(cat "$ROOT/VERSION")-ESP.img" -device nvme,serial=FRAMESINPUT,drive=framesnvme -device qemu-xhci,id=xhci -device "$USB",bus=xhci.0; rc=$?; set -e
[[ -f "$LOG" ]] || exit 1
grep -Fq FRAMES_KERNEL_READY "$LOG" || exit 1
grep -Fq FRAMES_XHCI_PROBE_OK "$LOG" || exit 1
printf 'Frames input profile %s produced serial evidence (qemu rc=%s)\n' "$MODE" "$rc"
