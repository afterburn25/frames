#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n,t in {"state":"fn recovery_init","request":"fn recovery_request","checksum":"fn recovery_snapshot_checksum","marker":"serial_marker_recovery_ready","allocation":"let recovery_state = bump_alloc"}.items():
    if t not in s: raise SystemExit("FAIL "+n)
if "recovery_request(recovery_state" in s: raise SystemExit("FAIL automatic recovery request")
print("PASS Frames 0.0.63 recovery source gates")
