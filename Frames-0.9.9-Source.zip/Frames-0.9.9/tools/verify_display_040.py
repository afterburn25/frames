#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn display_surface_init','info.framebuffer_stride<info.framebuffer_width','volatile_write64(state+48,1)','number>=80 && number<=95 { return 32; }','volatile_write64(process_state+616,display_state)','if number==80']:
 assert t in s,t
print('PASS Frames 0.4.0 display-surface source gates')
