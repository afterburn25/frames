#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'tools/evidence_manifest.py').read_text()
for t in ['sha256','size','EVIDENCE-MANIFEST.json']: assert t in s
print('PASS Frames 0.0.76 evidence-manifest source gates')
