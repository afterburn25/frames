#!/usr/bin/env python3
from pathlib import Path
import struct, hashlib, zlib, sys
ROOT=Path(__file__).resolve().parents[1]
EXPECTED_ABI=int((ROOT/'KERNEL_ABI').read_text().strip())
VER=(ROOT/'VERSION').read_text().strip()
EFI=ROOT/'build/BOOTX64.EFI'; FKRN=ROOT/'build/FramesKernel.fkrn'; FEX=ROOT/'build/System.fex'; IMG=ROOT/f'build/Frames-{VER}-ESP.img'

def ok(x,msg):
    if not x: raise SystemExit('FAIL: '+msg)
    print('PASS:',msg)

# PE32+ EFI validation
pe=EFI.read_bytes(); ok(pe[:2]==b'MZ','BOOTX64.EFI DOS/PE signature')
peoff=struct.unpack_from('<I',pe,0x3c)[0]; ok(pe[peoff:peoff+4]==b'PE\0\0','BOOTX64.EFI PE signature')
machine,nsects=struct.unpack_from('<HH',pe,peoff+4); ok(machine==0x8664,'BOOTX64.EFI machine x86-64')
opt=peoff+24; magic=struct.unpack_from('<H',pe,opt)[0]; ok(magic==0x20b,'BOOTX64.EFI PE32+')
subsystem=struct.unpack_from('<H',pe,opt+68)[0]; ok(subsystem==10,'BOOTX64.EFI subsystem EFI application')
num_dirs=struct.unpack_from('<I',pe,opt+108)[0]; ok(num_dirs>=6,'BOOTX64.EFI data directories present')
import_rva,import_sz=struct.unpack_from('<II',pe,opt+112+8); ok(import_rva==0 and import_sz==0,'BOOTX64.EFI has no host imports')
reloc_rva,reloc_sz=struct.unpack_from('<II',pe,opt+112+8*5); ok(reloc_rva!=0 and reloc_sz>=8,'BOOTX64.EFI has base relocations')

# FKRN64 validation
k=FKRN.read_bytes(); ok(k[:8]==b'FKRN64\0\0','FramesKernel FKRN64 magic')
vals=struct.unpack_from('<8sHHHHIIQQQQQQ32s16s',k,0)
_,ver,hsize,arch,flags,abi,nir,entry,code_off,code_sz,meta_off,meta_sz,reserved,digest,bid=vals
ok(ver==1 and hsize==160,'FramesKernel FKRN64/1 header')
ok(arch==1 and abi==EXPECTED_ABI and nir==3,f'FramesKernel x86-64 Frames ABI {EXPECTED_ABI} NIR3')
ok(entry<code_sz and code_off+code_sz<=len(k) and meta_off+meta_sz<=len(k),'FramesKernel section bounds')
calc=hashlib.sha256(k[code_off:code_off+code_sz]+k[meta_off:meta_off+meta_sz]).digest(); ok(calc==digest,'FramesKernel SHA-256 payload integrity')


# System.fex FEX64 validation
f=FEX.read_bytes(); ok(f[:8]==b'FEX64\0\0\0','System.fex FEX64 magic')
fv=struct.unpack_from('<8sHHHHIIQQQQQQ32s',f,0)
_,fver,fhsize,farch,fflags,fabi,fnir,fentry,fcode_off,fcode_sz,fmeta_off,fmeta_sz,freserved,fdigest=fv
ok(fver==1 and fhsize==128,'System.fex FEX64/1 header')
ok(farch==1 and fabi==1 and fnir==3,'System.fex x86-64 Frames ABI 1 NIR3')
ok(fentry<fcode_sz and fcode_off+fcode_sz<=len(f) and fmeta_off+fmeta_sz<=len(f),'System.fex section bounds')
fcalc=hashlib.sha256(f[fcode_off:fcode_off+fcode_sz]+f[fmeta_off:fmeta_off+fmeta_sz]).digest(); ok(fcalc==fdigest,'System.fex SHA-256 payload integrity')

# GPT validation
d=IMG.read_bytes(); sec=512; ok(len(d)==64*1024*1024,'ESP disk image is 64 MiB')
ok(d[510:512]==b'\x55\xaa','protective MBR signature')
h=d[sec:2*sec]; ok(h[:8]==b'EFI PART','primary GPT signature')
hsize=struct.unpack_from('<I',h,12)[0]; stored=struct.unpack_from('<I',h,16)[0]; tmp=bytearray(h[:hsize]); struct.pack_into('<I',tmp,16,0); ok((zlib.crc32(tmp)&0xffffffff)==stored,'primary GPT header CRC')
entries_lba,num_entries,entry_sz,entries_crc=struct.unpack_from('<QIII',h,72); entries=d[entries_lba*sec:entries_lba*sec+num_entries*entry_sz]; ok((zlib.crc32(entries)&0xffffffff)==entries_crc,'GPT partition-array CRC')
first,last=struct.unpack_from('<QQ',entries,32); ok(first==2048 and last>=first,'Frames ESP partition location')

# FAT32 + directory/file validation
base=first*sec; bpb=d[base:base+sec]; ok(bpb[510:512]==b'\x55\xaa','FAT32 boot-sector signature')
bps=struct.unpack_from('<H',bpb,11)[0]; spc=bpb[13]; rsv=struct.unpack_from('<H',bpb,14)[0]; nf=bpb[16]; fatsz=struct.unpack_from('<I',bpb,36)[0]; root=struct.unpack_from('<I',bpb,44)[0]
ok(bps==512 and spc==1 and nf==2 and root==2,'FAT32 BPB geometry')
data_sector=rsv+nf*fatsz
fat=d[base+rsv*sec:base+(rsv+fatsz)*sec]
def nxt(c): return struct.unpack_from('<I',fat,c*4)[0]&0x0fffffff
def cluster(c):
    off=base+(data_sector+(c-2)*spc)*sec; return d[off:off+spc*sec]
def file_chain(start,size):
    out=bytearray(); c=start; seen=set()
    while c<0x0ffffff8 and c>=2 and c not in seen:
        seen.add(c); out+=cluster(c); c=nxt(c)
    return bytes(out[:size])
def parse_dir(c):
    raw=cluster(c); out=[]; lfn=[]
    for i in range(0,len(raw),32):
        e=raw[i:i+32]
        if e[0]==0: break
        if e[0]==0xe5: lfn=[]; continue
        if e[11]==0x0f:
            chars=[]
            for off,count in ((1,5),(14,6),(28,2)):
                for j in range(count):
                    v=struct.unpack_from('<H',e,off+j*2)[0]
                    if v not in (0,0xffff): chars.append(chr(v))
            lfn.insert(0,''.join(chars)); continue
        short=(e[:8].decode('ascii').rstrip()+('.'+e[8:11].decode('ascii').rstrip() if e[8:11].strip() else ''))
        name=''.join(lfn) if lfn else short; lfn=[]
        cl=(struct.unpack_from('<H',e,20)[0]<<16)|struct.unpack_from('<H',e,26)[0]; size=struct.unpack_from('<I',e,28)[0]
        out.append((name,e[11],cl,size))
    return out
root_entries=parse_dir(root); efi_dir=next((x for x in root_entries if x[0].upper()=='EFI'),None); frames_dir=next((x for x in root_entries if x[0].upper()=='FRAMES'),None)
ok(efi_dir is not None and frames_dir is not None,'ESP root contains EFI and Frames directories')
boot_dir=next((x for x in parse_dir(efi_dir[2]) if x[0].upper()=='BOOT'),None); ok(boot_dir is not None,'ESP contains EFI/BOOT')
boot_file=next((x for x in parse_dir(boot_dir[2]) if x[0].upper()=='BOOTX64.EFI'),None); ok(boot_file is not None,'ESP contains EFI/BOOT/BOOTX64.EFI')
kern_file=next((x for x in parse_dir(frames_dir[2]) if x[0]=='FramesKernel.fkrn'),None); ok(kern_file is not None,'ESP contains long filename Frames/FramesKernel.fkrn')
system_file=next((x for x in parse_dir(frames_dir[2]) if x[0]=='System.fex'),None); ok(system_file is not None,'ESP contains Frames/System.fex')
stat_file=next((x for x in parse_dir(frames_dir[2]) if x[0].upper()=='BOOTSTAT.TXT'),None); ok(stat_file is not None,'ESP contains Frames/BOOTSTAT.TXT')
ok(file_chain(boot_file[2],boot_file[3])==pe,'ESP BOOTX64.EFI matches release binary byte-for-byte')
ok(file_chain(kern_file[2],kern_file[3])==k,'ESP FramesKernel.fkrn matches release kernel byte-for-byte')
ok(file_chain(system_file[2],system_file[3])==f,'ESP System.fex matches release FEX byte-for-byte')
stat=(ROOT/'build/BOOTSTAT.TXT').read_bytes(); ok(file_chain(stat_file[2],stat_file[3])==stat,'ESP BOOTSTAT.TXT matches generated gate report')
ok(b'decision: BLOCKED' in stat,'physical boot gate is explicitly BLOCKED')
print('ALL RELEASE STRUCTURE CHECKS PASSED')
