#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn internet_checksum','fn icmp_loopback_selftest','volatile_write8(page,8)','net_write_be16(page+4,1)','internet_checksum(page,8)!=0','volatile_write8(page,0)','volatile_write64(state+64,1)','network_ready=icmp_loopback_selftest']:
 assert t in s,t
print('PASS Frames 0.3.4 ICMP source gates')
