#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
checks={
"block wrapper":"fn block_read(",
"caller buffer":"requested_buffer",
"gpt signature":"6075990659671082565",
"header crc":"calculated_header_crc",
"array crc":"stored_array_crc",
"esp guid":"fn guid_is_esp(",
"gpt marker":"serial_marker_gpt_ok",
"boot-volume marker":"serial_marker_boot_volume_ok",
}
for name,needle in checks.items():
    if needle not in s: raise SystemExit(f"FAIL {name}")
for forbidden in ["nvme_io_write", "namespace_write", "gpt_write", "filesystem_write"]:
    if forbidden in s: raise SystemExit(f"FAIL forbidden write path: {forbidden}")
print("PASS Frames 0.0.44 read-only block/GPT source gates")
