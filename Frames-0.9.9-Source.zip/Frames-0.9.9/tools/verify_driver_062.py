#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn driver_kind_find', 'fn driver_bindings_init', 'if kind==7 { driver_kind=4; }', 'volatile_write64(process_state+784,driver_binding_state)', 'if number==114']:assert t in s,t
print('PASS verify_driver_062.py source gates')
