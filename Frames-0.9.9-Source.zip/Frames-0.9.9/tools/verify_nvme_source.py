#!/usr/bin/env python3
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
s=(root/'kernel/main.nx').read_text()
matrix=json.loads((root/'docs/HARDWARE-MATRIX.json').read_text())
checks={
 'PCI MMIO+busmaster enable':'fn pci_enable_mmio_busmaster' in s and 'pci_cfg_write32' in s,
 'NVMe controller ready polling':'fn nvme_wait_ready' in s,
 'Admin queue initialization':'fn nvme_admin_queue_init' in s and 'volatile_write64(base + 40,sq)' in s and 'volatile_write64(base + 48,cq)' in s,
 'Identify command builder':'fn nvme_admin_identify' in s and 'volatile_write32(command + 0,6 +' in s,
 'NVMe CQE CID/status layout':'completed_cid = status_word % 65536' in s and 'status_field = (status_word / 65536) % 65536' in s,
 'Identify Controller':'nvme_admin_identify(nvme_state,0,1,controller)' in s,
 'Active Namespace List':'nvme_admin_identify(nvme_state,0,2,list)' in s,
 'Identify Namespace':'nvme_admin_identify(nvme_state,active_nsid,0,namespace)' in s,
 'Namespace geometry':'controller + 516' in s and 'namespace + 128 + (format * 4)' in s and 'block_size = pow2_small(lbads)' in s,
 'I/O queue initializer':'fn nvme_io_queue_init' in s,
 'Number of Queues feature':'nvme_admin_simple(nvme_state,9,0,admin_args)' in s and 'volatile_write64(admin_args + 8,7)' in s,
 'Create I/O CQ 1':'nvme_admin_simple(nvme_state,5,io_cq,admin_args)' in s,
 'Create I/O SQ 1':'nvme_admin_simple(nvme_state,1,io_sq,admin_args)' in s and 'volatile_write64(admin_args + 16,65537)' in s,
 'I/O SQ/CQ doorbells':'base + 4096 + (2 * stride)' in s and 'base + 4096 + (3 * stride)' in s,
 'Bounded NVM Read opcode':'fn nvme_io_read_one' in s and 'volatile_write32(command + 0,2 +' in s,
 'Read SLBA fields':'volatile_write32(command + 40,lba_low)' in s and 'volatile_write32(command + 44,lba_high)' in s,
 'Exactly one logical block':'volatile_write32(command + 48,0)' in s and 'volatile_write64(nvme_state + 264,1)' in s,
 'Single-PRP safety gate':'block_size > 4096' in s and 'metadata_size != 0' in s and 'volatile_write64(command + 24,buffer)' in s,
 'Read completion validation':'completed_cid != cid || status != 0' in s and 'volatile_write64(nvme_state + 288,1)' in s,
 'Read checksum/state':'fn nvme_read_checksum' in s and 'volatile_write64(nvme_state + 272,checksum)' in s and 'volatile_write64(nvme_state + 312,block_size)' in s,
 'No namespace-write routine':'fn nvme_io_write' not in s and 'serial_marker_nvme_write' not in s and 'FRAMES_NVME_WRITE_OK' not in s,
 'Storage gate remains non-operational':matrix['required_gates']['storage_read_path'] == 'structural',
 'Physical boot remains blocked':matrix['physical_boot_approved'] is False,
}
# The marker is emitted by serial_putc byte values rather than a string literal.
checks['I/O queue serial marker']='fn serial_marker_nvme_ioq_ready' in s
checks['Read-success serial marker']='fn serial_marker_nvme_read_ok' in s
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+': '+name)
 if not ok: raise SystemExit(1)
print('ALL NVME 0.0.43 SOURCE GATES PASSED')
