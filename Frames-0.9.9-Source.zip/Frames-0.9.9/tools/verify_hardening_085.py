#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn dma_ledger_init','fn dma_record','fn alloc_dma_page','fn dma_ledger_audit','volatile_write64(phys_state+112,dma_state)','alloc_dma_page(phys_state,1)','alloc_dma_page(phys_state,2)','alloc_dma_page(phys_state,3)']: assert t in s
assert 'dma_ledger_ready=dma_ledger_audit(dma_state)' in s
print('PASS Frames 0.0.85 DMA ownership source gates')
