#!/usr/bin/env python3
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]; s=(r/'tools/runtime_evidence.py').read_text(); m=json.loads((r/'docs/RUNTIME-MARKERS.json').read_text())
for g in ['core','platform','smp','userspace','storage_nvme','safety']: assert g in m
for t in ['source_sha256','physical_boot_approved','--require-pass']: assert t in s
assert json.loads((r/'docs/HARDWARE-MATRIX.json').read_text())['physical_boot_approved'] is False
print('PASS Frames 0.0.71 runtime-evidence import source gates')
