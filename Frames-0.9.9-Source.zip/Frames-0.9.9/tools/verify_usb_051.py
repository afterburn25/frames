#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n in ["runtime=base+", "volatile_write32(intr+8,1)","fn xhci_reset_first_port(","xhci_port_write_base","serial_marker_xhci_port_ready"]:
    if n not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.51 xHCI event/root-port source gates")
