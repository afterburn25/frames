#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); b=(r/'tools/build.sh').read_text()
for t in ['phys_allocator_audit','serial_marker_phys_ledger_ok','volatile_write64(state + 56, best_start)','volatile_write64(state + 88, cursor)']: assert t in s
assert 'Nexus-Language-5.13.0' in b
print('PASS Frames 0.0.80 physical-memory ledger source gates')
