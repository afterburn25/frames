#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['volatile_write64(pt_stack + 8, stack_page + 7)','70368746283000','volatile_read64(pt_stack + 0) != 0','volatile_read64(pt_stack + 16) != 0']: assert t in s
assert 'volatile_write64(pt_stack + 0, stack_page + 7)' not in s
print('PASS Frames 0.0.82 user-stack guard source gates')
