#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); b=(r/'tools/build.sh').read_text()
for t in ['read_cr0()','write_cr0(cr0n)','65536','cpuid_ebx(7,0)','read_cr4()','write_cr4(cr4n)','1048576','enable_supervisor_protections(process_state)']: assert t in s
assert 'Nexus-Language-5.13.0' in b
print('PASS Frames 0.0.84 CR0.WP/SMEP source gates')
