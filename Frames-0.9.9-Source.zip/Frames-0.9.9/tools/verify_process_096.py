#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn syscall_capability_required','number>=32 && number<=39','number>=56 && number<=63','fn process_has_capability','18446744073709551614','volatile_write64(process_state+344','if number==8']: assert t in s
print('PASS Frames 0.0.96 capability enforcement source gates')
