#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn service_start','fn service_stop','fn service_heartbeat','fn service_active_count','service_start(service_state,sysid)','service_start(service_state,childid)','service_heartbeat(service_state,childid)','service_stop(service_state,childid)','volatile_write64(process_state+448,1)','if number==15']:
 assert t in s,t
print('PASS Frames 0.1.7 service lifecycle source gates')
