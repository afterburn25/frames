#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for t in ["fn safe_mode_policy","fn safe_mode_activate","serial_marker_safe_mode_policy_ok"]: assert t in s,t
if "safe_mode_activate(recovery_state," in s: raise SystemExit("FAIL automatic safe-mode activation")
print("PASS Frames 0.0.65 safe-mode source gates")
