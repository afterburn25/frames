#!/usr/bin/env python3
from pathlib import Path
import argparse,json
root=Path(__file__).resolve().parents[1]; a=argparse.ArgumentParser(); a.add_argument('--runtime',default=str(root/'build/RUNTIME-EVIDENCE.json')); a.add_argument('--hardware-record'); n=a.parse_args(); reasons=[]
runtime=Path(n.runtime); runtime_ok=False
if runtime.is_file():
 try: runtime_ok=json.loads(runtime.read_text()).get('status')=='PASS'
 except Exception: reasons.append('runtime evidence malformed')
else: reasons.append('runtime evidence missing')
hw_ok=False
if n.hardware_record and Path(n.hardware_record).is_file():
 try: hw_ok=json.loads(Path(n.hardware_record).read_text()).get('result')=='PASS'
 except Exception: reasons.append('hardware record malformed')
else: reasons.append('hardware certification record missing')
approved=runtime_ok and hw_ok
out={'frames_version':(root/'VERSION').read_text().strip(),'decision':'APPROVED' if approved else 'BLOCKED','runtime_pass':runtime_ok,'hardware_pass':hw_ok,'physical_boot_approved':approved,'reasons':reasons}
(root/'build/RUNTIME-PROMOTION.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
if not approved: raise SystemExit(2)
