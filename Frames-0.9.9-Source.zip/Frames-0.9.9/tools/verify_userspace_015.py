#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn klog_init','fn klog_write','volatile_write64(state+24,96)','idx=next%96','volatile_write64(process_state+392,log_state)','if number==13']:
    assert t in s, t
assert 'persistence' not in s[s.index('fn klog_init'):s.index('fn serial_marker_service_registry_ok')]
print('PASS Frames 0.1.5 structured log source gates')
