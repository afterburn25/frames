#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'tools/promotion_decision.py').read_text()
for t in ["decision':'APPROVED' if approved else 'BLOCKED",'runtime_ok and hw_ok','physical_boot_approved']: assert t in s
print('PASS Frames 0.0.78 fail-closed promotion-engine source gates')
