#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn ramfs_init','fn ramfs_create','fn ramfs_find','fn ramfs_write_u64','fn ramfs_read_u64','zero_page(page)','ramfs_write_u64(ramfs_state,rid,5067184330876600881)','vfs_mount_register(vfs_state,2,ramfs_state,2)','volatile_write64(process_state+496,ramfs_state)','if number==21']:
 assert t in s,t
seg=s[s.index('fn ramfs_init'):s.index('fn serial_marker_vnode_ok')]
for bad in ['block_write','nvme_write','ahci_write']: assert bad not in seg
print('PASS Frames 0.2.3 RAMFS source gates')
