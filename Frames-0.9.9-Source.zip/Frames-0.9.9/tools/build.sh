#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [[ -n "${NEXUS:-}" ]]; then
  NEXUS="$NEXUS"
elif [[ -x "$ROOT/toolchain/Nexus-Language-5.15.0/nexus" ]]; then
  NEXUS="$ROOT/toolchain/Nexus-Language-5.15.0/nexus"
elif [[ -x "/mnt/data/Nexus-Language-5.15.0/nexus" ]]; then
  NEXUS="/mnt/data/Nexus-Language-5.15.0/nexus"
elif command -v nexus >/dev/null 2>&1; then
  NEXUS="$(command -v nexus)"
else
  echo "Nexus 5.15.0 toolchain not found; set NEXUS=/path/to/nexus" >&2
  exit 2
fi
CLANG="${CLANG:-clang}"
LLD_LINK="${LLD_LINK:-lld-link}"
mkdir -p "$ROOT/build" "$ROOT/media/EFI/BOOT" "$ROOT/media/Frames"
python3 "$ROOT/tools/physical_boot_gate.py"
rm -f "$ROOT/media/Frames/System.fex"
"$NEXUS" kernel check "$ROOT/kernel/main.nx"
"$NEXUS" kernel build "$ROOT/kernel/main.nx" -o "$ROOT/build/FramesKernel.fkrn"
"$NEXUS" check "$ROOT/apps/System/main.nx"
"$NEXUS" build "$ROOT/apps/System/main.nx" --target frames-x64 -o "$ROOT/build/System.fex"
"$NEXUS" inspect "$ROOT/build/System.fex"
"$CLANG" --target=x86_64-pc-windows-msvc -ffreestanding -fshort-wchar -mno-red-zone -fno-stack-protector -fno-builtin -Wall -Wextra -Werror -c "$ROOT/boot/uefi/frames_boot.c" -o "$ROOT/build/frames_boot.obj"
"$LLD_LINK" /machine:x64 /subsystem:efi_application /entry:efi_main /nodefaultlib /timestamp:0 /out:"$ROOT/build/BOOTX64.EFI" "$ROOT/build/frames_boot.obj"
cp "$ROOT/build/BOOTX64.EFI" "$ROOT/media/EFI/BOOT/BOOTX64.EFI"
cp "$ROOT/build/FramesKernel.fkrn" "$ROOT/media/Frames/FramesKernel.fkrn"
cp "$ROOT/build/System.fex" "$ROOT/media/Frames/System.fex"
"$NEXUS" kernel inspect "$ROOT/build/FramesKernel.fkrn"
file "$ROOT/build/BOOTX64.EFI" "$ROOT/build/FramesKernel.fkrn"
