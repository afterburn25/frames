#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n in ["fn fat32_mount_boot_volume(","fn fat32_next_cluster(","fn fat32_cluster_lba(","short_name_system_fex","serial_marker_fat32_ok","serial_marker_boot_files_ok","read_u8(scratch+4)!=52"]:
    if n not in s: raise SystemExit("FAIL "+n)
for n in ["fat32_write","filesystem_write","block_write"]:
    if n in s: raise SystemExit("FAIL forbidden write path "+n)
print("PASS Frames 0.0.45 FAT32 read-only source gates")
