#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn audio_hda_inventory', 'classcode==4 && subclass==3', 'volatile_read64(hardware+216)', 'volatile_write64(process_state+720,hda_state)', 'if number==100']: assert t in s,t
print('PASS verify_audio_054.py source gates')
