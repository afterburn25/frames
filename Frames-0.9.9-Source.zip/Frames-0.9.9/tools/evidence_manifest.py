#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json
root=Path(__file__).resolve().parents[1]; a=argparse.ArgumentParser(); a.add_argument('paths',nargs='*'); n=a.parse_args(); items=[]
for s in n.paths:
 p=Path(s)
 if p.is_file(): items.append({'path':str(p),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
out={'frames_version':(root/'VERSION').read_text().strip(),'algorithm':'sha256','items':items}; (root/'build/EVIDENCE-MANIFEST.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
