#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn sandbox_profiles_init', 'volatile_write64(item+8,0)', 'volatile_write64(item+32,0)', 'volatile_write64(process_state+880,sandbox_state)', 'if number==132']:assert t in s,t
print('PASS verify_security_074.py source gates')
