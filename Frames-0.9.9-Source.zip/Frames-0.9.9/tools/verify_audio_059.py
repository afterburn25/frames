#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); q=(r/'tools/qemu_certify.sh').read_text()
for t in ['fn audio_core_gate','volatile_read64(process+680)','volatile_read64(process+752)','if score==2','serial_marker_audio_core_ok','volatile_write64(process_state+760,audio_gate_state)','if number==105']: assert t in s,t
assert 'FRAMES_AUDIO_CORE_OK' in q
print('PASS verify_audio_059.py source gates')
