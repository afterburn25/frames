#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn recovery_update_coordinator', 'volatile_read64(transaction+8)==3', 'volatile_write64(state+16,0)', 'volatile_write64(state+24,0)', 'volatile_write64(process_state+944,recovery_update_state)', 'if number==146']:assert t in s,t
print('PASS verify_update_086.py source gates')
