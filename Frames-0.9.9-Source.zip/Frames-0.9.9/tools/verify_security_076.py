#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn trust_domain_init', 'volatile_write64(item+24,0)', 'volatile_write64(process_state+896,trust_domain_state)', 'if number==134']:assert t in s,t
print('PASS verify_security_076.py source gates')
