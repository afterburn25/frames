#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn tcp_table_init','fn tcp_open','fn tcp_find','fn tcp_transition','current==2 && event==1','current==4 && event==2','current==5 && event==3','tcp_open(state,7000,7001,2130706433)','volatile_write64(state+32,1)','volatile_write64(process_state+592,tcp_state)','if number==66']:
 assert t in s,t
print('PASS Frames 0.3.7 TCP state source gates')
