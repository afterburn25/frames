#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for t in ["fn boot_health_assess","score=score+25","volatile_write64(recovery_state+80,score)","serial_marker_boot_health_ok"]:
    assert t in s,t
print("PASS Frames 0.0.64 boot-health source gates")
