#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn resource_accounting_refresh','fn resource_accounting_init','volatile_read64(process+344)','volatile_read64(phys+24)','volatile_read64(dma+8)','volatile_write64(process+312,state)','resource_accounting_refresh(resource_state,process_state)','if number==10']: assert t in s
print('PASS Frames 0.0.98 resource accounting source gates')
