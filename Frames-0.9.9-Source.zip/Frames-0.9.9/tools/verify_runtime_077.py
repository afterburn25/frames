#!/usr/bin/env python3
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]; s=json.loads((r/'docs/HARDWARE-CERTIFICATION-SCHEMA.json').read_text())
assert 'evidence_manifest_sha256' in s['required']; assert 'BLOCKED' in s['allowed_results']; assert len(s['physical_boot_approval_requires'])==7
print('PASS Frames 0.0.77 hardware-certification schema gates')
