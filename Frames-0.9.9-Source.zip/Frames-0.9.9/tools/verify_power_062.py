#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n,t in {"pm1a":"volatile_read32(fadt+64)","pm1len":"read_u8(fadt+89)","read16":"io_read16(pm1a)","write16":"io_write16(pm1a,val_a)","sleep":"slp_type*1024","enable":"+8192","marker":"serial_marker_acpi_shutdown_ready"}.items():
    if t not in s: raise SystemExit("FAIL "+n)
if "acpi_shutdown_execute(power_state" in s and "acpi_shutdown_execute(power_state);" in s: raise SystemExit("FAIL auto shutdown")
print("PASS Frames 0.0.62 ACPI shutdown source gates")
