#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn security_entropy_init', 'volatile_write64(state+24,0)', 'number>=128 && number<=143', 'volatile_write64(process_state+848,entropy_state)', 'if number==128']:assert t in s,t
print('PASS verify_security_070.py source gates')
