#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn device_events_init', 'fn device_event_emit', 'count>=64', 'device_event_selftest', 'volatile_write64(process_state+800,device_event_state)', 'if number==116']:assert t in s,t
print('PASS verify_driver_064.py source gates')
