#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn driver_platform_gate', 'volatile_read64(process+760)', 'volatile_read64(process+832)', 'if score==2', 'volatile_write64(process_state+840,driver_gate_state)', 'if number==121']:assert t in s,t
q=(r/'tools/qemu_certify.sh').read_text(); assert 'FRAMES_DRIVER_PLATFORM_OK' in q
print('PASS verify_driver_069.py source gates')
