#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for t in ["fn system_action_init","fn system_action_request","fn system_action_execute","serial_marker_system_action_ready"]: assert t in s,t
if "system_action_execute(action_state," in s: raise SystemExit("FAIL automatic action")
print("PASS Frames 0.0.68 action source gates")
