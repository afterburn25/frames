#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn thread_table_init','fn thread_create_record','count>=64','volatile_write64(process_state+264,thread_state)','thread_create_record(thread_state,1','thread_create_record(thread_state,2,0,0)','if number==5']: assert t in s
print('PASS Frames 0.0.93 thread registry source gates')
