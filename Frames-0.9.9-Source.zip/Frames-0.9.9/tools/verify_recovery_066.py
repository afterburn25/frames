#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text(); assert "fn panic_capture" in s; assert "serial_marker_panic_snapshot_ready" in s
if "panic_capture(recovery_state," in s: raise SystemExit("FAIL synthetic panic")
print("PASS Frames 0.0.66 panic source gates")
