#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn display_tile_init','while i<16','page!=first+(i*4096)','fn display_tile_fill','while i<16384','fn display_tile_present','volatile_write64(surface+56,volatile_read64(surface+56)+1)','fn display_tile_selftest','dirty_add(dirty,xy,(128*65536)+128,1)','volatile_write64(process_state+632,tile_state)','if number==83']:
 assert t in s,t
print('PASS Frames 0.4.3 software tile source gates')
