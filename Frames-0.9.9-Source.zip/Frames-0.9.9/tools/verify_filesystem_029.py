#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); q=(r/'tools/qemu_certify.sh').read_text()
for t in ['fn filesystem_platform_gate','volatile_read64(ug+24)==1','volatile_read64(vfs+8)>=4','ramfs_read_u64(ramfs,1)==5067184330876600881','volatile_read64(procfs+8)>=8','score==10','volatile_write64(process_state+544,filesystem_gate_state)','filesystem_gate_ready=filesystem_platform_gate','if number==27']:
 assert t in s,t
assert 'FRAMES_FILESYSTEM_PLATFORM_OK' in q
seg=s[s.index('fn filesystem_platform_gate'):s.index('fn serial_marker_fs_events_ok')]
for bad in ['block_write','nvme_write','ahci_write']: assert bad not in seg
print('PASS Frames 0.2.9 filesystem platform gate source gates')
