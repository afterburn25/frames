#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn audio_streams_init', 'fn audio_stream_create', 'count>=32', 'audio_stream_create(state,1,1,1)', 'volatile_write64(process_state+712,audio_stream_state)', 'if number==99']: assert t in s,t
print('PASS verify_audio_053.py source gates')
