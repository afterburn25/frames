#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn audio_timing_init', 'fn audio_timing_advance', 'frames>48000', 'volatile_read64(state+24)!=960', 'volatile_write64(process_state+736,audio_timing_state)', 'if number==102']: assert t in s,t
print('PASS verify_audio_056.py source gates')
