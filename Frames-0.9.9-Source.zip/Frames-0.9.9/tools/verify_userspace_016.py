#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn config_init','fn config_find','fn config_set','fn config_get','volatile_write64(state+16,64)','config_set(config_state,1,info.boot_policy_flags,1)','config_set(config_state,2,31,1)','volatile_write64(process_state+400,config_state)','if number==14']:
 assert t in s,t
seg=s[s.index('fn config_init'):s.index('fn serial_marker_klog_ok')]
for bad in ['block_write','nvme_write','ahci_write']: assert bad not in seg
print('PASS Frames 0.1.6 configuration registry source gates')
