#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn security_audit_init', 'fn security_audit_emit', 'count>=64', 'security_audit_selftest', 'volatile_write64(process_state+888,security_audit_state)', 'if number==133']:assert t in s,t
print('PASS verify_security_075.py source gates')
