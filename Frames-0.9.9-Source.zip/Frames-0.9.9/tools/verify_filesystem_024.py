#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn devfs_init','fn devfs_register','devfs_register(devfs_state,1,0,3)','devfs_register(devfs_state,2,log_state,1)','vfs_mount_register(vfs_state,3,devfs_state,2)','volatile_write64(process_state+504,devfs_state)','if number==22']:
 assert t in s,t
print('PASS Frames 0.2.4 devfs source gates')
