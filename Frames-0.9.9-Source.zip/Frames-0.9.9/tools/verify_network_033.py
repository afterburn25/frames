#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn net_write_be32','fn net_read_be32','fn ipv4_checksum20','fn ipv4_loopback_selftest','volatile_write8(page,69)','net_write_be32(page+12,2130706433)','ipv4_checksum20(page)!=0','volatile_write64(state+56,1)','if number==31']:
 assert t in s,t
print('PASS Frames 0.3.3 IPv4 source gates')
