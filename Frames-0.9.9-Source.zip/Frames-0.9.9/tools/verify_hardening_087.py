#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['16045690984833335023','17297757510497598158','volatile_write64(state+56,p0+16)','volatile_write64(state+64,raw_end-16)','let end=volatile_read64(state+64)','volatile_read64(end-8)!=16045690984833335023']: assert t in s
print('PASS Frames 0.0.87 heap redzone/canary source gates')
