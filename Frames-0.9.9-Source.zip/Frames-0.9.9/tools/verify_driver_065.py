#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn device_power_init', 'volatile_write64(first+8,3)', 'volatile_write64(first+8,0)', 'volatile_write64(process_state+808,device_power_state)', 'if number==117']:assert t in s,t
print('PASS verify_driver_065.py source gates')
