#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn security_platform_gate', 'volatile_read64(process+840)', 'volatile_read64(process+912)', 'if score==2', 'volatile_write64(process_state+920,security_gate_state)', 'if number==137']:assert t in s,t
print('PASS verify_security_079.py source gates')
