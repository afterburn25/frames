#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n in ["fn block_cache_init(","fn block_cache_read(","fn block_sequence_checksum(","serial_marker_block_cache_ok","count>64"]:
    if n not in s: raise SystemExit("FAIL "+n)
if "block_write" in s: raise SystemExit("FAIL write path")
print("PASS Frames 0.0.46 block-cache source gates")
