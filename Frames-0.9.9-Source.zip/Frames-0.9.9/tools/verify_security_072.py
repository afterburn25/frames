#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn credential_registry_init', 'fn credential_create', 'count>=32', 'credential_selftest', 'volatile_write64(process_state+864,credential_state)', 'if number==130']:assert t in s,t
print('PASS verify_security_072.py source gates')
