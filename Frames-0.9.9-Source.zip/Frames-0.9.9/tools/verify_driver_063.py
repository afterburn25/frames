#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn driver_record_by_kind', 'fn driver_lifecycle_selftest', 'volatile_write64(item+24,2)', 'volatile_write64(item+24,3)', 'volatile_write64(process_state+792,driver_lifecycle_state)', 'if number==115']:assert t in s,t
print('PASS verify_driver_063.py source gates')
