#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn dirty_init','fn dirty_add','last_index=(volatile_read64(state+16)+63)%64','if count<64','fn dirty_selftest','volatile_read64(state+8)!=2','volatile_write64(process_state+624,dirty_state)','if number==82']:
 assert t in s,t
print('PASS Frames 0.4.2 dirty-region source gates')
