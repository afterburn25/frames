#!/usr/bin/env python3
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]; p=json.loads((r/'docs/RUNTIME-CPU-USERSPACE.json').read_text())
assert len(p['smp'])>=5 and len(p['userspace'])>=7
print('PASS Frames 0.0.75 SMP/userspace evidence-profile gates')
