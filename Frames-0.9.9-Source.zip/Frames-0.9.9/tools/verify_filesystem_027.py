#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn fs_security_init','fn fs_security_add','fn fs_access','fn fs_security_seed','fs_security_add(state,1,3,1)','fs_security_add(state,2,1,3)','fs_access(state,1,3,2)!=0','fs_access(state,2,1,2)!=1','volatile_write64(state+24,1)','volatile_write64(process_state+528,fs_security_state)','if number==25']:
 assert t in s,t
print('PASS Frames 0.2.7 filesystem rights source gates')
