#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'tools/qemu_input_certify.sh').read_text()
for t in ['usb-kbd','usb-mouse','qemu-xhci','FRAMES_XHCI_PROBE_OK','readonly=on']: assert t in s
print('PASS Frames 0.0.73 QEMU input-profile source gates')
