#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n,t in {"reset flag":"(flags/1024)%2","gas":"let gas=fadt+116","reset value":"volatile_read8(fadt+128)","execute":"fn acpi_reset_execute","io":"io_write8(address,value)","marker":"serial_marker_acpi_reset_ready"}.items():
    if t not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.60 ACPI reset source gates")
