#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn stress_plan_init', 'while i<8', 'volatile_write64(item+16,0)', 'volatile_write64(process_state+968,stress_plan_state)', 'if number==161']:assert t in s,t
print('PASS verify_cert_093.py source gates')
