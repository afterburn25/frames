#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn fs_events_init','fn fs_event_emit','idx=next%64','fs_event_emit(fs_event_state,1,2,1)','fs_event_emit(fs_event_state,2,2,1)','volatile_write64(process_state+536,fs_event_state)','if number==26']:
 assert t in s,t
print('PASS Frames 0.2.8 filesystem event source gates')
