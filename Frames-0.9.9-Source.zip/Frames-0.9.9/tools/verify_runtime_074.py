#!/usr/bin/env python3
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]; p=json.loads((r/'docs/RUNTIME-POWER-RECOVERY.json').read_text())
assert p['automatic_reboot'] is False and p['automatic_shutdown'] is False
assert 'FRAMES_PHYSICAL_BOOT_BLOCKED' in p['recovery_required']
print('PASS Frames 0.0.74 power/recovery evidence-policy gates')
