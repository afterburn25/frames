#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn kernel_heap_init','p1!=p0+4096','p3!=p2+4096','fn kernel_heap_alloc','amount%16','cur+amount>end','fn kernel_heap_audit','kernel_heap_ready=kernel_heap_init']: assert t in s
print('PASS Frames 0.0.86 bounded kernel heap source gates')
