#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn display_fill_rect','packed_xy/65536','if x+w>width || x+w<x','volatile_write32(base+(((y+yy)*stride+(x+xx))*4),color)','fn display_rect_selftest','display_fill_rect(state,packed_xy,packed_wh,4286611584)!=16','volatile_write64(state+80,1)','if number==81']:
 assert t in s,t
print('PASS Frames 0.4.1 clipped rectangle source gates')
