#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n,t in {"config head":"2533274823952000","dynamic total":"total*281474976710656","descriptor walk":"while off+2<=total","HID class":"cls==3 && sub==1","interrupt in":"addr>=128 && attrs%4==3","marker":"serial_marker_usb_hid_found"}.items():
    if t not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.56 USB configuration/HID discovery source gates")
