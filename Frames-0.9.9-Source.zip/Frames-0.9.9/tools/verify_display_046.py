#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn topology_init','volatile_write64(state+8,1)','volatile_write64(state+24,1)','fn topology_refresh','current!=volatile_read64(state+16)','volatile_write64(state+32,volatile_read64(state+32)+1)','volatile_write64(process_state+656,topology_state)','if number==86']:
 assert t in s,t
print('PASS Frames 0.4.6 topology source gates')
