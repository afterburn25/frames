#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn security_manager_snapshot', 'volatile_read64(e0+24)==0', 'volatile_read64(u0+32)==0', 'if score==8', 'volatile_write64(process_state+912,security_manager_state)', 'if number==136']:assert t in s,t
print('PASS verify_security_078.py source gates')
