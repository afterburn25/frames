#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['sig==1380011332','sig==1397904969','acpi_checksum(dmar,dl)','acpi_checksum(ivrs,il)','volatile_write64(state+1848,dmar)','volatile_write64(state+1856,ivrs)','serial_marker_iommu_tables_ok']: assert t in s
assert 'iommu_translation' in (r/'docs/HARDWARE-MATRIX.json').read_text()
print('PASS Frames 0.0.88 IOMMU table discovery source gates')
