#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn known_good_init', 'fn known_good_failure', 'volatile_read64(state+32)>=3', 'known_good_select(state)!=1', 'volatile_write64(process_state+936,known_good_state)', 'if number==145']:assert t in s,t
print('PASS verify_update_083.py source gates')
