#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn user_pte_value','549755813888','fn user_range_valid','length>4096','fn copy_from_user','fn copy_to_user','user_range_valid(process,code,1,1)!=0','volatile_write64(process+352,1)']: assert t in s
print('PASS Frames 0.1.0 user-copy boundary source gates')
