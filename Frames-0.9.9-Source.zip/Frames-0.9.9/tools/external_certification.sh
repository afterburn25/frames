#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/tools/runtime_preflight.py" --require-ready
"$ROOT/tools/qemu_certify.sh"
python3 "$ROOT/tools/runtime_evidence.py" --serial "$ROOT/build/serial.log" --require-pass
python3 "$ROOT/tools/runtime_storage_cert.py" --serial "$ROOT/build/serial.log" --require-pass
python3 "$ROOT/tools/evidence_manifest.py" "$ROOT/build/serial.log" "$ROOT/build/RUNTIME-EVIDENCE.json" "$ROOT/build/STORAGE-RUNTIME-CERT.json"
echo 'Core VM certification evidence complete. Physical-machine record is still separately required for promotion.'
