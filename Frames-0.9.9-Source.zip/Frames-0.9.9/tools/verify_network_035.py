#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['number>=64 && number<=79 { return 16; }','fn udp_socket_init','fn udp_socket_open','fn udp_socket_find','fn udp_loopback_selftest','udp_socket_open(state,6060)','net_write_be16(page+4,16)','volatile_write64(state+32,1)','volatile_write64(process_state+576,udp_state)','if number==64']:
 assert t in s,t
print('PASS Frames 0.3.5 UDP/network capability source gates')
