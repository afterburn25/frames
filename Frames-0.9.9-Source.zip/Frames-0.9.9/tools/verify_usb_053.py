#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n in ["fn xhci_address_default_device(","volatile_write32(input+4,3)","(11*1024)+cycle", "control=control+512", "volatile_write64(dcbaa+(slot*8),output)","(mps*65536)+38","serial_marker_xhci_default_ep_ready"]:
    if n not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.53 xHCI Address Device context source gates")
