#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n in ["fn ahci_read_lba0(","volatile_write8(table+2,37)","volatile_write32(table+140,2147484159)","serial_marker_ahci_read_ok","pci_enable_mmio_busmaster(bdf)"]:
    if n not in s: raise SystemExit("FAIL "+n)
for n in ["ATA WRITE","ahci_write","volatile_write8(table+2,53)"]:
    if n in s: raise SystemExit("FAIL write path "+n)
print("PASS Frames 0.0.47 AHCI read-only source gates")
