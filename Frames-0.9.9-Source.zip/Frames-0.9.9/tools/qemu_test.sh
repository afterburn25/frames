#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VER="$(cat "$ROOT/VERSION")"
QEMU="${QEMU:-qemu-system-x86_64}"
OVMF_CODE="${OVMF_CODE:-}"
OVMF_VARS="${OVMF_VARS:-}"
if ! command -v "$QEMU" >/dev/null 2>&1; then echo "qemu-system-x86_64 not found" >&2; exit 2; fi
if [[ -z "$OVMF_CODE" || ! -f "$OVMF_CODE" ]]; then echo "Set OVMF_CODE=/path/to/OVMF_CODE.fd" >&2; exit 2; fi
VAR_DRIVE=()
if [[ -n "$OVMF_VARS" && -f "$OVMF_VARS" ]]; then
  cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.runtime.fd"
  VAR_DRIVE=(-drive "if=pflash,format=raw,file=$ROOT/build/OVMF_VARS.runtime.fd")
fi
"$ROOT/tools/build.sh"
python3 "$ROOT/tools/make_esp.py"
python3 "$ROOT/tools/verify_release.py"
rm -f "$ROOT/build/serial.log"
exec "$QEMU" -machine q35 -m 512M -cpu max -serial file:"$ROOT/build/serial.log" \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" \
  "${VAR_DRIVE[@]}" \
  -device qemu-xhci,id=xhci -device usb-kbd,bus=xhci.0 \
  -drive if=none,id=framesnvme,format=raw,readonly=on,file="$ROOT/build/Frames-${VER}-ESP.img" \
  -device nvme,serial=FRAMES${VER},drive=framesnvme
