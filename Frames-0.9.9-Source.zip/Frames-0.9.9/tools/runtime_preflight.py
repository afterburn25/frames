#!/usr/bin/env python3
from pathlib import Path
import argparse,json,os,shutil
root=Path(__file__).resolve().parents[1]
qemu=os.environ.get('QEMU','qemu-system-x86_64')
ovmf=os.environ.get('OVMF_CODE','')
qemu_path=shutil.which(qemu)
if not ovmf:
    candidates=[Path('/usr/share/OVMF/OVMF_CODE.fd'),Path('/usr/share/edk2/ovmf/OVMF_CODE.fd'),Path('/usr/share/edk2/x64/OVMF_CODE.fd')]
    found=[p for p in candidates if p.exists()]
    if found: ovmf=str(found[0])
ready=bool(qemu_path and ovmf and Path(ovmf).is_file())
reasons=[]
if not qemu_path: reasons.append('qemu-system-x86_64 unavailable')
if not ovmf or not Path(ovmf).is_file(): reasons.append('OVMF_CODE firmware unavailable')
data={'frames_version':(root/'VERSION').read_text().strip(),'status':'READY' if ready else 'BLOCKED','qemu':qemu_path or None,'ovmf_code':ovmf or None,'physical_boot_approved':False,'reasons':reasons}
(root/'build').mkdir(exist_ok=True); (root/'build/RUNTIME-CERTIFICATION.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
a=argparse.ArgumentParser(); a.add_argument('--require-ready',action='store_true'); ns=a.parse_args()
if ns.require_ready and not ready: raise SystemExit(2)
