#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn dhcp_state_init','fn dhcp_build_discover','net_write_be32(buffer+236,1669485411)','volatile_write8(buffer+242,1)','fn dhcp_build_test_offer','net_write_be32(buffer+16,167772687)','fn dhcp_parse_test_offer','volatile_write64(state+8,1)','volatile_write64(process_state+600,dhcp_state)','if number==67']:
 assert t in s,t
print('PASS Frames 0.3.8 DHCP codec source gates')
