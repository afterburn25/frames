#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn audio_manager_snapshot', 'if score==8', 'volatile_read64(process+720)', 'volatile_write64(process_state+752,audio_manager_state)', 'if number==104']: assert t in s,t
print('PASS verify_audio_058.py source gates')
