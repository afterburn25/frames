#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n,t in {"normal trb":"1060+cycle","hid event":"fn xhci_wait_hid_event","residue":"requested-residue","keyboard min":"protocol==1 && actual<8","mouse min":"protocol==2 && actual<3","marker":"serial_marker_usb_hid_report_ok"}.items():
    if t not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.58 USB HID report source gates")
