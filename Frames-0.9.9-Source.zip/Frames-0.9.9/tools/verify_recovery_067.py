#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for t in ["fn watchdog_init","fn watchdog_beat","fn watchdog_elapsed","serial_marker_watchdog_ready"]: assert t in s,t
if "watchdog_elapsed(watchdog_state" in s: raise SystemExit("FAIL automatic watchdog action")
print("PASS Frames 0.0.67 watchdog source gates")
