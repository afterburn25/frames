#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn process_registry_find','fn child_process_state_init','volatile_write64(child+16,pml4)','setup_user_fex(child_state','user_copy_contract_audit(child_state)','volatile_write64(crec+8,2)','volatile_write64(process_state+376,child_state)','serial_marker_child_fex_ready']: assert t in s
assert 'child_scheduling' in (r/'docs/HARDWARE-MATRIX.json').read_text()
print('PASS Frames 0.1.3 child FEX preparation source gates')
