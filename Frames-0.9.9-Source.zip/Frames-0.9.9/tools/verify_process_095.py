#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn shared_memory_table_init','fn shared_memory_create','pages!=1','zero_page(page)','volatile_write64(process_state+280,shared_state)','handle_create(handle_state,4,sid,3)','if number==7']: assert t in s
assert 'shared_memory_mapping' in (r/'docs/HARDWARE-MATRIX.json').read_text()
print('PASS Frames 0.0.95 shared-memory ownership source gates')
