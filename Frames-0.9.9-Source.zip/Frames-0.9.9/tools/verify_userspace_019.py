#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); q=(r/'tools/qemu_certify.sh').read_text()
for t in ['fn service_manager_snapshot','score==4','volatile_write64(process_state+416,service_manager_state)','fn userspace_platform_gate','volatile_read64(process+456)','score==5','volatile_write64(process_state+424,userspace_gate_state)','userspace_gate_ready=userspace_platform_gate','if number==17']:
 assert t in s,t
assert 'FRAMES_USERSPACE_PLATFORM_OK' in q
print('PASS Frames 0.1.9 native userspace platform gate source gates')
