#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text(); b=(r/'tools/build.sh').read_text()
for t in ['(ebx/1048576)%2!=0','2097152','volatile_write64(process_state+360,smap)','stac();','clac();','serial_marker_smap_ok']: assert t in s
assert 'Nexus-Language-5.15.0' in b
print('PASS Frames 0.1.1 SMAP-aware user copy source gates')
