#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'kernel/main.nx').read_text()
for t in ['fn driver_objects_init', 'while kind<=6', 'volatile_read64(state+8)!=6', 'number>=112 && number<=127', 'volatile_write64(process_state+768,driver_object_state)', 'if number==112']:assert t in s,t
print('PASS verify_driver_060.py source gates')
