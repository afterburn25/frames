#!/usr/bin/env python3
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]; m=json.loads((r/"docs/HARDWARE-MATRIX.json").read_text()); s=(r/"tools/runtime_preflight.py").read_text(); q=(r/"tools/qemu_certify.sh").read_text()
assert m["physical_boot_approved"] is False
assert "blocked-tool-unavailable" in m["required_gates"]["vm_runtime_certification"]
for t in ["qemu-system-x86_64","OVMF_CODE","RUNTIME-CERTIFICATION.json"]: assert t in s,t
for t in ["FRAMES_NVME_READ_OK","FRAMES_KERNEL_READY"]: assert t in q,t
print("PASS Frames 0.0.70 runtime-harness source gates")
