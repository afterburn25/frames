#!/usr/bin/env python3
from pathlib import Path
s=Path(__file__).resolve().parents[1].joinpath("kernel/main.nx").read_text()
for n,t in {"interval":"fn xhci_interrupt_interval","configure command":"(12*1024)+cycle","input add":"volatile_write32(input+4,1+add)","interrupt ep type":"(burst*256)+62","set config":"let setup=2304+(config*65536)","marker":"serial_marker_usb_configured_ok"}.items():
    if t not in s: raise SystemExit("FAIL "+n)
print("PASS Frames 0.0.57 USB HID Configure Endpoint source gates")
