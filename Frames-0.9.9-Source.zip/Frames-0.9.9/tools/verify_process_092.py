#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn process_registry_init','fn process_create_dormant','count>=32','clone_process_pml4(phys,kernel_pml4)','volatile_write64(process_state+256,process_registry)','process_create_dormant(process_registry,phys_state,kernel_pml4,1)','if number==4']: assert t in s
print('PASS Frames 0.0.92 process registry source gates')
