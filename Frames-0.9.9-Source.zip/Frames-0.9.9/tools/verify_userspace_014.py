#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn service_registry_init','fn service_register','fn service_find','count>=32','service_register(service_state,1,1,1)','service_register(service_state,2,2,0)','volatile_write64(process_state+384,service_state)','if number==12']: assert t in s
print('PASS Frames 0.1.4 service registry source gates')
