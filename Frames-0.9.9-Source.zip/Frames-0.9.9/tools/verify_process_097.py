#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['fn ipc_queue_init','fn ipc_send','fn ipc_receive','count>=32','ipc_send(state,1,2,42)','ipc_receive(state,2)!=42','volatile_write64(process_state+288,ipc_state)','if number==9']: assert t in s
assert 'ipc_user_buffers' in (r/'docs/HARDWARE-MATRIX.json').read_text()
print('PASS Frames 0.0.97 IPC source gates')
