#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]; s=(r/'kernel/main.nx').read_text()
for t in ['var supervisor=inherited','supervisor=supervisor-4','var inherited_user:u64=0','if inherited_user!=0 { return 0; }']: assert t in s
assert (r/'VERSION').read_text().strip()=='0.0.81'
print('PASS Frames 0.0.81 supervisor-only process inheritance source gates')
