#ifndef FRAMES_BOOTINFO_H
#define FRAMES_BOOTINFO_H
#include <stdint.h>
#define FRAMES_BOOT_MAGIC 0x4652414D45534231ULL
#define FRAMES_BOOT_VERSION 4ULL
#define FRAMES_BOOT_MODULE_SYSTEM_FEX 1ULL
#define FRAMES_BOOT_MODULE_VERIFIED 1ULL
typedef struct { uint64_t kind, physical_start, page_count, attributes; } FramesMemoryRegionV1;
typedef struct { uint64_t kind, flags, address, size, entry_offset, code_offset, code_size, reserved; } FramesBootModuleV1;
typedef struct {
    uint64_t magic, version;
    uint64_t memory_map, memory_map_entries, memory_region_size;
    uint64_t framebuffer, framebuffer_width, framebuffer_height, framebuffer_stride, framebuffer_format;
    uint64_t bootstrap_heap, bootstrap_heap_pages;
    uint64_t acpi_rsdp;
    uint64_t boot_modules, boot_module_count, boot_module_size, boot_policy_flags;
} FramesBootInfoV4;
#endif
