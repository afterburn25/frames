# Nexus 2.6.0 — Async/Await Task Runtime

Nexus 2.6 introduces hosted `async fn`, typed `Task<T>` values, and `await`. Async calls create native pthread-backed tasks with generated argument contexts; `await` joins and extracts the typed result. Task creation/await participates in the `task` effect contract. The direct Frames x64 backend intentionally rejects async until native scheduler/syscall integration exists.
