# Nexus 0.2.0 — Bootstrap Core & Native Execution Foundation

Nexus 0.2.0 is the first packaged baseline of the Nexus language project.

## Verified in this release

- lexer and recursive-descent parser
- typed AST and semantic validation
- native host builds through the C17 bootstrap backend
- immutable `let` and mutable `var`
- typed functions and calls
- arithmetic, comparisons, booleans, conditionals, and loops
- `for i in start..end`
- `break` / `continue`
- string `len()`
- runtime assertions
- CLI project creation and test execution
- passing positive execution suite and negative semantic suite

## Important status

Nexus does **not yet** directly emit Frames-native `.exe` files. 0.2.0 currently produces host-native executables by lowering Nexus to C17 and invoking the available host C compiler. This is intentional bootstrap infrastructure.

The next compiler architecture milestones are typed Nexus IR, direct native code generation, object/binary writers, a freestanding runtime, and then the Frames ABI/PE-compatible native executable target.
