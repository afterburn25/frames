# Nexus 5.11.0 — PCI Configuration I/O Foundation

Adds freestanding `io_read32()` and `io_write32()` kernel intrinsics for x86 port-mapped 32-bit I/O. Frames uses these first for PCI configuration mechanism #1 hardware inventory. Kernel ABI 4 and byte volatile access from Nexus 5.10 remain intact.
