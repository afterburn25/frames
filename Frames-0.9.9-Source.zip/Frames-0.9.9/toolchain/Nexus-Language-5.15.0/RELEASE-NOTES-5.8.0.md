# Nexus 5.8.0 — Frames Descriptor Table Primitives

- Adds freestanding x86-64 `load_gdt(base, limit)`.
- Adds freestanding x86-64 `load_tr(selector)` for task-register activation.
- Intended for the Frames-owned GDT/TSS and future ring-3 transition path.
