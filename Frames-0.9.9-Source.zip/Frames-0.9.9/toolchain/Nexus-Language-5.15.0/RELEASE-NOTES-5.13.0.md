# Nexus 5.13.0 — x86 Control-Register Hardening Intrinsics

Adds freestanding x86-64 kernel intrinsics `read_cr0`, `write_cr0`, `read_cr4`, and `write_cr4` while preserving existing CR2/CR3 and TLB invalidation support. These are intended for Frames memory-protection hardening such as CR0.WP and carefully gated CR4 security features.
