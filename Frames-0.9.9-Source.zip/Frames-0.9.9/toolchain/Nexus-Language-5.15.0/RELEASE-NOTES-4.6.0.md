# Nexus 4.6.0 — Frames Kernel ABI Generation 2

- Typed `kernel_main(info: &FramesBootInfoV1)` entry support.
- Direct x86-64 field reads through references to structs.
- Freestanding 32-bit volatile framebuffer reads/writes.
- `cpu_pause`, CR2/CR3 and TLB invalidation kernel intrinsics.
- Keeps Nexus 4.5 FKRN64/1 and Frames Kernel ABI 1 compatibility.
