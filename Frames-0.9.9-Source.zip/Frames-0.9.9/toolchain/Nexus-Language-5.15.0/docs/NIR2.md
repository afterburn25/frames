# Nexus NIR2

NIR2 is the Nexus 3.0 versioned intermediate representation contract. Every module begins with `nir.version 2`, declares `target portable`, carries source-language and capability metadata, and gives each function an explicit `bb.entry` block. The 3.0 verifier checks structural invariants; SSA, phi nodes, full CFG verification, alias metadata, and target legalization remain future NIR2.x work.
