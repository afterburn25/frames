# Nexus 2.0 Memory Model

Nexus 2.0 combines move semantics, borrowing, inferred reference-return provenance, explicit resource ownership and deterministic deferred actions.

## Moves

`move value` transfers ownership. Reading the source after transfer is a compile-time error. Hosted lowering clears moved `Owned<T>` pointers so generated code does not retain a second live owner.

## References

`&T` permits shared immutable access. `&mut T` is unique. Mutation, move or drop of the source is rejected while a conflicting borrow remains live. Stored borrows expire after their final syntactic use in a block.

## Returned references

A reference-returning function must derive its return from one unique reference parameter. Returning a reference to a local or mixing return provenance is rejected.

## Owned<T>

`new(value)` creates an `Owned<T>` allocation on the hosted backend. `*owner` accesses the contained value, `move owner` transfers ownership, and `drop owner` releases it. Nexus 2.0 intentionally requires explicit ownership endpoints rather than claiming complete automatic destruction across every control-flow form.

## defer

`defer { ... }` registers a function-scope action executed in LIFO order on explicit return or normal fallthrough. Nested/block-scoped defer is reserved for a later control-flow model.

## Unsafe

Raw address operations remain confined to explicit `unsafe { ... }` regions and the effect system can prohibit unsafe/allocation behavior from restricted functions.
