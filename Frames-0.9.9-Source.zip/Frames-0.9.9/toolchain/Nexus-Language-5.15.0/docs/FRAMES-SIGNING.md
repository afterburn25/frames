# Frames Publisher Signing — Preview v1

## Key format

`NexusEd25519Key/1` stores an Ed25519 raw private/public key pair, a publisher label, and a SHA-256 public-key fingerprint. Private key files should be protected as release credentials.

## Signature format

`FramesPublisherSignature/1` uses Ed25519. The signed message is a domain-separated canonical encoding of:

1. `frames.json`
2. `Signatures/integrity.json`

This binds application identity, version, capabilities, entry payload, source digest, and every integrity-protected payload hash to the signing key.

## Verification model

`nexus inspect` verifies:

- every integrity-manifest payload digest
- Ed25519 signature correctness
- public-key fingerprint consistency
- optionally, equality with a supplied trusted key

The current toolchain does not claim a global certificate authority or revocation system. That policy belongs to the future Frames security/update infrastructure.
