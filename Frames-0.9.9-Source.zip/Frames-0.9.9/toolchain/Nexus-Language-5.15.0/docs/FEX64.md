# FEX64/1

FEX64/1 is the first custom Frames executable container. The 128-byte header records format version, architecture, Frames ABI version, NIR version, entry offset, code and metadata offsets/sizes, and a SHA-256 digest over code+metadata. Nexus 3.4 supports x86-64 FEX64 payloads. A future Frames loader will map and execute these images.
