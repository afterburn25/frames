# Nexus Generics — 2.0

Nexus 2.0 supports generic functions plus explicit generic structs and enums on the hosted bootstrap backend. Generic functions are monomorphized per concrete call signature.

```nexus
struct Box<T> { value: T }

enum Choice<T> { Value(T), Empty }

trait Addable {}
impl Addable for i64;

fn twice<T: Addable>(value: T) -> T {
    return value + value;
}
```

Core generic types `Option<T>` and `Result<T,E>` are always available. Trait support in 2.0 is marker/constraint oriented; trait methods and associated types are post-2.0 work.
