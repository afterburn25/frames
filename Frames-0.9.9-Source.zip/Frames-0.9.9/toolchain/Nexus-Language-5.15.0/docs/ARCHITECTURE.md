# Nexus Compiler Architecture

## 0.2.0 bootstrap pipeline

```text
.nx source
   |
   v
Lexer
   |
   v
Parser
   |
   v
Typed AST / semantic validation
   |
   v
C17 bootstrap backend
   |
   v
Clang / GCC
   |
   v
Host-native executable
```

The C backend is a bootstrap mechanism. It gives Nexus a working native compiler quickly while the permanent backend is developed.

## Target architecture

```text
.nx source
   |
   v
Lexer -> Parser -> AST
                 |
                 v
          Semantic engine
                 |
                 v
             Nexus IR
          /      |      \
         v       v       v
      x86-64   ARM64    WASM
         |       |       |
         +-------+-------+
                 |
          Native linker
                 |
         executable/library
```

## Compiler layers planned

- frontend: lexical grammar, parser, diagnostics
- semantic engine: type system, ownership, lifetimes, effects, generics
- Nexus IR: typed SSA-style intermediate representation
- optimizer: constant folding, inlining, escape analysis, vectorization hooks
- target layer: x86-64, ARM64, WebAssembly
- binary writers: ELF, PE/COFF, and Frames-native executable metadata
- linker/runtime: freestanding and hosted profiles
- package/build graph: reproducible dependency resolution and incremental builds

## Frames OS relationship

Nexus is independent from Frames OS. Frames will be an important first-class target, but Nexus must remain useful on other operating systems and bare metal.

A future target might look like:

```text
nexus build app.nx --target x86_64-frames
```

and produce a Frames-native `.exe`. Windows `.exe` compatibility is a Frames runtime concern; Nexus itself can also later offer a Windows target when its ABI/backend work is implemented.
