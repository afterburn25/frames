# Nexus Roadmap after 3.0.0

Current completed milestone: **3.0.0 — Deterministic Resource Management**.

Next major train:

- 2.6 — async/await runtime foundation
- 2.7 — channels and structured concurrency v2
- 2.8 — data-race safety and Send/Sync-style contracts
- 2.9 — capability/effect system v2
- 3.0 — production NIR and direct native compiler transition

Longer term: Nexus-native linker, true FEX64 container, additional CPU/OS targets, package registry/tooling, self-hosting, and full Frames kernel/driver/service/UI profiles.
