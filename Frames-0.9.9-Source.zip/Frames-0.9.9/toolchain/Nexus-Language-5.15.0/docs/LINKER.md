# Nexus Linker 3.3

The 3.3 linker accepts one AMD64 COFF object generated from Nexus's direct assembly backend. It preserves `.text`/`.nxmeta`/data sections, resolves the entry symbol, and emits PE32+ Native images. It deliberately rejects unresolved relocations; multi-object linking and import libraries remain future work.
