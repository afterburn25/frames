# Nexus Memory & Resource Model 2.5

Nexus 2.5 extends the 2.0 ownership core with deterministic hosted cleanup. `Owned<T>` and `Vector<T>` resources registered in a lexical cleanup scope are released automatically when that scope exits. Explicit `drop` clears the backing resource so automatic cleanup is idempotent. A returned owned local is transferred out of the cleanup scope before cleanup runs.

`defer` is block-scoped, runs in LIFO order, and executes before owned resources from the same scope are destroyed. Deferred blocks may not contain `return` or nested `defer`.

This is still a bootstrap memory model. User-defined destructors, full path-sensitive destruction analysis, unwind cleanup, and direct-x64 parity are later work.
