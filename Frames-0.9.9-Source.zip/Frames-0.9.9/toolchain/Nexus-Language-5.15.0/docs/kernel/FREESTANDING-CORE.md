# Nexus Freestanding Core 4.2

The freestanding core has no libc, Linux, Windows, pthread, or host runtime requirement. The initial compiler intrinsic surface is:

- `cpu_halt()`
- `interrupts_disable()` / `interrupts_enable()`
- `io_read8()` / `io_write8()`
- `volatile_read64()` / `volatile_write64()`
- `mmio_read64()` / `mmio_write64()`

The SDK source under `sdk/core/` is the contract documentation; the first implementation is compiler intrinsic lowering so the kernel can exist before a userspace runtime exists.
