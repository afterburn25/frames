# Nexus Kernel Profile

Nexus kernel profiles are freestanding compilation units intended for Frames kernel code.

```nexus
kernel FramesKernel {
    arch: x86_64;
    abi: frames_1;
}
```

A kernel profile must define `fn kernel_main() -> void` and may not use hosted allocation, stdio, pthread-backed task/channel primitives, or hosted collections. Kernel-only CPU, I/O-port, volatile-memory, and MMIO intrinsics are compiler recognized.
