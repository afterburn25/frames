# Frames Kernel Build Workflow

```bash
./nexus kernel check examples/frames_kernel/kernel.nx
./nexus kernel build examples/frames_kernel/kernel.nx -o build/FramesKernel.fkrn
./nexus kernel inspect build/FramesKernel.fkrn
```

The build is source -> Nexus semantic/ownership checks -> direct x86-64 assembly -> COFF assembler object -> FKRN64/1 packaging. The final `.fkrn` does not contain or require Linux or Windows userspace.
