# Frames Kernel ABI 1

Initial target: x86-64 UEFI.

## Entry

The kernel image entry symbol is `kernel_main`. Nexus 4.5 enforces a no-argument `void` entry while the boot handoff structure is being stabilized. The boot loader will transition to passing `FramesBootInfoV1` once Frames 0.0.1 boot-loader integration begins.

## ABI primitives

- 64-bit little endian
- 8-byte fundamental kernel word
- stack alignment: 16 bytes at Nexus function boundaries
- integer/reference arguments use the current Frames x64 bootstrap calling convention
- native kernel code is freestanding and must not rely on hosted OS services

`FramesBootInfoV1` is defined in `sdk/frames/kernel_abi.nx` for the upcoming loader handoff.
