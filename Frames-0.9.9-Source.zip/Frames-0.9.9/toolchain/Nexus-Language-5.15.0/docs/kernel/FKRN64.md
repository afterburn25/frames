# FKRN64/1 — Frames Kernel Image

`.fkrn` is the native Frames kernel-image format and is distinct from application `.fex` files.

The fixed 160-byte header contains:

- `FKRN64` magic
- format version
- architecture
- freestanding flags
- Frames kernel ABI version
- Nexus NIR version
- kernel entry offset
- code offset/size
- metadata offset/size
- SHA-256 digest over code + metadata
- deterministic 128-bit build ID

Nexus 4.5 emits x86-64 FKRN64/1 images. The first Frames boot loader will validate this header before entering the kernel.
