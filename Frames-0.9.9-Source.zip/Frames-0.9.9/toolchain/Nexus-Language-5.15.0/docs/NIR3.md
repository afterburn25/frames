# NIR3

NIR3 is Nexus's versioned compiler IR contract in 3.1. It combines typed structural operations with explicit per-function CFG metadata. `ssa.mode memory` means local variables remain addressable memory objects while expression values are SSA-like temporaries conceptually; later passes may promote them.
