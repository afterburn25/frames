# Nexus Implementation Status — 3.0.0

Current milestone: **Nexus 4.0.0 — Deterministic Resource Management**.

## Working in the hosted bootstrap backend

- `Owned<T>` values are automatically freed at function/scope exit on the hosted backend.
- `Vector<T>` backing storage is automatically released.
- Explicit `drop` is cleanup-safe and prevents later double destruction.
- `defer` is block-scoped and executes LIFO before owned-resource destruction.
- Returning an owned resource transfers it out of cleanup instead of destroying it.

The accumulated Nexus 2.x core also includes generic functions and aggregates, `Option<T>` / `Result<T,E>`, `?`, ownership/moves, borrowing, inferred returned-reference provenance, traits/constraints, structured tasks/effects, Frames packaging/signing, NIR, and the native Frames `.fex` bootstrap path.

## Direct Frames x64 backend

The direct backend continues to support the freestanding primitive profile used to produce `Setup.fex`. High-level collections, closures, trait methods, aggregate lifetime lowering, and automatic resource management are currently hosted-backend features unless otherwise stated.

## Deferred

Async/await, channels/actors, full data-race analysis, production NIR, direct-backend feature parity, Nexus-native linker/FEX64 container, self-hosting, ARM64/RISC-V/WASM/macOS targets, and finalized Frames kernel/syscall/driver/GUI APIs remain later work.

## 4.0.0 native milestone

- Established the x86-64 native-generation-1 support contract.
- Added nexus native-check for deterministic native support reporting.
- A single direct build can combine generic structs, tagged enums, scalar generic specialization, references, match, move/drop and defer without C translation.
- Frames FEX64 metadata now records COMPILER=native-gen1.
- The hosted C17 backend remains the broad reference implementation for features still outside generation 1.
