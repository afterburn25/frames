# Nexus 1.x Compatibility Policy

Nexus 1.0 establishes the first stable core-language contract.

For the 1.x line:

- accepted 1.0 syntax should not be intentionally broken without a compatibility path;
- diagnostic wording may improve, but diagnostic codes are intended to remain meaningful;
- NIR-1 is an implementation/debug interface and may evolve with an explicit NIR version bump;
- the hosted C backend is a bootstrap implementation detail and is not part of the source-language ABI;
- Frames ABI metadata is versioned independently (`NEXUS-FRAMES-ABI=1`);
- experimental direct-backend limitations may be lifted without source incompatibility;
- features listed as outside the 1.0 core are not guaranteed until they are formally added to a later specification.

## Nexus 1.1 artifact-format note

Nexus 1.1 preserves the Nexus 1.x source-language compatibility promise while changing the default Frames-native artifact extension from `.exe` to `.fex`. This is an artifact/platform naming change, not a source-language breaking change. Legacy 1.0 Frames PE payloads can still be inspected, but new native Frames builds should use `.fex`.
