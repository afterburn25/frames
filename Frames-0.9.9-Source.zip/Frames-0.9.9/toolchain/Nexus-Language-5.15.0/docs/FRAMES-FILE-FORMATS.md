# Frames Native File Formats — Registry v1

Nexus 1.1 established a distinct native software identity for Frames; Nexus 2.0 retains and hardens that model. Native Frames software does **not** use the Windows `.exe`, `.dll`, or `.msi` extensions.

## Public native extensions

| Extension | Type | Role |
|---|---|---|
| `.fex` | Frames Executable | Raw native executable payload |
| `.fapp` | Frames Application | User-facing application bundle |
| `.fsetup` | Frames Setup | Guided installer bundle |
| `.fpkg` | Frames Package | General software/package container |
| `.flib` | Frames Library | Native shared/static library artifact |
| `.fdrv` | Frames Driver | Hardware driver artifact |
| `.fsvc` | Frames Service | System service artifact |
| `.fmod` | Frames Module | Loadable system/application module |
| `.ftheme` | Frames Theme | Desktop/UI theme |
| `.ficon` | Frames Icon Pack | Icon collection |
| `.ffont` | Frames Font Package | Font collection/package |
| `.fmanifest` | Frames Manifest | Application/package metadata |
| `.fupdate` | Frames Update | Signed OS update payload |
| `.fbackup` | Frames Backup | Backup archive |
| `.frecovery` | Frames Recovery | Recovery environment/package |
| `.nx` | Nexus Source | Nexus source code |

Windows compatibility retains `.exe`, `.dll`, and `.msi`. This gives the Frames loader an unambiguous first dispatch rule while still requiring binary/header validation before execution.

## `.fex` — Frames native executable

The 1.1 bootstrap FEX64 format uses PE32+/PE-COFF as its low-level object container, but the executable is identified as Frames-native by its `.nxmeta` section rather than by PE alone.

Required bootstrap metadata:

```text
NEXUS-FRAMES-ABI=1;FEX=1;FORMAT=FEX64;LANG=1.1.0;ARCH=x86_64;MODULE=<name>;KIND=app
```

The extension is presentation/dispatch metadata. Frames must inspect the binary metadata before granting native execution.

## `.fapp`, `.fsetup`, `.fpkg` — FramesBundle/1

These are deterministic ZIP-compatible containers, introduced in Nexus 1.1 and retained in Nexus 2.0, with a required `frames.json` manifest and SHA-256 integrity manifest. Nexus 1.4 added Ed25519 publisher signatures.

Example application bundle:

```text
MyApp.fapp
├── frames.json
├── Payload/
│   └── MyApp.fex
├── Resources/
│   └── Icon.png
└── Signatures/
    └── integrity.json
```

`integrity.json` provides file-integrity verification. Cryptographic publisher signing and Frames trust-store enforcement are reserved for the next signing milestone; SHA-256 integrity is not treated as publisher authentication.

## Icon identity

Every registered extension has an original Frames icon in SVG, PNG, and Windows-compatible ICO form under `assets/file-icons/`. The registry is in `assets/filetypes/frames-file-types.json` and the icon manifest is `assets/file-icons/icons.json`.
