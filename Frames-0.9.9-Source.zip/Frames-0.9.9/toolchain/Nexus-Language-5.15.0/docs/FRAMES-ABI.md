# Nexus Frames ABI v1 — Nexus 2.0

Frames ABI v1 originated with the Nexus 1.1 native-format transition and remains the active ABI foundation in Nexus 2.0.

## Native executable identity

- user-visible extension: `.fex`
- format identifier: `FEX64`
- bootstrap container: PE32+ / PE-COFF
- AMD64 machine type for `frames-x64`
- PE native subsystem
- no Windows CRT or Win32 imports required
- entry symbol: `main` in the current freestanding bootstrap profile
- `.nxmeta` identifies the file as Frames-native

Example metadata:

```text
NEXUS-FRAMES-ABI=1;FEX=1;FORMAT=FEX64;LANG=1.1.0;ARCH=x86_64;MODULE=Setup;KIND=app
```

Using PE/COFF as the bootstrap binary container does not make Frames dependent on Windows. `.exe` is now reserved for Windows compatibility; native Frames builds default to `.fex`.

## Calling convention preview

The direct x86-64 backend currently uses the Microsoft x64 register calling convention (`RCX`, `RDX`, `R8`, `R9`) for ordinary user functions. This is an ABI design choice for the x86-64 bootstrap and does not expose Win32 APIs. Frames syscall, kernel, driver, and GUI ABIs remain separately versioned work.

## Current direct-backend scope

The direct backend currently supports the freestanding primitive profile: integer/bool functions, locals, arithmetic, user calls, conditionals, while loops, range loops, break/continue, move expressions, and returns. Hosted strings, printing, pthread tasks, structs, arrays, and libc-backed services still use the C bootstrap backend.
