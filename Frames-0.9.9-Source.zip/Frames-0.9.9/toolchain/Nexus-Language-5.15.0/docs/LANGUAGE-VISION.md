# Nexus Language Vision

## Goal

Nexus should combine systems-level control with application-level productivity without forcing every program into one memory-management or runtime model.

The long-term target is a language capable of building:

- kernels and boot environments
- device drivers
- desktop and mobile applications
- backend services and distributed systems
- command-line tools
- game engines and games
- scientific/high-performance software
- embedded software
- WebAssembly modules
- Frames OS itself

## Proposed differentiators

These are **design targets**, not claims about 0.2.0.

### 1. Adaptive memory model

Nexus will aim to support several explicit ownership domains under one type system:

- `owned` — deterministic single-owner values
- `borrow` — checked temporary references
- `shared` — reference-counted shared ownership
- `arena` — region/arena lifetime allocation
- `raw` — explicit unsafe pointers for kernels/drivers

Normal code should get safety without a mandatory tracing garbage collector, while specialized software can choose the memory strategy that fits its workload.

### 2. Capability-first software

A future Nexus package should be able to declare capabilities such as:

```text
capability files.read;
capability network.client;
capability ui.window;
```

The compiler, package metadata, and operating system can then cooperate rather than treating permissions as an afterthought.

### 3. Structured concurrency

Async tasks, threads, actors, and parallel loops should share one cancellation/error model instead of becoming unrelated libraries.

### 4. Typed effects

Potentially dangerous or externally observable operations can eventually be represented in function contracts. This can make privileged OS code, networking, storage, and concurrency easier to audit.

### 5. Native ABI + portable IR

Nexus should compile to native machine code while retaining a stable Nexus IR that can support optimization, analysis, incremental compilation, and alternate targets.

### 6. First-class systems/application split

The language should recognize that kernels and GUI applications have different constraints while keeping one syntax and toolchain. Freestanding builds must not require the hosted standard library.

### 7. Predictable metaprogramming

Compile-time programming should be typed, deterministic, inspectable, and sandboxable rather than relying primarily on textual macros.

### 8. Integrated data-oriented programming

Nexus should make layout, alignment, SIMD-friendly structures, and explicit memory representation straightforward for games, graphics, databases, and kernels.

## Syntax direction

Nexus favors readable, low-noise syntax:

```nexus
fn distance(x: f64, y: f64) -> f64 {
    return sqrt(x * x + y * y);
}

fn main() -> i32 {
    let label = "Nexus";
    var total: i64 = 0;

    for i in 0..10 {
        total = total + i;
    }

    assert(total == 45, "math invariant failed");
    print(label);
    return 0;
}
```

The syntax is intentionally familiar. Nexus should be revolutionary because of its semantics, safety model, compiler, tooling, and cross-layer architecture—not because routine code is difficult to read.
