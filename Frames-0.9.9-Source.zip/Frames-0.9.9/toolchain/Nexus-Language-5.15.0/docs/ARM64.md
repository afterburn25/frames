# ARM64 Backend 3.5

The 3.5 backend is a freestanding primitive-profile AArch64 code generator. It supports integer/bool functions, up to eight register arguments, stack locals, arithmetic/comparison, direct calls, if/while/range loops, and FEX64/1 packaging. Aggregates, references, async runtime lowering, and SIMD are future parity work.
