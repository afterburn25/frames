# Nexus 5.0.0 — Frames Kernel Toolchain Generation 3

Adds kernel interrupt/runtime primitives needed for the next Frames milestones:
- `timer_stub_address()` with compiler-generated interrupt-preserving x86-64 timer entry and `iretq` return.
- enforced Nexus `fn kernel_timer_tick() -> void` handler contract.
- `thread_entry_stub_address()` and enforced `fn kernel_thread_entry() -> void` contract.
- `context_switch(old_rsp_slot, new_rsp)` backed by a compiler-generated x86-64 context switch helper that preserves flags and nonvolatile registers.
- retains the Nexus 4.9 page-fault exception ABI.
