# Nexus 1.2.0 — Tagged Data & Payload Enum Foundation

Nexus can now model typed success/error/state data directly in the language. Enum variants may carry one typed payload, and `match` arms can bind that payload with exhaustive checking.

This is the structural foundation for later generic `Option<T>` and `Result<T,E>` rather than pretending generic algebraic data types are complete before the generic type system exists.
