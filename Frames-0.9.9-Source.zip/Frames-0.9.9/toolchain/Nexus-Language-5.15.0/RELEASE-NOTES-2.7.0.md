# Nexus 2.7.0 — Typed Channels & Structured Task Communication

Adds generic `Channel<T>` values and blocking `send`, `recv`, and `close_channel` primitives backed by pthread mutex/condition variables. Channels are copyable handles to shared synchronized state and can be passed into async tasks. Channel operations participate in the `task` effect; creation also requires `alloc`.
