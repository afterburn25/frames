# Nexus 1.4.0 — Signed Frames Software & Trust Foundation

Nexus 1.4 makes the new Frames-native packaging model cryptographically verifiable. Frames bundles can be signed with Ed25519 publisher keys, inspected without installation, and rejected after payload tampering.

This release deliberately distinguishes **signature verification** from **publisher trust**: the compiler can prove which key signed a bundle, while the future Frames trust store will decide which keys or authorities the operating system trusts.
