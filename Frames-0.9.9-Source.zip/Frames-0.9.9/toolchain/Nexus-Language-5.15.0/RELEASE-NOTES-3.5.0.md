# Nexus 3.5.0 — ARM64 Native Backend Preview

Adds `ARM64FramesBackend`, `nexus emit-arm64`, and `--target frames-arm64`. Release tests assemble and package both Setup and a multi-function arithmetic/control-flow program as ARM64 FEX64/1 images and verify their architecture metadata and integrity.
