# Nexus 3.3.0 — Nexus PE Linker Foundation

Adds `NexusPELinker`, a deterministic minimal PE32+ linker for Nexus's single-COFF freestanding profile. Normal Frames x64 builds no longer invoke lld-link. Clang remains the assembler dependency.
