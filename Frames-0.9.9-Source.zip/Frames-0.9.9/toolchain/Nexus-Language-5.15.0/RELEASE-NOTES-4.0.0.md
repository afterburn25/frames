# Nexus 4.0.0 — Native Compiler Generation 1

- Established the x86-64 native-generation-1 support contract.
- Added nexus native-check for deterministic native support reporting.
- A single direct build can combine generic structs, tagged enums, scalar generic specialization, references, match, move/drop and defer without C translation.
- Frames FEX64 metadata now records COMPILER=native-gen1.
- The hosted C17 backend remains the broad reference implementation for features still outside generation 1.

## Native release tests

- `examples/native_gen1.nx`
