# Nexus 5.12.0 — 16-bit Kernel Port-I/O Foundation

- Adds freestanding kernel builtins `io_read16(port)` and `io_write16(port, value)`.
- Direct x86-64 kernel lowering uses `inw` / `outw` with the existing Nexus kernel calling conventions.
- Existing 8-bit and 32-bit port I/O remains unchanged.
- Added specifically to support correct ACPI PM1 control-register access in Frames.
