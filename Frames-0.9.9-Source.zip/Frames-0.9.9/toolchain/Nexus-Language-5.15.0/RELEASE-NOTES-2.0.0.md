# Nexus 2.0.0 — Ownership & Lifetime Core

Nexus 2.0 consolidates the post-1.5 memory-safety work into an explicit ownership/resource model. It adds `Owned<T>` heap ownership through `new(value)`, move-transfer that clears the old owner in generated C, explicit `drop`, function-scope LIFO `defer`, non-lexical borrow expiration, and inferred returned-reference provenance.

`defer` is intentionally function-scope in 2.0 and executes in LIFO order on explicit return/fallthrough. `Owned<T>` is available on the hosted bootstrap backend; full native-backend ownership lowering and reference-containing aggregate lifetimes remain post-2.0 work.
