# Nexus 1.3.0 — Borrowing & Non-Escaping Reference Foundation

Nexus 1.3 introduces safe, non-escaping references. Immutable references can alias; mutable references are unique for their lexical lifetime. Sources cannot be mutated or moved while a stored borrow is active.

The model is intentionally conservative. References cannot yet be returned from functions or stored inside structs/enums because doing so safely requires the later lifetime-parameter system.
