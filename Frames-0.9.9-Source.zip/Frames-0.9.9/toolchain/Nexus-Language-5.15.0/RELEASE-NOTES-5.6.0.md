# Nexus 5.6.0 — Frames AP Entry Address Foundation

- Adds `ap_entry_address()` to the freestanding x86-64 kernel profile.
- Requires `fn kernel_ap_entry(smp_state: u64) -> void` when used.
- Returns the native Nexus function address for use by a secondary-processor long-mode trampoline.
- Enables Frames to transition an AP from architecture bootstrap code into ordinary Nexus kernel code.
