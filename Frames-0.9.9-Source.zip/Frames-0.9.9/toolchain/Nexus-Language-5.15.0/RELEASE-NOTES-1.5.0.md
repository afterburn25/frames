# Nexus 1.5.0 — Generic Functions & Monomorphization Foundation

Nexus 1.5 introduces its first real generic compilation model. Generic function calls infer type parameters from statically known argument types. The hosted backend discovers required concrete instantiations, emits deterministic specialized functions, and routes calls to those specializations.

Generic aggregate types and traits are not represented as complete in this release. The purpose of 1.5 is to establish and verify the monomorphization machinery on which those features can be built.
