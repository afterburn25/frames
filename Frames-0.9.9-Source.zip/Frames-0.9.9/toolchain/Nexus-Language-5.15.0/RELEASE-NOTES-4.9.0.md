# Nexus 4.9.0 — Frames Exception ABI Foundation

- Adds `page_fault_stub_address()` to freestanding x86-64 kernel profiles.
- The compiler emits an x86-64 page-fault entry shim that captures the hardware error code, interrupted RIP, CR2 fault address, and RFLAGS.
- The shim calls a Nexus handler with the enforced signature:
  `fn kernel_page_fault(error: u64, rip: u64, fault_address: u64, rflags: u64) -> void`.
- Preserves Nexus 4.8 IDT and kernel tooling behavior.
