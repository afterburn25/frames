# Nexus 2.5.0 — Deterministic Resource Management

## Completed

- `Owned<T>` values are automatically freed at function/scope exit on the hosted backend.
- `Vector<T>` backing storage is automatically released.
- Explicit `drop` is cleanup-safe and prevents later double destruction.
- `defer` is block-scoped and executes LIFO before owned-resource destruction.
- Returning an owned resource transfers it out of cleanup instead of destroying it.

## Compatibility

This release preserves the Nexus 2.x source/toolchain compatibility direction and Frames ABI v1 metadata. Native Frames applications remain `.fex`; `.exe` remains reserved for future Windows compatibility.

## Scope boundary

The hosted C17 backend has the broadest language coverage. The direct Frames x64 backend remains intentionally smaller and does not yet have parity for the new high-level features in this release train.
