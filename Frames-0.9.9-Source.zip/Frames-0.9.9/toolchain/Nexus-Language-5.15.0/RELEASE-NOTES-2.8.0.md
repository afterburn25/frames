# Nexus 2.8.0 — Atomic Sharing & Data-Race Safety Foundation

Adds compiler-defined `Atomic<T>` integer handles with sequentially consistent load/store/add operations and a `shared` effect. Async call boundaries now enforce a Send-safe type policy: synchronized `Channel<T>` and `Atomic<T>` handles plus scalar value types may cross tasks, while references, `Owned<T>`, `Vector<T>`, and `Task<T>` are rejected.
