# Nexus 1.0.0 — Core Language & Frames ABI Foundation

## Release status

This release was built and tested as part of the Nexus 0.3 → 1.0 release train.

## Implemented

- Linear move expression and compile-time use-after-move rejection.
- nexus lint with unused-binding/mutability/effect-contract warnings.
- nexus doctor toolchain readiness report.
- nexus explain extended diagnostic explanations.
- Frozen Nexus 1.0 core language specification and 1.x compatibility policy.
- Automated release self-test covering hosted suite, negative semantic suite, Frames Setup.exe build, PE inspection, and ABI metadata verification.
- Honest implementation-status document separating shipped features from deferred generics, traits, borrowing/lifetimes, async/await, self-hosting, and additional targets.

## Verification

The included Nexus compiler and tests are the source of truth for implemented behavior. Features not present in the compiler/tests are not represented as complete.
