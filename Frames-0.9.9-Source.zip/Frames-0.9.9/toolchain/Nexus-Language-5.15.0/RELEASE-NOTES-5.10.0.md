# Nexus 5.10.0 — Frames Boot Module & Byte Memory Foundation

Adds Frames Kernel ABI 4 / `FramesBootInfoV4` acceptance plus kernel-safe `volatile_read8()` and `volatile_write8()` primitives. This release is used by Frames 0.0.33 for native FEX64 boot-module loading and byte-accurate executable copying. Existing Frames kernel ABIs 1–3 remain accepted.
