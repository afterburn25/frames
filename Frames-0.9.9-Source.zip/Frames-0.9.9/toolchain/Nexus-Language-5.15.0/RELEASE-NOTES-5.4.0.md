# Nexus 5.4.0 — Local APIC Spurious Interrupt Foundation

Adds `spurious_stub_address()` and a compiler-generated interrupt-preserving x86-64 spurious interrupt entry that invokes `kernel_spurious_interrupt() -> void` and returns with `iretq`.
