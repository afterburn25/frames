# Nexus 5.9.0 — Frames User Transition & Software Syscall ABI

- Adds `user_syscall_stub_address()` with a ring-3 interrupt entry that forwards RAX as a syscall number to `kernel_user_syscall(number: u64)`.
- Adds `user_enter(cr3, rip, rsp, return_slot)` for a controlled x86-64 `iretq` transition to the Frames user selectors.
- Adds `user_return(kernel_cr3, saved_rsp)` for the initial proof path back to a saved kernel continuation.
- These are bootstrap primitives for Frames process/ring-3 validation, not the final fast SYSCALL/SYSRET ABI.
