# Nexus 3.1.0 — NIR3 Control-Flow Foundation

This milestone upgrades NIR2 to NIR3 with deterministic AST-derived CFG metadata, explicit control-flow edges, a memory-SSA contract, stronger IR verification, and `NIR=3` Frames metadata. It intentionally does not claim full register SSA/phi construction yet.
