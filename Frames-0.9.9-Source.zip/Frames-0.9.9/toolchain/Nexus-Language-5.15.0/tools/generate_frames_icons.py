#!/usr/bin/env python3
from pathlib import Path
import io, json
import cairosvg
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets'/'file-icons'
OUT.mkdir(parents=True,exist_ok=True)

TYPES={
'fex':('.fex','#4D8DFF','executable'),'fapp':('.fapp','#17D9D2','application'),'fsetup':('.fsetup','#8B5CFF','installer'),
'fpkg':('.fpkg','#E49A52','package'),'flib':('.flib','#4CBAFF','library'),'fdrv':('.fdrv','#28C7E8','driver'),
'fsvc':('.fsvc','#397BFF','service'),'fmod':('.fmod','#27D5B4','module'),'ftheme':('.ftheme','#A66CFF','theme'),
'ficon':('.ficon','#18CFE6','icons'),'ffont':('.ffont','#9C62FF','font'),'fmanifest':('.fmanifest','#5D9EFF','manifest'),
'fupdate':('.fupdate','#24C7EE','update'),'fbackup':('.fbackup','#44B7F5','backup'),'frecovery':('.frecovery','#FF657A','recovery'),
'nx':('.nx','#6F63FF','nexus source')}

def glyph(kind,c):
    sw='stroke="%s" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" fill="none"'%c
    if kind=='fex': return f'<path d="M92 70 L156 54 L127 111 L173 102 L91 185 L112 125 L76 132 Z" fill="{c}" opacity=".95"/>'
    if kind=='fapp': return f'<path d="M128 54 L177 82 L177 139 L128 168 L79 139 L79 82 Z" {sw}/><path d="M79 82 L128 111 L177 82 M128 111 V168" {sw}/>'
    if kind=='fsetup': return f'<path d="M128 54 V129 M94 102 L128 136 L162 102" {sw}/><rect x="79" y="151" width="98" height="24" rx="12" fill="{c}"/>'
    if kind=='fpkg': return f'<path d="M76 88 L128 60 L180 88 L128 116 Z" fill="{c}" opacity=".9"/><path d="M76 88 V151 L128 181 L180 151 V88 M128 116 V181" {sw}/>'
    if kind=='flib': return f'<rect x="72" y="64" width="112" height="28" rx="8" fill="{c}"/><rect x="72" y="105" width="112" height="28" rx="8" fill="{c}" opacity=".78"/><rect x="72" y="146" width="112" height="28" rx="8" fill="{c}" opacity=".56"/>'
    if kind=='fdrv': return f'<rect x="87" y="70" width="82" height="82" rx="13" {sw}/><rect x="108" y="91" width="40" height="40" rx="6" fill="{c}"/><path d="M72 86H55 M72 108H55 M72 130H55 M184 86H201 M184 108H201 M184 130H201 M104 55V42 M128 55V42 M152 55V42 M104 167V184 M128 167V184 M152 167V184" {sw}/>'
    if kind=='fsvc': return f'<circle cx="112" cy="108" r="34" {sw}/><circle cx="112" cy="108" r="9" fill="{c}"/><circle cx="159" cy="148" r="25" {sw}/><circle cx="159" cy="148" r="7" fill="{c}"/><path d="M112 60V47 M112 169V156 M64 108H51 M173 108H160 M78 74L69 65 M155 151L166 162" {sw}/>'
    if kind=='fmod': return f'<path d="M87 72 H118 C118 54 146 54 146 72 H176 V104 C194 104 194 132 176 132 V165 H143 C143 183 115 183 115 165 H87 V135 C69 135 69 107 87 107 Z" fill="{c}" opacity=".9"/>'
    if kind=='ftheme': return f'<path d="M128 56 C82 56 57 85 57 119 C57 156 89 178 123 178 H138 C151 178 157 163 148 154 C141 147 143 136 158 134 C180 131 195 111 193 91 C190 68 162 56 128 56 Z" {sw}/><circle cx="91" cy="102" r="9" fill="{c}"/><circle cx="117" cy="82" r="9" fill="{c}"/><circle cx="147" cy="84" r="9" fill="{c}"/>'
    if kind=='ficon': return f'<rect x="66" y="62" width="124" height="105" rx="13" {sw}/><circle cx="102" cy="94" r="12" fill="{c}"/><path d="M76 152 L110 119 L132 139 L151 120 L180 152" {sw}/>'
    if kind=='ffont': return f'<path d="M78 68H178 M128 68V171 M97 171H159" {sw}/>'
    if kind=='fmanifest': return f'<path d="M83 55H148L178 85V177H83Z" {sw}/><path d="M148 55V85H178 M103 111H156 M103 136H156" {sw}/><path d="M104 157 L116 169 L143 145" {sw}/>'
    if kind=='fupdate': return f'<path d="M79 103 C89 70 128 56 159 72 C174 80 184 94 188 109 M188 109 L168 96 M188 109 L194 87 M177 135 C164 166 126 178 96 162 C82 154 72 141 68 126 M68 126 L89 139 M68 126 L62 148" {sw}/>'
    if kind=='fbackup': return f'<ellipse cx="128" cy="73" rx="54" ry="22" fill="{c}"/><path d="M74 73V111 C74 123 98 133 128 133 C158 133 182 123 182 111V73 M74 112V150 C74 162 98 172 128 172 C158 172 182 162 182 150V112" {sw}/>'
    if kind=='frecovery': return f'<circle cx="128" cy="115" r="58" {sw}/><circle cx="128" cy="115" r="25" {sw}/><path d="M92 70L111 94 M164 70L145 94 M92 160L111 136 M164 160L145 136" {sw}/>'
    if kind=='nx': return f'<path d="M73 167V64 L128 129 L183 64 V167" {sw}/><path d="M73 64L183 167" stroke="{c}" stroke-width="9" stroke-linecap="round"/>'
    return ''

def svg(kind,ext,color):
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#18213C"/><stop offset="1" stop-color="#080D1B"/></linearGradient><filter id="s" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="8" stdDeviation="8" flood-color="#000" flood-opacity=".45"/></filter></defs>
<g filter="url(#s)"><path d="M48 20H162L208 66V220C208 230 200 238 190 238H48C38 238 30 230 30 220V38C30 28 38 20 48 20Z" fill="url(#g)" stroke="{color}" stroke-width="4"/><path d="M162 20V66H208" fill="#26365D" stroke="{color}" stroke-width="4" stroke-linejoin="round"/><path d="M43 35H54V211H43Z" fill="{color}" opacity=".86"/></g>
<g>{glyph(kind,color)}</g>
<rect x="54" y="194" width="130" height="31" rx="10" fill="#050812" opacity=".9"/><text x="119" y="216" fill="#F4F7FF" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="19" text-anchor="middle">{ext}</text>
</svg>'''

registry={"version":1,"family":"Frames Native File Icons","generated_by":"Nexus 1.1.0","icons":{}}
for kind,(ext,color,desc) in TYPES.items():
    text=svg(kind,ext,color)
    (OUT/f'{kind}.svg').write_text(text,encoding='utf-8')
    png=cairosvg.svg2png(bytestring=text.encode(),output_width=256,output_height=256)
    (OUT/f'{kind}.png').write_bytes(png)
    base=Image.open(io.BytesIO(png)).convert('RGBA')
    base.save(OUT/f'{kind}.ico',format='ICO',sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)])
    registry['icons'][ext]={"name":kind,"description":desc,"svg":f"{kind}.svg","png":f"{kind}.png","ico":f"{kind}.ico"}
(OUT/'icons.json').write_text(json.dumps(registry,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(f'generated {len(TYPES)} Frames/Nexus icon sets in {OUT}')
