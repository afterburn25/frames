#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p build
./nexus kernel check examples/frames_kernel/kernel.nx
./nexus kernel build examples/frames_kernel/kernel.nx -o build/FramesKernel.fkrn
./nexus kernel inspect build/FramesKernel.fkrn
./nexus inspect build/FramesKernel.fkrn
for f in kernel_negative_tests/*.nx; do
  if ./nexus kernel check "$f" >/tmp/nexus-kernel-neg.out 2>&1; then
    echo "FAIL: expected rejection: $f" >&2
    exit 1
  fi
  echo "PASS expected rejection: $f"
done
./nexus filetypes | grep -q '^.fkrn'
echo "Nexus kernel self-test: PASS"
