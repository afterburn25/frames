# Nexus 5.2.0 — Kernel CPU Discovery & Timing Foundation

Adds freestanding x86-64 kernel intrinsics `cpuid_eax`, `cpuid_ebx`, `cpuid_ecx`, `cpuid_edx`, and `read_tsc`. CPUID preserves RBX so generated kernel functions remain ABI-safe.
