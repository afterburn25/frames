# Nexus 4.8.0 — Frames Interrupt Table Foundation

- `interrupt_stub_address()` exposes a compiler-generated x86-64 emergency interrupt halt stub.
- `load_idt(base, limit)` emits a freestanding `lidt`.
- Kernel builds append a catch-all stub that disables interrupts and halts permanently.
- Frames Kernel ABI 1/2 compatibility is preserved.
