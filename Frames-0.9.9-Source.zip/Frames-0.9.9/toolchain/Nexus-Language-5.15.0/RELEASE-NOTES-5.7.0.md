# Nexus 5.7.0 — Frames Reschedule IPI ABI

- Adds `reschedule_stub_address()` to the freestanding x86-64 kernel profile.
- Requires `fn kernel_reschedule_ipi() -> void` when the intrinsic is used.
- Emits an interrupt-preserving x86-64 entry stub that invokes the Nexus handler and returns with `iretq`.
- Intended for Frames cross-CPU wakeup/reschedule IPIs; LAPIC EOI remains explicit in Nexus kernel code.
