# Nexus 3.2.0 — Direct x64 Reference Lowering

The direct Frames x64 backend can now lower safe scalar references and mutable references end-to-end, including borrowing locals, passing references to functions, dereference reads, and dereference assignment.
