# Nexus 4.5.0

**Frames Kernel Build Tooling**

Adds the complete `nexus kernel check|build|inspect` workflow producing and verifying `FramesKernel.fkrn` from Nexus source.

## Kernel quick start

```bash
./nexus kernel check examples/frames_kernel/kernel.nx
./nexus kernel build examples/frames_kernel/kernel.nx -o build/FramesKernel.fkrn
./nexus kernel inspect build/FramesKernel.fkrn
```

Nexus remains a general-purpose language; this release adds the freestanding toolchain needed to bootstrap the independent Frames kernel.
