# Nexus 5.3.0 — Frames Kernel ABI 3 / ACPI Handoff Foundation

Adds `frames_3` kernel ABI support and typed `FramesBootInfoV3` kernel entry acceptance while retaining Frames ABI 1/2 compatibility. ABI 3 is reserved for the UEFI-to-kernel ACPI RSDP handoff used by Frames 0.0.17.
