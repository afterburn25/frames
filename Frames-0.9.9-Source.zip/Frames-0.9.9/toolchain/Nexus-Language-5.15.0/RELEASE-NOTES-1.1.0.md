# Nexus 1.1.0 — Frames Native Application Ecosystem & File Identity

Nexus 1.1 is the first post-1.0 release and makes a deliberate platform break from Windows naming conventions without breaking the Nexus 1.x source-language core.

## Native software identity

Frames-native x86-64 builds now default to `.fex`. A `.fex` is verified by its Nexus/Frames metadata, not by filename alone. `.exe` is reserved for Windows-compatible applications.

The initial native registry also defines `.fapp`, `.fsetup`, `.fpkg`, `.flib`, `.fdrv`, `.fsvc`, `.fmod`, `.ftheme`, `.ficon`, `.ffont`, `.fmanifest`, `.fupdate`, `.fbackup`, and `.frecovery`.

## FramesBundle/1

`nexus package` now turns a Nexus project into `.fapp`, `.fsetup`, or `.fpkg`. The deterministic container includes `frames.json`, a compiled `.fex`, optional application icon resources, and SHA-256 integrity metadata.

The integrity metadata detects modification but is not yet a publisher signature. Public-key signing and trust-store policy remain a subsequent security milestone.

## Original file icons

Nexus 1.1 ships an original Frames file-icon family for all registered extensions. Each icon is supplied as vector SVG, 256px transparent PNG, and multi-resolution ICO. These are intended to become the default Frames shell associations later.

## Compatibility

The 1.0 hosted language suite and semantic-negative suite remain passing. Nexus 1.1 changes Frames artifact naming and packaging; it does not remove 1.0 source syntax.
