# Nexus 3.4.0 — Native FEX64 Container

Adds FEX64/1 with the `FEX64` magic, Frames ABI and architecture fields, entry offset, code/metadata sections, and SHA-256 payload integrity. Frames x64 builds and packaged `.fsetup` payloads now use FEX64/1 by default; PE-FEX remains a compatibility target.
