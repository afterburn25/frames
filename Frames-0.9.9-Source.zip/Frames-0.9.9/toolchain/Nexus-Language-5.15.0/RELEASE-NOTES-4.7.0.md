# Nexus 4.7.0 — Frames Kernel ABI 2 & Bootstrap Memory Support

- Adds Frames Kernel ABI 2 selection (`abi: frames_2`).
- Supports typed `kernel_main(info: &FramesBootInfoV2)`.
- FKRN64 header now records kernel ABI 2 when selected.
- Kernel metadata records the selected ABI and `kernel-gen2`.
- Retains ABI 1 source/build compatibility.
