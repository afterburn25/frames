# Nexus 5.14.0 — Frames Syscall ABI v1 Stub

- Expands the Frames ring-3 `int 0x80` kernel bridge to four u64 inputs: syscall number plus three arguments.
- Requires `kernel_user_syscall(number,arg0,arg1,arg2) -> u64`.
- Restores the returned u64 into the saved user RAX before `iretq`.
- Preserves the existing interrupt-frame and kernel/user return machinery.
