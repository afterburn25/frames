# Nexus 5.1.0 — Kernel CPU State Access

Adds freestanding x86-64 MSR access for Frames kernel runtime work:
- `read_msr(msr: u64) -> u64`
- `write_msr(msr: u64, value: u64) -> void`

Frames uses this initially for an IA32_GS_BASE scheduler-state anchor during cooperative context switching.
