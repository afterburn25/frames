# Nexus 3.0.0 — NIR2 & Native Backend Expansion

Nexus 3.0 introduces the versioned NIR2 contract (`nir.version 2`, portable target metadata, explicit entry basic blocks) and a `nexus verify-ir` structural verifier. The direct Frames x64 backend expands beyond the primitive-only preview to support compile-time constants, payloadless enums, enum values, and exhaustive payloadless enum `match` lowering, and marks generated FEX metadata with `NIR=2`.

The hosted C17 backend still has broader language coverage; 3.0 is a native-backend transition milestone, not a claim of full backend parity or self-hosting.
