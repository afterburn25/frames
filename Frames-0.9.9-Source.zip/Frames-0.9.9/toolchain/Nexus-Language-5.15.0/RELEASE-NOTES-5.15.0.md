# Nexus 5.15.0 — Frames SMAP Access-Control Intrinsics

- Adds freestanding kernel intrinsics `stac()` and `clac()`.
- Direct x86-64 lowering emits STAC/CLAC with no hosted runtime dependency.
- Intended for Frames' bounded user-copy paths when CR4.SMAP is enabled after CPUID gating.
