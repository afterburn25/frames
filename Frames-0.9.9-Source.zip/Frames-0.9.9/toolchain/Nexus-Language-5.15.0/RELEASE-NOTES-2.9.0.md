# Nexus 2.9.0 — Capability Security & Effect Contracts v2

Adds module-level `capabilities(...)` declarations, privileged effect enforcement for network/filesystem/process/device/graphics/audio/storage/boot/system, `use_capability()` and `has_capability()` compiler intrinsics, NIR capability metadata, and Frames `.nxmeta` capability emission. Privileged effects cannot be performed unless both the function effect set and application capability declaration permit them.
