# Nexus 4.5.0 — Frames Kernel Build Tooling

Adds the complete `nexus kernel check|build|inspect` workflow producing and verifying `FramesKernel.fkrn` from Nexus source.

## Frames direction

This release is part of the Nexus kernel-toolchain train for the independent **Frames** operating system. The kernel target is freestanding and does not depend on Windows or Linux userspace.
