# Nexus 5.5.0 — Frames Local APIC Timer ABI

- Adds `lapic_timer_stub_address()` to the freestanding x86-64 kernel profile.
- Requires `fn kernel_lapic_timer_tick() -> void` when used.
- Compiler emits a dedicated interrupt-preserving LAPIC timer entry that returns with `iretq`.
- Keeps legacy `timer_stub_address()` intact for PIT/PIC fallback and calibration.
