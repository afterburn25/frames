from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
NEXUS = ROOT / "nexus"

CASES = [
    (
        "immutable assignment",
        'fn main() -> i32 { let x = 1; x = 2; return 0; }',
        "cannot assign to immutable binding",
    ),
    (
        "bad if condition",
        'fn main() -> i32 { if 1 { print("bad"); } return 0; }',
        "if condition must be bool",
    ),
    (
        "wrong function argument",
        'fn f(x: str) -> i32 { return 0; } fn main() -> i32 { f(9); return 0; }',
        "expects str, got i64",
    ),
    (
        "break outside loop",
        'fn main() -> i32 { break; return 0; }',
        "break used outside a loop",
    ),
    (
        "use after move",
        'fn main() -> i32 { let x = "owned"; let y = move x; print(x); return 0; }',
        "use of moved value",
    ),
    (
        "missing enum payload",
        'enum R { Ok(i64), Empty } fn main() -> i32 { let x = R::Ok; return 0; }',
        "requires payload type i64",
    ),
    (
        "wrong enum payload",
        'enum R { Ok(i64), Empty } fn main() -> i32 { let x = R::Ok("bad"); return 0; }',
        "expects i64, got str",
    ),
    (
        "bind payloadless variant",
        'enum R { Ok(i64), Empty } fn main() -> i32 { let x = R::Empty; match x { R::Ok(v) => { print(v); }, R::Empty(v) => { print(v); }, } return 0; }',
        "has no payload to bind",
    ),
    (
        "assign while borrowed",
        'fn main() -> i32 { var x = 1; let view = &x; x = 2; print(*view); return 0; }',
        "cannot assign to 'x' while it is borrowed",
    ),
    (
        "duplicate mutable borrow",
        'fn main() -> i32 { var x = 1; let a = &mut x; let b = &mut x; print(*a); return 0; }',
        "cannot mutably borrow 'x' while it is already borrowed",
    ),
    (
        "copy mutable reference",
        'fn main() -> i32 { var x = 1; let a = &mut x; let b = a; return 0; }',
        "cannot be copied; use move",
    ),
    (
        "return local reference",
        'fn bad() -> &i64 { let x = 1; return &x; } fn main() -> i32 { return 0; }',
        "needs a reference parameter",
    ),
    (
        "generic argument conflict",
        'fn choose<T>(a: T, b: T) -> T { return a; } fn main() -> i32 { let x = choose(1, "bad"); return 0; }',
        "does not match T",
    ),
    (
        "uninferable generic parameter",
        'fn make<T>() -> T { return 0; } fn main() -> i32 { return 0; }',
        "must be inferable from parameters",
    ),
    (
        "unsatisfied trait constraint",
        'trait Addable {} impl Addable for i64; fn twice<T: Addable>(x: T) -> T { return x + x; } fn main() -> i32 { let x = twice("bad"); return 0; }',
        "requires str: Addable",
    ),
    (
        "try outside result function",
        'fn f() -> Result<i64,i64> { return Result<i64,i64>::Ok(1); } fn main() -> i32 { let x = f()?; return 0; }',
        "requires return type Result",
    ),
    (
        "use after drop",
        'fn main() -> i32 { let x = 1; drop x; print(x); return 0; }',
        "use of moved value",
    ),
    (
        "drop borrowed value",
        'fn main() -> i32 { var x = 1; let r = &x; drop x; print(*r); return 0; }',
        "cannot drop 'x' while it is borrowed",
    ),
    (
        "pure allocation",
        'pure fn f() -> i32 { let x = new(1); drop x; return 0; } fn main() -> i32 { return f(); }',
        "pure function cannot perform effect 'alloc'",
    ),
    (
        'vector push type mismatch',
        'fn main() -> i32 effects(alloc) { var v = vector([1,2]); push(&mut v, "bad"); return 0; }',
        'push() expects i64, got str',
    ),

    (
        'foreach scalar',
        'fn main() -> i32 { let x = 1; for item in x { print(item); } return 0; }',
        'for-each requires Vector<T> or array',
    ),

    (
        'missing trait method',
        'trait D { fn show(value: Self) -> str; } impl D for i64 { } fn main() -> i32 { return 0; }',
        'missing method(s): show',
    ),

    (
        'aggregate reference escape',
        'struct V { item: &i64 } fn bad() -> V { let x = 1; return V { item: &x }; } fn main() -> i32 { return 0; }',
        'must source field item from a reference parameter',
    ),

    (
        'return inside defer',
        'fn main() -> i32 { defer { return 1; } return 0; }',
        'defer body cannot contain return or nested defer',
    ),

    (
        "async non-Send reference",
        'async fn bad(x: &i64) -> i64 effects() { return *x; } fn main() -> i32 effects(task) { let x = 1; let t = bad(&x); return 0; }',
        "is not Send-safe",
    ),
    (
        "undeclared privileged capability",
        'fn f() -> i32 effects(network) { use_capability("network"); return 0; } fn main() -> i32 { return 0; }',
        "capability 'network' is not declared",
    ),
]

for label, source, expected in CASES:
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "case.nx"
        p.write_text(source, encoding="utf-8")
        r = subprocess.run([str(NEXUS), "check", str(p)], text=True, capture_output=True)
        assert r.returncode != 0, f"{label}: expected failure"
        assert expected in r.stderr, f"{label}: expected {expected!r}, got {r.stderr!r}"
        print(f"PASS: {label}")
