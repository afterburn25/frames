# Frames 0.9.35 Runtime Certification Kit v30

Gate 4: **Disposable System-Volume Filesystem Write Certification**

Sealed source SHA-256:

`fe42480d94a7b883763ab41897d0dfabe8d5ee7610764cde44703357f204520a`

Workflow SHA-256:

`eb3f7a1c2ae1efecba44b65d1a7ea2e440f69365ba2ee569c1bc32292142a2dd`

## Safety model

The real Frames boot ESP remains read-only.

v30 creates a separate full 64 MiB clone of the current Frames GPT/FAT32
system/ESP volume and attaches it as a second NVMe controller whose serial must
be exactly `FRAMESSYS0935`.

The clone contains one preallocated certification file, `SYSWRITE.TST`, backed
by two already-allocated FAT32 clusters. Frames' Gate-4 write API accepts only
three exact LBAs:

1. the directory sector containing `SYSWRITE.TST`;
2. preallocated data cluster A;
3. preallocated data cluster B.

GPT, FAT tables, FAT32 boot sector, BOOTX64.EFI, FramesKernel.fkrn,
System.fex, BOOTSTAT.TXT, and the actual boot disk are outside that write API.

## Required runtime proof

- all accepted 0.9.34 baseline/lifecycle/filesystem gates remain PASS;
- `FRAMES_SYSTEM_VOLUME_CLONE_FOUND`;
- `FRAMES_SYSTEM_VOLUME_FAT_OK`;
- 64 alternating file-data/directory-metadata transactions;
- exactly 131 NVM writes and 131 NVM flushes including restoration;
- `FRAMES_SYSTEM_VOLUME_FILE_WRITE_OK`;
- `FRAMES_SYSTEM_VOLUME_METADATA_OK`;
- `FRAMES_SYSTEM_VOLUME_GUARDS_OK`;
- `FRAMES_SYSTEM_VOLUME_RESTORE_OK`;
- `FRAMES_SYSTEM_VOLUME_WRITE_CERT_OK`;
- no `FRAMES_SYSTEM_VOLUME_WRITE_CERT_FAIL`;
- full 64 MiB clone returns byte-for-byte to its pristine SHA-256;
- final `FRAMES_KERNEL_READY` is observed before QMP quit.

Expected artifact name:

`frames-0.9.35-system-volume-evidence-v30`

Physical-machine writes, actual boot-volume writes, FAT allocation/freeing,
physical boot, and Frames 1.0 remain blocked.
