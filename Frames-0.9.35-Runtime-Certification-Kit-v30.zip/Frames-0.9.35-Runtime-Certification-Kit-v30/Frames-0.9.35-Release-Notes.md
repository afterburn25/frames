# Frames 0.9.35 — Disposable System-Volume Filesystem Write Certification Gate 4

## Baseline

Built from externally accepted Frames 0.9.34 Gate 3. The 70-marker runtime contract, 8/8 stress/fault matrix, sacrificial raw NVMe write path, destructive reboot/S5 lifecycle certification, and sacrificial crash-consistent filesystem path are retained unchanged.

## Gate 4 scope

- Adds a disposable 64 MiB clone of the current Frames GPT/FAT32 ESP/system volume.
- The actual boot ESP remains attached read-only.
- The writable clone must identify as `FRAMESSYS0935`.
- Before arming writes, Frames independently performs GPT discovery and the existing FAT32 boot-volume mount checks on the clone, including discovery/validation of the Frames directory, System.fex, and BOOTSTAT.TXT.
- The clone generator preallocates `SYSWRITE.TST` with two FAT32 clusters. Both FAT chains are already allocated and remain untouched at runtime.
- Runtime write API is an exact three-LBA allowlist: one directory sector plus the two test data clusters. Generic bounded-write certification remains disabled for this target.

## Mutation workload

Frames performs 64 alternating copy-on-write-style file updates. Every cycle:

1. reads and validates the `SYSWRITE.TST` directory entry;
2. writes a deterministic 512-byte generation to the inactive preallocated cluster;
3. issues NVM Flush;
4. reads back and checks the full data checksum/header/generation;
5. changes the FAT32 directory entry to point at the newly written cluster;
6. flushes the directory sector;
7. rereads the directory sector and validates cluster/size metadata.

The workload must produce exactly 131 NVM Write commands and 131 NVM Flush commands including final restoration.

## Restoration and guards

At completion Frames restores cluster A to its pristine generation-0 bytes, zeros cluster B, restores the directory entry to cluster A, re-runs GPT/FAT/system-file discovery, revalidates both preallocated FAT chains as EOC, and verifies the certification entry. The host then requires the entire 64 MiB clone to be byte-identical to its pristine pre-run copy.

## Runtime markers

- `FRAMES_SYSTEM_VOLUME_CLONE_FOUND`
- `FRAMES_SYSTEM_VOLUME_FAT_OK`
- `FRAMES_SYSTEM_VOLUME_FILE_WRITE_OK`
- `FRAMES_SYSTEM_VOLUME_METADATA_OK`
- `FRAMES_SYSTEM_VOLUME_GUARDS_OK`
- `FRAMES_SYSTEM_VOLUME_RESTORE_OK`
- `FRAMES_SYSTEM_VOLUME_WRITE_CERT_OK`
- fatal: `FRAMES_SYSTEM_VOLUME_WRITE_CERT_FAIL`

## Explicitly not certified

- writes to the actual boot/system NVMe;
- FAT allocation/freeing on the system clone;
- arbitrary system-file replacement;
- physical-machine disk writes;
- physical boot;
- Frames 1.0 promotion.
