# Frames 0.9.13 Runtime Certification Kit

Place `Frames-0.9.13-Source.zip` at the repository root and install `Frames-0.9.13-GitHub-Runtime-Certification.yml` as `.github/workflows/frames-runtime-certify.yml`.

Run the workflow and upload the resulting `frames-runtime-evidence` artifact back to ChatGPT for analysis.
