# Frames 0.9.36 Gate-5 v31 Evidence Analysis

## Decision

**REJECTED — Gate 5 did not arm.**

Frames 0.9.35 remains the externally certified authoritative baseline.

Uploaded evidence SHA-256:

`1589c8df479077261aea95dacfd8892374371eeb289e30bb4784ed2d47bf5dc3`

## What passed

The v31 run reached QEMU and successfully re-proved the inherited certification chain:

- 70/70 base runtime markers;
- 8/8 stress/fault categories;
- raw sacrificial NVMe write/integrity Gate 1;
- destructive reboot/S5 Gate 2;
- crash-consistent sacrificial filesystem Gate 3;
- disposable system-volume write Gate 4.

The dedicated Gate-5 QEMU process itself exited `0`.

## Gate-5 failure

`FAT-LIFECYCLE-CERTIFY-EXIT-CODE.txt` = `1`.

`FAT-LIFECYCLE-EVIDENCE.json` = `FAIL`.

All Gate-5 lifecycle markers were absent, including:

- `FRAMES_FAT_LIFECYCLE_TARGET_FOUND`
- `FRAMES_FAT_CREATE_OK`
- `FRAMES_FAT_GROW_OK`
- `FRAMES_FAT_TRUNCATE_OK`
- `FRAMES_FAT_RENAME_OK`
- `FRAMES_FAT_DELETE_OK`
- `FRAMES_FAT_REALLOC_OK`
- `FRAMES_FAT_MIRROR_OK`
- `FRAMES_FAT_RESTORE_OK`
- `FRAMES_FAT_LIFECYCLE_CERT_OK`

The serial instead emitted:

`FRAMES_STORAGE_WRITE_DIAG stage=0x00000000000000FF detail=0x000000000000033D`

followed by:

`FRAMES_STORAGE_WRITE_INTEGRITY_FAIL`

`0x33D` is decimal `829`, matching the fail-closed `storage_write_fail(829)` routing path.

The FAT lifecycle media remained completely unchanged, which is why
`FAT-LIFECYCLE-MEDIA.json` correctly reports PASS and byte-identical restoration.
No Gate-5 writes occurred.

## Root cause

`nvme_fat_lifecycle_target_arm()` stored descriptor-derived cluster/LBA context in
a scratch region named `ctx`.

It then called `fat_lifecycle_sector_pristine()` with overlapping scratch memory.
That function uses `scratch+4096` for the second FAT mirror, which aliases and
overwrites `ctx`.

The subsequent four-pool validation loop then read the overwritten FAT-sector
bytes as if they were the saved cluster/LBA context. Gate 5 therefore returned
unarmed and fell into the generic fail-closed storage rejection path.

## v32 fix

- Pool validation now uses the preserved local `c0..c3` and `l0..l3` values and
  never rereads the clobbered `ctx` memory after the mirror-pristine call.
- The UEFI loader banner is corrected from `FRAMES 0.9.35` to `FRAMES 0.9.36`.
- `fat_lifecycle_evidence.py` now treats inherited storage/filesystem/lifecycle/
  stress/runtime fatal markers as Gate-5 failures, including
  `FRAMES_STORAGE_WRITE_INTEGRITY_FAIL`.
- The source verifier explicitly rejects reintroduction of the scratch-alias loop.

No certification requirement was weakened.
