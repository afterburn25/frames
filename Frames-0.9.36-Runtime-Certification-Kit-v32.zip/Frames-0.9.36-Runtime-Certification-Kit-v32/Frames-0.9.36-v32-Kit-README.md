# Frames 0.9.36 Runtime Certification Kit v32

This is the Gate-5 runtime hotfix after the v31 QEMU run exposed a scratch-memory
alias in `nvme_fat_lifecycle_target_arm()`.

Sealed source SHA-256:

`aded1ac2783840a1872f06c9ea12033cdd16fa6f53d78e8505985549b48da956`

Workflow SHA-256:

`ee56a4975a4303ea094dce2a0022231ea959de0fdeaeab596dae2b9d97b0a41f`

The FAT lifecycle contract is unchanged:
- target serial `FRAMESFAT0936`;
- exact seven-LBA write allowlist;
- create / grow / truncate / rename / delete / reallocate / restore;
- 7 phases;
- exactly 47 NVM writes;
- exactly 33 NVM flushes;
- exactly 14 mirrored FAT updates;
- full 64 MiB clone byte-identical after restoration.

v32 changes only the implementation/evidence correctness needed for that contract:
- fixes scratch-context clobber before target arming;
- fixes UEFI version banner;
- rejects inherited fatal markers in Gate-5 evidence.

Expected evidence artifact:

`frames-0.9.36-fat-lifecycle-evidence-v32`
