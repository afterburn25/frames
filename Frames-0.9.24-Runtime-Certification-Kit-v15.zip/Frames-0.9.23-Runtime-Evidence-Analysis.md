# Frames 0.9.23 Runtime Evidence Analysis

External GitHub Actions QEMU/OVMF confirmation is a clean PASS.

- Frames version: 0.9.23
- Nexus: 5.20.0
- Required runtime markers: 70 expected / 70 present / 0 missing
- Fatal markers: 0
- qemu_certify.sh exit code: 0
- Runtime evidence status: PASS
- core/platform/smp/userspace/storage_nvme/safety: all PASS
- read-only NVMe profile: PASS
- persistent write path: not certified
- physical boot approved: false
- serial SHA-256: `31175e69a7826a42c20ca64b585c8713225188f69734a43977e8b7108fd9fd13`

Nexus 5.20 short-circuit runtime confirmation:
- `FRAMES_RESCHED_IPI_OK` present
- `FRAMES_RESCHED_FALLBACK_SENT` absent
- `SHORT-CIRCUIT-RUNTIME.json`: PASS
- eager_rhs_after_ack: false

The complete AP/SMP return and reschedule chain remains present through `FRAMES_SMP_SCHEDULER_OK`, and `FRAMES_KERNEL_READY` is present. No AP protection fault or page fault occurred.

Conclusion: Frames 0.9.23 is the clean externally verified QEMU runtime baseline. The next certification lane is the separate eight-category stress/fault plan; this result does not promote Frames 1.0 and does not approve physical boot.
