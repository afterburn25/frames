# Frames 0.9.24 Allocator Stress Certification Kit v15

This kit begins the fail-closed eight-category stress/fault certification train from the externally verified Frames 0.9.23 clean QEMU runtime baseline.

Upload this ZIP to the GitHub repository root and use `Frames-0.9.24-GitHub-Stress-Certification-v15.yml` as the active workflow.

A successful phase-1 run must preserve the existing 70/70 runtime marker gate and also produce `FRAMES_STRESS_ALLOCATOR_OK`. `STRESS-EVIDENCE.json` must report allocator PASS, seven categories NOT-EXECUTED, and Frames 1.0 not promoted.

Physical boot remains BLOCKED. Persistent media writes remain absent/uncertified.
