# Frames 0.9.24 — Allocator Stress/Fault Certification Phase 1

Frames 0.9.23 externally reconfirmed the full QEMU/OVMF runtime lane (70/70, 0 fatal, exit 0). 0.9.24 begins the required eight-category stress/fault plan with allocator category 1.

The allocator runtime test:
1. allocates and memory-verifies 64 sequential physical pages;
2. verifies cursor/free/used accounting and allocator invariants;
3. constructs an isolated 16 KiB guarded kernel heap, performs 31×512-byte allocations plus a final 480-byte allocation to exactly consume its usable region, then requires a further allocation to fail;
4. verifies zero-size and >heap-size requests fail;
5. verifies both heap guard canaries after exhaustion;
6. constructs an isolated 64-record DMA ledger and requires record 65 to be rejected.

`FRAMES_STRESS_ALLOCATOR_OK` is emitted only after all checks pass. `FRAMES_STRESS_ALLOCATOR_FAIL` is fail-closed stress evidence. The existing 70-marker runtime contract is unchanged. Frames 1.0 remains blocked.
