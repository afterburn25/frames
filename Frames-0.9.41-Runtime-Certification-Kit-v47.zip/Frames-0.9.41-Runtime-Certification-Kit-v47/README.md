# Frames 0.9.41 Runtime Certification Kit v47

This kit contains the direct Unit Attention recovery repair for the native USB
mass-storage certification path.

Use `Frames-0.9.41-GitHub-Native-USB-Mass-Storage-Certification-v47.yml` as:

`.github/workflows/frames-0.9.41-native-usb-msc-v47.yml`

Keep `Frames-0.9.41-Source-v47.zip` available in the repository. The workflow is pinned to:

`18e05ff200afdb5c3ef1e8e0d13c61a8f01179c5f0103707876c93a63aa111a2`

Run the workflow and download:

`frames-0.9.41-native-usb-storage-evidence-v47`

Upload that evidence ZIP for certification review.

Do not promote Frames 0.9.41 before that external run passes.
Frames 0.9.40 v41 remains the certified fallback.
