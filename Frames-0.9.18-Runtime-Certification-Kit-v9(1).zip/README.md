# Frames 0.9.18 Runtime Certification Kit

Use this kit for the next GitHub Actions QEMU/OVMF run.

Repository root:
- `Frames-0.9.18-Source.zip` (or this complete runtime kit ZIP)

Workflow:
- copy `Frames-0.9.18-GitHub-Runtime-Certification-v9.yml` to `.github/workflows/frames-runtime-certify.yml` (the filename may differ; contents matter).

The v9 workflow is strict to Frames 0.9.18 and validates the sealed source SHA before extraction.

Expected final missing markers to test:
- `FRAMES_RESCHED_IPI_OK`
- `FRAMES_CPU_AFFINITY_OK`
- `FRAMES_SMP_SCHEDULER_OK`

Upload `frames-0.9.18-runtime-evidence` back to ChatGPT even if the Action is red.

Physical boot remains blocked and Frames 1.0 is not promoted by this package.
