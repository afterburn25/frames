# Frames 0.9.17 v8 Runtime Evidence Analysis

## Result

Frames 0.9.17 executed under GitHub Actions QEMU/OVMF using the CI-hardened v8 workflow.

- Required markers: 70
- Present: 67
- Missing: 3
- Fatal markers: 0
- `FRAMES_KERNEL_READY`: present
- Storage NVMe read-only profile: PASS
- Physical boot: not approved

Missing markers:
- `FRAMES_RESCHED_IPI_OK`
- `FRAMES_CPU_AFFINITY_OK`
- `FRAMES_SMP_SCHEDULER_OK`

Serial SHA-256:
`dc325677b4a658b1ddd079ecbceccd9aceab2a4441678d3ea45847888f58089c`

## Major proofs earned in 0.9.17

0.9.17 successfully earned the previously blocked GPT/FAT/VFS and downstream platform chain:

- `FRAMES_GPT_OK`
- `FRAMES_BOOT_VOLUME_OK`
- `FRAMES_FAT32_OK`
- `FRAMES_VFS_MOUNT_OK`
- `FRAMES_VNODE_OK`
- `FRAMES_OPEN_FILE_OK`
- `FRAMES_FILESYSTEM_PLATFORM_OK`
- `FRAMES_NETWORK_CORE_OK`
- `FRAMES_DISPLAY_CORE_OK`
- `FRAMES_AUDIO_CORE_OK`
- `FRAMES_DRIVER_PLATFORM_OK`
- `FRAMES_SECURITY_PLATFORM_OK`
- `FRAMES_RECOVERY_UPDATE_OK`
- `FRAMES_KERNEL_READY`

The AP scheduler path also progressed through:

- `FRAMES_AP_GDT_OK`
- `FRAMES_AP_APIC_ENABLE_OK`
- `FRAMES_AP_TIMER_COUNTING_OK`
- `FRAMES_AP_TIMER_OK`
- `FRAMES_AP_WORKER_ENTER`
- `FRAMES_AP_RUNQUEUE_OK`
- `FRAMES_RESCHED_IPI_SENT`

The BSP's complete worker lifecycle and sustained scheduler markers were also present.

## Final root cause

The remaining failure is isolated to the BSP-to-AP fixed reschedule IPI.

0.9.17 installed the reschedule handler at vector decimal 50 (`0x32`) and called the xAPIC ICR helper with raw low value 50 (`0x00000032`). That selects fixed delivery vector `0x32`, but leaves the ICR Level/Assert bit clear.

Intel's local APIC ICR programming rules require the Level flag to be asserted for ordinary delivery modes other than INIT level-deassert. The BSP can therefore observe the ICR send operation completing (`FRAMES_RESCHED_IPI_SENT`) without the AP accepting the fixed interrupt.

Vector `0x32` also shares interrupt-priority class 3 with the LAPIC scheduler timer at vector `0x30`. Moving reschedule delivery to vector `0x50` places it in class 5 and removes same-class arbitration from the certification path.

## Frames 0.9.18 repair

Frames 0.9.18:

- installs `reschedule_stub_address()` at IDT vector `0x50` (80 decimal);
- sends xAPIC ICR low `0x4050` (Level/Assert + fixed vector `0x50`);
- records the selected vector and ICR low value in supplemental SMP state;
- keeps actual AP receipt (`ap_scheduler+208 > 0`) mandatory for `FRAMES_RESCHED_IPI_OK`;
- keeps AP receipt mandatory for `FRAMES_CPU_AFFINITY_OK` and `FRAMES_SMP_SCHEDULER_OK`;
- expands only the bounded acknowledgement wait; no required marker is relaxed.

Fresh QEMU/OVMF runtime evidence is required. Frames 1.0 remains unpromoted.
