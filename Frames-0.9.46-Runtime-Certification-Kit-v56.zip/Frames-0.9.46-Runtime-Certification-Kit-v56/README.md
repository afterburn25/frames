# Frames 0.9.46 Runtime Certification Kit v56

This kit certifies FAPP Native Application Loader Phase 1 from the externally certified Frames 0.9.45 v55 baseline.

Install `Frames-0.9.46-GitHub-FAPP-Native-Application-Loader-Certification-v56.yml` as:
`.github/workflows/frames-0.9.46-fapp-native-application-loader-v56.yml`

Keep `Frames-0.9.46-Source-v56.zip` available in the repository.

Exact source SHA-256:
`ed823f9d449e53913a018d754cfc90f5369ff2a729afe7c3eda73d404cf430a7`

The workflow retains the v55 filesystem watchdog and complete inherited regression suite, then certifies the packaged FAPP launch as a third native userspace cycle.

Expected artifact:
`frames-0.9.46-fapp-native-application-loader-evidence-v56`

Physical boot remains blocked. Do not promote 0.9.46 until external v56 evidence passes.
