# Frames 0.9.27 v18 Stress Evidence Analysis

Evidence archive SHA-256: `86f991bb345814e917180ee41ba75b46901117eb4515f798b7f364dd3481565a`

## Decision

**Phase 4 rejected / not promoted.** Frames 0.9.26 remains the latest externally runtime/stress-certified authoritative baseline.

## Passing evidence

- QEMU certifier exit code: `0`.
- Base runtime marker contract: `70 expected / 70 present / 0 missing / 0 fatal`.
- `RUNTIME-EVIDENCE.json`: `PASS` for core, platform, SMP, userspace, storage_nvme, and safety.
- Serial SHA-256: `c74db2fc0ef3c2f30a2f0c3a4cceaf4bfbe5db91a251d982e1a5b2ed96274ab7`.
- Short-circuit runtime evidence: `PASS`, `eager_rhs_after_ack=false`, fallback marker absent.
- Read-only NVMe runtime certification: `PASS`; `write_path_certified=false`.
- Allocator stress: `PASS`.
- Scheduler stress: `PASS`.
- Storage-read stress: `PASS`.

## Blocking evidence

- Stress certifier exit code: `1`.
- Stress ledger: `3 executed / 3 passed / 0 failed`.
- USB/input: `NOT-EXECUTED`.
- Serial advances through `FRAMES_USB_HID_FOUND` but never emits `FRAMES_USB_CONFIGURED_OK`, `FRAMES_USB_HID_REPORT_OK`, `FRAMES_INPUT_QUEUE_OK`, or `FRAMES_STRESS_USB_INPUT_OK`.
- Therefore the USB/input Phase-4 gate was not earned and Frames 1.0 remains blocked.

## Additional reproducibility observation

The v18 GitHub runner rebuilt `BOOTX64.EFI` as SHA-256 `700a038fc4366bfb38dabc673f11d002d3af95d75ebc2d10eb1bd8fc39f76de8`, while the locally sealed v18 verification record had `ce8b058056eece8d83d05642d2f37e897e815c6ec34970b23fdba5639d042e92`. The sealed source archive itself matched the expected source SHA-256, and the Nexus-built kernel/FEX hashes matched their expected v18 values. This is treated as a host Clang/LLD toolchain reproducibility observation, not source substitution.

## Repair disposition

Remain on version `0.9.27`; use v19 certification tooling to expose xHCI configuration completion stages and inject deterministic QEMU keyboard activity before attempting Phase-4 promotion again.
