# Frames 0.9.27 Runtime Certification Kit v19

Use the v19 workflow with the enclosed sealed source archive. The workflow accepts only source SHA-256:

`3b1ecc1664bb94731406f7f5f865deae3f482ea36fb75c80ee97c1e3fab9b167`

This is a repair run for USB/Input Phase 4. Do not promote 0.9.27 unless the returned evidence has QEMU certifier exit 0, stress certifier exit 0, 70/70 base markers with no fatal markers, all prior evidence gates PASS, and exactly 4/4 stress categories PASS including USB/input.

If USB configuration still stops, preserve the entire evidence ZIP. `FRAMES_USB_CONFIGURE_DIAG`, `qmp-input.log`, and `qemu-debug.log` are specifically included to identify the next fault without guessing.
