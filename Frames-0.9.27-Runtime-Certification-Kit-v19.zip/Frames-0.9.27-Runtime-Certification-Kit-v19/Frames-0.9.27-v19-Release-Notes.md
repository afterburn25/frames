# Frames 0.9.27 v19 — USB/Input Phase-4 Diagnostic & Deterministic Input Repair

Frames 0.9.27 v19 is a repair/certification candidate for the rejected v18 USB/input Phase-4 run. It does **not** advance to Frames 0.9.28 and it does **not** promote Frames 1.0.

Changes:
- records xHCI command completion code/slot and transfer-event completion code/slot/endpoint in reserved diagnostic state;
- emits `FRAMES_USB_CONFIGURE_DIAG stage=<hex> detail=<hex>` around every fail-closed boot-HID configuration stage;
- keeps the existing successful path marker `FRAMES_USB_CONFIGURED_OK` unchanged;
- adds QMP-driven keyboard down/up injection during QEMU certification so the emulated USB keyboard has deterministic real input activity;
- records `qmp-input.log` and `qemu-debug.log` in the runtime evidence package;
- records QEMU, Clang, and LLD versions in workflow diagnostics;
- adds `FRAMES_STRESS_USB_INPUT_FAIL` to the external workflow fatal-marker set;
- preserves the exactly 70-unique-marker base runtime contract;
- preserves allocator, scheduler, storage-read, and USB/input as the exact four required Phase-4 stress categories;
- preserves read-only storage certification, the physical-boot block, and the Frames 1.0 promotion block.

The v19 source is locally source/build verified and same-toolchain clean-source reproducible, but external QEMU/OVMF runtime PASS is intentionally unclaimed until v19 evidence is returned.
