# Frames 0.9.37 Runtime Certification Kit v35

Milestone: **Scalable SMP & Multi-Core Certification Gate 6**

Sealed source SHA-256:

`2e8e0af7191dd4f6549e419abfbbb3e254012dc1b6886bbe4672b167457ffcdd`

Workflow SHA-256:

`08127d4eac09f83357a33a80d8a6f872d5d133bcc12e63600c8beecc36ab09a6`

## CPU architecture

Frames now uses:
- up to 128 MADT/per-CPU records;
- 128 independent scheduler slots;
- 128 independent AP bootstrap stacks;
- 128 independent AP worker stacks;
- two 64-bit affinity words per CPU (128-bit mask).

v35 externally targets:

`2, 4, 8, 16, 32, 64, 96` logical CPUs.

The 96-CPU lane must prove:
- 95 APs online;
- 95 AP LAPIC timer deliveries;
- 95 timer-driven worker dispatches;
- 95 explicit reschedule-IPI acknowledgements;
- 32 CPUs represented in affinity-mask word 1.

The first AP retains the established deep interrupt/scheduler regression proof.
Additional APs require one independently verified scheduler dispatch and one IPI
acknowledgement each, avoiding artificial TCG repetition while still executing
real per-CPU work.

v35 re-proves all accepted Frames 0.9.36 Gates 1-5 before the SMP matrix.

Expected artifact:

`frames-0.9.37-smp-scale-evidence-v35`

Physical boot and removable USB boot remain blocked pending later gates.
