# Frames 0.9.32 Runtime Certification Kit v26

Post-stress Gate 1: Persistent Storage Write & Integrity Certification.

Sealed source SHA-256:

`b3d570f5fc8262320b301ff7475687b8d28848c83aaa24d44a4ea57eccdce86e`

## Safety topology

The existing Frames boot ESP NVMe remains **read-only**.

The workflow creates a separate 16 MiB sacrificial NVMe image and exposes it as
a second controller with serial `FRAMESWRITE0932`. Frames will not arm NVM Write
unless both the controller serial and on-media `FRAMES_WRITE_CERT_V1` header /
geometry contract match.

Only LBAs 4096..4111 are writable by the certification command path.

## Required successful external evidence

- QEMU certifier exit 0
- 70/70 base runtime markers, zero fatal markers
- all eight established stress categories remain PASS
- `FRAMES_NVME_WRITE_TARGET_FOUND`
- `FRAMES_NVME_WRITE_OK`
- `FRAMES_NVME_FLUSH_OK`
- `FRAMES_STORAGE_WRITE_GUARDS_OK`
- `FRAMES_STORAGE_WRITE_INTEGRITY_OK`
- no `FRAMES_STORAGE_WRITE_INTEGRITY_FAIL`
- `STORAGE-RUNTIME-CERT.json`: read_path_certified=true, write_path_certified=true
- `boot_volume_write_certified=false`
- `sacrificial_target_only=true`
- `WRITE-MEDIA-INTEGRITY.json`: PASS and byte_identical_after_restore=true
- `STORAGE-WRITE-EVIDENCE.json`: PASS

Physical boot, boot-volume/filesystem writes, destructive power actions, and
Frames 1.0 promotion remain separate blocked gates.
