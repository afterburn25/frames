# Frames 0.9.43 v52 — Developer Preview Command-Mask Sentinel Repair

v52 fixes a Phase 2 developer-preview control-flow defect exposed by the external v51 run.

The command completion mask legitimately reaches 255 after help/version/cpu/memory/devices/run/reboot/shutdown all complete. v50/v51 also used return value 255 as a fatal sentinel, so the shell treated the fully-complete mask as failure immediately after shutdown and never accepted the final exit command.

v52 moves the internal failure sentinel to 257, outside the valid 0..255 mask range. Success remains 256. No FEX ABI, userspace, storage, write policy, or physical-boot policy is changed.
