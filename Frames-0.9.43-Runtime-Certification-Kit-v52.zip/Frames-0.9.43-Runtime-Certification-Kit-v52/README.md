# Frames 0.9.43 Runtime Certification Kit v52

v52 fixes the Developer Preview command-mask/failure-sentinel collision exposed by
the external v51 run.

Install `Frames-0.9.43-GitHub-Interactive-Developer-Preview-Certification-v52.yml` as:
`.github/workflows/frames-0.9.43-interactive-developer-preview-v52.yml`

Keep `Frames-0.9.43-Source-v52.zip` available in the repository.

Exact source SHA-256:
`0c06f06336eb6afecc8ffe7e7becc2682cfdea9f77fa5763dbcc533880c9d6be`

Run the workflow and upload:
`frames-0.9.43-interactive-developer-preview-evidence-v52.zip`
