# Frames 0.9.44 Runtime Certification Kit v53

This kit certifies Nexus SDK / Developer Tooling Phase 1 from the externally certified
Frames 0.9.43 v52 baseline.

Install `Frames-0.9.44-GitHub-Nexus-SDK-Developer-Tooling-Certification-v53.yml` as:
`.github/workflows/frames-0.9.44-nexus-sdk-developer-tooling-v53.yml`

Keep `Frames-0.9.44-Source-v53.zip` available in the repository.

Exact source SHA-256:
`cc8ff5ae42a3bc7faf0184aceb597fda713433d6f1624a0c39515560e05d4b31`

Expected artifact:
`frames-0.9.44-nexus-sdk-developer-tooling-evidence-v53.zip`
