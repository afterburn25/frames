# Frames 0.9.22 Runtime Certification Kit v13

This kit contains the sealed Frames 0.9.22 source archive, the strict GitHub Actions v13 runtime-certification workflow, the 0.9.21 runtime-evidence analysis, and local verification records.

## GitHub use
1. Put `Frames-0.9.22-Runtime-Certification-Kit-v13.zip` at the repository root.
2. Replace the active workflow contents with `Frames-0.9.22-GitHub-Runtime-Certification-v13.yml` (for example `.github/workflows/main.yml`).
3. Run the workflow.
4. Download artifact `frames-0.9.22-runtime-evidence` and return it for analysis, even if the Action is red.

The workflow is fail-closed: it only accepts the exact 0.9.22 source SHA embedded in the workflow and deliberately ignores older Frames kits.

## Primary supplemental diagnostics
- `FRAMES_AP_SEGMENTS_NORMALIZED_OK`
- `FRAMES_AP_IRET_FRAME=<rip>,<cs>,<rflags>`
- `FRAMES_AP_PROTECTION_FAULT=<vector>,<error>,<rip>,<cs>`
- `FRAMES_AP_BARE_IRQ_RETURN_OK`

A protection-fault diagnostic is evidence of a real AP return-path fault, not certification success. Required SMP markers remain unchanged.
