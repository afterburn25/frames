# Frames 0.9.21 Runtime Evidence Analysis

## Result
The uploaded GitHub Actions / QEMU / OVMF evidence is a genuine Frames 0.9.21 run using bundled Nexus 5.18.0.

- Required markers: 70
- Present: 64
- Missing: 6
- Fatal markers: 0
- Core: PASS
- Platform: PASS
- Userspace: PASS
- NVMe read-only storage: PASS
- Safety: PASS
- SMP: BLOCKED
- Physical boot approval: false
- QEMU certification exit code: 1
- serial.log SHA-256: `6269f18314634b8b3c2ebaf9b517912304f0e1a67c36fc1f4380fdf45993ac8a`

## Missing required markers
- `FRAMES_AP_WORKER_ENTER`
- `FRAMES_AP_RUNQUEUE_OK`
- `FRAMES_RESCHED_IPI_SENT`
- `FRAMES_RESCHED_IPI_OK`
- `FRAMES_CPU_AFFINITY_OK`
- `FRAMES_SMP_SCHEDULER_OK`

## Decisive AP evidence
0.9.21 reached:

- `FRAMES_AP_ENTER`
- `FRAMES_AP_RUNTIME_OK`
- `FRAMES_AP_ONLINE_OK`
- `FRAMES_AP_GDT_OK`
- `FRAMES_AP_CS_NORMALIZED_OK`
- `FRAMES_AP_APIC_ENABLE_OK`
- `FRAMES_AP_TIMER_COUNTING_OK`
- `FRAMES_AP_TIMER_OK`

It did **not** reach supplemental `FRAMES_AP_BARE_IRQ_RETURN_OK`.

The first AP timer interrupt in 0.9.21 intentionally bypasses scheduler dispatch. Therefore the missing bare-return proof isolates the failure to the raw timer interrupt return path after handler entry/EOI and before execution resumes in `kernel_ap_entry`. Scheduler/worker context switching is not involved in this first probe.

## Stable subsystems
The run retained `FRAMES_KERNEL_READY`, the full GPT/FAT32/VFS/filesystem chain, networking, display, audio, driver, security, recovery/update, BSP worker lifecycle, and sustained BSP scheduler markers. No page-fault or other fatal runtime marker was reported.

## 0.9.22 response
Frames 0.9.22 is a diagnostic/repair checkpoint, not a claimed runtime fix. It adds:

1. Shared-GDT data/stack descriptor preservation at selector `0x10` and explicit AP DS/ES/SS normalization after LGDT/CS normalization.
2. Exact pre-IRET hardware-frame capture for AP timer RIP/CS/RFLAGS.
3. Fail-closed AP #TS/#NP/#SS/#GP capture stubs that publish vector, error code, fault RIP, and CS to BSP-visible evidence.
4. Supplemental diagnostics `FRAMES_AP_SEGMENTS_NORMALIZED_OK`, `FRAMES_AP_IRET_FRAME=...`, and `FRAMES_AP_PROTECTION_FAULT=...`.
5. The required 70-marker certification contract remains unchanged.

## Promotion status
Frames 1.0 is not promoted. Physical boot remains blocked, persistent media writes remain absent/uncertified, and the external SMP runtime gate is still incomplete.
