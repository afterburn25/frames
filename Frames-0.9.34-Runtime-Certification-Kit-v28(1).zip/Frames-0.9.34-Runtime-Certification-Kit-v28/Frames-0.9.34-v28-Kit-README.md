# Frames 0.9.34 Runtime Certification Kit v28

Gate 3: **Sacrificial Filesystem Write & Hard-Crash Recovery Certification**

Sealed source SHA-256:

`332254da868f7ff87a2bb51dd862b0759a17cd323ce2e137b4f52010f2efaa77`

The boot/system NVMe remains read-only. Filesystem writes can arm only on a separate 16 MiB NVMe controller whose Identify Controller serial is exactly `FRAMESFS0934` and whose LBA-0 superblock is `FRAMES_FS_CERT_V2`. LBA 0 itself is outside the write gate.

v28 first re-proves the accepted 0.9.33-derived runtime/storage/lifecycle baseline. It then executes one 32-transaction normal filesystem lane and four hard-crash lanes. The crash lanes SIGKILL QEMU after journal prepare, data flush, metadata flush, or commit flush and then boot the exact same disk image again.

Promotion requires `FILESYSTEM-EVIDENCE.json: PASS`, five media-verification PASS records, four expected crash exit codes 137, four clean recovery exits 0, `FRAMES_FS_MUTATION_OK`, four `FRAMES_FS_CRASH_POINT_READY` markers, four `FRAMES_FS_RECOVERY_OK` markers, correct rollback/roll-forward direction, and no `FRAMES_FS_WRITE_CERT_FAIL`.

Physical boot, boot/system-volume writes, arbitrary physical-disk writes, and Frames 1.0 promotion remain blocked.
