# Frames 0.9.34 — Sacrificial Filesystem Write & Crash-Recovery Certification Gate 3

- Rebuilt directly from externally accepted Frames 0.9.33 Gate 2.
- Preserves the exact 70-marker runtime contract, 8/8 stress matrix, sacrificial raw NVMe write certification, real disposable-VM reboot with second boot, and real ACPI S5 shutdown.
- Adds a dedicated 16 MiB filesystem target whose NVMe Identify Controller serial must be exactly `FRAMESFS0934`.
- The boot/system NVMe stays QEMU read-only and cannot arm filesystem writes.
- Filesystem media identity is `FRAMES_FS_CERT_V2`; LBA 0 is outside the writable gate. Only LBAs 1..255 can be written by this certification path.
- Uses control LBA 1, write-ahead journal LBA 8, metadata LBA 16, and copy-on-write data slots LBAs 128/129.
- Normal certification performs 32 fully ordered copy-on-write file transactions with explicit NVMe Flush boundaries and readback/checksum validation.
- Four hard-crash lanes SIGKILL QEMU after journal prepare, data flush, metadata flush, or commit flush.
- Second boot must roll prepared transactions back and committed transactions forward, clear the journal, and verify the selected file data checksum.
- Success markers: `FRAMES_FS_WRITE_TARGET_FOUND`, `FRAMES_FS_JOURNAL_OK`, `FRAMES_FS_MUTATION_OK`, and `FRAMES_FS_RECOVERY_OK`.
- `FRAMES_FS_WRITE_CERT_FAIL` is fail-closed.
- Boot/system-volume filesystem writes, arbitrary physical-disk writes, and physical boot remain blocked.
