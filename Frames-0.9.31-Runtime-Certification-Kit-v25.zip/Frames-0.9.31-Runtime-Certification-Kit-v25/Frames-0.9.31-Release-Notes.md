# Frames 0.9.31 — Power Stress/Fault Certification Phase 8

- Retains the externally accepted Frames 0.9.30 Phase-7 runtime/stress baseline and the unchanged 70-marker base contract.
- Adds category 8: fail-closed non-destructive power/lifecycle stress.
- Requires the real ACPI reset and S5/shutdown descriptors and emits `FRAMES_POWER_PATH_FOUND`.
- Revalidates FADT checksums, reset GAS constraints, PM1 control addresses and S5 sleep types.
- Fault-injects five isolated ACPI power descriptor defects and requires fail-closed rejection.
- Validates 2,048 PM1 SLP_TYP/SLP_EN encodings across all eight type values and 256 representative current register values.
- Queues 128 alternating reboot/shutdown actions on isolated state without executing reset or shutdown.
- Performs 512 isolated D0/D3 software device-power policy transitions with invalid-state/reason/index rejection.
- Verifies 4,096 monotonic TSC samples and 256 watchdog heartbeats.
- Proves live ACPI power, system-action, watchdog and device-power states remain unchanged.
- Adds `FRAMES_STRESS_POWER_OK` / `FRAMES_STRESS_POWER_FAIL` and stage/detail diagnostics.
- Phase 8 requires exactly 8 executed / 8 passed / 0 failed categories.
- No destructive reset/shutdown, persistent-media write or physical-machine power certification is claimed.
- Physical boot and Frames 1.0 remain BLOCKED.
