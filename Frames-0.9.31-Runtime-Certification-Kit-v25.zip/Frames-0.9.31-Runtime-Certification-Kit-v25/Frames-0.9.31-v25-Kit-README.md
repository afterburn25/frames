# Frames 0.9.31 Runtime Certification Kit v25

Phase 8: Power Stress/Fault Certification.

Sealed source SHA-256:

`7270cff0a13a59f8fcd2a1acf80178b8f182068fa3181552c12eeaa718235636`

A successful external run must produce:

- `FRAMES_POWER_PATH_FOUND`
- `FRAMES_STRESS_POWER_OK`
- QEMU certifier exit 0
- stress certifier exit 0
- 70/70 base runtime markers
- zero fatal markers
- allocator/scheduler/storage-read/USB-input/network/display/recovery/power all PASS
- exactly 8 executed / 8 passed / 0 failed

The Phase-8 profile is deliberately non-destructive. It must not actually reset or shut down the VM.

Physical boot, persistent-media writes, destructive power-action certification, and Frames 1.0 promotion remain separate gates.
