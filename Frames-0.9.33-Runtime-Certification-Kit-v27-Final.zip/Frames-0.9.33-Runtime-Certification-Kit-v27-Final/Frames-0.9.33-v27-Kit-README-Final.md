# Frames 0.9.33 Runtime Certification Kit v27 — Final

Post-stress Gate 2: **Destructive Reboot & Shutdown Certification**.

Sealed source SHA-256: `a9ce4db17f900d9962daf861ec588f4c299581054fb5d3ea96f7984edda88717`

The workflow first re-proves the accepted 0.9.32 runtime/stress/storage-write baseline, then runs two isolated lifecycle VMs. Reboot mode requires `FRAMESREBOOT0933`, persists a one-time token, executes the real ACPI reset path, and must return through a second complete Frames boot. Shutdown mode requires `FRAMESSHUTDOWN0933`, persists its token, executes real ACPI S5, and QEMU must terminate naturally.

Normal media cannot arm these destructive actions. Physical-machine power certification, boot-volume/filesystem writes, physical boot, and Frames 1.0 remain blocked.
