# Frames 0.9.43 — Interactive Developer Preview Phase 2: Native FEX Launch

Source baseline: externally certified Frames 0.9.42 v49.

## Added

- `run` command in the framebuffer developer-preview shell.
- Direct native re-launch of the verified boot `System.fex` through the existing Frames ring-3 mapping and syscall ABI.
- Fail-closed validation of the loaded FEX image before every preview launch.
- Exact syscall-accounting proof: the FEX return thunk must execute exactly three syscalls (ABI query, ordinary user call, exit).
- Dedicated developer-preview FEX launch/ring3-return/exit/command markers.
- FEX image-size and syscall-delta diagnostics.
- Phase 2 external evidence contract requiring a second real ring-3/FEX cycle before preview certification.

## Safety

- Reuses the existing verified user address space; no new executable loader format is introduced.
- `reboot` and `shutdown` remain blocked.
- No persistent physical-media write path is enabled.
- SCSI WRITE(10) remains absent.
- Physical hardware boot remains blocked.
- Frames 1.0 remains unpromoted.

## Promotion requirement

External v50 QEMU/OVMF evidence must pass the complete inherited v49 suite plus the Phase 2 developer-preview native FEX launch lane.
