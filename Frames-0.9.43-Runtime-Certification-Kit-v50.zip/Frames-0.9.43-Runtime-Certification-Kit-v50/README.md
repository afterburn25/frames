# Frames 0.9.43 Runtime Certification Kit v50

Interactive Developer Preview Phase 2 adds native `System.fex` launch from the
certified framebuffer shell.

Install `Frames-0.9.43-GitHub-Interactive-Developer-Preview-Certification-v50.yml` as:

`.github/workflows/frames-0.9.43-interactive-developer-preview-v50.yml`

Keep `Frames-0.9.43-Source-v50.zip` available in the repository.

Exact source SHA-256:
`ad8e53c3ec6faacbf580f741730d133b88a536cd79ec15e65faa5a7d182d172b`

The workflow reruns the full inherited v49 certification suite and then types:
`help`, `version`, `cpu`, `memory`, `devices`, `run`, `reboot`, `shutdown`, `exit`.

Expected artifact:
`frames-0.9.43-interactive-developer-preview-evidence-v50`

Do not promote 0.9.43 until that external evidence passes.
