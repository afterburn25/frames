# Frames Status — 0.9.38

Authoritative external baseline: **Frames 0.9.37 — Scalable SMP & Multi-Core Certification Gate 6 (v36)**.

Current candidate: **Frames 0.9.38 — Removable USB Boot Certification Gate 7**.

Physical boot remains BLOCKED.
