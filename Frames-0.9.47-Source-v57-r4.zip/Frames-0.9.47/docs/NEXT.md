# Next

After Frames 0.9.47 Developer Preview Phase 3 is externally certified, continue automatically into **Frames 0.9.48 — HelixFS Read-Only Integration Phase 1**.

That milestone should introduce the first HelixFS on-disk superblock/inode/directory parser and mount it read-only behind the existing VFS. No HelixFS mutation path, format operation, persistent physical-media write, or physical boot unlock is permitted until a later explicit disposable-write certification milestone.
