# Frames Physical Boot Gate — 0.9.47

Frames 0.9.46 v56 is the latest externally certified authoritative baseline.

Frames 0.9.47 is a VM-only Developer Preview candidate that adds continuous USB HID keyboard polling and live `processes` / `filesystems` inspection. It does not unlock physical boot or persistent media mutation.

The preview remains non-destructive. `reboot` and `shutdown` are blocked; persistent physical-media writes remain disabled; SCSI WRITE(10) remains absent.

**Decision: BLOCKED-PENDING-DEVELOPER-PREVIEW-V57**

Physical hardware boot remains diagnostic-only and intentionally blocked. Frames 1.0 is not promoted.
