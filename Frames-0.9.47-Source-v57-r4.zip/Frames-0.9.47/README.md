# Frames 0.9.47 — Developer Preview Phase 3: Continuous USB Input & System Inspection

Frames 0.9.47 is built directly from the externally certified Frames 0.9.46 v56 baseline.

This milestone advances the VM-only Developer Preview in two targeted ways:

- the shell continuously re-arms and polls the configured xHCI boot-HID interrupt endpoint and accepts USB HID keyboard keycodes through the existing input queue, while retaining PS/2 fallback;
- new `processes` and `filesystems` commands expose live kernel process/thread and VFS/vnode/ramfs/devfs/procfs counts from the already-certified platform state.

The FAPP application loader, Nexus SDK, storage stack, and destructive-write policy are unchanged. Physical hardware boot remains diagnostic-only and blocked. Persistent physical-media writes remain disabled.
