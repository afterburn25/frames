#!/usr/bin/env python3
from pathlib import Path
import argparse,json
p=argparse.ArgumentParser(); p.add_argument('--developer-evidence',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
d=json.loads(Path(a.developer_evidence).read_text())
checks_src=d.get('checks',{}); markers=d.get('markers',{}); diag={int(k):v for k,v in d.get('diagnostics',{}).items()} if d.get('diagnostics') else {}
generic=d.get('generic_userspace_markers',{})
required_markers=['FRAMES_DEVPREV_FAPP_MANIFEST_OK','FRAMES_DEVPREV_FAPP_HASH_OK','FRAMES_DEVPREV_FAPP_ABI_OK','FRAMES_DEVPREV_FAPP_LAUNCH_BEGIN','FRAMES_DEVPREV_FAPP_EXIT_OK','FRAMES_DEVPREV_CMD_APP_OK']
checks={
 'developer_preview_pass':d.get('status')=='PASS',
 'profile_phase1':d.get('profile')=='fapp-native-application-loader-phase1',
 'three_userspace_cycles':checks_src.get('three_userspace_cycles') is True,
 'packaged_fapp_cycle_after_app':checks_src.get('packaged_fapp_cycle_after_app') is True,
 'fapp_image_nonzero':checks_src.get('fapp_image_nonzero') is True and diag.get(7,0)>0,
 'fapp_syscall_delta_exact':checks_src.get('fapp_syscall_delta_exact') is True and diag.get(8)==3,
 'markers_exact_once':all(markers.get(m)==1 for m in required_markers),
 'generic_cycle_counts_exact':all(generic.get(k)==3 for k in ('ring3_enter','ring3_return','fex_exit','syscall_abi','user_syscall')),
 'media_unchanged':checks_src.get('media_unchanged') is True,
 'no_fatal':checks_src.get('no_fatal') is True,
}
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'fapp-native-application-loader-phase1','checks':checks,'fapp_image_size':diag.get(7),'fapp_syscall_delta':diag.get(8),'required_markers':{m:markers.get(m,0) for m in required_markers},'generic_userspace_markers':generic,'developer_preview_serial_sha256':d.get('serial_sha256')}
print(json.dumps(out,indent=2))
if a.require_pass and status!='PASS': raise SystemExit(1)
