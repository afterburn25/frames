#!/usr/bin/env python3
import argparse,json,sys
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--normal',required=True); p.add_argument('--detach',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
n=json.loads(Path(a.normal).read_text()); d=json.loads(Path(a.detach).read_text()); checks={'normal_pass':n.get('status')=='PASS','detach_pass':d.get('status')=='PASS','profiles_match':n.get('profile')==d.get('profile')=='removable-usb-boot-gate7'}; out={'status':'PASS' if all(checks.values()) else 'FAIL','profile':'removable-usb-boot-gate7-matrix','checks':checks,'lanes':{'normal':n,'detach':d}}; print(json.dumps(out,indent=2,sort_keys=True));
if a.require_pass and out['status']!='PASS': sys.exit(1)
