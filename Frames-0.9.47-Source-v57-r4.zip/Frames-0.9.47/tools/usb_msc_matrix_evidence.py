#!/usr/bin/env python3
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--normal',required=True); p.add_argument('--detach',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args(); n=json.loads(Path(a.normal).read_text()); d=json.loads(Path(a.detach).read_text()); out={'status':'PASS' if n.get('status')=='PASS' and d.get('status')=='PASS' else 'FAIL','profile':'native-usb-mass-storage-phase2','lanes':{'normal':n,'detach':d}}; print(json.dumps(out,indent=2));
if a.require_pass and out['status']!='PASS': raise SystemExit(1)
