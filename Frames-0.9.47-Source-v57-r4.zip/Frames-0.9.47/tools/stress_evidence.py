#!/usr/bin/env python3
from pathlib import Path
import argparse, json, hashlib
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--serial',default=str(root/'build/serial.log'))
p.add_argument('--require-allocator-pass',action='store_true')
p.add_argument('--require-scheduler-pass',action='store_true')
p.add_argument('--require-storage-read-pass',action='store_true')
p.add_argument('--require-usb-input-pass',action='store_true')
p.add_argument('--require-network-pass',action='store_true')
p.add_argument('--require-display-pass',action='store_true')
p.add_argument('--require-recovery-pass',action='store_true')
p.add_argument('--require-power-pass',action='store_true')
n=p.parse_args()
serial=Path(n.serial)
raw=serial.read_bytes() if serial.exists() else b''
text=raw.decode('utf-8','replace')
names=['allocator','scheduler','storage-read','usb-input','network','display','recovery','power']
markers={'allocator':('FRAMES_STRESS_ALLOCATOR_OK','FRAMES_STRESS_ALLOCATOR_FAIL')}
cats={}
for name in names:
    okm,failm=markers.get(name,(f'FRAMES_STRESS_{name.upper().replace("-","_")}_OK',f'FRAMES_STRESS_{name.upper().replace("-","_")}_FAIL'))
    status='PASS' if okm in text else ('FAIL' if failm in text else 'NOT-EXECUTED')
    cats[name]={'status':status,'pass_marker':okm,'fail_marker':failm}
executed=sum(1 for x in cats.values() if x['status']!='NOT-EXECUTED')
passed=sum(1 for x in cats.values() if x['status']=='PASS')
failed=sum(1 for x in cats.values() if x['status']=='FAIL')
doc={
 'frames_version':(root/'VERSION').read_text().strip(),
 'profile':'stress-fault-phase8-allocator-scheduler-storage-read-usb-input-network-display-recovery-power',
 'serial_sha256':hashlib.sha256(raw).hexdigest(),
 'required_categories':8,
 'executed_categories':executed,
 'passed_categories':passed,
 'failed_categories':failed,
 'categories':cats,
 'status':'PASS' if cats['allocator']['status']=='PASS' and cats['scheduler']['status']=='PASS' and cats['storage-read']['status']=='PASS' and cats['usb-input']['status']=='PASS' and cats['network']['status']=='PASS' and cats['display']['status']=='PASS' and cats['recovery']['status']=='PASS' and cats['power']['status']=='PASS' and failed==0 else ('FAIL' if failed else 'BLOCKED'),
 'frames_1_0_promoted':False,
}
out=serial.parent/'STRESS-EVIDENCE.json'
out.write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps(doc,indent=2))
if n.require_allocator_pass and cats['allocator']['status']!='PASS':
    raise SystemExit(1)
if n.require_scheduler_pass and cats['scheduler']['status']!='PASS':
    raise SystemExit(1)
if n.require_storage_read_pass and not (cats['allocator']['status']=='PASS' and cats['scheduler']['status']=='PASS' and cats['storage-read']['status']=='PASS' and executed==3 and passed==3 and failed==0):
    raise SystemExit(1)

if n.require_usb_input_pass and not (cats['allocator']['status']=='PASS' and cats['scheduler']['status']=='PASS' and cats['storage-read']['status']=='PASS' and cats['usb-input']['status']=='PASS' and executed==4 and passed==4 and failed==0):
    raise SystemExit(1)

if n.require_network_pass and not (cats['allocator']['status']=='PASS' and cats['scheduler']['status']=='PASS' and cats['storage-read']['status']=='PASS' and cats['usb-input']['status']=='PASS' and cats['network']['status']=='PASS' and executed==5 and passed==5 and failed==0):
    raise SystemExit(1)

if n.require_display_pass and not (cats['allocator']['status']=='PASS' and cats['scheduler']['status']=='PASS' and cats['storage-read']['status']=='PASS' and cats['usb-input']['status']=='PASS' and cats['network']['status']=='PASS' and cats['display']['status']=='PASS' and executed==6 and passed==6 and failed==0):
    raise SystemExit(1)

if n.require_recovery_pass and not (cats['allocator']['status']=='PASS' and cats['scheduler']['status']=='PASS' and cats['storage-read']['status']=='PASS' and cats['usb-input']['status']=='PASS' and cats['network']['status']=='PASS' and cats['display']['status']=='PASS' and cats['recovery']['status']=='PASS' and executed==7 and passed==7 and failed==0):
    raise SystemExit(1)

if n.require_power_pass and not (cats['allocator']['status']=='PASS' and cats['scheduler']['status']=='PASS' and cats['storage-read']['status']=='PASS' and cats['usb-input']['status']=='PASS' and cats['network']['status']=='PASS' and cats['display']['status']=='PASS' and cats['recovery']['status']=='PASS' and cats['power']['status']=='PASS' and executed==8 and passed==8 and failed==0):
    raise SystemExit(1)
