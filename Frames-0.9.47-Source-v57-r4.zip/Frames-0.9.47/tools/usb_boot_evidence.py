#!/usr/bin/env python3
import argparse,json,hashlib,sys
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--serial',required=True); p.add_argument('--qemu-exit',type=int,default=0); p.add_argument('--lane',choices=['normal','detach'],required=True); p.add_argument('--monitor'); p.add_argument('--before-guard'); p.add_argument('--after-guard'); p.add_argument('--media'); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
raw=Path(a.serial).read_bytes(); text=raw.decode(errors='ignore')
markers=['FRAMES_USB_BOOT_POLICY_OK','FRAMES_USB_BOOT_DEVICE_PATH_OK','FRAMES_USB_BOOT_MEDIA_OK','FRAMES_USB_BOOT_SYSTEM_READ_OK','FRAMES_USB_BOOT_CERT_OK','FRAMES_USB_BOOT_DETACH_WINDOW','FRAMES_USB_BOOT_RESIDENT_OK']
checks={m:(text.count(m)==1) for m in markers}; checks['no_usb_fail']='FRAMES_USB_BOOT_CERT_FAIL' not in text; checks['qemu_exit_zero']=a.qemu_exit==0
# Normal proves complete kernel continuation. Detach proves resident kernel continues after host removes boot media.
checks['resident_after_handoff']='FRAMES_USB_BOOT_RESIDENT_OK' in text
mon=Path(a.monitor).read_text(errors='ignore') if a.monitor and Path(a.monitor).exists() else ''
if a.lane=='detach':
    checks['device_deleted']='QMP USB DEVICE_DELETED event observed during FRAMES_USB_BOOT_DETACH_WINDOW' in mon
    checks['resident_after_detach']='FRAMES_USB_BOOT_RESIDENT_OK observed after USB detach' in mon
else: checks['normal_lane']=True
if a.before_guard and a.after_guard:
    b=Path(a.before_guard).read_bytes(); c=Path(a.after_guard).read_bytes(); checks['internal_guard_byte_identical']=b==c; guard_sha=hashlib.sha256(b).hexdigest()
else: guard_sha=None
if a.media:
    media=json.loads(Path(a.media).read_text()); checks['media_evidence_pass']=media.get('status')=='PASS'
else: media=None
fatals=['FRAMES_USB_BOOT_CERT_FAIL','FRAMES_SMP_SCALE_CERT_FAIL','FRAMES_FAT_LIFECYCLE_CERT_FAIL','FRAMES_SYSTEM_VOLUME_WRITE_CERT_FAIL','FRAMES_FS_WRITE_CERT_FAIL','FRAMES_LIFECYCLE_DESTRUCTIVE_FAIL','FRAMES_STORAGE_WRITE_INTEGRITY_FAIL','FRAMES_STRESS_ALLOCATOR_FAIL','FRAMES_STRESS_SCHEDULER_FAIL','FRAMES_STRESS_STORAGE_READ_FAIL','FRAMES_STRESS_USB_INPUT_FAIL','FRAMES_STRESS_NETWORK_FAIL','FRAMES_STRESS_DISPLAY_FAIL','FRAMES_STRESS_RECOVERY_FAIL','FRAMES_STRESS_POWER_FAIL','FRAMES_PAGE_FAULT','FRAMES_AP_PROTECTION_FAULT=','PANIC','ASSERT','TRIPLE']
checks['no_fatal']=not any(x in text for x in fatals)
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'removable-usb-boot-gate7','lane':a.lane,'serial_sha256':hashlib.sha256(raw).hexdigest(),'checks':checks,'guard_sha256':guard_sha,'media':media,'markers':{m:text.count(m) for m in markers}}
print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': sys.exit(1)
