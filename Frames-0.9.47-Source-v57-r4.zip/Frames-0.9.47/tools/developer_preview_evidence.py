#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,re
p=argparse.ArgumentParser(); p.add_argument('--serial',required=True); p.add_argument('--qemu-exit',type=int,required=True); p.add_argument('--media-before',required=True); p.add_argument('--media-after',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
raw=Path(a.serial).read_bytes(); text=raw.decode(errors='replace'); before=Path(a.media_before).read_bytes(); after=Path(a.media_after).read_bytes()
markers=['FRAMES_DEVPREV_POLICY_OK','FRAMES_DEVPREV_SURFACE_OK','FRAMES_DEVPREV_USB_POLL_ARMED','FRAMES_DEVPREV_INPUT_READY','FRAMES_DEVPREV_READY','FRAMES_DEVPREV_USB_REPORT_OK','FRAMES_DEVPREV_CMD_HELP_OK','FRAMES_DEVPREV_CMD_VERSION_OK','FRAMES_DEVPREV_CMD_CPU_OK','FRAMES_DEVPREV_CMD_MEMORY_OK','FRAMES_DEVPREV_CMD_DEVICES_OK','FRAMES_DEVPREV_CMD_PROCESSES_OK','FRAMES_DEVPREV_CMD_FILESYSTEMS_OK','FRAMES_DEVPREV_CMD_SDK_OK','FRAMES_DEVPREV_FAPP_MANIFEST_OK','FRAMES_DEVPREV_FAPP_HASH_OK','FRAMES_DEVPREV_FAPP_ABI_OK','FRAMES_DEVPREV_FAPP_LAUNCH_BEGIN','FRAMES_DEVPREV_FAPP_EXIT_OK','FRAMES_DEVPREV_CMD_APP_OK','FRAMES_DEVPREV_FEX_LAUNCH_BEGIN','FRAMES_DEVPREV_FEX_RING3_RETURN_OK','FRAMES_DEVPREV_FEX_EXIT_OK','FRAMES_DEVPREV_CMD_RUN_OK','FRAMES_DEVPREV_CMD_REBOOT_BLOCKED','FRAMES_DEVPREV_CMD_SHUTDOWN_BLOCKED','FRAMES_DEVPREV_CMD_EXIT_OK','FRAMES_DEVPREV_CERT_OK']
counts={m:text.count(m) for m in markers}; fatal=['FRAMES_DEVPREV_CERT_FAIL','FRAMES_PAGE_FAULT','FRAMES_PROTECTION_FAULT']; diag={}; diag_counts={}
for x,y in re.findall(r'FRAMES_DEVPREV_DIAG stage=(?:0x)?([0-9A-Fa-f]+) value=(?:0x)?([0-9A-Fa-f]+)',text):
 st=int(x,16); val=int(y,16); diag_counts[st]=diag_counts.get(st,0)+1
 if diag_counts[st]==1: diag[st]=val
positions=[text.find(m) for m in markers]
generic={'ring3_enter':text.count('FRAMES_RING3_ENTER'),'ring3_return':text.count('FRAMES_RING3_RETURN'),'fex_exit':text.count('FRAMES_FEX_EXIT_OK'),'syscall_abi':text.count('FRAMES_SYSCALL_ABI_OK'),'user_syscall':text.count('FRAMES_USER_SYSCALL_OK')}
app_launch_pos=text.find('FRAMES_DEVPREV_FAPP_LAUNCH_BEGIN'); app_ok_pos=text.find('FRAMES_DEVPREV_CMD_APP_OK'); launch_pos=text.find('FRAMES_DEVPREV_FEX_LAUNCH_BEGIN'); cmd_run_pos=text.find('FRAMES_DEVPREV_CMD_RUN_OK')
first_ring3=text.find('FRAMES_RING3_ENTER')
second_ring3=text.find('FRAMES_RING3_ENTER',first_ring3+1)
third_ring3=text.find('FRAMES_RING3_ENTER',second_ring3+1)
first_fex_exit=text.find('FRAMES_FEX_EXIT_OK')
second_fex_exit=text.find('FRAMES_FEX_EXIT_OK',first_fex_exit+1)
third_fex_exit=text.find('FRAMES_FEX_EXIT_OK',second_fex_exit+1)
checks={
 'markers_exact_once':all(v==1 for v in counts.values()),
 'no_fatal':not any(f in text for f in fatal),
 'qemu_exit_zero':a.qemu_exit==0,
 'media_unchanged':before==after,
 'command_order':all(p>=0 for p in positions) and positions==sorted(positions),
 'diagnostics_unique':all(diag_counts.get(i,0)==1 for i in (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)),
 'cpu_nonzero':diag.get(1,0)>0,
 'memory_nonzero':diag.get(2,0)>0,
 'devices_nonzero':diag.get(3,0)>0,
 'fex_image_nonzero':diag.get(4,0)>0,
 'fex_syscall_delta_exact':diag.get(5)==3,
 'fapp_image_nonzero':diag.get(7,0)>0,
 'fapp_syscall_delta_exact':diag.get(8)==3,
 'sdk_abi_exact':diag.get(6)==65536,
 'process_count_nonzero':diag.get(9,0)>0,
 'thread_count_nonzero':diag.get(10,0)>0,
 'vfs_mounts_nonzero':diag.get(11,0)>0,
 'vnode_count_nonzero':diag.get(12,0)>0,
 'ramfs_count_nonzero':diag.get(13,0)>0,
 'devfs_count_nonzero':diag.get(14,0)>0,
 'procfs_count_nonzero':diag.get(15,0)>0,
 'kernel_ready_before_preview':text.find('FRAMES_KERNEL_READY')>=0 and text.find('FRAMES_KERNEL_READY')<text.find('FRAMES_DEVPREV_READY'),
 'three_userspace_cycles':all(generic[k]==3 for k in ('ring3_enter','ring3_return','fex_exit','syscall_abi','user_syscall')),
 'packaged_fapp_cycle_after_app':app_launch_pos>=0 and second_ring3>app_launch_pos and second_fex_exit>second_ring3 and app_ok_pos>second_fex_exit,
 'native_fex_cycle_after_run':launch_pos>=0 and third_ring3>launch_pos and third_fex_exit>third_ring3 and cmd_run_pos>third_fex_exit,
}
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'developer-preview-phase3-continuous-usb-input-system-inspection','serial_sha256':hashlib.sha256(raw).hexdigest(),'checks':checks,'markers':counts,'diagnostics':diag,'diagnostic_counts':diag_counts,'generic_userspace_markers':generic,'media':{'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'byte_identical':before==after}}
print(json.dumps(out,indent=2))
if a.require_pass and status!='PASS': raise SystemExit(1)
