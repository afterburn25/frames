#!/usr/bin/env python3
from pathlib import Path
import argparse,struct,hashlib
p=argparse.ArgumentParser(); p.add_argument('--image',required=True); p.add_argument('--package'); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
d=Path(a.image).read_bytes(); sec=512; ok=True
try:
 h=d[sec:2*sec]; assert h[:8]==b'EFI PART'; ent=struct.unpack_from('<Q',h,72)[0]*sec; first=struct.unpack_from('<Q',d,ent+32)[0]; b=first*sec; rsv=struct.unpack_from('<H',d,b+14)[0]; nf=d[b+16]; fs=struct.unpack_from('<I',d,b+36)[0]; ds=rsv+nf*fs; fat=b+rsv*sec
 def coff(c): return b+(ds+(c-2))*sec
 def fat_get(c): return struct.unpack_from('<I',d,fat+c*4)[0]&0x0fffffff
 def read_entry(name):
  raw=d[coff(5):coff(5)+sec]; found=None
  for off in range(0,sec,32):
   e=raw[off:off+32]
   if e[0]==0: break
   if e[:11]==name: found=e; break
  assert found is not None
  cl=(struct.unpack_from('<H',found,20)[0]<<16)|struct.unpack_from('<H',found,26)[0]; sz=struct.unpack_from('<I',found,28)[0]
  out=bytearray(); seen=set()
  while cl>=2 and cl<0x0ffffff8 and len(out)<sz:
   assert cl not in seen; seen.add(cl); out.extend(d[coff(cl):coff(cl)+sec]); cl=fat_get(cl)
  return bytes(out[:sz])
 challenge=read_entry(b'DEVPREV CFG'); assert challenge==b'FRAMES_DEVELOPER_PREVIEW_V1\n'
 app=read_entry(b'HELLO   FAP')
 if a.package: assert app==Path(a.package).read_bytes()
 print('PASS: DEVPREV.CFG exact challenge')
 print('PASS: HELLO.FAP embedded package byte identity')
 print('DEVPREV.CFG sha256='+hashlib.sha256(challenge).hexdigest())
 print('HELLO.FAP sha256='+hashlib.sha256(app).hexdigest())
 print('image sha256='+hashlib.sha256(d).hexdigest())
except Exception as e:
 ok=False; print('FAIL:',e)
if a.require_pass and not ok: raise SystemExit(1)
