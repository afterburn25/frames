#!/usr/bin/env python3
import argparse,json,hashlib,re
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--serial',required=True); p.add_argument('--lane',choices=['normal','detach'],required=True); p.add_argument('--qemu-exit',type=int,required=True); p.add_argument('--media',required=True); p.add_argument('--monitor'); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
raw=Path(a.serial).read_bytes(); text=raw.decode(errors='replace'); media=json.loads(Path(a.media).read_text()); mon=Path(a.monitor).read_text(errors='replace') if a.monitor and Path(a.monitor).exists() else ''
markers=['FRAMES_USB_MSC_POLICY_OK','FRAMES_USB_MSC_DEVICE_FOUND','FRAMES_USB_MSC_ENDPOINTS_OK','FRAMES_USB_MSC_CONFIGURED_OK','FRAMES_USB_MSC_INQUIRY_OK','FRAMES_USB_MSC_UNIT_ATTENTION_OK','FRAMES_USB_MSC_READY_OK','FRAMES_USB_MSC_CAPACITY_OK','FRAMES_USB_MSC_READ_OK','FRAMES_USB_MSC_READONLY_OK','FRAMES_USB_MSC_CERT_OK','FRAMES_USB_MSC_DETACH_WINDOW','FRAMES_USB_MSC_RESIDENT_OK']
fatal=['FRAMES_USB_MSC_CERT_FAIL','FRAMES_HWCOMPAT_REPORT_FAIL','FRAMES_PHYSICAL_PREVIEW_CERT_FAIL','FRAMES_USB_BOOT_CERT_FAIL','FRAMES_SMP_SCALE_CERT_FAIL','FRAMES_FAT_LIFECYCLE_FAIL','FRAMES_SYSTEM_VOLUME_WRITE_FAIL','FRAMES_FILESYSTEM_WRITE_FAIL','FRAMES_LIFECYCLE_DESTRUCTIVE_FAIL','FRAMES_STORAGE_WRITE_INTEGRITY_FAIL','FRAMES_PAGE_FAULT','FRAMES_AP_PROTECTION_FAULT=','PANIC','ASSERT','TRIPLE']
counts={m:text.count(m) for m in markers}
diag_matches=re.findall(r'FRAMES_USB_MSC_DIAG stage=(?:0x)?([0-9A-Fa-f]+) value=(?:0x)?([0-9A-Fa-f]+)',text)
diag_counts={}
diag={}
for x,y in diag_matches:
    stage=int(x,16); value=int(y,16)
    diag_counts[stage]=diag_counts.get(stage,0)+1
    if diag_counts[stage]==1:
        diag[stage]=value
checks={'markers_exact_once':all(v==1 for v in counts.values()),'no_fatal':not any(f in text for f in fatal),'qemu_exit_zero':a.qemu_exit==0,'media_pass':media.get('status')=='PASS','challenge_checksum':diag.get(12)==2301139167,'diagnostics_unique':all(v==1 for v in diag_counts.values()),'resident_after_detach_window':text.find('FRAMES_USB_MSC_RESIDENT_OK')>text.find('FRAMES_USB_MSC_DETACH_WINDOW')}
if a.lane=='detach': checks['device_deleted_event']='QMP USBMSC DEVICE_DELETED event observed' in mon; checks['resident_after_delete']='FRAMES_USB_MSC_RESIDENT_OK observed after USBMSC detach' in mon; checks['qmp_quit']='QMP quit acknowledged after USBMSC detach survival proof' in mon
status='PASS' if all(checks.values()) else 'FAIL'; out={'status':status,'profile':'native-usb-mass-storage-phase2','lane':a.lane,'serial_sha256':hashlib.sha256(raw).hexdigest(),'checks':checks,'markers':counts,'diagnostics':diag,'diagnostic_counts':diag_counts,'media':media}; print(json.dumps(out,indent=2))
if a.require_pass and status!='PASS': raise SystemExit(1)
