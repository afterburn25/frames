#!/usr/bin/env python3
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser()
for n in ['boot_before','boot_after','data_before','data_after','support_before','support_after']: p.add_argument('--'+n.replace('_','-'),dest=n,required=True)
p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
def h(x):
 b=Path(x).read_bytes(); return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
pairs={}
for name in ['boot','data','support']:
 before=h(getattr(a,name+'_before')); after=h(getattr(a,name+'_after')); pairs[name]={'before':before,'after':after,'identical':before==after}
out={'status':'PASS' if all(x['identical'] for x in pairs.values()) else 'FAIL','media':pairs}; print(json.dumps(out,indent=2))
if a.require_pass and out['status']!='PASS': raise SystemExit(1)
