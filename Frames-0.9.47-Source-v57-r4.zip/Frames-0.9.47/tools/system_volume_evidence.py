#!/usr/bin/env python3
from pathlib import Path
import argparse,json,re,hashlib
p=argparse.ArgumentParser(); p.add_argument('--serial',required=True); p.add_argument('--media',required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
log=Path(a.serial).read_text(errors='replace'); media=json.loads(Path(a.media).read_text())
markers=['FRAMES_SYSTEM_VOLUME_CLONE_FOUND','FRAMES_SYSTEM_VOLUME_FAT_OK','FRAMES_SYSTEM_VOLUME_FILE_WRITE_OK','FRAMES_SYSTEM_VOLUME_METADATA_OK','FRAMES_SYSTEM_VOLUME_GUARDS_OK','FRAMES_SYSTEM_VOLUME_RESTORE_OK','FRAMES_SYSTEM_VOLUME_WRITE_CERT_OK']
checks={m:(m in log) for m in markers}
checks['no_fail']='FRAMES_SYSTEM_VOLUME_WRITE_CERT_FAIL' not in log
checks['kernel_ready']='FRAMES_KERNEL_READY' in log
checks['media_pass']=media.get('status')=='PASS' and media.get('checks',{}).get('byte_identical_after_restore') is True
stages={}
for mm in re.finditer(r'FRAMES_SYSTEM_VOLUME_DIAG stage=0x([0-9A-Fa-f]+) detail=0x([0-9A-Fa-f]+)',log): stages[int(mm.group(1),16)]=int(mm.group(2),16)
expected={1:2048,2:64,3:131,4:131,5:3}
for k,v in expected.items(): checks[f'stage_{k}']=stages.get(k)==v
status='PASS' if all(checks.values()) else 'FAIL'
out={'status':status,'profile':'disposable-system-volume-fat32-gate4','serial_sha256':hashlib.sha256(Path(a.serial).read_bytes()).hexdigest(),'checks':checks,'diagnostics':stages,'media_status':media.get('status')}
Path(a.serial).parent.joinpath('SYSTEM-VOLUME-EVIDENCE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n'); print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and status!='PASS': raise SystemExit(1)
