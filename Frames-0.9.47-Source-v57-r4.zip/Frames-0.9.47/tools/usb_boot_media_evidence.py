#!/usr/bin/env python3
import argparse,hashlib,json,sys
from pathlib import Path
p=argparse.ArgumentParser()
for n in ['usb_before','usb_after','internal_before','internal_after','guard_before','guard_after']: p.add_argument('--'+n.replace('_','-'),dest=n,required=True)
p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
def pair(x,y):
    xb=Path(x).read_bytes(); yb=Path(y).read_bytes(); return {'before_sha256':hashlib.sha256(xb).hexdigest(),'after_sha256':hashlib.sha256(yb).hexdigest(),'same_size':len(xb)==len(yb),'byte_identical':xb==yb,'bytes':len(xb)}
out={'profile':'removable-usb-boot-gate7-media','usb_boot_media':pair(a.usb_before,a.usb_after),'internal_support_media':pair(a.internal_before,a.internal_after),'internal_guard_media':pair(a.guard_before,a.guard_after)}
out['status']='PASS' if all(v['byte_identical'] and v['same_size'] for k,v in out.items() if k.endswith('_media')) else 'FAIL'
print(json.dumps(out,indent=2,sort_keys=True))
if a.require_pass and out['status']!='PASS': sys.exit(1)
