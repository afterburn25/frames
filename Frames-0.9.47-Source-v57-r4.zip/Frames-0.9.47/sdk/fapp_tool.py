#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json, zipfile, sys

STAMP=(1980,1,1,0,0,0)
ENTRY_MANIFEST="APP-MANIFEST.json"
ENTRY_FEX="APP.FEX"

def sha256(data): return hashlib.sha256(data).hexdigest()

def verify_fex(raw):
    if len(raw) <= 128 or raw[:8] != b'FEX64\x00\x00\x00':
        raise ValueError("invalid FEX64 payload")

def package(fex_path, app_name, out_path, frames_min="0.9.47"):
    raw=Path(fex_path).read_bytes(); verify_fex(raw)
    manifest={
        "format":"FAPP1",
        "app_name":app_name,
        "frames_min":frames_min,
        "target":"frames-x64",
        "fex_abi":1,
        "payload":ENTRY_FEX,
        "fex_sha256":sha256(raw),
        "fex_size":len(raw),
    }
    manifest_raw=(json.dumps(manifest,sort_keys=True,separators=(",",":"))+"\n").encode()
    out=Path(out_path); out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,"w") as z:
        for name,data in ((ENTRY_MANIFEST,manifest_raw),(ENTRY_FEX,raw)):
            zi=zipfile.ZipInfo(name,STAMP); zi.compress_type=zipfile.ZIP_STORED
            zi.external_attr=(0o100644)<<16
            z.writestr(zi,data,compress_type=zipfile.ZIP_STORED)
    return verify(out)

def verify(path):
    p=Path(path)
    with zipfile.ZipFile(p) as z:
        if z.testzip() is not None: raise ValueError("ZIP integrity failure")
        if z.namelist() != [ENTRY_MANIFEST,ENTRY_FEX]:
            raise ValueError("unexpected FAPP entry set/order")
        manifest=json.loads(z.read(ENTRY_MANIFEST))
        raw=z.read(ENTRY_FEX)
    verify_fex(raw)
    if manifest.get("format")!="FAPP1": raise ValueError("format")
    if manifest.get("target")!="frames-x64": raise ValueError("target")
    if manifest.get("fex_abi")!=1: raise ValueError("fex_abi")
    if manifest.get("payload")!=ENTRY_FEX: raise ValueError("payload")
    if manifest.get("fex_size")!=len(raw): raise ValueError("size")
    if manifest.get("fex_sha256")!=sha256(raw): raise ValueError("hash")
    return {
        "status":"PASS",
        "profile":"frames-fapp-v1",
        "package_sha256":sha256(p.read_bytes()),
        "package_size":p.stat().st_size,
        "manifest":manifest,
    }

ap=argparse.ArgumentParser()
sp=ap.add_subparsers(dest="cmd",required=True)
p=sp.add_parser("package"); p.add_argument("fex"); p.add_argument("app_name"); p.add_argument("output")
v=sp.add_parser("verify"); v.add_argument("package")
a=ap.parse_args()
try:
    result=package(a.fex,a.app_name,a.output) if a.cmd=="package" else verify(a.package)
    print(json.dumps(result,indent=2))
except Exception as e:
    print(f"FAPP ERROR: {e}",file=sys.stderr); raise SystemExit(1)
