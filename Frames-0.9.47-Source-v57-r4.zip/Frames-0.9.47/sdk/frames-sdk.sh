#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NEXUS="${NEXUS:-$ROOT/toolchain/Nexus-Language-5.20.0/nexus}"
cmd="${1:-doctor}"
case "$cmd" in
  doctor)
    [[ -x "$NEXUS" ]] || { echo "Frames SDK: Nexus compiler missing" >&2; exit 2; }
    ver="$("$NEXUS" --version)"
    [[ "$ver" == "Nexus 5.20.0" ]] || { echo "Frames SDK: unexpected compiler: $ver" >&2; exit 1; }
    python3 - "$ROOT/sdk/SDK-MANIFEST.json" <<'PY'
import json,sys
m=json.load(open(sys.argv[1]))
assert m["frames_version"]=="0.9.47"
assert m["nexus_version"]=="5.20.0"
assert m["target"]=="frames-x64"
assert m["fex_abi"]==1
assert m["app_bundle_format"]=="FAPP1"
assert m["app_bundle_extension"]==".fapp"
print("Frames SDK doctor: PASS")
PY
    ;;
  new)
    dest="${2:?usage: frames-sdk.sh new DIR}"
    mkdir -p "$dest"
    cp "$ROOT/sdk/examples/hello/main.nx" "$dest/main.nx"
    echo "Created Frames Nexus app: $dest/main.nx"
    ;;
  build)
    src="${2:?usage: frames-sdk.sh build SOURCE.nx OUTPUT.fex}"
    out="${3:?usage: frames-sdk.sh build SOURCE.nx OUTPUT.fex}"
    "$NEXUS" check "$src"
    "$NEXUS" build "$src" --target frames-x64 -o "$out"
    "$NEXUS" inspect "$out"
    ;;
  inspect)
    fex="${2:?usage: frames-sdk.sh inspect APP.fex}"
    "$NEXUS" inspect "$fex"
    ;;
  package)
    fex="${2:?usage: frames-sdk.sh package APP.fex APP_NAME OUTPUT.fapp}"
    name="${3:?usage: frames-sdk.sh package APP.fex APP_NAME OUTPUT.fapp}"
    out="${4:?usage: frames-sdk.sh package APP.fex APP_NAME OUTPUT.fapp}"
    python3 "$ROOT/sdk/fapp_tool.py" package "$fex" "$name" "$out"
    ;;
  verify)
    app="${2:?usage: frames-sdk.sh verify APP.fapp}"
    python3 "$ROOT/sdk/fapp_tool.py" verify "$app"
    ;;
  *)
    echo "usage: frames-sdk.sh {doctor|new DIR|build SOURCE.nx OUTPUT.fex|inspect APP.fex|package APP.fex APP_NAME OUTPUT.fapp|verify APP.fapp}" >&2
    exit 2
    ;;
esac
