# Frames 0.9.41 Runtime Certification Kit v45

This is the direct-source repair candidate for the native USB MSC failure observed in v42.

## Repository use

You can either extract this kit or place the standalone files in the repository.

Put the workflow at:

`.github/workflows/frames-0.9.41-native-usb-msc-v45.yml`

Keep `Frames-0.9.41-Source-v45.zip` in the repository where the workflow can find it.

The workflow is pinned to this exact repaired source SHA-256:

`3a4d18c95d61bac7e6f3bc83307508e035f1cad4332a2ed1633c0e28332b2aa3`

Run the workflow and download:

`frames-0.9.41-native-usb-storage-evidence-v45`

Upload that evidence ZIP for certification review.

Frames 0.9.41 remains unpromoted until the external v45 run passes.
Frames 0.9.40 v41 remains the certified fallback.
