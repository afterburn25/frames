# Frames 0.9.41 Runtime Certification Kit v45

Milestone: **Native USB Mass-Storage SuperSpeed Gate Repair Certification Candidate**

Sealed source SHA-256:

`688db39790ce07d24eabc7cec26d3327192f91890c99abc6bacd8c400272a6d1`

Full workflow SHA-256:

`e12e44c8692f8fd8849a0b97e91cfcd8f78516e6788e94602896e236b5ef173c`

## Restored certification method

v45 uses the same architecture that produced the complete earlier evidence:

1. The source is repaired before CI.
2. One immutable source ZIP is sealed by SHA-256.
3. GitHub Actions selects only that exact source.
4. The complete inherited QEMU/OVMF certification chain runs.
5. Native USB MSC normal + hot-unplug lanes run last.
6. An `if: always()` evidence sweep gathers diagnostics even after a failed gate.
7. `upload-artifact@v4` uploads the entire `runtime-evidence` directory.

There is no source mutation or auto-repair step in GitHub Actions.

Expected evidence artifact:

`frames-0.9.41-native-usb-storage-evidence-v45`

Frames 0.9.41 remains a candidate until that external artifact is inspected and
accepted. Frames 0.9.40 v41 remains authoritative.
