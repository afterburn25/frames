# Frames 0.9.41 v45 — Native USB MSC SuperSpeed Gate Repair Candidate

This is a certification revision of Frames 0.9.41, not a promotion or a product
version bump. Frames 0.9.40 v41 remains the authoritative externally certified
baseline until v45 external evidence passes.

## Corrected

- Native USB MSC configuration now accepts xHCI speed ID 4 (SuperSpeed) in the
  QEMU `qemu-xhci + usb-storage` certification profile.
- The repair is applied to the source before CI and sealed by SHA-256.
- The full v42-style external certification workflow is restored; CI performs no
  source mutation or auto-repair.
- A source-specific v45 verifier prevents the SuperSpeed rejection from returning
  and protects the existing `SET_CONFIGURATION` and read-only SCSI constraints.

## Unchanged safety scope

- Read-only BOT/SCSI path only: INQUIRY, TEST UNIT READY, READ CAPACITY(10), READ(10).
- No SCSI WRITE(10).
- Protected boot/data/support media must satisfy the existing byte-identity rules.
- Physical boot approval is not granted by this repair.
- Frames 1.0 remains NOT promoted.
