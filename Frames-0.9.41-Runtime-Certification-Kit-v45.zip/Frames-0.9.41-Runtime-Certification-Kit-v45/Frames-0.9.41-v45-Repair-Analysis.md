# Frames 0.9.41 v45 — Native USB MSC SuperSpeed Gate Repair Analysis

Date: 2026-08-12 (America/Chicago)
Status: certification candidate; **not externally certified**
Authoritative fallback: Frames 0.9.40 v41

## Why v43/v44 are retired

The v43/v44 track changed the proven certification architecture by asking GitHub
Actions to locate and mutate the v42 source before certification. That repair-first
wrapper was much smaller than the full v42 certification workflow and could fail
before QEMU while still uploading a nearly empty evidence directory.

v45 returns to the prior method: repair locally, seal one immutable source ZIP,
then make GitHub Actions certify that exact SHA with the full inherited pipeline.
The CI workflow does not mutate the source.

## v42 runtime failure boundary

The v42 runtime evidence recorded:

- `FRAMES_USB_MSC_DEVICE_FOUND`
- `FRAMES_USB_MSC_ENDPOINTS_OK`
- `FRAMES_USB_MSC_DIAG stage=0x1 value=0x304`
- `FRAMES_USB_MSC_DIAG stage=0x2 value=0x4`
- `FRAMES_USB_MSC_CERT_FAIL`

No `FRAMES_USB_MSC_CONFIGURED_OK` marker was reached.

In the exact v42 source, stage 2 is emitted by the first check inside
`usb_msc_configure()`:

```text
let speed=volatile_read64(xhci_state+184);
if speed<2 || speed>=4 { serial_usb_msc_diag(2,speed); return 0; }
```

Therefore value `0x4` was rejected before endpoint-context configuration and before
the later `SET_CONFIGURATION` request.

## v45 source repair

The single runtime logic change is:

```text
speed<2 || speed>=4
```

becomes:

```text
speed<2 || speed>4
```

This admits xHCI protocol speed ID 4 (SuperSpeed), which is the value observed in
the v42 QEMU `qemu-xhci + usb-storage` lane. Endpoint maximum packet sizes up to
1024 bytes were already supported by the surrounding code.

The `SET_CONFIGURATION` request is intentionally unchanged:

```text
xhci_control_no_data_out(xhci_state,2304+(config*65536))
```

The v45 verifier requires that packing to remain present and continues to require
that SCSI `WRITE(10)` is absent.

## Sealed identities

- Frames source: `Frames-0.9.41-Source-v45.zip`
- Source SHA-256: `688db39790ce07d24eabc7cec26d3327192f91890c99abc6bacd8c400272a6d1`
- Full external workflow: `Frames-0.9.41-GitHub-Native-USB-Mass-Storage-Certification-v45.yml`
- Workflow SHA-256: `e12e44c8692f8fd8849a0b97e91cfcd8f78516e6788e94602896e236b5ef173c`

## Promotion rule

Frames 0.9.41 remains NOT promoted until the full external v45 workflow re-proves
all inherited Gates 1–8, the seven-profile 0.9.40 hardware matrix, and both native
USB MSC lanes with exact markers, byte-identical protected media, no fatal/write
markers, and `DEVICE_DELETED` before the detach-lane resident proof.
