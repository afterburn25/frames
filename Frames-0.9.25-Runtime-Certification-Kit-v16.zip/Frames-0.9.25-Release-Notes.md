# Frames 0.9.25 — Scheduler Stress/Fault Certification Phase 2

Frames 0.9.24 externally passed allocator stress category 1 while preserving the clean 70/70 QEMU runtime baseline. 0.9.25 advances to scheduler category 2 without changing the required 70-marker runtime contract.

## Scheduler stress

A synthetic scheduler state exercises round-robin choice, CPU-affinity mismatch, wildcard affinity, sleeping/exited workers, and the no-runnable boundary without performing a context switch. Only after that matrix passes is the live BSP scheduler armed for stress observation.

The live certificate requires at least 512 BSP timer ticks and dispatches; worker-0 sleep/wake/resume progress; worker-1 exit and reap; sustained scheduler and lifecycle proof; correct BSP/AP affinity; an already-certified BSP↔AP scheduler relationship; at least 32 AP timer IRQs, AP dispatches and AP worker runs; AP runqueue-return proof; and real reschedule-IPI receipt.

`FRAMES_STRESS_SCHEDULER_OK` is emitted only after all checks pass. `FRAMES_STRESS_SCHEDULER_FAIL` records fail-closed scheduler stress evidence.

## Evidence integrity

`stress_evidence.py` now hashes the raw serial bytes, matching `runtime_evidence.py` and eliminating the harmless CRLF-normalization hash difference observed in the 0.9.24 artifact. A valid phase-2 certificate requires exactly two executed and passed stress categories: allocator and scheduler.

Categories storage-read, USB/input, network, display, recovery and power remain NOT-EXECUTED. Frames 1.0 remains blocked.
