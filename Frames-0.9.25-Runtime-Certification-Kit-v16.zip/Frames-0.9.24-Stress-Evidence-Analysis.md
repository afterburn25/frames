# Frames 0.9.24 Stress Evidence Analysis

The GitHub Actions QEMU/OVMF v15 artifact is a valid allocator-stress phase-1 pass.

## Runtime baseline retained

- Frames version: 0.9.24
- QEMU certifier exit code: 0
- Required runtime markers: 70 expected / 70 present / 0 missing / 0 fatal
- Runtime evidence: PASS
- Groups PASS: core, platform, smp, userspace, storage_nvme, safety
- Short-circuit runtime: PASS; fallback-after-ack absent
- Read-only NVMe runtime profile: PASS; write_path_certified=false
- Physical boot approved: false
- Archived serial.log raw SHA-256: d2c17e161e0dbfeac8e3900a88426aaac3fd64361ceacbac3adee8e4d0020231

## Allocator stress phase 1

- Stress certifier exit code: 0
- FRAMES_STRESS_ALLOCATOR_OK: present
- FRAMES_STRESS_ALLOCATOR_FAIL: absent
- executed_categories: 1
- passed_categories: 1
- failed_categories: 0
- allocator: PASS
- scheduler, storage-read, usb-input, network, display, recovery, power: NOT-EXECUTED
- frames_1_0_promoted: false

## Evidence hash note

The 0.9.24 `STRESS-EVIDENCE.json` records serial SHA-256 `e622338c0f7c628b21f8b25ae67fc57b6544b5611aa6c49dc01708ea83d71c71`, while the archived serial file hashes to `d2c17e161e0dbfeac8e3900a88426aaac3fd64361ceacbac3adee8e4d0020231`.

This is not divergent runtime content. The 0.9.24 stress tool used `Path.read_text()` and then hashed the normalized UTF-8 text. Python normalized 12 CRLF sequences to LF. Re-hashing that normalized text reproduces `e622338...` exactly. `runtime_evidence.py` hashes raw bytes and reproduces `d2c17e...` exactly. Frames 0.9.25 changes stress evidence to hash raw serial bytes so both evidence paths use the same artifact-integrity convention.

Conclusion: allocator stress category 1 is externally PASS. Frames 1.0 remains blocked.
