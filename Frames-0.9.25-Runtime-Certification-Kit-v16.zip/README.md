# Frames 0.9.25 Scheduler Stress Certification Kit v16

Use this kit for the next GitHub Actions QEMU/OVMF certification run.

1. Put the v16 kit at the repository root (duplicate suffixes such as `(1)` are supported).
2. Replace the active workflow with `Frames-0.9.25-GitHub-Stress-Certification-v16.yml`.
3. Run the workflow.
4. Download and upload the `frames-0.9.25-stress-evidence` artifact.

A valid phase-2 result requires the unchanged 70/70 runtime gate plus allocator and scheduler stress PASS. `STRESS-EVIDENCE.json` must report exactly 2 executed / 2 passed / 0 failed; six categories must remain NOT-EXECUTED. Physical boot and Frames 1.0 remain blocked.
