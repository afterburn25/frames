# Frames 0.9.14 Runtime Certification Kit

Put this kit ZIP or `Frames-0.9.14-Source.zip` at the repository root.
Use `Frames-0.9.14-GitHub-Runtime-Certification.yml` as `.github/workflows/frames-runtime-certify.yml`.
Run the workflow and upload the resulting `frames-runtime-evidence` artifact for analysis.

Frames 0.9.14 remains diagnostic-only; physical boot and Frames 1.0 promotion are blocked pending real evidence.
