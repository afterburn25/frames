# Frames 0.9.36 Runtime Certification Kit v31

Gate 5: **FAT32 Allocation & Full File Lifecycle Certification**

Sealed source SHA-256:

`237a02bd730509cd21f3cbd14e8c8eb55ade8de259dcc931d12e61954948d69f`

Workflow SHA-256:

`8cc72eb1ac7c7340802f2ab05befa6a0ba947a922363620855d325d8e3e82cfd`

The real Frames boot/system NVMe remains read-only.

The writable Gate-5 target is a disposable 64 MiB system-volume clone whose
NVMe serial must be exactly `FRAMESFAT0936`.

Before writes arm, Frames validates:
- GPT/FAT32 system-volume structure;
- read-only `FATGATE.CFG` descriptor;
- four-cluster allocation pool;
- one writable FAT sector in each mirror;
- both FAT sectors are identical;
- every FAT entry in those writable sectors is free;
- exact seven-LBA write allowlist.

Runtime lifecycle:
1. create `LIFE0001.TST`;
2. grow it from one to four clusters;
3. truncate it to two clusters and free released clusters;
4. rename it to `LIFE0002.TST`;
5. delete it and free its chain;
6. create `LIFE0003.TST` using freed clusters;
7. delete and restore the complete test region.

Required accounting:
- 7 lifecycle phases
- 47 NVM Write commands
- 33 NVM Flush commands
- 14 mirrored FAT-entry updates
- full 64 MiB clone byte-identical after restore

v31 also re-proves all accepted Gates 1–4 before Gate 5.

Expected evidence artifact:

`frames-0.9.36-fat-lifecycle-evidence-v31`

Physical-machine writes, actual boot-volume writes, removable USB boot,
physical boot, and Frames 1.0 remain blocked.
