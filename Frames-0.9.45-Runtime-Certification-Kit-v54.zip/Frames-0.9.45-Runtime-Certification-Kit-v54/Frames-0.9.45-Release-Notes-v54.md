# Frames 0.9.45 — Nexus SDK / Developer Tooling Phase 2: FEX Application Packaging

Built from the externally certified Frames 0.9.44 v53 baseline.

Phase 2 introduces the deterministic FAPP1 application-bundle contract. The SDK
can now package a verified FEX64 executable with a canonical application manifest
and verify the bundle's FEX hash, size, target, and ABI. Repeated packaging of the
same FEX/name must produce byte-identical `.fapp` output.

The HelloFrames SDK example is built into `HelloFrames.fapp`. Certification embeds
that package on the Developer Preview image under the short FAT alias `HELLO.FAP`
and proves byte identity against the host-generated `.fapp`. The preview image is
still attached read-only during QEMU certification.

This milestone does not add arbitrary package loading in the kernel yet. It first
certifies the package/storage contract that a later app-loader phase will consume.

Physical boot remains blocked, reboot/shutdown remain blocked in Developer Preview,
and SCSI WRITE(10) remains absent.
