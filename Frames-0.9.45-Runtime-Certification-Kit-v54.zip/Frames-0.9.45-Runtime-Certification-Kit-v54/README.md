# Frames 0.9.45 Runtime Certification Kit v54

This kit certifies Nexus SDK / Developer Tooling Phase 2: deterministic FAPP1 application packaging.

Install `Frames-0.9.45-GitHub-Nexus-SDK-App-Packaging-Certification-v54.yml` as:
`.github/workflows/frames-0.9.45-nexus-sdk-app-packaging-v54.yml`

Keep `Frames-0.9.45-Source-v54.zip` available in the repository.

Exact source SHA-256:
`60c207d9a1c1936bc0f9c35f7fdcd111380a1f275b36bd7f40acf0f44134184a`

Expected artifact:
`frames-0.9.45-nexus-sdk-app-packaging-evidence-v54.zip`

Physical hardware boot remains blocked.
