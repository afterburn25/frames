Frames 0.9.26 Storage-Read Stress Certification Kit v17

Upload this ZIP to the GitHub repository root and use Frames-0.9.26-GitHub-Stress-Certification-v17.yml as the active workflow.

Expected evidence artifact: frames-0.9.26-stress-evidence
Required phase-3 result: 70/70 base runtime markers; allocator, scheduler, storage-read PASS; exactly five stress categories NOT-EXECUTED; zero fatal markers.
Frames 1.0 and physical boot remain blocked.
