# Frames 0.9.25 Stress Evidence Analysis

Frames 0.9.25 v16 is a valid external QEMU/OVMF PASS and completes stress/fault category 2 (scheduler) while preserving category 1 (allocator).

- QEMU certifier exit: 0
- Stress certifier exit: 0
- Required runtime markers: 70/70, zero missing, zero fatal
- Runtime groups: core/platform/SMP/userspace/storage_nvme/safety PASS
- Raw archived serial SHA-256: `1854eebc224b321cf5a7b472df8efa796070c25aaf0d20a18f7b6e2232ca9715`
- Stress profile: `stress-fault-phase2-allocator-scheduler`
- Executed/pass/fail: 2 / 2 / 0
- allocator: PASS
- scheduler: PASS
- storage-read, usb-input, network, display, recovery, power: NOT-EXECUTED
- `FRAMES_STRESS_ALLOCATOR_OK` present
- `FRAMES_STRESS_SCHEDULER_OK` present
- `FRAMES_STRESS_SCHEDULER_FAIL` absent
- `FRAMES_SMP_SCHEDULER_OK` and `FRAMES_KERNEL_READY` present
- Physical boot approved: false
- Persistent write path: not certified

The stress-evidence serial SHA exactly matches the archived `serial.log` and runtime-evidence SHA, confirming the raw-byte hashing repair introduced after 0.9.24.
