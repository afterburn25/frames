# Frames 0.9.27 — USB/Input Stress/Fault Certification Phase 4

- Preserves the externally verified Frames 0.9.26 70/70 QEMU runtime baseline and allocator+scheduler+storage-read stress passes.
- Repairs the xHCI boot-HID transition needed for category 4: corrects full/low-speed interval rounding, programs Max ESIT Payload/Average TRB Length for the periodic interrupt endpoint, and explicitly selects HID boot protocol after SET_CONFIGURATION.
- Adds stress category 4 for the xHCI boot-HID and input-queue path.
- Requires a configured xHCI boot-HID endpoint, a completed real HID interrupt report, matching HID protocol state, and an intact captured-report checksum before stress begins.
- Replays the captured hardware-originated HID report into an isolated 64-event scratch input queue for 128 decode cycles without mutating the live input queue.
- Forces deterministic queue wrap/overwrite behavior and verifies final capacity/count/head/tail invariants, event-kind validity, and nonzero event timestamps.
- Revalidates the original HID report checksum on every cycle and after the queue stress run, proving the captured DMA report remains stable while input decoding is exercised.
- Emits `FRAMES_STRESS_USB_INPUT_OK` only after every USB/input invariant passes; otherwise emits `FRAMES_STRESS_USB_INPUT_FAIL`.
- Stress evidence phase 4 requires exactly allocator, scheduler, storage-read, and USB/input PASS. Network, display, recovery, and power remain NOT-EXECUTED.
- The existing 70-marker base runtime contract remains unchanged and stress markers remain orthogonal to it.
- Physical boot remains BLOCKED. Persistent-media writes remain absent/uncertified. Frames 1.0 is not promoted.
