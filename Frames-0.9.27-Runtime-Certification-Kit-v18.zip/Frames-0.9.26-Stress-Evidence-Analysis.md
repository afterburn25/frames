# Frames 0.9.26 Stress Evidence Analysis

Evidence inspected: `frames-0.9.26-stress-evidence(1).zip` (2026-08-11)

## Result

Frames 0.9.26 passed the intended Phase-3 QEMU/OVMF stress gate and is the accepted external runtime/stress baseline for Frames 0.9.27 development.

- QEMU certifier exit: 0
- Stress certifier exit: 0
- Base runtime markers: 70 expected / 70 present / 0 missing
- Fatal markers: 0
- Runtime groups: core, platform, safety, SMP, storage/NVMe, userspace PASS
- Allocator stress: PASS
- Scheduler stress: PASS
- Storage-read stress: PASS
- Stress categories: 3 executed / 3 passed / 0 failed
- USB/input, network, display, recovery, power: NOT-EXECUTED
- Short-circuit runtime: PASS; eager RHS after acknowledgement false; fallback absent
- Persistent storage writes: not certified
- Frames 1.0 promotion: blocked
- Physical boot: blocked

Evidence ZIP SHA-256: `84a761b0b07ded53acbbd59a76ff7cc02e965c5eaa65189c89f5a29632520421`
Serial SHA-256: `ad2366fada20c19a1c0e8673ac3c9d57401884ce6608e494cc8fc90c1452c70d`

This evidence justifies using 0.9.26 as the inherited external baseline. It does not certify the new 0.9.27 USB/input phase; that requires a new external QEMU/OVMF run.
