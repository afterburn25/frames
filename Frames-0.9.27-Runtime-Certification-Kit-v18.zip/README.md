Frames 0.9.27 USB/Input Stress Certification Kit v18

Upload this ZIP to the GitHub repository root and use Frames-0.9.27-GitHub-Stress-Certification-v18.yml as the active workflow.

Expected evidence artifact: frames-0.9.27-stress-evidence
Required phase-4 result: 70/70 base runtime markers; allocator, scheduler, storage-read, USB/input PASS; exactly four stress categories NOT-EXECUTED; zero fatal markers.
Frames 1.0 and physical boot remain blocked.

The source also repairs the xHCI boot-HID transition needed for the phase: full/low-speed interval rounding, periodic endpoint Max ESIT Payload/Average TRB Length, and explicit HID boot-protocol selection.
