# Frames 0.9.29 Runtime Certification Kit v22

Run the included GitHub Actions workflow against this kit/source. Promotion requires 70/70 base markers and exactly 6/6 Phase-6 stress PASS, including display.
