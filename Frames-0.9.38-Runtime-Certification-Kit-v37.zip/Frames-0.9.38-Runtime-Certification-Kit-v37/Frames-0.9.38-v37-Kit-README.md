# Frames 0.9.38 Runtime Certification Kit v37

Milestone: **Removable USB Boot Certification Gate 7**

Sealed source SHA-256:

`44b303cb34471108bc8825ee435023eaaf6cf2e900218f5dea53932b34649928`

Workflow SHA-256:

`a3cdf3d1f071b870e15f8dabcbd31184cdb005e08e739948f98409a7655d8b3f`

Gate 7 uses a dedicated 64 MiB GPT/FAT32 certification image containing
`Frames/USBBOOT.CFG` with the exact challenge `FRAMES_USB_BOOT_CERT_V1`.

The UEFI loader must prove:
- it was loaded from a device path containing a USB messaging node;
- Block I/O exists and media is present on the same loaded-image device handle;
- FramesKernel.fkrn and System.fex were loaded and SHA-256 verified from that
  challenged USB filesystem.

The guest then emits:
- FRAMES_USB_BOOT_POLICY_OK
- FRAMES_USB_BOOT_DEVICE_PATH_OK
- FRAMES_USB_BOOT_MEDIA_OK
- FRAMES_USB_BOOT_SYSTEM_READ_OK
- FRAMES_USB_BOOT_CERT_OK
- FRAMES_USB_BOOT_DETACH_WINDOW
- FRAMES_USB_BOOT_RESIDENT_OK

v37 runs two USB lanes:
1. normal removable USB boot/handoff;
2. actual QMP hot-unplug during the detach window, requiring a real
   DEVICE_DELETED event before the resident-kernel proof.

Both lanes require the USB boot image, internal support volume, and independent
writable internal guard media to remain byte-identical.

The workflow first re-proves every accepted Frames 0.9.37 requirement,
including the full 2/4/8/16/32/64/96 logical-CPU SMP matrix.

Expected evidence artifact:

`frames-0.9.38-usb-boot-evidence-v37`

This gate does not certify native post-ExitBootServices USB mass-storage I/O or
physical USB hardware. Physical boot remains BLOCKED.
