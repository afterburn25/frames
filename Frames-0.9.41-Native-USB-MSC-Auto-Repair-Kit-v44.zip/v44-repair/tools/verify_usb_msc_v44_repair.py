#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path

REQ_MARKERS = [
    'FRAMES_USB_MSC_POLICY_OK','FRAMES_USB_MSC_DEVICE_FOUND','FRAMES_USB_MSC_ENDPOINTS_OK',
    'FRAMES_USB_MSC_CONFIGURED_OK','FRAMES_USB_MSC_INQUIRY_OK','FRAMES_USB_MSC_READY_OK',
    'FRAMES_USB_MSC_CAPACITY_OK','FRAMES_USB_MSC_READ_OK','FRAMES_USB_MSC_READONLY_OK',
    'FRAMES_USB_MSC_CERT_OK','FRAMES_USB_MSC_DETACH_WINDOW','FRAMES_USB_MSC_RESIDENT_OK',
]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--repair-report', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a=p.parse_args()
    root=a.source
    report=json.loads(a.repair_report.read_text())
    checks={}
    checks['version_0941']=(root/'VERSION').read_text().strip()=='0.9.41'
    checks['repair_report_pass']=report.get('status')=='PASS' and bool(report.get('changed'))
    texts=[]
    for f in root.rglob('*'):
        if not f.is_file() or any(x in f.parts for x in ('build','toolchain','.git')): continue
        if f.suffix.lower() not in ('.nx','.nxs','.c','.h','.py','.sh','.txt','.md'): continue
        try: texts.append(f.read_text(errors='strict'))
        except Exception: pass
    corpus='\n'.join(texts)
    checks['markers_retained']=all(m in corpus for m in REQ_MARKERS)
    checks['fatal_marker_retained']='FRAMES_USB_MSC_CERT_FAIL' in corpus
    # The original 0.9.41 contract intentionally implements only read-side SCSI.
    # Reject obvious new WRITE(10) opcode/code declarations while allowing docs that say it is absent.
    bad=[]
    for f in root.rglob('*'):
        if not f.is_file() or any(x in f.parts for x in ('build','toolchain','.git')): continue
        if f.suffix.lower() not in ('.nx','.nxs','.c','.h'): continue
        try: t=f.read_text(errors='strict')
        except Exception: continue
        for pat in (r'\bSCSI[_A-Z]*WRITE[_A-Z]*10\b', r'\bWRITE10\b', r'\bwrite10\s*\(', r'\bscsi_write\s*\('):
            if re.search(pat,t,re.I): bad.append(str(f.relative_to(root)))
    checks['scsi_write10_implementation_absent']=not bad
    checks['qemu_usb_msc_certifier_present']=(root/'tools/qemu_usb_msc_matrix_certify.sh').is_file()
    checks['original_0941_verifier_present']=(root/'tools/verify_runtime_repair_0941.py').is_file()
    out={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'write10_hits':sorted(set(bad))}
    a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
    return 0 if out['status']=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())
