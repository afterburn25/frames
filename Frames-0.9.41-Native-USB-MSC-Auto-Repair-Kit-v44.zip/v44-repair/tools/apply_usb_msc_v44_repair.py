#!/usr/bin/env python3
from __future__ import annotations
import argparse, difflib, hashlib, json, re
from pathlib import Path

TEXT_SUFFIXES={'.nx','.nxs','.c','.h','.cc','.cpp','.inc','.txt'}
SKIP_PARTS={'build','toolchain','.git','runtime-evidence'}
MARKER_A='FRAMES_USB_MSC_ENDPOINTS_OK'
MARKER_B='FRAMES_USB_MSC_CONFIGURED_OK'
FATAL='FRAMES_USB_MSC_CERT_FAIL'
ANCHORS=('SET_CONFIGURATION','USB_REQ_SET_CONFIGURATION','USB_REQUEST_SET_CONFIGURATION','set_configuration','set configuration','SetConfiguration','SET CONFIGURATION')
PACKED_SETUP='0x0000000000010900'

def sha(b:bytes): return hashlib.sha256(b).hexdigest()

def iter_text(root:Path):
    for p in root.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in TEXT_SUFFIXES: continue
        rel=p.relative_to(root)
        if any(x in rel.parts for x in SKIP_PARTS): continue
        try: t=p.read_text()
        except Exception: continue
        yield p,t

def anchors_in(text:str):
    out=[]; low=text.lower()
    for a in ANCHORS:
        n=a.lower(); s=0
        while True:
            i=low.find(n,s)
            if i<0: break
            out.append(i); s=i+max(1,len(n))
    return sorted(set(out))

def replace_assignment(block,names,value):
    changes=[]
    for name in names:
        pat=re.compile(rf'(?P<prefix>(?<![A-Za-z0-9_])(?:(?:[A-Za-z_][A-Za-z0-9_]*)\.)?{re.escape(name)}\s*(?:=|:)\s*)(?P<value>[^,;\n\r}}]+)',re.I)
        m=pat.search(block)
        if m:
            old=m.group('value').strip()
            if old!=value:
                block=block[:m.start('value')]+value+block[m.end('value'):]
                changes.append({'field':name,'old':old,'new':value})
    return block,changes

def patch_named(text,anchor):
    lo=max(0,anchor-1500); hi=min(len(text),anchor+2200); block=text[lo:hi]; orig=block; allc=[]
    specs=[(('bmRequestType','request_type','requestType'),'0x00'),(('bRequest','request','request_code'),'0x09'),(('wValue','value'),'0x0001'),(('wIndex','index'),'0x0000'),(('wLength','length'),'0x0000')]
    present=[]
    for names,val in specs:
        present.append(any(re.search(rf'(?<![A-Za-z0-9_])(?:(?:[A-Za-z_][A-Za-z0-9_]*)\.)?{re.escape(n)}\s*(?:=|:)',orig,re.I) for n in names))
        block,c=replace_assignment(block,names,val); allc.extend(c)
    if sum(present)>=4 and present[1]:
        return text[:lo]+block+text[hi:], 'named-fields' if allc else 'named-fields-already-correct', allc
    return text,None,[]

def patch_array(text,anchor):
    lo=max(0,anchor-1600); hi=min(len(text),anchor+2200); block=text[lo:hi]
    found={}; pat=re.compile(r'(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*\[\s*(?P<idx>[0-7])\s*\]\s*=\s*(?P<val>[^;\n\r,]+)')
    for m in pat.finditer(block): found.setdefault(m.group('var'),set()).add(int(m.group('idx')))
    found={k:v for k,v in found.items() if len(v)>=5 and 0 in v and 1 in v}
    if len(found)!=1:return text,None,[]
    var=next(iter(found)); vals={0:'0x00',1:'0x09',2:'0x01',3:'0x00',4:'0x00',5:'0x00',6:'0x00',7:'0x00'}; changes=[]
    for idx,val in vals.items():
        p=re.compile(rf'(?P<prefix>\b{re.escape(var)}\s*\[\s*{idx}\s*\]\s*=\s*)(?P<value>[^;\n\r,]+)'); m=p.search(block)
        if not m: continue
        old=m.group('value').strip()
        if old!=val:
            block=block[:m.start('value')]+val+block[m.end('value'):]; changes.append({'field':f'{var}[{idx}]','old':old,'new':val})
    return (text[:lo]+block+text[hi:], 'setup-byte-array' if changes else 'setup-byte-array-already-correct', changes)

def patch_packed(text,anchor):
    lo=max(0,anchor-1200); hi=min(len(text),anchor+1600); block=text[lo:hi]
    pat=re.compile(r'(?P<prefix>\b(?:setup(?:_packet|_param|_value|_request)?|request(?:_packet|_param|_value)?|trb_parameter)\b\s*=\s*)(?P<value>0x[0-9A-Fa-f]{8,16}|[0-9]+)',re.I)
    ms=list(pat.finditer(block))
    if len(ms)!=1:return text,None,[]
    m=ms[0]; old=m.group('value')
    if old.lower()==PACKED_SETUP.lower(): return text,'packed-setup-already-correct',[]
    block=block[:m.start('value')]+PACKED_SETUP+block[m.end('value'):]
    return text[:lo]+block+text[hi:],'packed-setup',[{'field':'packed setup packet','old':old,'new':PACKED_SETUP}]

def split_args(s):
    args=[]; buf=[]; depth=0; quote=None; esc=False
    for ch in s:
        if quote:
            buf.append(ch)
            if esc: esc=False
            elif ch=='\\':esc=True
            elif ch==quote:quote=None
            continue
        if ch in ('"',"'"): quote=ch; buf.append(ch); continue
        if ch in '([{':depth+=1
        elif ch in ')]}':depth=max(0,depth-1)
        if ch==',' and depth==0: args.append(''.join(buf).strip());buf=[]
        else:buf.append(ch)
    args.append(''.join(buf).strip());return args

def patch_helper(text,anchor):
    lo=max(0,anchor-1600); hi=min(len(text),anchor+2200); block=text[lo:hi]
    call_start=re.compile(r'\b(?P<fn>[A-Za-z_][A-Za-z0-9_]*(?:control|setup|request)[A-Za-z0-9_]*)\s*\(',re.I); cands=[]
    for m in call_start.finditer(block):
        depth=1;quote=None;esc=False;j=m.end()
        while j<len(block) and depth:
            ch=block[j]
            if quote:
                if esc:esc=False
                elif ch=='\\':esc=True
                elif ch==quote:quote=None
            else:
                if ch in ('"',"'"):quote=ch
                elif ch=='(':depth+=1
                elif ch==')':depth-=1
            j+=1
        if depth:continue
        args=split_args(block[m.end():j-1]); ri=[i for i,a in enumerate(args) if re.search(r'SET[_ ]?CONFIGURATION|USB_REQ_SET_CONFIGURATION|USB_REQUEST_SET_CONFIGURATION',a,re.I)]
        if not ri:
            context=block[max(0,m.start()-220):min(len(block),j+220)]
            if 'set_configuration' in context.lower() or 'set configuration' in context.lower(): ri=[i for i,a in enumerate(args) if a.strip().lower() in ('9','0x09')]
        if len(ri)==1:cands.append((m,j,args,ri[0]))
    if len(cands)!=1:return text,None,[]
    m,j,args,ri=cands[0]
    if ri<1 or ri+3>=len(args):return text,None,[]
    old=[args[ri-1],args[ri],args[ri+1],args[ri+2],args[ri+3]]
    args[ri-1]='0x00'
    if re.fullmatch(r'\s*(?:9|0x0?9)\s*',args[ri],re.I):args[ri]='0x09'
    args[ri+1]='0x0001';args[ri+2]='0x0000';args[ri+3]='0x0000'
    new=m.group(0)+', '.join(args)+')'; oldcall=block[m.start():j]
    if oldcall==new:return text,'control-helper-call-already-correct',[]
    block=block[:m.start()]+new+block[j:]
    newv=[args[ri-1],args[ri],args[ri+1],args[ri+2],args[ri+3]]
    changes=[{'field':f,'old':o,'new':n} for f,o,n in zip(('bmRequestType','bRequest','wValue','wIndex','wLength'),old,newv)]
    return text[:lo]+block+text[hi:],'control-helper-call',changes

METHODS=(patch_named,patch_array,patch_packed,patch_helper)

def score_file(text,path,anchor):
    s=0; low=text.lower()
    has_a=MARKER_A in text;has_b=MARKER_B in text
    if has_a:s+=80
    if has_b:s+=80
    if has_a and has_b:s+=80
    if 'usb_msc' in low or 'usb msc' in low or 'mass-storage' in low or 'mass storage' in low:s+=50
    if 'xhci' in low:s+=20
    for marker in (MARKER_A,MARKER_B):
        pos=text.find(marker)
        if pos>=0:
            d=abs(anchor-pos)
            if d<=4000:s+=50
            elif d<=12000:s+=25
    name=str(path).lower()
    if 'usb' in name:s+=15
    if 'msc' in name:s+=25
    return s

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--report',type=Path,required=True);ap.add_argument('--diff',type=Path,required=True);a=ap.parse_args()
    root=a.source.resolve(); report={'repair_revision':'v44','target':'Frames 0.9.41 native USB MSC SET_CONFIGURATION control request','source_root':str(root),'status':'FAIL','fail_closed':True}
    a.report.parent.mkdir(parents=True,exist_ok=True)
    if not (root/'VERSION').is_file() or (root/'VERSION').read_text().strip()!='0.9.41':
        report['reason']='source VERSION is not exactly 0.9.41';a.report.write_text(json.dumps(report,indent=2)+'\n');return 2
    files=list(iter_text(root)); ma=[p for p,t in files if MARKER_A in t]; mb=[p for p,t in files if MARKER_B in t]
    report['marker_a_files']=[str(p.relative_to(root)) for p in ma];report['marker_b_files']=[str(p.relative_to(root)) for p in mb]
    if not ma or not mb:
        report['reason']='required USB MSC boundary markers were not both found somewhere in source';a.report.write_text(json.dumps(report,indent=2)+'\n');return 3
    target=[]
    for p,t in files:
        aa=anchors_in(t)
        if not aa:continue
        low=t.lower(); relevant=(MARKER_A in t or MARKER_B in t or 'usb_msc' in low or 'usb msc' in low or 'mass storage' in low or 'mass-storage' in low)
        if relevant:
            for pos in aa:target.append((p,t,pos,score_file(t,p,pos)))
    report['anchor_candidate_count']=len(target)
    diag=[]; recognized=[]
    for p,t,pos,sc in target:
        entry={'file':str(p.relative_to(root)),'anchor_offset':pos,'score':sc,'excerpt':t[max(0,pos-900):min(len(t),pos+1500)]}
        methods=[]
        for fn in METHODS:
            cand,name,changes=fn(t,pos)
            if name:
                methods.append({'method':name,'changed':cand!=t,'changes':changes})
                recognized.append((sc,p,t,pos,cand,name,changes))
        entry['recognized_methods']=methods;diag.append(entry)
    report['candidates']=diag[:40]
    # Deduplicate equivalent recognitions by file+result hash, then rank.
    uniq={}
    for item in recognized:
        sc,p,t,pos,cand,name,changes=item; key=(str(p),sha(cand.encode()))
        old=uniq.get(key)
        if old is None or sc>old[0]:uniq[key]=item
    rec=list(uniq.values()); rec.sort(key=lambda x:x[0],reverse=True)
    changed=[x for x in rec if x[4]!=x[2]]
    report['recognized_candidate_count']=len(rec);report['changed_candidate_count']=len(changed)
    if not changed:
        report['reason']='no uniquely recognized incorrect SET_CONFIGURATION representation found; detailed candidate excerpts retained';a.report.write_text(json.dumps(report,indent=2)+'\n');return 4
    top=changed[0]
    ambiguous=len(changed)>1 and changed[1][0]>=top[0]-20
    if ambiguous:
        report['reason']='multiple high-confidence mutable SET_CONFIGURATION candidates; refusing to guess';report['top_scores']=[x[0] for x in changed[:5]];a.report.write_text(json.dumps(report,indent=2)+'\n');return 5
    sc,path,original,pos,repaired,method,changes=top
    # Require the chosen file to be semantically tied to MSC, or to carry a certification marker.
    low=original.lower(); tied=(MARKER_A in original or MARKER_B in original or 'usb_msc' in low or 'usb msc' in low or 'mass storage' in low or 'mass-storage' in low)
    if not tied:
        report['reason']='top candidate was not semantically tied to USB MSC';a.report.write_text(json.dumps(report,indent=2)+'\n');return 6
    for marker in (MARKER_A,MARKER_B,FATAL):
        if marker not in '\n'.join(t for _,t in files):
            report['reason']=f'required policy marker missing from source: {marker}';a.report.write_text(json.dumps(report,indent=2)+'\n');return 7
    path.write_text(repaired)
    diff=''.join(difflib.unified_diff(original.splitlines(True),repaired.splitlines(True),fromfile=str(path.relative_to(root))+'.v43',tofile=str(path.relative_to(root))+'.v44'))
    a.diff.parent.mkdir(parents=True,exist_ok=True);a.diff.write_text(diff)
    report.update({'status':'PASS','source_file':str(path.relative_to(root)),'source_file_before_sha256':sha(original.encode()),'source_file_after_sha256':sha(repaired.encode()),'method':method,'changes':changes,'score':sc,'changed':True,'diff_sha256':sha(diff.encode()),'reason':'uniquely ranked USB-MSC SET_CONFIGURATION representation normalized; external QEMU/OVMF certification still required'})
    a.report.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));return 0

if __name__=='__main__':raise SystemExit(main())
