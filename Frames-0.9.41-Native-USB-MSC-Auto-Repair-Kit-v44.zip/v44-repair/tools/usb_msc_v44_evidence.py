#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
REQ=[
'FRAMES_USB_MSC_POLICY_OK','FRAMES_USB_MSC_DEVICE_FOUND','FRAMES_USB_MSC_ENDPOINTS_OK',
'FRAMES_USB_MSC_CONFIGURED_OK','FRAMES_USB_MSC_INQUIRY_OK','FRAMES_USB_MSC_READY_OK',
'FRAMES_USB_MSC_CAPACITY_OK','FRAMES_USB_MSC_READ_OK','FRAMES_USB_MSC_READONLY_OK',
'FRAMES_USB_MSC_CERT_OK','FRAMES_USB_MSC_DETACH_WINDOW','FRAMES_USB_MSC_RESIDENT_OK']
FATAL=['FRAMES_USB_MSC_CERT_FAIL','FRAMES_PAGE_FAULT','FRAMES_AP_PROTECTION_FAULT=']
def lane(path:Path):
    raw=path.read_bytes(); text=raw.decode(errors='replace')
    counts={m:text.count(m) for m in REQ}; fatal={m:text.count(m) for m in FATAL if m in text}
    return {'status':'PASS' if all(v==1 for v in counts.values()) and not fatal else 'FAIL',
            'serial_sha256':hashlib.sha256(raw).hexdigest(),'marker_counts':counts,'fatal_counts':fatal}
def main():
    p=argparse.ArgumentParser(); p.add_argument('--normal',type=Path,required=True); p.add_argument('--detach',type=Path,required=True); p.add_argument('--output',type=Path,required=True); p.add_argument('--require-pass',action='store_true'); a=p.parse_args()
    out={'profile':'native-usb-mass-storage-phase2-v44','lanes':{'normal':lane(a.normal),'detach':lane(a.detach)}}
    out['status']='PASS' if all(x['status']=='PASS' for x in out['lanes'].values()) else 'FAIL'
    a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
    return 0 if (not a.require_pass or out['status']=='PASS') else 1
if __name__=='__main__': raise SystemExit(main())
