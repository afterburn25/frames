# Frames 0.9.41 Native USB MSC Auto-Repair / Certification v44

v44 corrects the v43 repair-automation failure. The v43 GitHub run found the exact sealed 0.9.41 source with SHA-256 `054c8477a79720c731025bde2407e4d073a12408a458809c135fbc16b518d50c`, but the transformer incorrectly required `FRAMES_USB_MSC_ENDPOINTS_OK` and `FRAMES_USB_MSC_CONFIGURED_OK` to exist in the same source file. The actual source does not satisfy that layout assumption, so v43 stopped before build/QEMU.

v44 removes that assumption. It indexes the complete exact source tree, permits the two boundary markers to live in different files, discovers SET_CONFIGURATION anchors in USB-MSC-related source, records bounded candidate excerpts in the repair report, and patches only a uniquely ranked high-confidence representation. If candidates are ambiguous or unrecognized, it fails closed and preserves enough source context in the evidence artifact to make the next repair exact.

The intended SET_CONFIGURATION request remains:
- bmRequestType = 0x00
- bRequest = 0x09
- wValue = 0x0001
- wIndex = 0x0000
- wLength = 0x0000

Safety is unchanged: SCSI WRITE(10) remains absent, media identity checks and hot-unplug proof remain mandatory, physical boot approval is not granted, and Frames 1.0 is not promoted by this workflow.
