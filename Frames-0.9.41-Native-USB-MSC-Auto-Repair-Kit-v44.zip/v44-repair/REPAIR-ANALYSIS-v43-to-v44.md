# Frames 0.9.41 v43 -> v44 Repair Analysis

Date: 2026-08-12 (America/Chicago)

## v43 evidence result

- Uploaded v43 evidence SHA-256: `7bb009f28d11c9cd206d9a40b2ef90bc9c1194587ea1a93211dc794f5d371af2`
- ZIP integrity: PASS
- Exact v42 source found: `054c8477a79720c731025bde2407e4d073a12408a458809c135fbc16b518d50c`
- v43 repair status: FAIL (fail-closed)
- marker_candidate_count: 0
- reason: v43 expected exactly one source file containing both USB MSC boundary markers
- No repaired source, QEMU result, or aggregate certification result was produced.

## v44 correction

v44 treats marker placement and request implementation as separate discovery problems. It requires each boundary marker to exist somewhere in the exact source tree, then scans USB-MSC-related files for SET_CONFIGURATION anchors and recognizes named-field, setup-byte-array, packed-setup, or explicit control-helper forms. Candidates are scored by proximity to boundary markers and USB-MSC/xHCI semantics. Only a uniquely ranked mutable candidate is patched; close ties fail closed.

The v44 report retains bounded candidate excerpts so a later exact source-specific correction is possible even if automatic recognition cannot safely patch the real representation.
