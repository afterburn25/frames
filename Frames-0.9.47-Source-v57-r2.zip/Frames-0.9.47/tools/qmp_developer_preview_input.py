#!/usr/bin/env python3
import json,socket,sys,time
from pathlib import Path
if len(sys.argv)<3: raise SystemExit('usage: qmp_developer_preview_input.py SOCKET SERIAL_LOG')
sock_path=sys.argv[1]; log=Path(sys.argv[2]); deadline=time.time()+90
while time.time()<deadline:
    if log.exists() and 'FRAMES_DEVPREV_READY' in log.read_text(errors='ignore'): break
    time.sleep(0.05)
else: raise SystemExit('developer preview ready marker not observed')
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
connect_deadline=time.time()+10
while True:
    try: s.connect(sock_path); break
    except OSError:
        if time.time()>=connect_deadline: raise SystemExit('QMP socket unavailable')
        time.sleep(0.05)
f=s.makefile('rwb',buffering=0)
def recv_obj(timeout=5):
    s.settimeout(timeout)
    while True:
        line=f.readline()
        if not line: raise EOFError('QMP closed')
        obj=json.loads(line)
        if 'event' in obj: continue
        return obj
def cmd(execute,args=None):
    payload={'execute':execute}
    if args is not None: payload['arguments']=args
    f.write((json.dumps(payload,separators=(',',':'))+'\n').encode()); return recv_obj()
recv_obj(); cmd('qmp_capabilities')
def key(qcode):
    for down in (True,False):
        r=cmd('input-send-event',{'events':[{'type':'key','data':{'down':down,'key':{'type':'qcode','data':qcode}}}]})
        if 'error' in r: raise SystemExit(str(r))
        time.sleep(0.035)
def type_command(text):
    for ch in text:
        key(ch)
    key('ret'); time.sleep(0.12)
for command in ('help','version','cpu','memory','devices','processes','filesystems','sdk','app','run','reboot','shutdown','exit'):
    type_command(command)
cert_deadline=time.time()+30
while time.time()<cert_deadline:
    if log.exists() and 'FRAMES_DEVPREV_CERT_OK' in log.read_text(errors='ignore'):
        r=cmd('quit'); print('PASS: developer preview Phase 3 USB input/system inspection command sequence certified; quit=',r,flush=True); f.close(); s.close(); raise SystemExit(0)
    time.sleep(0.05)
raise SystemExit('developer preview certification marker not observed')
