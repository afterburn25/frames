# Frames 0.9.41 v42 -> v43 Repair Analysis

Date: 2026-08-12 (America/Chicago)

## v42 evidence identity

- Evidence ZIP SHA-256: `f12cfbed2e487c30bf4a1874c78de8d5040d07ef94764265f860b809960fa94e`
- Exact v42 source SHA-256: `054c8477a79720c731025bde2407e4d073a12408a458809c135fbc16b518d50c`
- v42 USB-MSC certifier: exit `1`
- v42 USB-MSC normal QEMU lane: exit `124` (timeout)

## Last successful native USB-MSC boundary

Observed in v42:

- `FRAMES_XHCI_RING_READY`
- `FRAMES_XHCI_PORT_READY`
- `FRAMES_XHCI_SLOT_READY`
- `FRAMES_XHCI_DEFAULT_EP_READY`
- `FRAMES_XHCI_DESCRIPTOR8_OK`
- `FRAMES_XHCI_ADDRESSED_OK`
- `FRAMES_XHCI_DEVICE_DESCRIPTOR_OK`
- `FRAMES_USB_MSC_DEVICE_FOUND`
- `FRAMES_USB_MSC_ENDPOINTS_OK`

Then:

- `FRAMES_USB_MSC_DIAG stage=0x1 value=0x304`
- `FRAMES_USB_MSC_DIAG stage=0x2 value=0x4`
- `FRAMES_USB_MSC_CERT_FAIL`

No `FRAMES_USB_MSC_CONFIGURED_OK` or later SCSI-success marker was emitted.

## v43 repair strategy

The v43 workflow does not extend the timeout or weaken the certifier. It:

1. Requires the exact v42 source SHA before any mutation.
2. Locates the single source file containing both the endpoint-ready and configured markers.
3. Finds the SET_CONFIGURATION construction within that bounded source region.
4. Normalizes the request to a standard host-to-device device request for configuration value 1.
5. Writes a unified diff and JSON repair report.
6. Re-runs the original 0.9.41 verifier plus a v43 safety verifier.
7. Rebuilds and executes inherited runtime/storage/filesystem/SMP/USB-boot/physical-preview/hardware-compat gates.
8. Executes native USB-MSC normal + hot-unplug lanes and independently checks exact marker cardinality.
9. Uploads all evidence and the newly sealed repaired source.

## Explicitly unchanged

- Challenge LBA: 128
- Challenge blocks: 2 x 512 bytes
- Challenge checksum: `2301139167` (`0x892898DF`)
- Challenge SHA-256: `75511bbffe842f383d47ade67c12851c0358c38cd404738a0069377a67fd7880`
- SCSI WRITE(10): intentionally absent
- Physical hardware boot approval: unchanged / not granted by this repair
- Frames 1.0 promotion: not granted by this repair
