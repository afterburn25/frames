# Frames 0.9.41 Native USB MSC Auto-Repair / Certification v43

This is a fail-closed repair overlay for the failed Frames 0.9.41 v42 native USB mass-storage run.

## Why this is an overlay

The uploaded v42 evidence archive contains runtime evidence and hashes, but it does **not** contain the sealed `Frames-0.9.41-Source.zip` bytes. The v42 GitHub run proves that the exact source archive used there had SHA-256:

`054c8477a79720c731025bde2407e4d073a12408a458809c135fbc16b518d50c`

v43 therefore refuses to invent a replacement source archive. Instead, it finds that exact v42 source (directly or inside the v42 runtime kit), verifies its hash before extraction, applies a narrowly scoped control-transfer repair, rebuilds it, certifies it, and uploads a newly sealed repaired source ZIP with a newly computed SHA-256.

## Failure signature being repaired

The v42 native USB-MSC lane reached device enumeration and endpoint discovery, then stopped before `FRAMES_USB_MSC_CONFIGURED_OK` with completion code `0x4`. The repair is scoped to the `SET_CONFIGURATION` control request boundary immediately after `FRAMES_USB_MSC_ENDPOINTS_OK`.

For the bounded QEMU `usb-storage` certification profile, v43 normalizes the standard SET_CONFIGURATION setup request to:

- `bmRequestType = 0x00`
- `bRequest = 0x09`
- `wValue = 0x0001`
- `wIndex = 0x0000`
- `wLength = 0x0000`

The transformer recognizes common named-field, setup-byte-array, packed-setup, and control-helper forms. If it cannot identify the exact representation with high confidence, it stops and emits a context-bearing repair report instead of guessing.

## Safety policy retained

v43 does not add SCSI WRITE(10), does not relax media byte-identity checks, does not remove USB hot-unplug proof, does not approve physical hardware boot, and does not promote Frames 1.0. The old `verify_runtime_repair_0941.py` is still required to pass.

## Use

1. Keep the exact v42 `Frames-0.9.41-Source*.zip` or v42 runtime certification kit in the repository.
2. Easiest: put `Frames-0.9.41-Native-USB-MSC-Auto-Repair-Kit-v43.zip` and the standalone v43 workflow YAML in the repository. The workflow automatically extracts the repair tools. Alternatively, extract this kit at the repository root.
3. Commit/push to `main`, or run the v43 workflow manually with **Run workflow**.
4. Download the `frames-0.9.41-native-usb-storage-evidence-v43` artifact from the completed run.

The artifact contains runtime evidence plus `Frames-0.9.41-Source-v43-repaired.zip` and its generated SHA-256.

## Promotion rule

Do not promote Frames 0.9.41 merely because the repair applied or preflight passed. Promotion requires the v43 aggregate exit code to be `0` and the native USB-MSC normal + detach evidence to pass with every required marker exactly once and no fatal marker.
