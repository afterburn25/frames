#!/usr/bin/env python3
"""Frames 0.9.41 v43 fail-closed USB MSC control-transfer repair.

This transformer is intentionally narrow.  It only edits the source file that
contains the native USB-MSC certification markers, and only when it can identify
a SET_CONFIGURATION request representation with high confidence.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import re
import sys
from pathlib import Path

TEXT_SUFFIXES = {'.nx', '.nxs', '.c', '.h', '.cc', '.cpp', '.inc', '.txt'}
SKIP_PARTS = {'build', 'toolchain', '.git', 'runtime-evidence'}
MARKER_A = 'FRAMES_USB_MSC_ENDPOINTS_OK'
MARKER_B = 'FRAMES_USB_MSC_CONFIGURED_OK'
ANCHORS = (
    'SET_CONFIGURATION', 'USB_REQ_SET_CONFIGURATION', 'USB_REQUEST_SET_CONFIGURATION',
    'set_configuration', 'set configuration', 'SetConfiguration', 'SET CONFIGURATION'
)
PACKED_SETUP = '0x0000000000010900'


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def iter_text_files(root: Path):
    for p in root.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in TEXT_SUFFIXES:
            continue
        if any(part in SKIP_PARTS for part in p.relative_to(root).parts):
            continue
        try:
            data = p.read_bytes()
            text = data.decode('utf-8')
        except (UnicodeDecodeError, OSError):
            continue
        yield p, text


def marker_candidates(root: Path):
    out = []
    for p, text in iter_text_files(root):
        if MARKER_A in text and MARKER_B in text:
            out.append((p, text))
    return out


def find_anchor_positions(text: str, lo: int, hi: int):
    region = text[lo:hi]
    positions = []
    low_region = region.lower()
    for anchor in ANCHORS:
        start = 0
        needle = anchor.lower()
        while True:
            i = low_region.find(needle, start)
            if i < 0:
                break
            positions.append(lo + i)
            start = i + max(1, len(needle))
    return sorted(set(positions))


def replace_assignment(block: str, names, value: str):
    changes = []
    for name in names:
        # Supports Nexus/C-like `field = expr`, `field: expr`, and `.field = expr`.
        pat = re.compile(
            rf'(?P<prefix>(?<![A-Za-z0-9_])(?:(?:[A-Za-z_][A-Za-z0-9_]*)\.)?{re.escape(name)}\s*(?:=|:)\s*)'
            rf'(?P<value>[^,;\n\r}}]+)',
            re.IGNORECASE,
        )
        m = pat.search(block)
        if m:
            old = m.group('value').strip()
            if old != value:
                block = block[:m.start('value')] + value + block[m.end('value'):]
                changes.append({'field': name, 'old': old, 'new': value})
    return block, changes


def patch_named_fields(text: str, anchor: int):
    lo = max(0, anchor - 1200)
    hi = min(len(text), anchor + 1800)
    block = text[lo:hi]
    original = block
    all_changes = []
    specs = [
        (('bmRequestType', 'request_type', 'requestType'), '0x00'),
        (('bRequest', 'request', 'request_code'), '0x09'),
        (('wValue', 'value'), '0x0001'),
        (('wIndex', 'index'), '0x0000'),
        (('wLength', 'length'), '0x0000'),
    ]
    for names, value in specs:
        block, changes = replace_assignment(block, names, value)
        if changes:
            all_changes.extend(changes)
    present_specs = []
    for names, _ in specs:
        present = any(re.search(rf'(?<![A-Za-z0-9_])(?:(?:[A-Za-z_][A-Za-z0-9_]*)\.)?{re.escape(n)}\s*(?:=|:)', original, re.I) for n in names)
        present_specs.append(present)
    # Require at least four of the five setup fields, including bRequest. This
    # permits some fields to already be correct without weakening recognition.
    if sum(present_specs) >= 4 and present_specs[1]:
        if all_changes:
            return text[:lo] + block + text[hi:], 'named-fields', all_changes
        return text, 'named-fields-already-correct', []
    if original != block:
        # Ambiguous partial match: do not keep it.
        return text, None, []
    return text, None, []


def patch_array_setup(text: str, anchor: int):
    lo = max(0, anchor - 1400)
    hi = min(len(text), anchor + 1800)
    block = text[lo:hi]
    # Find a variable with at least 5 byte-index assignments in the window.
    vars_found = {}
    pat = re.compile(r'(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*\[\s*(?P<idx>[0-7])\s*\]\s*=\s*(?P<val>[^;\n\r,]+)')
    for m in pat.finditer(block):
        vars_found.setdefault(m.group('var'), set()).add(int(m.group('idx')))
    vars_found = {k: v for k, v in vars_found.items() if len(v) >= 5 and 0 in v and 1 in v}
    if len(vars_found) != 1:
        return text, None, []
    var = next(iter(vars_found))
    values = {0:'0x00', 1:'0x09', 2:'0x01', 3:'0x00', 4:'0x00', 5:'0x00', 6:'0x00', 7:'0x00'}
    changes = []
    for idx, val in values.items():
        p = re.compile(rf'(?P<prefix>\b{re.escape(var)}\s*\[\s*{idx}\s*\]\s*=\s*)(?P<value>[^;\n\r,]+)')
        m = p.search(block)
        if not m:
            continue
        old = m.group('value').strip()
        if old != val:
            block = block[:m.start('value')] + val + block[m.end('value'):]
            changes.append({'field': f'{var}[{idx}]', 'old': old, 'new': val})
    if changes:
        return text[:lo] + block + text[hi:], 'setup-byte-array', changes
    return text, None, []


def patch_packed_setup(text: str, anchor: int):
    lo = max(0, anchor - 900)
    hi = min(len(text), anchor + 1200)
    block = text[lo:hi]
    # High-confidence forms: assignment to a setup/request parameter-like symbol.
    pat = re.compile(
        r'(?P<prefix>\b(?:setup(?:_packet|_param|_value|_request)?|request(?:_packet|_param|_value)?|trb_parameter)\b\s*=\s*)'
        r'(?P<value>0x[0-9A-Fa-f]{8,16}|[0-9]+)',
        re.IGNORECASE,
    )
    matches = list(pat.finditer(block))
    if len(matches) != 1:
        return text, None, []
    m = matches[0]
    old = m.group('value')
    if old.lower() == PACKED_SETUP.lower():
        return text, 'packed-setup-already-correct', []
    block = block[:m.start('value')] + PACKED_SETUP + block[m.end('value'):]
    return text[:lo] + block + text[hi:], 'packed-setup', [{'field':'packed setup packet', 'old':old, 'new':PACKED_SETUP}]


def split_args(s: str):
    args, buf = [], []
    depth = 0
    quote = None
    esc = False
    for ch in s:
        if quote:
            buf.append(ch)
            if esc:
                esc = False
            elif ch == '\\':
                esc = True
            elif ch == quote:
                quote = None
            continue
        if ch in ('"', "'"):
            quote = ch
            buf.append(ch)
            continue
        if ch in '([{':
            depth += 1
        elif ch in ')]}':
            depth = max(0, depth - 1)
        if ch == ',' and depth == 0:
            args.append(''.join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    args.append(''.join(buf).strip())
    return args


def patch_helper_call(text: str, anchor: int):
    lo = max(0, anchor - 1200)
    hi = min(len(text), anchor + 1800)
    block = text[lo:hi]
    # Find calls whose function name explicitly denotes a control/setup request.
    call_start = re.compile(r'\b(?P<fn>[A-Za-z_][A-Za-z0-9_]*(?:control|setup|request)[A-Za-z0-9_]*)\s*\(', re.IGNORECASE)
    candidates = []
    for m in call_start.finditer(block):
        depth, quote, esc = 1, None, False
        j = m.end()
        while j < len(block) and depth:
            ch = block[j]
            if quote:
                if esc: esc = False
                elif ch == '\\': esc = True
                elif ch == quote: quote = None
            else:
                if ch in ('"', "'"): quote = ch
                elif ch == '(': depth += 1
                elif ch == ')': depth -= 1
            j += 1
        if depth:
            continue
        body = block[m.end():j-1]
        args = split_args(body)
        req_indices = [i for i,a in enumerate(args) if re.search(r'SET[_ ]?CONFIGURATION|USB_REQ_SET_CONFIGURATION', a, re.I)]
        if not req_indices:
            # Literal 0x09 only accepted if SET_CONFIGURATION anchor occurs inside this call's surrounding line/comment.
            context = block[max(0,m.start()-180):min(len(block),j+180)]
            if 'set_configuration' in context.lower() or 'set configuration' in context.lower():
                req_indices = [i for i,a in enumerate(args) if a.strip().lower() in ('9','0x09')]
        if len(req_indices) == 1:
            candidates.append((m, j, args, req_indices[0]))
    if len(candidates) != 1:
        return text, None, []
    m, j, args, ri = candidates[0]
    # Conventional control helper order: bmRequestType, bRequest, wValue, wIndex, wLength.
    if ri < 1 or ri + 3 >= len(args):
        return text, None, []
    oldvals = [args[ri-1], args[ri], args[ri+1], args[ri+2], args[ri+3]]
    args[ri-1] = '0x00'
    # Preserve symbolic request name if present; normalize a numeric form.
    if re.fullmatch(r'\s*(?:9|0x0?9)\s*', args[ri], re.I):
        args[ri] = '0x09'
    args[ri+1] = '0x0001'
    args[ri+2] = '0x0000'
    args[ri+3] = '0x0000'
    indent = ''
    new_body = ', '.join(args)
    new_call = m.group(0) + new_body + ')'
    old_call = block[m.start():j]
    if old_call == new_call:
        return text, 'helper-call-already-correct', []
    block = block[:m.start()] + new_call + block[j:]
    newvals = [args[ri-1], args[ri], args[ri+1], args[ri+2], args[ri+3]]
    changes = [{'field':n, 'old':o, 'new':nval} for n,o,nval in zip(
        ('bmRequestType','bRequest','wValue','wIndex','wLength'), oldvals, newvals)]
    return text[:lo] + block + text[hi:], 'control-helper-call', changes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--source', required=True, type=Path)
    ap.add_argument('--report', required=True, type=Path)
    ap.add_argument('--diff', required=True, type=Path)
    ap.add_argument('--allow-noop-if-correct', action='store_true')
    args = ap.parse_args()
    root = args.source.resolve()
    report = {
        'repair_revision': 'v43',
        'target': 'Frames 0.9.41 native USB MSC SET_CONFIGURATION control request',
        'source_root': str(root),
        'status': 'FAIL',
        'fail_closed': True,
    }
    if not (root / 'VERSION').is_file() or (root / 'VERSION').read_text().strip() != '0.9.41':
        report['reason'] = 'source VERSION is not exactly 0.9.41'
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
        return 2

    candidates = marker_candidates(root)
    report['marker_candidate_count'] = len(candidates)
    report['marker_candidates'] = [str(p.relative_to(root)) for p,_ in candidates]
    if len(candidates) != 1:
        report['reason'] = 'expected exactly one source file containing both USB MSC boundary markers'
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
        return 3

    path, original = candidates[0]
    a = original.find(MARKER_A)
    b = original.find(MARKER_B)
    lo, hi = max(0, min(a,b)-18000), min(len(original), max(a,b)+8000)
    anchors = find_anchor_positions(original, lo, hi)
    report['source_file'] = str(path.relative_to(root))
    report['source_file_before_sha256'] = sha256_bytes(original.encode())
    report['anchor_count'] = len(anchors)
    if not anchors:
        # Save a bounded context report for a future exact source-specific repair.
        context = original[lo:hi]
        report['reason'] = 'no SET_CONFIGURATION anchor found near native USB MSC marker boundary'
        report['context_sha256'] = sha256_bytes(context.encode())
        report['context_excerpt'] = context[:12000]
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
        return 4

    # Prefer the anchor closest to the configured marker while still after endpoint discovery.
    anchors.sort(key=lambda x: abs(x - b))
    methods = (patch_named_fields, patch_array_setup, patch_packed_setup, patch_helper_call)
    chosen = None
    repaired = original
    changes = []
    for anchor in anchors:
        for method in methods:
            candidate, name, local_changes = method(original, anchor)
            if name:
                chosen = name
                repaired = candidate
                changes = local_changes
                break
        if chosen:
            break

    report['method'] = chosen
    report['changes'] = changes
    if not chosen:
        context = original[lo:hi]
        report['reason'] = 'SET_CONFIGURATION was found, but its source representation was not one of the fail-closed recognized forms'
        report['context_sha256'] = sha256_bytes(context.encode())
        report['context_excerpt'] = context[:12000]
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
        return 5

    # Required policy/safety strings must survive the transformation.
    for marker in (MARKER_A, MARKER_B, 'FRAMES_USB_MSC_CERT_FAIL'):
        if marker not in repaired:
            report['reason'] = f'repair unexpectedly removed required marker {marker}'
            args.report.write_text(json.dumps(report, indent=2) + '\n')
            return 6

    if repaired == original and not args.allow_noop_if_correct:
        report['reason'] = 'recognized form was already normalized; refusing an unproven no-op repair'
        args.report.write_text(json.dumps(report, indent=2) + '\n')
        return 7

    if repaired != original:
        path.write_text(repaired)
    diff = ''.join(difflib.unified_diff(
        original.splitlines(True), repaired.splitlines(True),
        fromfile=str(path.relative_to(root)) + '.v42',
        tofile=str(path.relative_to(root)) + '.v43',
    ))
    args.diff.parent.mkdir(parents=True, exist_ok=True)
    args.diff.write_text(diff)
    report['source_file_after_sha256'] = sha256_bytes(repaired.encode())
    report['changed'] = repaired != original
    report['diff_sha256'] = sha256_bytes(diff.encode())
    report['status'] = 'PASS'
    report['reason'] = 'recognized SET_CONFIGURATION representation normalized; external QEMU/OVMF certification still required'
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
