# Frames 0.9.46 v56 Parallel r8 Evidence Repair

This is an evidence-only repair. It does not change Frames source bytes and does
not rerun QEMU.

Upload the r8 workflow first, then this runtime kit last.

The workflow validates the exact r6 identity/change-impact evidence and exact r7
lane artifacts, corrects the kernel-smoke parser marker from
FRAMES_USERSPACE_READY to FRAMES_USERSPACE_PLATFORM_OK, and emits the final
aggregate evidence artifact.
