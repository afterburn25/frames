# Frames 0.9.40 Runtime Certification Kit v40

Milestone: **Real Hardware Compatibility Expansion — Phase 1**

Source SHA-256:

`d761997e6cd276c1d46d7db655b0c10836b3e5cd1b3f35189e3f8785af553a6d`

Workflow SHA-256:

`887f30b1bb19af96928705eaf1949202b5c8621f82838343843d9c3d112179b1`

The workflow first re-proves the complete accepted Frames 0.9.39 chain:
runtime, stress, storage, lifecycle, filesystem, system-volume, FAT lifecycle,
2–96 logical CPU SMP, removable USB hot-unplug, and all seven physical-preview
adversarial write-safety lanes.

It then runs seven new compatibility profiles:

`baseline`
`qemu64`
`ahci`
`no-network`
`ehci-ps2`
`virtio-vga`
`mixed-storage`

New compatibility reporting records CPU identity/features, ACPI optional-table
inventory, expanded PCI classes, NVMe/AHCI/IDE/RAID inventory, USB controller
generation, passive network inventory, and GOP dimensions.

The 0.9.40 image itself remains a candidate pending v40 external evidence.
Frames 0.9.39 v39 remains the already-approved diagnostic physical-preview
baseline.

Native USB mass-storage I/O after ExitBootServices is explicitly not claimed
by this phase.

Expected evidence artifact:

`frames-0.9.40-hardware-compat-evidence-v40`
