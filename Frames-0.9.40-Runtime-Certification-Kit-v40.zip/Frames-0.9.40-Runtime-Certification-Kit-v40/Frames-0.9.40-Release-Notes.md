# Frames 0.9.40 — Real Hardware Compatibility Expansion Phase 1

Frames 0.9.40 builds on the externally certified 0.9.39 Physical Hardware Preview and expands the diagnostic compatibility layer without enabling persistent internal-disk writes.

## Implemented
- CPU vendor/family/model/stepping and feature fingerprint capture.
- ACPI optional-table inventory (MCFG/FADT/HPET/DMAR/IVRS) alongside the required MADT/APIC path.
- Expanded PCI class inventory: bridges, IDE, RAID, UHCI, OHCI, EHCI, xHCI, Ethernet/other network, VGA/other display.
- Physical-preview storage readiness accepts a successful read-only NVMe or AHCI path.
- Physical-preview input readiness supports the existing PS/2 queue fallback when xHCI is absent; xHCI remains fully verified when present.
- Network hardware becomes optional for diagnostic preview; its inventory remains passive/read-only.
- GOP framebuffer dimensions are recorded and checked for a usable minimum.
- Structured `FRAMES_HWCOMPAT_*` serial report for later real-machine compatibility capture.
- QEMU compatibility matrix covers baseline, qemu64 CPU, AHCI storage, no-network, EHCI/PS2 fallback, virtio-vga GOP, and mixed NVMe+AHCI profiles.

## Safety
The 0.9.39 physical-preview write/destructive lock remains in force. No installer or unrestricted internal-disk write path is enabled.

## Deferred
Native post-ExitBootServices USB mass-storage I/O remains a later compatibility phase; 0.9.40 does not falsely claim that driver.
