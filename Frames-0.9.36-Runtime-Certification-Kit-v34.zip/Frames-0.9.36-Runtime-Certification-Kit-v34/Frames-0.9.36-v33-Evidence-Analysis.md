# Frames 0.9.36 Gate-5 v33 Evidence Analysis

## Decision

**REJECTED — workflow stopped in inherited Gate 3 before Gate 5.**

Frames 0.9.35 remains the externally certified authoritative baseline.

Uploaded evidence SHA-256: `36475fa458594fa718f6590a42bcfbbb69f5cd42992bf02485f5c251622b491c`

## Passed before the stop

- exact v33 source selection and preflight;
- Nexus 5.20.0 source/build checks;
- baseline runtime certification, 70/70 markers;
- 8/8 stress matrix;
- raw sacrificial NVMe write/integrity Gate 1;
- destructive reboot/S5 Gate 2.

The v33 Gate-2 QMP repair worked: reboot QEMU exit `0`, shutdown QEMU exit `0`, lifecycle evidence `PASS`, and the reboot monitor recorded `QMP quit acknowledged after FRAMES_LIFECYCLE_REBOOT_RETURNED`.

## Stop point

The Gate-3 normal filesystem guest reached `FRAMES_FS_WRITE_TARGET_FOUND`, `FRAMES_FS_JOURNAL_OK`, `FRAMES_FS_MUTATION_OK`, and final `FRAMES_KERNEL_READY`. The host monitor then reported `QMP greeting timeout after FRAMES_FS_MUTATION_OK`.

Only Gate-3 scenario 0 ran. Gate-3 crash/recovery scenarios, Gate 4, and Gate 5 were not executed.

## Root cause and v34 fix

The hardened quit monitor correctly requires an actual QMP greeting. Gate 3 still left `qmp_input_inject.py` holding QMP after the guest proof marker, reproducing the same single-client ownership problem already fixed for Gate 2.

v34 applies proof-marker release consistently to every orderly lane: Gate-3 normal/recovery, Gate 4, and Gate 5. Intentional Gate-3 SIGKILL crash lanes remain unchanged. The quit monitor still requires greeting, capability negotiation, quit acknowledgement/EOF, and parent QEMU exit `0`. No guest/kernel FAT contract or threshold is weakened.
