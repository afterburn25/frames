# Frames 0.9.36 Runtime Certification Kit v34

Sealed source SHA-256: `ac50722c8f6ea17b4349f009e5a284fbb341880131445172f22a6144707da428`
Workflow SHA-256: `7d4502eec2d84b3e49de38fd414d287ba76d5aaf51fbdc25421aa602b06e59b3`

v34 is a host-QMP ownership hotfix. Guest/kernel Gate-5 semantics are unchanged: `FRAMESFAT0936`, exact seven-LBA allowlist, create/grow/truncate/rename/delete/reallocate/restore, 7 phases, 47 writes, 33 flushes, 14 mirrored FAT updates, and full 64 MiB byte-identical restoration.

Orderly QMP lanes now release the input client at their proof marker before the hardened quit client connects. Intentional Gate-3 crash lanes remain SIGKILL-based and unchanged.

Expected evidence artifact: `frames-0.9.36-fat-lifecycle-evidence-v34`
