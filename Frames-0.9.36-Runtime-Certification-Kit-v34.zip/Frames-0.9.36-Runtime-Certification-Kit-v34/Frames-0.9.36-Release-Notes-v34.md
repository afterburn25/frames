# Frames 0.9.36 — FAT32 Allocation & Full File Lifecycle Certification Gate 5

Frames 0.9.36 is built directly from the externally accepted Frames 0.9.35 Gate-4 baseline.

Gate 5 widens disposable system-volume write testing from a preallocated two-cluster file to real FAT32 allocation/freeing and complete short-name file lifecycle semantics on a full cloned Frames system/ESP volume.

## Safety boundary

- The real Frames boot/system NVMe remains read-only.
- The Gate-5 disposable clone must identify exactly as `FRAMESFAT0936`.
- The clone contains a read-only descriptor file `FATGATE.CFG` that defines one test directory slot and a four-cluster free pool.
- Only seven exact LBAs are writable: the test directory sector, one sector in FAT copy 1, the mirrored sector in FAT copy 2, and four pool data-cluster sectors.
- GPT, FAT32 boot/reserved sectors, all non-pool FAT sectors, `BOOTX64.EFI`, `FramesKernel.fkrn`, `System.fex`, `BOOTSTAT.TXT`, the descriptor file, and every non-test data cluster remain outside the Gate-5 write API.

## Certified lifecycle workload

The runtime performs seven ordered lifecycle phases:

1. Create `LIFE0001.TST` using one newly allocated FAT32 cluster.
2. Grow it to four clusters and verify both FAT mirrors.
3. Truncate it to two clusters, free the released clusters, and zero released data.
4. Rename it in place to `LIFE0002.TST`.
5. Delete it, free its remaining clusters, and clear released data.
6. Create `LIFE0003.TST` by reallocating clusters freed by the earlier truncate/delete sequence.
7. Delete the second file and restore the test slot, FAT entries, and all pool data to the pristine clone state.

Every data update is flushed and read back. Every FAT allocation/free operation updates both FAT copies, flushes, and verifies that the mirrors agree.

Expected Gate-5 runtime accounting:

- 7 lifecycle phases
- 47 NVM Write commands
- 33 NVM Flush commands
- 14 mirrored FAT entry updates
- 4 allocation-pool clusters

The host verifier requires the complete 64 MiB clone to be byte-identical to its pristine pre-run copy.

## Required markers

- `FRAMES_FAT_LIFECYCLE_TARGET_FOUND`
- `FRAMES_FAT_CREATE_OK`
- `FRAMES_FAT_GROW_OK`
- `FRAMES_FAT_TRUNCATE_OK`
- `FRAMES_FAT_RENAME_OK`
- `FRAMES_FAT_DELETE_OK`
- `FRAMES_FAT_REALLOC_OK`
- `FRAMES_FAT_MIRROR_OK`
- `FRAMES_FAT_RESTORE_OK`
- `FRAMES_FAT_LIFECYCLE_CERT_OK`
- fatal: `FRAMES_FAT_LIFECYCLE_CERT_FAIL`

## Still blocked

Gate 5 does not authorize writes to the actual boot/system NVMe, arbitrary system-file replacement, physical-machine disk writes, or physical boot. Frames 1.0 remains unpromoted.

## v32 Gate-5 certification hotfix

The first v31 external Gate-5 run reached QEMU but did not arm the FAT lifecycle path.
Root cause: `nvme_fat_lifecycle_target_arm()` stored descriptor-derived cluster/LBA
context in scratch memory that was later overwritten by `fat_lifecycle_sector_pristine()`.
The subsequent pool validation therefore read clobbered context and fell into the
fail-closed raw-storage rejection path (`storage_write_fail(829)`).

v32 fixes the scratch-alias bug by validating the pool with preserved local cluster/LBA
values, corrects the UEFI loader banner to Frames 0.9.36, and hardens
`fat_lifecycle_evidence.py` so inherited storage/filesystem/lifecycle/stress fatal
markers also fail Gate 5.



## Certification harness hotfix v34

The v33 external run proved the Gate-2 QMP race fix but exposed the same single-client QMP ownership issue in the inherited Gate-3 normal lane. The guest reached `FRAMES_FS_MUTATION_OK` and `FRAMES_KERNEL_READY`, but the input injector still held the QMP connection and the hardened quit monitor correctly timed out waiting for a real greeting. v34 applies proof-marker QMP release consistently to every orderly QMP-terminated certification lane: Gate-3 normal/recovery, Gate-4 system-volume, and Gate-5 FAT lifecycle. Intentional Gate-3 SIGKILL crash lanes are unchanged. No guest filesystem/FAT contract or certification threshold is weakened.
