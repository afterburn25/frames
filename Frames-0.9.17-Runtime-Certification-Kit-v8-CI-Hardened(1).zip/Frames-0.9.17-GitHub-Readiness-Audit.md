# Frames 0.9.17 — GitHub Runtime Readiness Audit

Audit date: 2026-08-11

## Conclusion

No remaining **known CI/workflow/configuration error** was found that should prevent a successful GitHub Actions finish if Frames 0.9.17 earns the required runtime markers under QEMU/OVMF.

The original v7 workflow had two real CI hazards that are corrected by the included v8 workflow:

1. **Stale Frames source selection** — an older unpacked tree or older `Frames-*-Source.zip` could win before the current runtime kit.
2. **Independent OVMF selection** — CODE and VARS were discovered separately and could theoretically come from different firmware families.

The v8 workflow is strict to Frames 0.9.17 and its authoritative source SHA-256.

## Authoritative source lock

Expected Frames version: `0.9.17`

Expected source ZIP SHA-256:

`7d13285e1b03f22dc2c000e5a00570f0fbab998d0c28254e05b697bfd1a2d32a`

The workflow accepts a renamed duplicate such as `Frames-0.9.17-Runtime-Certification-Kit(1).zip`, extracts the embedded source, and verifies this source hash before building.

## Audit results

- Source ZIP archive integrity: PASS.
- Runtime-kit archive integrity: PASS.
- Source/kernel build from fresh extraction: PASS.
- EFI/FKRN/FEX/GPT/FAT32 release verifier: PASS.
- Frames 0.9.17 runtime-convergence source verifier: PASS.
- Nexus 5.17 regression suite: 25 passed, 0 failed.
- Nexus compiler semantic checks: 26 PASS.
- Every shell script in the source: `bash -n` PASS.
- Python tool compilation: PASS.
- v8 GitHub YAML parse: PASS.
- Every v8 shell block: `bash -n` PASS.
- Stale-repository simulation with 0.9.15 + 0.9.16 + renamed 0.9.17 kit: PASS; exact 0.9.17 was selected.
- Corrupted 0.9.17 source archive rejection: PASS.
- Matching OVMF-family selection simulation: PASS, including different CODE/VARS file sizes.
- QEMU certifier marker contract: 70 expected markers, 70 unique.
- Evidence directory is always created and uploaded on failure.

## v8 workflow hardening

The included workflow:

- Requires `EXPECTED_FRAMES_VERSION=0.9.17`.
- Verifies the exact authoritative source ZIP SHA-256 before extraction.
- Ignores stale 0.9.15/0.9.16 source trees and kits.
- Prefers a matching `OVMF_CODE_4M.fd` + `OVMF_VARS_4M.fd` pair, with a matching standard pair as fallback.
- Does **not** require split OVMF CODE/VARS images to have equal file size.
- Verifies `qemu-system-x86_64`, `clang`, `lld-link`, Python, and unzip after installation.
- Runs build/release/current-version source verification before QEMU.
- Runs runtime preflight and generates `RUNTIME-CERTIFICATION.json`.
- Raises the QEMU runtime window from 60 to 120 seconds for the newly reachable real GPT/FAT read path.
- Preserves preflight console output, QEMU console output, serial output, missing-marker JSON, storage certification, runtime evidence, and workflow diagnostics.
- Fails a would-be positive-marker pass if `FRAMES_PAGE_FAULT` is also present.
- Uploads a versioned artifact named `frames-0.9.17-runtime-evidence`.

## Runtime-path review

### SMP

The 0.9.17 source sequence is coherent:

1. AP comes online with shared GDT/IDT contract.
2. AP LAPIC timer interrupt is recorded before scheduler dispatch.
3. AP worker enters.
4. AP runqueue proof is recorded only after the worker yields back to the timer-interrupt context.
5. BSP emits `FRAMES_AP_RUNQUEUE_OK` after observing that proof.
6. BSP sends vector-50 reschedule IPI.
7. AP increments its reschedule receipt state.
8. BSP emits `FRAMES_RESCHED_IPI_OK`.
9. BSP periodic scheduler tick can then emit `FRAMES_CPU_AFFINITY_OK` and `FRAMES_SMP_SCHEDULER_OK`.

No static ordering deadlock was found in this path.

### Storage / GPT / FAT32 / VFS

The 0.9.17 NVMe repair copies a completed one-block DMA read into the caller's requested block buffer before returning success.

For the exact generated 64 MiB ESP image:

- logical block size: 512 bytes;
- GPT partition entries: 128;
- GPT entry size: 128 bytes;
- GPT partition-array blocks: 32;
- ESP first LBA: 2048;
- FAT32 sectors per cluster: 1;
- FAT count: 2;
- FAT sectors: 977;
- FAT root cluster: 2.

The image builder creates the short FAT aliases the runtime reader expects:

- `SYSTEM~1FEX`
- `BOOTSTATTXT`

`System.fex` is smaller than one sector, matching the bounded first-sector VFS read proof.

All ten inputs to `filesystem_platform_gate()` are populated in dependency order if GPT/FAT and the FEX readback succeed. The downstream network → display → audio → driver → security consolidated gate chain is structurally consistent.

## Bounded-resource audit

### Bootstrap heap

- Allocated by UEFI: 192 pages.
- Current static kernel bootstrap reservations: 133 pages / 544,768 bytes.
- Headroom: 59 pages.

PASS for this build.

### DMA ledger

The DMA ledger supports 64 entries and does not currently recycle entries.

For the intended GitHub QEMU configuration, the successful path is approximately:

- 7 fixed NVMe DMA pages;
- 41 NVMe one-block read DMA pages through initial read, cache proof, GPT, FAT32, and VFS FEX readback;
- up to 14 xHCI/USB-HID DMA pages.

Estimated maximum: **62 / 64** entries when the complete USB-keyboard path succeeds.

This fits the intended two-device QEMU run, but the margin is too small for broader hardware certification. An active AHCI/SATA path can allocate four additional DMA pages, so DMA-page reuse or a larger safe ledger should be addressed in a later hardware-hardening build before physical certification.

## Non-blocking cleanup items

These do not affect the GitHub runtime pass:

- `docs/STATUS.md` inside the sealed 0.9.17 source still carries stale wording from the 0.9.16 descriptor-table milestone.
- `docs/RUNTIME-MARKERS.json` is a grouped 29-marker evidence subset, while `qemu_certify.sh` is the authoritative stricter 70-marker runtime gate.
- The source ZIP contains the earlier v7 workflow; GitHub should use the external v8 workflow supplied in this kit. The source itself is intentionally left sealed so its verified SHA-256 remains unchanged.

## Remaining uncertainty

The remaining uncertainty is **runtime behavior**, not a known GitHub workflow defect. The next GitHub run must prove the 0.9.17 AP runqueue/reschedule path and the newly reachable GPT/FAT/VFS dependency chain. A red run after using v8 should therefore produce enough evidence to identify a real remaining Frames runtime defect rather than a silent CI packaging problem.
