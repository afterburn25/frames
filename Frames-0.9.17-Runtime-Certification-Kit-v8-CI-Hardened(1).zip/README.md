# Frames 0.9.17 — CI-Hardened Runtime Certification Kit v8

Use this kit for the next GitHub QEMU/OVMF certification run.

## Repository setup

1. Put `Frames-0.9.17-Source.zip` at the repository root **or** leave this complete kit ZIP at the repository root.
2. Copy `Frames-0.9.17-GitHub-Runtime-Certification-v8.yml` to:
   `.github/workflows/frames-runtime-certify.yml`
3. Commit/push to `main` or run the workflow manually.
4. Confirm the log says `Frames version: 0.9.17`.
5. After the run, download `frames-0.9.17-runtime-evidence` and upload it back to ChatGPT.

The workflow deliberately ignores older Frames releases and verifies the exact authoritative 0.9.17 source hash before building.
