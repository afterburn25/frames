# Frames 0.9.41 Runtime Certification Kit v46

v46 retains the direct USB MSC SuperSpeed kernel repair from v45 and hardens only
the host SMP evidence parser against bounded UART prefix truncation.

Place `Frames-0.9.41-Source-v46.zip` where the workflow can discover it and install
`Frames-0.9.41-GitHub-Native-USB-Mass-Storage-Certification-v46.yml` at:

`.github/workflows/frames-0.9.41-native-usb-msc-v46.yml`

The workflow is pinned to source SHA-256:

`3d0ab764dfaa572bad9c801b6f15803dc0b804e316d252e27aac7f0cd324ced2`

Run it and upload the resulting:
`frames-0.9.41-native-usb-storage-evidence-v46.zip`

Do not promote Frames 0.9.41 until that external evidence passes.
