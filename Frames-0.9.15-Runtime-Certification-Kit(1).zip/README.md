# Frames 0.9.15 Runtime Certification Kit

Upload this ZIP, or its contained `Frames-0.9.15-Source.zip`, to the root of the GitHub repository. Install the contained workflow as `.github/workflows/frames-runtime-certify.yml`, then run the workflow manually.

The workflow supports a runtime-kit ZIP directly and always preserves evidence, even when certification remains blocked.

Expected new diagnostic markers in this release include:
- `FRAMES_AP_APIC_ENABLE_OK`
- `FRAMES_AP_TIMER_COUNTING_OK`
- `FRAMES_AP_TIMER_DIAG=<initial>,<current>,<irq-count>`

The required certification markers remain fail-closed. Physical boot remains BLOCKED and persistent media writes remain absent.
