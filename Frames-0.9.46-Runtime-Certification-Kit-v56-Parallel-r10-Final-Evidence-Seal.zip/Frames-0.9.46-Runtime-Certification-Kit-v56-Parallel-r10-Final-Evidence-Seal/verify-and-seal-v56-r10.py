#!/usr/bin/env python3
from pathlib import Path
import zipfile,hashlib,json,os,sys,shutil,traceback

EXPECTED_R9_SHA="762922b346f263ceba3878a16e697740ebd6b3c65d6a22cb881bd671e93fc13b"
EXPECTED_SOURCE="ed823f9d449e53913a018d754cfc90f5369ff2a729afe7c3eda73d404cf430a7"

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for c in iter(lambda:f.read(1024*1024),b""): h.update(c)
    return h.hexdigest()

def main():
    root=Path(os.environ["KIT_ROOT"])
    out=Path(os.environ["EVIDENCE"])
    out.mkdir(parents=True,exist_ok=True)
    src=root/"Frames-0.9.46-Source-v56.zip"
    r9=root/"frames-0.9.46-fapp-native-application-loader-parallel-evidence-v56-r9.zip"
    checks={}
    checks["source_sha"]=src.exists() and sha_file(src)==EXPECTED_SOURCE
    checks["r9_sha"]=r9.exists() and sha_file(r9)==EXPECTED_R9_SHA

    with zipfile.ZipFile(r9) as z:
        checks["r9_zip_integrity"]=z.testzip() is None
        names=z.namelist()
        required=[
            "KERNEL-BOOT-SMOKE-EVIDENCE.json",
            "PARALLEL-INCREMENTAL-CERTIFICATION.json",
            "REUSED-R7-LANES-EVIDENCE.json",
            "WORKFLOW-IDENTITY.txt",
            "R9-EVALUATION-EXIT-CODE.txt",
            "R9-STEP-OUTCOMES.txt",
        ]
        checks["required_files"]=all(n in names for n in required)
        agg=json.loads(z.read("PARALLEL-INCREMENTAL-CERTIFICATION.json"))
        smoke=json.loads(z.read("KERNEL-BOOT-SMOKE-EVIDENCE.json"))
        reuse=json.loads(z.read("REUSED-R7-LANES-EVIDENCE.json"))
        checks["aggregate_pass"]=(
            agg.get("status")=="PASS"
            and agg.get("workflow_revision")=="v56-parallel-r9"
            and agg.get("candidate_source_sha256")==EXPECTED_SOURCE
            and all(agg.get("checks",{}).values())
        )
        checks["smoke_pass"]=(
            smoke.get("status")=="PASS"
            and smoke.get("qemu_certifier_exit")==0
            and not smoke.get("fatal")
            and all(v==1 for v in smoke.get("required_marker_counts",{}).values())
            and smoke.get("accepted_marker")=="FRAMES_USERSPACE_PLATFORM_OK"
        )
        checks["reuse_pass"]=reuse.get("status")=="PASS"
        checks["r9_eval_exit"]=z.read("R9-EVALUATION-EXIT-CODE.txt").decode().strip()=="0"
        steps=z.read("R9-STEP-OUTCOMES.txt").decode()
        checks["r9_steps"]=("locate=success" in steps and "evaluate=success" in steps)

        # Copy authoritative evidence files; omit the streaming console from the canonical seal.
        canonical=[
            "KERNEL-BOOT-SMOKE-EVIDENCE.json",
            "PARALLEL-INCREMENTAL-CERTIFICATION.json",
            "REUSED-R7-LANES-EVIDENCE.json",
            "WORKFLOW-IDENTITY.txt",
            "R9-EVALUATION-EXIT-CODE.txt",
            "R9-STEP-OUTCOMES.txt",
            "R9-KIT-IDENTITY.txt",
            "R9-START.txt",
        ]
        for n in canonical:
            if n in names:
                (out/n).write_bytes(z.read(n))

    status="PASS" if all(checks.values()) else "FAIL"
    final={
        "status":status,
        "profile":"frames-0.9.46-v56-parallel-r10-final-evidence-seal",
        "workflow_revision":"v56-parallel-r10",
        "frames_version":"0.9.46",
        "candidate_source_sha256":EXPECTED_SOURCE,
        "input_r9_evidence_sha256":EXPECTED_R9_SHA,
        "repair":{
            "type":"final-evidence-manifest-seal",
            "runtime_reexecuted":False,
            "source_bytes_changed":False,
            "reason":"r9 manifest was generated while streaming R9-EVALUATION-CONSOLE.log; authoritative evidence itself passed",
            "streaming_console_excluded_from_canonical_manifest":True,
        },
        "checks":checks,
    }
    (out/"FINAL-CERTIFICATION.json").write_text(json.dumps(final,indent=2)+"\n")
    (out/"WORKFLOW-IDENTITY-R10.txt").write_text(
        "frames_version=0.9.46\n"
        "workflow_revision=v56-parallel-r10\n"
        f"candidate_source_sha256={EXPECTED_SOURCE}\n"
        f"input_r9_evidence_sha256={EXPECTED_R9_SHA}\n"
    )

    # Generate final manifest only after every other output file is complete.
    files=[p for p in sorted(out.iterdir()) if p.is_file() and p.name!="EVIDENCE-FILES-SHA256.txt"]
    manifest="".join(f"{sha_file(p)}  {p.name}\n" for p in files)
    (out/"EVIDENCE-FILES-SHA256.txt").write_text(manifest)

    # Verify manifest immediately after generation.
    mism=[]
    for line in manifest.splitlines():
        h,n=line.split("  ",1)
        p=out/n
        if not p.exists() or sha_file(p)!=h:
            mism.append(n)
    (out/"EVIDENCE-MANIFEST-VERIFY.json").write_text(json.dumps({
        "status":"PASS" if not mism else "FAIL",
        "files_verified":len(files),
        "mismatches":mism
    },indent=2)+"\n")

    # Rebuild manifest one final time so it includes its verifier JSON too.
    files=[p for p in sorted(out.iterdir()) if p.is_file() and p.name!="EVIDENCE-FILES-SHA256.txt"]
    (out/"EVIDENCE-FILES-SHA256.txt").write_text(
        "".join(f"{sha_file(p)}  {p.name}\n" for p in files)
    )
    # Final verification.
    mism=[]
    for line in (out/"EVIDENCE-FILES-SHA256.txt").read_text().splitlines():
        h,n=line.split("  ",1)
        if sha_file(out/n)!=h: mism.append(n)
    if mism:
        raise RuntimeError(f"final manifest mismatch: {mism}")
    if status!="PASS":
        raise RuntimeError(f"r10 final seal checks failed: {checks}")
    print(json.dumps(final,indent=2))
    return 0

if __name__=="__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as e:
        out=Path(os.environ.get("EVIDENCE","."))
        out.mkdir(parents=True,exist_ok=True)
        (out/"R10-EXCEPTION.txt").write_text(
            "".join(traceback.format_exception(type(e),e,e.__traceback__))
        )
        traceback.print_exc()
        raise SystemExit(2)
