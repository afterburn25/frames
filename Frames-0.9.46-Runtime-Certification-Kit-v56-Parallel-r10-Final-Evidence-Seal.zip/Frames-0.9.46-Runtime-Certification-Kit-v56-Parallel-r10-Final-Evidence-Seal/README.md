# Frames 0.9.46 v56 Parallel r10 Final Evidence Seal

Evidence-only canonical sealing repair. No source changes and no QEMU rerun.

Upload the workflow first, then this runtime kit last.

r10 validates the exact external r9 evidence by SHA and regenerates the final
evidence manifest only after all workflow diagnostic files are complete.
