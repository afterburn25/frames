# Frames 0.9.34 v28 Preflight Evidence Analysis

The uploaded Gate-3 evidence archive was rejected before QEMU execution.

- Evidence archive SHA-256: `0426561453bdd551dd9db00e816fd0d4b05293ad229c4bcbe120286104bc6b4b`
- Archive contents: `SOURCE-INTEGRITY-FAILURE.txt`, `NO-SERIAL-LOG.txt`, `WORKFLOW-DIAGNOSTICS.txt`
- QEMU/runtime/filesystem certification did not run.
- Stale workflow expected source SHA-256:
  `567ad9a58cea432e2568a32bc00f4892f9a18432374bed3aa28fa41c29f3dd6f`
- Actual source embedded in the fresh redo kit:
  `332254da868f7ff87a2bb51dd862b0759a17cd323ce2e137b4f52010f2efaa77`

Root cause: the standalone v28 workflow filename collided with the discarded
filesystem attempt and still carried that discarded attempt's expected source
hash. The fresh v28 runtime kit itself contained the correct source and correct
workflow, but GitHub's `.github/workflows/main.yml` was populated from the stale
standalone workflow.

Decision:
- Frames 0.9.34 is NOT promoted from this run.
- Frames 0.9.33 remains authoritative.
- No runtime or filesystem failure is inferred because QEMU never started.
- v29 is a workflow-only repair; the sealed 0.9.34 source/kernel is unchanged.
- v29 scans all same-version source candidates and selects only the exact
  expected SHA-256 instead of selecting by newest timestamp.
