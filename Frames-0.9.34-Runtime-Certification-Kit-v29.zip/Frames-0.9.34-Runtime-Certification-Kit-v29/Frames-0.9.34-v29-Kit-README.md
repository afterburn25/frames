# Frames 0.9.34 Runtime Certification Kit v29

This is a workflow-only repair of the fresh Frames 0.9.34 Gate-3 candidate.

Sealed source SHA-256 remains:

`332254da868f7ff87a2bb51dd862b0759a17cd323ce2e137b4f52010f2efaa77`

The prior uploaded run never reached QEMU because a stale standalone v28
workflow expected the discarded filesystem attempt's source hash.

v29 removes that ambiguity:
- unique workflow/kit revision names;
- exact source SHA pin;
- every same-version source candidate is hashed;
- only the exact source is selected;
- stale duplicate files are ignored rather than selected by timestamp.

All runtime, lifecycle, raw-storage and filesystem certification requirements
are otherwise unchanged.

Expected uploaded evidence artifact:

`frames-0.9.34-filesystem-evidence-v29`
