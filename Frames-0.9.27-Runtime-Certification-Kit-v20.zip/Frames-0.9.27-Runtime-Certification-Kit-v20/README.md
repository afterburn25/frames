# Frames 0.9.27 v20 Runtime Certification Kit

Use `Frames-0.9.27-GitHub-Stress-Certification-v20.yml` with the sealed
`Frames-0.9.27-Source-v20.zip`.

This candidate fixes the DMA-ledger lifetime failure identified by the v19
external evidence. It does not claim Phase-4 promotion until the new GitHub
QEMU/OVMF evidence returns stress exit 0 with USB/input PASS.

The evidence artifact name remains `frames-0.9.27-stress-evidence`.
