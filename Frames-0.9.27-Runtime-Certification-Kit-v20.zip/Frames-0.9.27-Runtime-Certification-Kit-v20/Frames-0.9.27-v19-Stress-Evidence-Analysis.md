# Frames 0.9.27 v19 Stress Evidence Analysis

External evidence archive: `frames-0.9.27-stress-evidence(1).zip`

- Evidence archive SHA-256: `24d7fd6154b0f1e729f6ac41897c6103ec96be2d40ff28c52d1322f51e017ffa`
- Frames version: `0.9.27`
- QEMU: `8.2.2`
- Host Clang: `18.1.3`
- Host LLD: `18.1.3`
- QEMU certification exit: `0`
- Stress certification exit: `1`
- Runtime markers: `70 expected / 70 present / 0 missing / 0 fatal`
- Runtime evidence: `PASS`
- Serial SHA-256: `a2a0c0d68d929369b838f4895e6184c18168372e042b8d9ca3f97d2aa7384cd1`
- Short-circuit runtime: `PASS`, `eager_rhs_after_ack=false`, fallback absent
- Read-only NVMe runtime certification: `PASS`, persistent writes remain uncertified
- Allocator stress: `PASS`
- Scheduler stress: `PASS`
- Storage-read stress: `PASS`
- USB/input stress: `NOT-EXECUTED`
- Stress ledger: `3 executed / 3 passed / 0 failed`
- Overall Phase-4 stress status: `BLOCKED`

## Decisive USB diagnostic

The serial log reaches:

`FRAMES_USB_HID_FOUND`

and then emits:

`FRAMES_USB_CONFIGURE_DIAG stage=0x0000000000000005 detail=0x0000000000000000`

It does not reach `FRAMES_USB_CONFIGURED_OK`, `FRAMES_USB_HID_REPORT_OK`,
`FRAMES_INPUT_QUEUE_OK`, or `FRAMES_STRESS_USB_INPUT_OK`.

In v19 source, stage `0x5` is the allocation of the HID Configure-Endpoint input
context plus the interrupt transfer ring.

## Root cause

The ordinary synchronous NVMe path `nvme_io_read_block()` allocated a new
DMA-owned 4 KiB page for every block read and recorded every page in the fixed
64-entry DMA ledger. The v19 serial contains 41 `FRAMES_NVME_READ_OK` events
before the USB configuration attempt, on top of the controller, queue,
descriptor, and xHCI DMA allocations. The pages were not released or reused.

This made the USB failure a resource-lifetime problem rather than a demonstrated
xHCI Configure Endpoint rejection. v20 therefore repairs the NVMe DMA lifetime
instead of increasing the ledger capacity.

Frames 0.9.27 v19 is rejected for Phase 4. Frames 0.9.26 remains the latest
externally runtime/stress-certified authoritative baseline.
