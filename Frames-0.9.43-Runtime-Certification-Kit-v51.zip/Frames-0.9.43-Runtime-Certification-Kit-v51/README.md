# Frames 0.9.43 Runtime Certification Kit v51

v51 is a workflow-only repair for the v50 preflight failure.

Install `Frames-0.9.43-GitHub-Interactive-Developer-Preview-Certification-v51.yml` as:

`.github/workflows/frames-0.9.43-interactive-developer-preview-v51.yml`

Keep `Frames-0.9.43-Source-v51.zip` available in the repository.

Exact source SHA-256:
`ad8e53c3ec6faacbf580f741730d133b88a536cd79ec15e65faa5a7d182d172b`

Run the workflow and upload:
`frames-0.9.43-interactive-developer-preview-evidence-v51.zip`
