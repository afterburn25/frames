# Frames 0.9.40 v40 Hardware Compatibility Evidence Analysis

## Decision

**REJECTED / NOT PROMOTED.**

Frames 0.9.39 v39 remains the externally certified authoritative baseline.

Evidence archive SHA-256:

`a30803b730179b921dd7dce41666a1bea96ed8af268b022946833ca7bf072a9b`

## Exact source/workflow identity

v40 selected the exact expected Frames 0.9.40 source:

`d761997e6cd276c1d46d7db655b0c10836b3e5cd1b3f35189e3f8785af553a6d`

Observed:
- workflow revision: `v40`
- Nexus: `5.20.0`
- QEMU: `8.2.2`
- Clang: `18.1.3`
- LLD: `18.1.3`

## Inherited certification

All inherited Gates 1–8 passed again.

- baseline runtime certifier: 0
- 70/70 runtime markers
- short-circuit runtime: PASS
- 8/8 stress: PASS
- storage Gate 1: PASS
- reboot/S5 Gate 2: PASS
- filesystem Gate 3: PASS
- S1–S4 crash exits: 137
- S1–S4 recovery exits: 0
- system-volume Gate 4: PASS
- FAT lifecycle Gate 5: PASS
- SMP Gate 6 aggregate: PASS
- 2/4/8/16/32/64/96 CPU lanes: PASS
- 96 CPU diagnostics: 96 / 95 / 95 / 95 / 32 / 95
- removable USB Gate 7: PASS
- physical-preview safety Gate 8: PASS

Fatal sweep across 34 serial logs found zero physical-preview, USB, SMP,
storage, filesystem, FAT, lifecycle, stress, page-fault, panic, assert, or
triple-fault markers.

## v40 compatibility stage

`HWCOMPAT-CERTIFY-EXIT-CODE.txt` = `1`.

Profiles reached:

- baseline: PASS
  - serial SHA-256 `f039e368331e37c35a14f69fcb4ab4004b6e7b67356d9e0857f3556154c4a4f5`
- qemu64: PASS
  - serial SHA-256 `da98555d1efb6fe081b61729ef4e9106dfa909f81710de7f97332335a806f5f7`
- ahci: PASS
  - serial SHA-256 `6544bee60ca24078bb8887ac7e92e468d349e8e449aaffa2a582e09be9807c5f`
- no-network: FAIL
  - QEMU exit 0
  - serial SHA-256 `ac1e4ce1ec1d74ee5572918260dec3578a64413b4aad088c602821e4296148b8`
  - all required markers exactly once
  - no fatal marker
  - only failed check: `network_optional=false`
  - stage 6 network-controller count = 1

Because the matrix is fail-fast, these profiles were not reached:
- ehci-ps2
- virtio-vga
- mixed-storage

## Root cause

The no-network profile removed the explicit e1000e/netdev arguments by setting
the QEMU `NET` array empty.

With no explicit networking option, QEMU instantiated its default NIC.

Frames correctly discovered that controller and correctly reported:

`FRAMES_HWCOMPAT_DIAG stage=6 value=1`

The evidence parser correctly required zero controllers for the no-network
profile, so the lane failed.

This is a **QEMU harness topology bug**, not a Frames kernel networking bug.

## v41 correction

v41 changes only the no-network QEMU topology:

`NET=(-nic none)`

The evidence requirement remains unchanged: stage 6 must equal zero.

The source verifier now explicitly requires the `-nic none` no-network
topology, preventing this regression from returning silently.

Kernel compatibility logic, hardware markers, safety locks, and the seven
profile definitions are unchanged.
