# Frames 0.9.40 Runtime Certification Kit v41

Harness-only rerun after the v40 no-network topology failure.

Source SHA-256:

`e40c7a9e19d14f20fef5df95236ed521f27400a25f36cd295e329e3734b98bb4`

Workflow SHA-256:

`45c6e8ecb2f2fd9da31d279016764d25e147f61a4451b3d56f640002f52363c1`

v40 re-proved every inherited Gate 1–8 and passed baseline, qemu64, and AHCI.
The no-network profile failed because QEMU created a default NIC when the
explicit e1000e arguments were omitted.

v41 fixes the topology by passing:

`-nic none`

for the no-network profile.

The evidence parser is unchanged and still requires network-controller count 0.

The complete matrix remains:

`baseline`
`qemu64`
`ahci`
`no-network`
`ehci-ps2`
`virtio-vga`
`mixed-storage`

Expected evidence artifact:

`frames-0.9.40-hardware-compat-evidence-v41`

Frames 0.9.39 remains the approved physical-preview baseline until v41 passes.
