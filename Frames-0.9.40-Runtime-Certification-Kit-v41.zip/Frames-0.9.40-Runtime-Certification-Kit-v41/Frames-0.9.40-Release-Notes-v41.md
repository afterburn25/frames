# Frames 0.9.40 — Hardware Compatibility Certification v41

Harness-only correction after the first v40 external compatibility run.

- v40 re-proved inherited Gates 1–8.
- baseline, qemu64, and AHCI compatibility profiles passed.
- no-network failed because omitting explicit NIC arguments allowed QEMU to instantiate its default NIC.
- v41 passes `-nic none` in the no-network profile, so the lane now measures a genuinely network-less machine.
- Kernel code, hardware-compatibility evidence requirements, write/destructive safety policy, and all seven profile definitions remain unchanged.
- The fail-fast matrix will proceed to EHCI/PS2, virtio-vga, and mixed-storage only after no-network passes.
