# Frames 0.9.36 Runtime Certification Kit v33

Gate-5 rerun after the v32 inherited lifecycle-harness timeout.

Sealed source SHA-256:

`925089edee565047280c8f4feaa342a76e9e23782109429cd57746c8d76486e8`

Workflow SHA-256:

`d60c802253d00bc7804fc2a1f82854573b8390f8fead32b19ff7c971d88e9cad`

v33 does **not** weaken the lifecycle or FAT certification contract. It only makes
QMP ownership/termination deterministic after the second-boot proof marker:

1. the keyboard injector releases its QMP client when
   `FRAMES_LIFECYCLE_REBOOT_RETURNED` appears;
2. the quit monitor connects to the real QMP server, verifies the greeting,
   negotiates capabilities, sends `quit`, and waits for acknowledgement/EOF;
3. the shell still requires reboot QEMU exit code 0;
4. shutdown/S5, Gates 3–4, and Gate 5 then run normally only if Gate 2 passes.

Gate-5 requirements remain:
- target `FRAMESFAT0936`;
- exact seven-LBA allowlist;
- create/grow/truncate/rename/delete/reallocate/restore;
- 7 phases / 47 writes / 33 flushes / 14 mirrored FAT updates;
- full 64 MiB clone byte-identical after restore;
- no inherited or Gate-5 fatal marker.

Expected evidence artifact:

`frames-0.9.36-fat-lifecycle-evidence-v33`
