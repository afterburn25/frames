# Frames 0.9.36 Gate-5 v32 Evidence Analysis

## Decision

**REJECTED / NOT PROMOTED — workflow stopped in inherited Gate 2 before Gate 5.**

Frames 0.9.35 remains the externally certified authoritative baseline.

Evidence archive SHA-256:

`ca32359e3d46c8adb005565e8862dd5e3074fac4fc2ad9194af925ea5528f743`

## What passed

The v32 run selected the exact hotfix source SHA:

`aded1ac2783840a1872f06c9ea12033cdd16fa6f53d78e8505985549b48da956`

The following preflight/baseline work passed:

- Nexus 5.20.0 source/build/release verification;
- exact 70/70 base runtime marker contract;
- runtime QEMU certifier exit 0;
- 8/8 stress certifier exit 0;
- storage-runtime certifier exit 0;
- raw sacrificial storage-write certifier exit 0;
- short-circuit runtime proof remained clean.

## Where the run stopped

`LIFECYCLE-CERTIFY-EXIT-CODE.txt` = `1`.

The lifecycle console shows the reboot QEMU lane was killed by GNU `timeout` and
returned `124` at the 300-second outer timeout.

This occurred **after the guest lifecycle proof had completed**. The reboot serial
contains:

- `FRAMES_LIFECYCLE_TARGET_FOUND`
- `FRAMES_LIFECYCLE_STATE_PERSISTED`
- `FRAMES_LIFECYCLE_REBOOT_ARMED`
- `FRAMES_LIFECYCLE_REBOOT_EXECUTE`
- an actual firmware restart and second Frames 0.9.36 boot
- second `FRAMES_KERNEL_START`
- second `FRAMES_KERNEL_READY`
- `FRAMES_LIFECYCLE_REBOOT_RETURNED`

`reboot-monitor.log` says:

`QMP quit sent after FRAMES_LIFECYCLE_REBOOT_RETURNED`

However, the v32 monitor did not wait for QEMU to acknowledge the `quit` command.
The QMP input injector also retained the single QMP client for all 600 keyboard
cycles (1200 down/up log lines). The second monitor connection could therefore
race the long-lived input client / QMP chardev and report a send before QEMU had
actually processed the quit command. The outer timeout then won the race.

Because `run_reboot` returned failure, the shutdown lane and subsequent Gate-3,
Gate-4, and Gate-5 runtime lanes were not executed in this run. Preflight-generated
media JSON files do not count as runtime re-certification.

## v33 repair

v33 is a harness-only repair; the 0.9.36 kernel/FAT lifecycle implementation is
unchanged from v32.

- `qmp_input_inject.py` gains an optional stop-log/stop-marker contract.
- The reboot lane asks the injector to release QMP immediately after
  `FRAMES_LIFECYCLE_REBOOT_RETURNED` appears.
- `qmp_marker_quit.py` now waits for the real QMP greeting, negotiates
  `qmp_capabilities`, sends `quit`, and waits for an acknowledgement/EOF.
- The parent shell still requires reboot QEMU exit code `0`.
- Gate-2 reboot/second-boot markers, shutdown/S5 proof, Gates 3–4, and every Gate-5
  requirement remain unchanged and fail closed.
- `verify_runtime_repair_0936.py` includes anti-regression checks for this QMP
  release/acknowledgement behavior.

No certification requirement was weakened.
