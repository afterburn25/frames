# Frames 0.9.19 Runtime Evidence Analysis

## Result
Frames 0.9.19 v10 booted successfully under GitHub Actions QEMU/OVMF and reproduced the stable 67/70 runtime state with zero fatal markers.

Required runtime marker result:
- expected: 70
- present: 67
- missing: 3
- fatal: 0

Missing only:
- `FRAMES_RESCHED_IPI_OK`
- `FRAMES_CPU_AFFINITY_OK`
- `FRAMES_SMP_SCHEDULER_OK`

`FRAMES_KERNEL_READY` is present. Core, platform, userspace, read-only NVMe storage, and safety groups pass. The full GPT/FAT32/VFS/filesystem/network/display/audio/driver/security/recovery-update chain also remains proven.

## New 0.9.19 diagnostics
The serial trace contains:
- `FRAMES_RESCHED_IPI_SENT`
- `FRAMES_RESCHED_TARGET_TIMEOUT`
- `FRAMES_RESCHED_FALLBACK_SENT`
- `FRAMES_RESCHED_FALLBACK_TIMEOUT`

It does **not** contain `FRAMES_RESCHED_TIMER_ALIVE`.

That result rules out explicit APIC destination selection as the sole remaining cause. Both the physical-destination fixed IPI and the one-AP all-excluding-self shorthand fixed IPI failed to obtain an AP handler acknowledgement.

More importantly, the AP timer IRQ counter did not advance during either acknowledgement wait. The AP had already completed one LAPIC timer interrupt and one worker dispatch/return cycle (`FRAMES_AP_TIMER_OK`, `FRAMES_AP_WORKER_ENTER`, `FRAMES_AP_RUNQUEUE_OK`), then became interrupt-inert.

## Root cause found in source
The AP trampoline enters 64-bit kernel code using selector `CS=0x18` (GDT index 3). `kernel_ap_entry()` then loads the BSP-owned shared GDT before loading the shared IDT. The shared GDT builder cleared the table and installed a valid kernel code descriptor at the BSP's live `current_cs` slot, but did not guarantee that slot 3 / selector `0x18` remained valid.

The first AP LAPIC timer interrupt can enter successfully because the shared IDT gate targets the BSP's valid kernel code selector. The handler can run, dispatch the AP worker, return to interrupt context, set runqueue evidence, issue EOI, and reach the interrupt stub's `iretq`.

At `iretq`, however, the saved interrupt frame restores the AP's interrupted selector `CS=0x18`. That selector is revalidated against the newly loaded shared GDT. If slot 3 is empty, the AP faults on interrupt return. This exactly explains the evidence pattern: one AP timer handler succeeds, then no subsequent AP timer IRQs and no fixed IPI acknowledgement, while the BSP and the rest of Frames continue normally.

## 0.9.20 repair
Frames 0.9.20 preserves a valid 64-bit kernel code descriptor at shared-GDT selector `0x18`. It also publishes a post-first-interrupt-return flag only after execution returns to `kernel_ap_entry`, reasserts IF there, and makes BSP SMP progression wait for that proof before sending the reschedule IPI.

Supplemental expected proof:
- `FRAMES_AP_IRQ_RETURN_OK`

The required 70-marker contract is unchanged. Actual AP reschedule-handler receipt remains mandatory for `FRAMES_RESCHED_IPI_OK`, `FRAMES_CPU_AFFINITY_OK`, and `FRAMES_SMP_SCHEDULER_OK`.

## Evidence identity
- Frames version: 0.9.19
- Serial SHA-256: `deaa65f7d26820400e50085d968cc48abe8bf2942e2aa5f4cb23b446990f1b5f`
- Persistent media write path: not certified
- Physical boot: not approved
