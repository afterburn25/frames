# Frames 0.9.20 Runtime Certification Kit v11

Use this kit for the next GitHub Actions QEMU/OVMF certification run.

1. Put `Frames-0.9.20-Runtime-Certification-Kit-v11.zip` at the repository root.
2. Replace the workflow contents with `Frames-0.9.20-GitHub-Runtime-Certification-v11.yml` as `.github/workflows/main.yml` (or your existing workflow filename).
3. Run `Frames 0.9.20 Runtime Certification v11`.
4. Confirm the early log reports Frames 0.9.20 and source SHA-256 `e1a7325e0f0e0bd456f68dbf04e929ee50e0f09fa01768a9ea79d1671dc0b69b`.
5. Download `frames-0.9.20-runtime-evidence` and upload it back for analysis, even if the Action is red.

Primary expected new supplemental proof: `FRAMES_AP_IRQ_RETURN_OK`.
Required closure remains: `FRAMES_RESCHED_IPI_OK`, `FRAMES_CPU_AFFINITY_OK`, `FRAMES_SMP_SCHEDULER_OK`.
