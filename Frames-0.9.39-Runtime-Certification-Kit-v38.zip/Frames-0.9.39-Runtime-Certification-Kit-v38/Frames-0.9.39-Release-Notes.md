# Frames 0.9.39 — Physical Boot Safety Certification Gate 8

Built from the accepted Frames 0.9.38 v37 removable-USB baseline.

## Added
- Dedicated `Frames/PHYSBOOT.CFG` challenge for the physical hardware preview image.
- Loader requires the physical-preview challenge to be combined with the already-certified diagnostic removable-USB proof.
- Kernel physical-preview policy that fail-closes unless diagnostic, USB-path, Block-I/O, media-present, verified-system-read, and removable-media flags are all present.
- Physical-preview override that suppresses all persistent NVMe write-certification target arming and destructive reboot/shutdown certification execution.
- Diagnostic readiness markers for CPU/memory, ACPI/APIC, PCI/storage, USB/input queue, UEFI framebuffer, and passive network discovery.
- Adversarial internal-media matrix using every previously authorized destructive certification identity as a writable internal disk while physical-preview mode is active.
- Byte-identical verification of each internal target plus an AHCI/SATA sentinel.

## Scope
Gate 8 certifies the *safety policy of the physical-preview image under QEMU/OVMF*. If external Gate-8 evidence passes, that exact diagnostic image may be approved for the first controlled physical boot on spare/test hardware. The gate does not claim universal hardware compatibility, native post-boot USB storage I/O, networking, audio output, GPU acceleration, or installer readiness.

Physical boot remains blocked until the v38 external evidence is accepted. Frames 1.0 remains unpromoted.
