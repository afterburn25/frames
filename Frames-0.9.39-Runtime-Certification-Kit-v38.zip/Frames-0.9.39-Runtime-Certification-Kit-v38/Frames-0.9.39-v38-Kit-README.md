# Frames 0.9.39 Runtime Certification Kit v38

Milestone: **Physical Boot Safety Certification Gate 8**

Sealed source SHA-256:

`4d81ccb6ae2ef67969f7cea39932847cc419d287906082775e027dbf574ef9c9`

Workflow SHA-256:

`fa4bdf0c8108176b79c79844cd43c823ee5b899de5a5b17589e81a16192318fc`

This is the final VM-side safety gate before the first controlled diagnostic
physical Frames USB boot.

The dedicated image:

`Frames-0.9.39-Physical-Hardware-Preview.img`

contains both:
- `Frames/USBBOOT.CFG` -> `FRAMES_USB_BOOT_CERT_V1`
- `Frames/PHYSBOOT.CFG` -> `FRAMES_PHYSICAL_PREVIEW_V1`

The physical-preview policy suppresses all persistent/destructive certification
writers before secondary-NVMe target binding.

v38 adversarially presents each previously authorized writable target identity:

`FRAMESWRITE0932`
`FRAMESREBOOT0933`
`FRAMESSHUTDOWN0933`
`FRAMESFS0934`
`FRAMESSYS0935`
`FRAMESFAT0936`

Every lane also contains writable internal support NVMe and writable SATA
sentinel media. All must remain byte-identical.

The preview must prove CPU/memory, ACPI/APIC, PCI/storage, USB/input-queue,
UEFI framebuffer, and passive network discovery while remaining diagnostic-only.

v38 first re-proves all accepted Gates 1-7, including 96 logical CPUs and the
actual removable-USB DEVICE_DELETED survival proof.

Expected evidence artifact:

`frames-0.9.39-physical-boot-safety-evidence-v38`

IMPORTANT: this candidate image is **not yet approved for physical boot**.
Do not flash/boot it on real hardware until the v38 external evidence is
accepted and Frames 0.9.39 is explicitly promoted.
