# Frames 0.9.28 Runtime Certification Kit v21

Use `Frames-0.9.28-GitHub-Stress-Certification-v21.yml` with the sealed `Frames-0.9.28-Source.zip` in the repository root, or place this whole kit in the repository and run the workflow.

The workflow fail-closes on source SHA mismatch and requires the Phase-5 network stress gate. A valid successful artifact is named `frames-0.9.28-stress-evidence`.

Do not treat this candidate as promoted until the returned evidence is independently checked. Physical boot and Frames 1.0 remain blocked.
