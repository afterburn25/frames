# Frames 0.9.37 Gate-6 v35 Evidence Analysis

**Decision: REJECTED — 96-CPU literal marker integrity failure.**

Evidence SHA-256: `22012de9725dd216f788387037513f3307ce05bafe24596938af967b8b745f3d`

Inherited Gates 1–5 passed. SMP lanes 2/4/8/16/32/64 passed. The 96-CPU guest also proved the numeric SMP state: 96 CPUs, 95 APs online, 95 timer proofs, 95 worker proofs, 32 high-word affinity CPUs, and 95 IPI acknowledgements. `FRAMES_SMP_SCALE_CERT_OK` was present and QEMU exited 0.

The only failed check was the literal `FRAMES_SMP_SCALE_APS_ONLINE_OK` marker. A concurrent `FRAMES_SCHEDULER_SUSTAINED` line interleaved byte-by-byte with that BSP marker on shared COM1, splitting the marker. v36 fixes serial proof integrity by temporarily quiescing AP progress-marker output only while the BSP emits the Gate-6 marker block. The evidence parser remains strict and no SMP requirement is relaxed.
