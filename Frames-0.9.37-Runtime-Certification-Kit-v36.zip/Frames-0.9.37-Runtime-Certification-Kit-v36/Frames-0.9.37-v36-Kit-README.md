# Frames 0.9.37 Runtime Certification Kit v36

Source SHA-256: `c9e2ffcd25ea59a22601bb544bd3bafffc96f71b6d78085ff45eda91cc417042`

Workflow SHA-256: `3c34a858bf7fc6783ae00cc22736bd3975548bd01ea87365c2580a4856b409c1`

This is the 96-CPU COM1 marker-integrity hotfix. The matrix remains `2, 4, 8, 16, 32, 64, 96`. At 96 CPUs it still requires 95 APs online, 95 timers, 95 worker dispatches, 95 IPI acknowledgements, and 32 high-word affinity CPUs. No parser relaxation is used.

Expected evidence artifact: `frames-0.9.37-smp-scale-evidence-v36`.
