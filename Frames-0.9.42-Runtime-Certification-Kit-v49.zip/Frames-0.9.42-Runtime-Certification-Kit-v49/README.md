# Frames 0.9.42 Runtime Certification Kit v49

This kit starts the Interactive Developer Preview Phase 1 certification train
from the externally certified Frames 0.9.41 v48 baseline.

Install `Frames-0.9.42-GitHub-Interactive-Developer-Preview-Certification-v49.yml` as:

`.github/workflows/frames-0.9.42-interactive-developer-preview-v49.yml`

Keep `Frames-0.9.42-Source-v49.zip` available in the repository.

The workflow is fail-closed on this exact source SHA-256:

`1789ce2af7eee3fb8c082e1aef648541d072d9d77457fb031f3492d2ece53a39`

It reruns the full inherited v48 certification suite and then certifies the new
framebuffer + keyboard developer-preview command shell.

Expected GitHub artifact:

`frames-0.9.42-interactive-developer-preview-evidence-v49`

Physical hardware boot remains blocked. Do not promote 0.9.42 until the external
v49 evidence passes.
