# Frames 0.9.45 Runtime Certification Kit v55

v55 fixes the indefinite-hang failure mode in the sacrificial filesystem QEMU harness.
The Frames kernel/FEX/application-package implementation is unchanged from v54.

Install the workflow as:

`.github/workflows/frames-0.9.45-nexus-sdk-developer-tooling-v55.yml`

The filesystem lane now has a 300-second per-QEMU watchdog and a 60-minute GitHub-step
upper bound.

Run v55 and upload:

`frames-0.9.45-nexus-sdk-developer-tooling-evidence-v55.zip`

Exact source SHA-256:
`f79e43eac7d2047bde1fb20cb7ade9f1ce09bbabffa9acc95d62acf9ca574199`
