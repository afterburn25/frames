# Frames 0.9.46 v56 Parallel r9 Evidence Repair

Evidence-only repair. No Frames source changes and no QEMU rerun.

r9 fixes the r8 workflow-generation bug by moving the evidence verifier into a
standalone Python file inside this sealed kit. The GitHub YAML no longer embeds
the large verifier body.

The workflow always creates runtime-evidence before evaluation and uploads
diagnostic evidence before its final fail-closed verdict.
