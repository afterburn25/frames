# Frames 0.9.30 Runtime Certification Kit v24

Phase 7: Recovery Stress/Fault Certification.

Sealed source SHA-256:

`e2d66aa93afc45acb35eb2939aa5c0901ef5010d94f38e04e7761fc730e4565e`

The GitHub/QEMU run must produce:

- `FRAMES_RECOVERY_PATH_FOUND`
- `FRAMES_STRESS_RECOVERY_OK`
- QEMU certifier exit 0
- stress certifier exit 0
- 70/70 base runtime markers
- zero fatal markers
- allocator/scheduler/storage-read/USB-input/network/display/recovery all PASS
- exactly 7 executed / 7 passed / 0 failed

Power remains NOT-EXECUTED. Physical boot and Frames 1.0 remain blocked.
