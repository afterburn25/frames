# Frames 0.9.16 Runtime Certification Kit

Contents:
- `Frames-0.9.16-Source.zip`
- `Frames-0.9.16-GitHub-Runtime-Certification.yml`

GitHub usage:
1. Put this runtime kit ZIP, or the source ZIP directly, at the repository root.
2. Install the workflow as `.github/workflows/frames-runtime-certify.yml`.
3. Run the workflow.
4. Download the `frames-runtime-evidence` artifact even if the job is red.
5. Return that evidence ZIP for diagnosis.

The workflow can discover a Frames runtime-kit ZIP automatically and extract the source archive inside it.

Primary 0.9.16 evidence target:
- `FRAMES_AP_GDT_OK`
- `FRAMES_AP_TIMER_OK`
- `FRAMES_AP_WORKER_ENTER`
- `FRAMES_AP_RUNQUEUE_OK`
- `FRAMES_RESCHED_IPI_SENT`
- `FRAMES_RESCHED_IPI_OK`

Physical boot remains BLOCKED.
