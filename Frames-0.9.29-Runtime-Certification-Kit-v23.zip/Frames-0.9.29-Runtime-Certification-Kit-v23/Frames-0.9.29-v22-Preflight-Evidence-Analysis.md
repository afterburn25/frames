# Frames 0.9.29 v22 Preflight Evidence Analysis

Date: 2026-08-11

## Decision

**REJECTED / PRE-RUNTIME BLOCKED**

The v22 GitHub run did not reach QEMU. It was stopped by the preflight source gate before any serial/runtime evidence was produced.

## Evidence identity

- Evidence archive: `frames-0.9.29-stress-evidence.zip`
- Evidence SHA-256: `4a5bcfc1f6a03793ab14328aba57462ad725786cb37fa5bc1500fbb4683ab365`
- Expected Frames version: `0.9.29`
- Exact sealed source SHA-256: `94eec3b599bababf47d8ac1d9215c7887f88ff7be98d82701ca263c6d1f8761c`
- GitHub toolchain: QEMU 8.2.2, Clang 18.1.3, LLD 18.1.3
- Nexus: 5.20.0

## What passed before the stop

The source was discovered as Frames 0.9.29 and the build completed far enough to produce:

- FramesKernel.fkrn
- System.fex
- BOOTX64.EFI
- Frames-0.9.29-ESP.img
- BOOTSTAT.TXT

Release-structure verification reported `ALL RELEASE STRUCTURE CHECKS PASSED`.

The expected Nexus kernel hash was reproduced:
`9fb5862a6d5675ad43c692769bf793a1675f07f0fb02ed7a287a9967a45177f9`

The expected System FEX hash was reproduced:
`b3c34e79abe1eadc30b9ca9a28a1e2616f9880533f18ebce81537d36830e12dd`

## Exact failure

Preflight then emitted:

`FAIL: version is 0.9.28`

This came from the v22 GitHub workflow invoking the **old Phase-5 verifier**:

`python3 tools/verify_runtime_repair_0928.py`

instead of the Phase-6 verifier:

`python3 tools/verify_runtime_repair_0929.py`

The v22 workflow also contained two stale 0.9.28 labels in the source-discovery step.

## Root cause

This is a **workflow-only certification wiring defect**. It is not a Frames 0.9.29 kernel, display, source-version, or runtime failure.

The sealed Frames 0.9.29 source contains `tools/verify_runtime_repair_0929.py`, and that verifier passes all Phase-6 source gates when executed against the exact sealed source.

## Repair

Certification workflow v23:

- invokes `verify_runtime_repair_0929.py`;
- removes the stale 0.9.28 source labels;
- keeps `EXPECTED_FRAMES_VERSION=0.9.29`;
- keeps the exact same sealed source SHA-256 `94eec3b599bababf47d8ac1d9215c7887f88ff7be98d82701ca263c6d1f8761c`;
- keeps `--require-display-pass`;
- keeps `FRAMES_STRESS_DISPLAY_FAIL` fatal;
- does not modify the kernel/source baseline.

Frames 0.9.28 remains the latest externally runtime/stress-certified authoritative baseline until a v23 QEMU/OVMF run earns Phase 6.
