# Frames 0.9.29 Runtime Certification Kit v23

This kit repairs the v22 GitHub preflight wiring error. The sealed source is unchanged.

Source SHA-256: `94eec3b599bababf47d8ac1d9215c7887f88ff7be98d82701ca263c6d1f8761c`

Run the included `Frames-0.9.29-GitHub-Stress-Certification-v23.yml` in GitHub Actions with this kit/source available.

Expected successful Phase-6 evidence includes:

- `FRAMES_DISPLAY_FRAMEBUFFER_FOUND`
- `FRAMES_STRESS_DISPLAY_OK`
- 70/70 base markers
- 6 executed / 6 passed / 0 failed
- QEMU exit 0
- stress exit 0
