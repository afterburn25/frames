# Frames 0.9.29 v23 — Phase-6 Certification Workflow Repair

Frames 0.9.29 v23 is a **certification-workflow-only repair**. The sealed Frames 0.9.29 source is unchanged.

## Fixed

- Replaced the accidental v22 preflight call to `tools/verify_runtime_repair_0928.py` with `tools/verify_runtime_repair_0929.py`.
- Corrected stale `0.9.28` source labels in the GitHub certification workflow.
- Preserved the exact sealed Frames 0.9.29 source SHA-256:
  `94eec3b599bababf47d8ac1d9215c7887f88ff7be98d82701ca263c6d1f8761c`

## Unchanged promotion gate

Phase 6 still requires:

- QEMU certifier exit 0
- stress certifier exit 0
- 70/70 base runtime markers
- 0 fatal markers
- allocator PASS
- scheduler PASS
- storage-read PASS
- USB/input PASS
- network PASS
- display PASS
- exactly 6 executed / 6 passed / 0 failed
- `FRAMES_DISPLAY_FRAMEBUFFER_FOUND`
- `FRAMES_STRESS_DISPLAY_OK`

Frames 0.9.28 remains authoritative until that external evidence is accepted.
