# Frames 0.9.23 Runtime Certification Kit v14

This kit contains the sealed Frames 0.9.23 source archive, strict GitHub Actions v14 runtime-certification workflow, the successful 0.9.22 runtime-evidence analysis, and local verification records.

## GitHub use
1. Put `Frames-0.9.23-Runtime-Certification-Kit-v14.zip` at the repository root.
2. Replace the active workflow contents with `Frames-0.9.23-GitHub-Runtime-Certification-v14.yml`.
3. Run the workflow.
4. Download artifact `frames-0.9.23-runtime-evidence` and return it for analysis.

The workflow accepts only the exact sealed 0.9.23 source SHA and ignores older Frames kits.

## Purpose
0.9.22 already achieved 70/70 required QEMU runtime markers. 0.9.23 confirms that Nexus 5.20 true short-circuit lowering removes the unnecessary fallback IPI observed after a successful targeted reschedule acknowledgement.

v14 writes `SHORT-CIRCUIT-RUNTIME.json` and fails if `FRAMES_RESCHED_FALLBACK_SENT` occurs after `FRAMES_RESCHED_IPI_OK`.

The required 70-marker runtime contract remains unchanged. Physical boot remains blocked.
