# Frames 0.9.22 Runtime Evidence Analysis

## Result

Frames 0.9.22 achieved the first complete external GitHub Actions QEMU/OVMF runtime certification pass.

- Frames version: `0.9.22`
- Required markers: `70`
- Present markers: `70`
- Missing markers: `0`
- Fatal markers: `0`
- `qemu_certify.sh` exit code: `0`
- Runtime evidence status: `PASS`
- Physical boot approved: `false`
- Storage profile: `storage-nvme-read-only` PASS
- Persistent write path certified: `false`
- Serial SHA-256: `0f5d240ec26248fd5fc19172a655036919f58f55ad787ff3b7dc1186889ad51f`

## Runtime groups

All runtime evidence groups passed:
- core
- platform
- smp
- userspace
- storage_nvme
- safety

## AP/SMP closure

The segment-state and interrupt-return repairs introduced in 0.9.22 were externally proven.

Observed sequence:

```text
FRAMES_AP_GDT_OK
FRAMES_AP_CS_NORMALIZED_OK
FRAMES_AP_SEGMENTS_NORMALIZED_OK
FRAMES_AP_APIC_ENABLE_OK
FRAMES_AP_TIMER_COUNTING_OK
FRAMES_AP_TIMER_OK
FRAMES_AP_BARE_IRQ_RETURN_OK
FRAMES_AP_WORKER_ENTER
FRAMES_AP_RUNQUEUE_OK
FRAMES_AP_IRQ_RETURN_OK
FRAMES_RESCHED_IPI_SENT
FRAMES_RESCHED_IPI_OK
FRAMES_CPU_AFFINITY_OK
FRAMES_SMP_SCHEDULER_OK
FRAMES_KERNEL_READY
```

No `FRAMES_AP_PROTECTION_FAULT=` marker and no `FRAMES_PAGE_FAULT` marker appeared.

This proves:
- the AP can load the shared GDT/IDT;
- AP CS and DS/ES/SS normalization is viable;
- a scheduler-free LAPIC timer interrupt returns through `iretq`;
- the scheduled AP timer/worker path returns through `iretq`;
- the AP receives a real reschedule IPI;
- CPU affinity and the SMP scheduler gate can be earned;
- the complete 70-marker QEMU runtime contract can close.

## Supplemental anomaly discovered after PASS

Serial ordering contains:

```text
FRAMES_RESCHED_IPI_SENT
FRAMES_RESCHED_IPI_OK
FRAMES_RESCHED_FALLBACK_SENT
```

The fallback call is the right operand of:

```text
if resched_ok == 0 && send_reschedule_ipi_fallback(cpu_state,smp_state) != 0
```

Once `FRAMES_RESCHED_IPI_OK` is emitted, `resched_ok` is nonzero and the fallback call should not execute under short-circuit boolean semantics.

Inspection of Nexus 5.19.0 native lowering confirmed that both operands of `&&` and `||` were evaluated eagerly before their boolean result was combined. The hosted C backend already preserves normal short-circuit semantics.

This does not invalidate the 70/70 runtime result: the AP acknowledgement required by `FRAMES_RESCHED_IPI_OK` happened before the unnecessary fallback send, and all required gates passed. It does, however, expose a real compiler/backend correctness bug that should be repaired before stress/fault certification.

Frames 0.9.23 + Nexus 5.20.0 therefore exists as a runtime-baseline cleanup checkpoint with branch-based short-circuit lowering.

## Promotion status

This evidence completes the current QEMU/OVMF 70-marker runtime lane. It does **not** promote Frames 1.0.

Still required:
- stress/fault certification;
- completion/import of the eight-category external certification matrix;
- separate physical-hardware certification/promotion evidence.

Physical boot remains explicitly blocked.
