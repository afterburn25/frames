# Frames 0.9.23 — Nexus Short-Circuit Semantics & QEMU Runtime Baseline Freeze

## External 0.9.22 result
Frames 0.9.22 achieved the first complete external QEMU/OVMF runtime pass:
- 70 required markers expected
- 70 present
- 0 missing
- 0 fatal
- QEMU certifier exit code 0
- all runtime evidence groups PASS
- physical boot still not approved

The AP segment-state and IRET repairs were proven by:
- `FRAMES_AP_SEGMENTS_NORMALIZED_OK`
- `FRAMES_AP_BARE_IRQ_RETURN_OK`
- `FRAMES_AP_WORKER_ENTER`
- `FRAMES_AP_RUNQUEUE_OK`
- `FRAMES_AP_IRQ_RETURN_OK`
- `FRAMES_RESCHED_IPI_OK`
- `FRAMES_CPU_AFFINITY_OK`
- `FRAMES_SMP_SCHEDULER_OK`

## Nexus 5.20.0
The same successful run exposed a non-gating language/backend defect: `FRAMES_RESCHED_FALLBACK_SENT` appeared after `FRAMES_RESCHED_IPI_OK`. The fallback was on the right side of `&&`, so it should have been skipped.

Nexus 5.20.0:
- implements true short-circuit `&&` on x86-64 and ARM64 native backends;
- implements true short-circuit `||` on x86-64 and ARM64 native backends;
- adds side-effect regression coverage;
- keeps hosted-C semantics unchanged.

## Certification policy
The required QEMU runtime marker contract remains exactly 70 markers. Frames 1.0 is NOT promoted by this release. Stress/fault certification, the remaining external certification matrix, and physical-hardware evidence remain mandatory.
