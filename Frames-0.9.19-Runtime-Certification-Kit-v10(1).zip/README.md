# Frames 0.9.19 Runtime Certification Kit v10

Use this kit for the next GitHub Actions QEMU/OVMF run.

Repository root:
- `Frames-0.9.19-Source.zip`, or
- this complete runtime-kit ZIP.

Workflow:
- copy `Frames-0.9.19-GitHub-Runtime-Certification-v10.yml` to `.github/workflows/frames-runtime-certify.yml` (the filename may differ; the contents matter).

The v10 workflow is strict to Frames 0.9.19 and verifies the sealed source SHA-256 before extraction:

`efeb13afbcf5f9bc16378f6b6b124576abd9711c213725ae2a8276f671e59e69`

Expected required closure markers:
- `FRAMES_RESCHED_IPI_OK`
- `FRAMES_CPU_AFFINITY_OK`
- `FRAMES_SMP_SCHEDULER_OK`

Supplemental diagnostics may include:
- `FRAMES_RESCHED_TIMER_ALIVE`
- `FRAMES_RESCHED_TARGET_TIMEOUT`
- `FRAMES_RESCHED_FALLBACK_SENT`
- `FRAMES_RESCHED_FALLBACK_TIMEOUT`

The shorthand fallback is allowed only when the runtime topology contains exactly one AP. It does not synthesize any required marker: `FRAMES_RESCHED_IPI_OK` still requires the AP interrupt handler to increment its receipt counter.

Upload `frames-0.9.19-runtime-evidence` back to ChatGPT even if the Action is red.

Physical boot remains blocked and Frames 1.0 is not promoted by this package.
