# Frames 0.9.18 Runtime Evidence Analysis

## Result

The strict v9 GitHub Actions workflow selected and booted the exact Frames 0.9.18 source under QEMU/OVMF.

Runtime marker result:
- expected: 70
- present: 67
- missing: 3
- fatal markers: 0

Missing only:
- `FRAMES_RESCHED_IPI_OK`
- `FRAMES_CPU_AFFINITY_OK`
- `FRAMES_SMP_SCHEDULER_OK`

`FRAMES_KERNEL_READY` is present.

## Runtime evidence groups

- core: PASS
- platform: PASS
- userspace: PASS
- storage_nvme: PASS
- safety: PASS
- smp: BLOCKED only because `FRAMES_SMP_SCHEDULER_OK` was not earned

Storage profile `storage-nvme-read-only`: PASS. Persistent media writes remain uncertified and absent.

Serial SHA-256:
`7bf3cea65c784d34198725e1ec5c52960ed1a8302e021e7d02b57e8a286ecc0b`

## Confirmed successful progression

0.9.18 preserved every major 0.9.17 runtime success:
- GPT, ESP/boot-volume, FAT32, and boot-file discovery;
- VFS, vnode, open-file readback, RAMFS, devfs, procfs, paths, filesystem rights/events;
- `FRAMES_FILESYSTEM_PLATFORM_OK`;
- network/display/audio/driver/security/recovery-update consolidated gates;
- AP startup and online proof;
- shared AP kernel GDT/IDT coherence;
- APIC enable and LAPIC timer countdown;
- `FRAMES_AP_TIMER_OK`;
- `FRAMES_AP_WORKER_ENTER`;
- `FRAMES_AP_RUNQUEUE_OK`;
- `FRAMES_RESCHED_IPI_SENT`;
- full BSP worker lifecycle;
- sustained BSP scheduler;
- `FRAMES_KERNEL_READY`.

No page fault or other fatal marker appeared.

## Remaining boundary

Changing the targeted reschedule IPI from vector `0x32` to asserted, higher-priority vector `0x50` (`ICR low 0x4050`) did not cause the AP reschedule receipt counter to increment.

The evidence therefore narrows the remaining QEMU runtime blocker to delivery/acceptance of the BSP-originated **fixed reschedule IPI**. It does not implicate AP startup, descriptor tables, timer delivery, scheduler dispatch/return, storage/filesystem, userspace, or downstream subsystem gates.

## 0.9.19 response

Frames 0.9.19 keeps the targeted physical-destination `0x4050` attempt first and fail-closed. If it times out:
- the BSP samples whether the AP timer interrupt count continued advancing;
- on the exactly-one-AP certification topology only, the BSP retries the same fixed vector with xAPIC destination shorthand `all excluding self` (`ICR low 0xC4050`);
- the required `FRAMES_RESCHED_IPI_OK` marker is emitted only if the AP's actual reschedule handler increments its shared receipt counter.

The 70-marker contract is unchanged. Physical boot remains blocked.
