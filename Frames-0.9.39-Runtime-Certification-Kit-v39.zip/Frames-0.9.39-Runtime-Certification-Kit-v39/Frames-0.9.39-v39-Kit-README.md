# Frames 0.9.39 Runtime Certification Kit v39

Gate-8 UEFI transport-proof hotfix.

Source SHA-256:

`7ee62048c2521a6dcc4c259d4d550110b0c71333fab98b712d8fa518f48604e5`

Workflow SHA-256:

`e931323b3a2873f7c43c69e09e04a8496035a2f6ce66362da427da6cf1b6b095`

v39 removes EFI `BlockIo.Media.RemovableMedia` as an independent Gate-8
requirement because v38 proved that QEMU can expose it as false on a genuine
USB boot.

Physical-preview mode still requires the exact USB challenge, a USB messaging
Device Path, Block I/O, MediaPresent, verified kernel/FEX from that filesystem,
diagnostic-only policy, and the exact PHYSBOOT challenge.

All seven adversarial safety lanes and all media-integrity requirements are
unchanged.

Expected evidence:

`frames-0.9.39-physical-boot-safety-evidence-v39`

Physical boot remains BLOCKED until v39 passes.
