# Frames 0.9.39 Gate-8 v38 Evidence Analysis

## Decision

**REJECTED — Gate 8 did not enter the kernel.**

Frames 0.9.38 remains the externally certified authoritative baseline.

Evidence archive SHA-256:

`b3c68710ea7076df7bdebc2901ef20b2cbd46374155a000007c700628c361d5a`

## What passed before Gate 8

v38 selected the exact expected source and re-proved all inherited Gates 1-7:
runtime 70/70, 8/8 stress, raw storage, destructive reboot/S5, filesystem
crash/recovery, system-volume, FAT lifecycle, the complete 2/4/8/16/32/64/96
SMP matrix, and removable USB normal/hot-unplug certification.

## Gate-8 failure

`PHYSICAL-PREVIEW-CERTIFY-EXIT-CODE.txt` = `1`.

Only the generic Gate-8 lane was reached.

`PHYSICAL-PREVIEW-GENERIC-QEMU-EXIT-CODE.txt` = `124`.

OVMF selected the USB device and Frames reported:

`[USB] Removable USB boot certification challenge verified`

but the loader halted with:

`FRAMES BOOT ERROR: Physical preview requires diagnostic removable USB proof`

The kernel never started.

## Root cause

Gate 8 added one extra predicate beyond Gate 7: EFI Block I/O had to report
`Media->RemovableMedia == true` (boot-policy bit 64).

QEMU's genuine `usb-storage` boot path exposed `RemovableMedia=false`, even
though the loaded-image Device Path contained a USB node and the established
USB proof had already succeeded.

The failure is therefore an over-constrained UEFI metadata predicate, not an
internal-disk safety failure.

## v39 correction

v39 no longer treats EFI `RemovableMedia` metadata as an independent trust
requirement.

Physical-preview mode still requires:
- diagnostic-only policy;
- exact USBBOOT.CFG challenge;
- actual USB messaging Device Path proof;
- Block I/O;
- MediaPresent;
- verified Frames kernel and System FEX from that same boot filesystem;
- exact PHYSBOOT.CFG challenge.

An internal NVMe/SATA boot still cannot arm physical preview because it cannot
satisfy the required USB messaging Device Path and USB challenge proof.

No adversarial storage-safety requirement is weakened.
