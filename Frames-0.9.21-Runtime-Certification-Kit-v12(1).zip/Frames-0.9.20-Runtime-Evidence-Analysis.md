# Frames 0.9.20 Runtime Evidence Analysis

## Result

The GitHub Actions QEMU/OVMF run selected and booted Frames 0.9.20 successfully. The run did **not** reach the complete 70-marker runtime gate, but it materially narrowed the last SMP failure.

### Required marker result

- Expected: **70**
- Present: **66**
- Missing: **4**
- Fatal markers: **0**

Missing required markers:

- `FRAMES_RESCHED_IPI_SENT`
- `FRAMES_RESCHED_IPI_OK`
- `FRAMES_CPU_AFFINITY_OK`
- `FRAMES_SMP_SCHEDULER_OK`

### Runtime groups

- core: **PASS**
- platform: **PASS**
- userspace: **PASS**
- storage_nvme: **PASS**
- safety: **PASS**
- smp: **BLOCKED** only because `FRAMES_SMP_SCHEDULER_OK` was not earned

`FRAMES_KERNEL_READY` is present.

Storage runtime profile `storage-nvme-read-only` is **PASS**. Persistent-media writes remain uncertified and absent from the product path.

Serial SHA-256:

`8661dd447f4cc92ccbe44a9d37fb0b5117b4fd4735e2131fe9ef77b86a0f891d`

## Decisive SMP evidence

0.9.20 successfully reached:

- `FRAMES_AP_GDT_OK`
- `FRAMES_AP_APIC_ENABLE_OK`
- `FRAMES_AP_TIMER_COUNTING_OK`
- `FRAMES_AP_TIMER_OK`
- `FRAMES_AP_WORKER_ENTER`
- `FRAMES_AP_RUNQUEUE_OK`

However, the new supplemental `FRAMES_AP_IRQ_RETURN_OK` marker did **not** appear.

0.9.20 intentionally blocked reschedule-IPI injection until the AP published a flag from `kernel_ap_entry` after the first timer interrupt had fully returned through the interrupt stub. Because that proof never arrived, `FRAMES_RESCHED_IPI_SENT` was correctly withheld.

This narrows the real failure boundary to the tail of the AP's first timer cycle:

1. LAPIC timer interrupt enters successfully.
2. Scheduler dispatches the AP worker.
3. Worker yields back to the timer-handler context.
4. The handler reaches the runqueue proof.
5. Execution does **not** subsequently reach resumed `kernel_ap_entry` code.

The remaining defect is therefore after the worker context-switch return and before/at the final interrupt return to normal AP execution. It is not a storage, VFS, userspace, timer-programming, AP-startup, or worker-dispatch failure.

## 0.9.21 repair direction

Frames 0.9.21 isolates the remaining path in two independent stages:

1. The first AP LAPIC timer interrupt is a **bare interrupt-return probe**. Scheduler dispatch is disabled, the handler records the IRQ, sends EOI, and returns immediately.
2. Only after `kernel_ap_entry` proves that bare return completed is scheduler dispatch enabled for the next timer interrupt.
3. A second proof is published only after the scheduled timer/worker cycle also returns all the way to `kernel_ap_entry`.
4. The AP additionally reloads its live CS onto the BSP/shared kernel selector after adopting the shared GDT, eliminating reliance on the trampoline selector for subsequent interrupt return.

The authoritative 70-marker runtime gate remains unchanged and fail-closed.
