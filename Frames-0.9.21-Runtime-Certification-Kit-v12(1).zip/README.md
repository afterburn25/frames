# Frames 0.9.21 Runtime Certification Kit v12

This kit contains the sealed Frames 0.9.21 source archive, the strict GitHub Actions v12 runtime-certification workflow, and the analysis of the real 0.9.20 runtime evidence that motivated this build.

## GitHub use

1. Upload `Frames-0.9.21-Runtime-Certification-Kit-v12.zip` to the repository root, or upload the contained `Frames-0.9.21-Source.zip` directly.
2. Replace `.github/workflows/frames-runtime-certify.yml` (or the workflow file you currently use) with `Frames-0.9.21-GitHub-Runtime-Certification-v12.yml`.
3. Run the workflow.
4. Download `frames-0.9.21-runtime-evidence` even if the Action is red.
5. Return that ZIP for analysis.

The workflow is locked to Frames 0.9.21 and the exact sealed source SHA-256. Older/newer source archives are ignored.

## Primary supplemental diagnostics

- `FRAMES_AP_CS_NORMALIZED_OK`
- `FRAMES_AP_BARE_IRQ_RETURN_OK`
- `FRAMES_AP_IRQ_RETURN_OK`

The 70 required certification markers are unchanged.
