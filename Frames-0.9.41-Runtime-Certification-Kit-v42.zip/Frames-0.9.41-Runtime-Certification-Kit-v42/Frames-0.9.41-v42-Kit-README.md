# Frames 0.9.41 Runtime Certification Kit v42

Milestone: **Native USB Mass-Storage Runtime Phase 2**

Source SHA-256:

`054c8477a79720c731025bde2407e4d073a12408a458809c135fbc16b518d50c`

Workflow SHA-256:

`8733223c62531a2bd230b37cf8a16237323e5e559eeb78ea3950b33165e10670`

v42 first re-proves the entire accepted Frames 0.9.40 chain, including Gates
1–8, 96 logical CPUs, removable USB hot-unplug, physical-preview write safety,
and all seven 0.9.40 hardware compatibility profiles.

It then runs two new native USB Mass Storage lanes. Firmware boots Frames via a
separate EHCI controller; Frames must initialize a second xHCI controller and
read a separate USB Mass Storage device using its own post-ExitBootServices
Bulk-Only Transport/SCSI path.

Read-only command set: INQUIRY, TEST UNIT READY, READ CAPACITY(10), READ(10).
No WRITE(10) implementation exists in this phase.

The data image is writable at the QEMU layer and must remain byte-identical.
The detach lane requires a real asynchronous QMP DEVICE_DELETED event after the
read proof and before FRAMES_USB_MSC_RESIDENT_OK.

Expected evidence artifact:

`frames-0.9.41-native-usb-storage-evidence-v42`

0.9.41 remains a candidate until that evidence is accepted. Frames 0.9.40 v41
remains the externally certified authoritative baseline.
