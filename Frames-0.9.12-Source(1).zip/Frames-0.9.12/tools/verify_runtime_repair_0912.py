#!/usr/bin/env python3
from pathlib import Path
import importlib.util, sys, tempfile
root=Path(__file__).resolve().parents[1]
def ok(c,m):
    if not c: raise SystemExit('FAIL: '+m)
    print('PASS:',m)
ok((root/'VERSION').read_text().strip()=='0.9.12','version is 0.9.12')
b=(root/'tools/build.sh').read_text()
ok('Nexus-Language-5.17.0/nexus' in b,'build selects Nexus 5.17.0')
cp=root/'toolchain/Nexus-Language-5.17.0/compiler/nexus/compiler.py'
s=cp.read_text()
ok('user_enter_context' in s and 'user_return_context' in s,'frame-complete user continuation builtins registered')
ok("movq %rbp, 8(%r9)" in s,'user enter context saves kernel RBP')
ok("movq 8(%rdx), %rbp" in s and "movq (%rdx), %rsp" in s,'user return context restores kernel RBP and RSP')
spec=importlib.util.spec_from_file_location('nx517verify',cp); mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'ctx.nx'
    p.write_text('module C; kernel C { arch: x86_64; abi: frames_4; } fn kernel_main() -> void { user_enter_context(1,2,3,4); user_return_context(1,4); return; }')
    asm=mod.compile_to_x64_frames_asm(p)
    ok('nx_kernel_user_enter_context' in asm and 'movq %rbp, 8(%r9)' in asm,'context entry regression emits RBP save')
    ok('nx_kernel_user_return_context' in asm and 'movq 8(%rdx), %rbp' in asm,'context return regression emits RBP restore')
k=(root/'kernel/main.nx').read_text()
ok('user_enter_context(' in k and 'process_state + 992' in k,'Frames ring3 probe uses dedicated continuation record')
ok('user_return_context(' in k and 'process_state+992' in k,'Frames exit syscall uses frame-complete return')
ok('volatile_write8(code_page+2060,1)' in k and 'volatile_write8(code_page+2069,2)' in k,'user thunk executes syscall 1 before syscall 2')
ok('serial_marker_user_syscall_ok' in k,'ordinary userspace syscall marker remains wired')
loader=(root/'boot/uefi/frames_boot.c').read_text()
ok('FRAMES 0.9.12\\r\\n' in loader,'UEFI banner updated to 0.9.12')
print('ALL FRAMES 0.9.12 CONTINUATION-RETURN SOURCE GATES PASSED')
