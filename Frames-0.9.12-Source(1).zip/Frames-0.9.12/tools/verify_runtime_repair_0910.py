#!/usr/bin/env python3
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]

def ok(cond,msg):
    if not cond: raise SystemExit('FAIL: '+msg)
    print('PASS:',msg)

ok((root/'VERSION').read_text().strip()=='0.9.10','version is 0.9.10')
loader=(root/'boot/uefi/frames_boot.c').read_text()
kernel=(root/'kernel/main.nx').read_text()
qemu=(root/'tools/qemu_certify.sh').read_text()

m=re.search(r'const UINTN bootstrap_pages=(\d+);',loader)
ok(m is not None,'bootstrap page declaration found')
pages=int(m.group(1))
entries=[]
km=kernel[kernel.index('fn kernel_main'):]
pre=km[:km.index('var allocator_ready')]
for mm in re.finditer(r'let\s+([A-Za-z0-9_]+)\s*=\s*bump_alloc\(&mut heap_cursor,\s*heap_end,\s*(\d+)\);',pre):
    entries.append((mm.group(1),int(mm.group(2))))
required=sum(x[1] for x in entries)
ok(len(entries)>=118,'kernel bootstrap reservation inventory parsed')
ok(required==544768,'kernel bootstrap reservation is 544768 bytes / 133 pages')
ok(pages*4096>=required+32*4096,'bootstrap heap has at least 32 pages of headroom')
ok('valid_acpi_rsdp' in loader and 'checksum8_zero' in loader,'UEFI validates ACPI RSDP candidates')
ok('if(!generic && valid_acpi_rsdp(candidate)) generic=candidate;' in loader,'UEFI has validated signature fallback for ACPI RSDP')
for code in range(1,9): ok(f'acpi_diag_fail({code})' in kernel,f'ACPI diagnostic code {code} is wired')
ok('FRAMES 0.9.10\\r\\n' in loader,'UEFI banner updated to 0.9.10')
ok('mkdir -p "$ROOT/build"' in qemu and qemu.index('mkdir -p "$ROOT/build"') < qemu.index('cp "$OVMF_VARS"'),'QEMU harness creates build directory before OVMF VARS copy')
ok('decision: BLOCKED' not in kernel,'kernel does not hardcode an approval decision')
print('ALL FRAMES 0.9.10 RUNTIME-REPAIR SOURCE GATES PASSED')
