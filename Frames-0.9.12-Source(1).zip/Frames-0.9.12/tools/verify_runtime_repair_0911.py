#!/usr/bin/env python3
from pathlib import Path
import importlib.util, sys, tempfile
root=Path(__file__).resolve().parents[1]
def ok(c,m):
    if not c: raise SystemExit('FAIL: '+m)
    print('PASS:',m)
ok((root/'VERSION').read_text().strip()=='0.9.11','version is 0.9.11')
b=(root/'tools/build.sh').read_text()
ok('Nexus-Language-5.16.0/nexus' in b,'build selects Nexus 5.16.0')
cp=root/'toolchain/Nexus-Language-5.16.0/compiler/nexus/compiler.py'
s=cp.read_text()
ok('self.emit("    xorq %rdx, %rdx"); self.emit("    divq %r10")' in s,'unsigned divide/modulo uses DIVQ')
ok("{'<':'b','>':'a','<=':'be','>=':'ae'}" in s,'unsigned ordering uses unsigned condition codes')
spec=importlib.util.spec_from_file_location('nx516verify',cp); mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'u.nx'; p.write_text('module U; kernel U { arch: x86_64; abi: frames_4; } fn kernel_main() -> void { let x: u64 = 9223372036854775815; let q=x/4; let r=x%4; let c=x>7; if q!=0 && r!=0 && c { cpu_halt(); } return; }')
    asm=mod.compile_to_x64_frames_asm(p)
    ok('divq %r10' in asm and 'idivq %r10' not in asm,'u64 regression fixture lowers unsigned division')
    ok('seta %al' in asm,'u64 regression fixture lowers unsigned comparison')
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'s.nx'; p.write_text('module S; kernel S { arch: x86_64; abi: frames_4; } fn kernel_main() -> void { let x: i64 = -9; let q=x/4; let c=x<0; if q!=0 && c { cpu_halt(); } return; }')
    asm=mod.compile_to_x64_frames_asm(p)
    ok('idivq %r10' in asm,'i64 regression fixture preserves signed division')
    ok('setl %al' in asm,'i64 regression fixture preserves signed comparison')
k=(root/'kernel/main.nx').read_text()
ok('fn acpi_checksum' in k and 'fn read_u8' in k,'ACPI checksum path present and rebuilt with unsigned semantics')
ok('fn user_pte_value' in k and '9223372036854775808' in k,'NX-bearing PTE user-copy path present and rebuilt with unsigned semantics')
loader=(root/'boot/uefi/frames_boot.c').read_text()
ok('FRAMES 0.9.11\\r\\n' in loader,'UEFI banner updated to 0.9.11')
print('ALL FRAMES 0.9.11 UNSIGNED-RUNTIME-REPAIR SOURCE GATES PASSED')
