#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]
q=(r/'tools/qemu_certify.sh').read_text(); b=(r/'tools/build.sh').read_text(); w=(r/'.github/workflows/frames-runtime-certify.yml').read_text()
for t in ['qemu-xhci,id=xhci','usb-kbd,bus=xhci.0','OVMF_VARS.runtime.fd']: assert t in q,t
assert 'toolchain/Nexus-Language-5.16.0/nexus' in b
for t in ['runs-on: ubuntu-24.04','qemu-system-x86','ovmf','./tools/qemu_certify.sh']: assert t in w,t
print('PASS Frames 0.9.9 external runtime handoff gates')
