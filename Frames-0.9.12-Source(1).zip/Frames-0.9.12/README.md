# Frames 0.9.12 — Full Kernel Continuation Return

Frames 0.9.12 is a runtime-repair release driven by real QEMU/OVMF evidence from Frames 0.9.11.

The 0.9.11 evidence proved ACPI/MADT/platform discovery, user-copy validation, ring-3 entry, Syscall ABI 1.0 and FEX exit all execute. It then exposed a post-exit page fault at the user thunk because the original Nexus bootstrap `user_return` primitive restored kernel RSP but not the frame pointer used by Nexus kernel functions.

0.9.12 bundles Nexus 5.17.0 and adds frame-complete ring-3 continuation primitives:

- `user_enter_context(cr3, rip, rsp, context_slot)` saves kernel RSP and RBP before `iretq`;
- `user_return_context(kernel_cr3, context_slot)` restores CR3, RBP and RSP before returning to the saved kernel continuation;
- the legacy `user_enter`/`user_return` builtins remain available for compatibility but Frames no longer uses them for the process-exit proof;
- Process 1 reserves a dedicated 16-byte continuation record at offsets +992/+1000;
- the FEX return thunk now performs syscall 0 (ABI query), syscall 1 (ordinary userspace syscall proof), then syscall 2 (process exit), so `FRAMES_USER_SYSCALL_OK` is earned by real ring-3 execution before exit.

Storage remains read-only. Physical boot remains blocked pending full runtime, stress/fault and physical-machine certification.
