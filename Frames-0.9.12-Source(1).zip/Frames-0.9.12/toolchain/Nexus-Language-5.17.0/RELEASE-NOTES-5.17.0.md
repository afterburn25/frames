# Nexus 5.17.0 — Full Frames Ring-3 Continuation Context

- Adds `user_enter_context(cr3, rip, rsp, context_slot)` for Frames kernels. It stores the kernel continuation RSP at `context_slot` and kernel RBP at `context_slot + 8` before entering CPL3.
- Adds `user_return_context(kernel_cr3, context_slot)`. It disables interrupts, restores kernel CR3, restores RBP and RSP from the continuation record, and returns to the exact saved kernel call continuation.
- Keeps the original `user_enter` and `user_return` bootstrap builtins for source compatibility.
- This fixes non-local ring-3 return through frame-pointer-based Nexus kernel functions.
