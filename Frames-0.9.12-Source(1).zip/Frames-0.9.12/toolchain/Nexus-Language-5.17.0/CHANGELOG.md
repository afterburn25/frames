# 5.0.0
- Frames kernel toolchain generation 3: timer interrupt entry and context-switch foundation.

# 4.9.0
- Frames exception ABI foundation and compiler-generated page-fault entry shim.

# Nexus Changelog

## 4.5.0 — Frames Kernel Build Tooling

- Adds the complete `nexus kernel check|build|inspect` workflow producing and verifying `FramesKernel.fkrn` from Nexus source.

# Nexus 4.0.0 — Native Compiler Generation 1

- Established the x86-64 native-generation-1 support contract.
- Added nexus native-check for deterministic native support reporting.
- A single direct build can combine generic structs, tagged enums, scalar generic specialization, references, match, move/drop and defer without C translation.
- Frames FEX64 metadata now records COMPILER=native-gen1.
- The hosted C17 backend remains the broad reference implementation for features still outside generation 1.

# Nexus 3.0.0

- Introduced NIR2 and `nexus verify-ir`.
- Added explicit NIR function entry blocks and portable target metadata.
- Expanded direct Frames x64 lowering to constants and payloadless enums/match.
- Added `NIR=2` to native Frames metadata.

# Nexus 2.9.0

- Added module/application capability declarations.
- Privileged effects now require declared capabilities.
- Frames `.fex` metadata now carries the compiled capability set.

# Nexus 2.8.0

- Added `Atomic<T>` and sequentially consistent atomic operations.
- Added `shared` effect enforcement.
- Added compile-time Send-safety checks for async task arguments.

# Nexus 2.7.0

- Added typed `Channel<T>` task communication.
- Added synchronized `send`, `recv`, and `close_channel`.
- Channels can be copied into async task contexts safely.

# Nexus 2.6.0

- Added real hosted `async fn`, `Task<T>`, and `await` using native threads.
- Generated per-function async contexts support typed arguments and results.
- Async operations require the `task` effect.

# Changelog

## 5.17.0
- Added frame-complete Frames ring-3 continuation builtins `user_enter_context` and `user_return_context`, preserving kernel RSP and RBP across controlled CPL3 execution.

## 2.6.0 — Deterministic Resource Management

- `Owned<T>` values are automatically freed at function/scope exit on the hosted backend.
- `Vector<T>` backing storage is automatically released.
- Explicit `drop` is cleanup-safe and prevents later double destruction.
- `defer` is block-scoped and executes LIFO before owned-resource destruction.
- Returning an owned resource transfers it out of cleanup instead of destroying it.


## 1.5.0 — Generic Functions & Monomorphization Foundation

- Added generic function declarations: `fn identity<T>(value: T) -> T`.
- Added inference of generic type parameters from call arguments.
- Added specialization/monomorphization for each concrete call signature.
- Added generic type parameters through immutable and mutable reference patterns such as `&T` and `&mut T`.
- Added deterministic backend symbol mangling for specializations.
- Added compile-time rejection of conflicting generic argument types.
- Added rejection of generic parameters that cannot be inferred from function parameters.
- Added generic function signatures to Nexus API documentation and NIR presentation.
- Retained typed payload enums, borrow safety, Frames-native formats, and Ed25519 package signing.

## 1.4.0 — Signed Frames Software & Trust Foundation
- Ed25519 signed FramesBundle/1 packages and trusted-key verification.

## 1.3.0 — Borrowing & Non-Escaping Reference Foundation
- `&T`, `&mut T`, dereference and lexical borrow safety.

## 1.2.0 — Tagged Data & Payload Enum Foundation
- Typed payload enums and bound exhaustive match.

## 1.1.0 — Frames-Native Formats & Application Packaging
- `.fex` and FramesBundle/1.

## 5.2.0
- Kernel CPUID register intrinsics and TSC read primitive for Frames hardware discovery.

## 5.3.0
- Frames Kernel ABI 3 and FramesBootInfoV3 typed kernel entry support.

## 5.4.0
- Compiler-generated safe spurious-interrupt return stub for Frames local APIC ownership.

## 5.16.0
- Correct unsigned x64 division, modulo, and ordered comparisons.
