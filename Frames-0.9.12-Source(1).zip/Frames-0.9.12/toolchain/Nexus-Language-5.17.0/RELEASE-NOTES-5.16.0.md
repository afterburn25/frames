# Nexus 5.16.0 — Correct Unsigned x64 Arithmetic and Ordering

- Fixes the x86-64 backend so `u64`/`u32` division and modulo use `divq` with a zeroed high dividend instead of signed `idivq`.
- Fixes ordered comparisons for unsigned integers to use the x86 unsigned condition codes (`b`, `a`, `be`, `ae`).
- Preserves signed `i64`/`i32` division and ordering through `idivq` and signed condition codes.
- This repair is required for Frames page-table entries carrying the NX high bit and for ACPI byte extraction/checksum paths that operate on arbitrary 64-bit chunks.
