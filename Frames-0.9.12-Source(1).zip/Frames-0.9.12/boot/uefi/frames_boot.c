#include <stdint.h>
#include <stddef.h>

typedef uint64_t UINTN;
typedef uint64_t EFI_STATUS;
typedef void *EFI_HANDLE;
typedef uint64_t EFI_PHYSICAL_ADDRESS;
typedef uint16_t CHAR16;
typedef uint8_t BOOLEAN;

#define EFIAPI __attribute__((ms_abi))
#define EFI_SUCCESS 0ULL
#define EFI_ERROR(x) (((x) >> 63) != 0)
#define EFI_BUFFER_TOO_SMALL (0x8000000000000005ULL)
#define EFI_FILE_MODE_READ 0x0000000000000001ULL
#define AllocateAnyPages 0
#define EfiLoaderCode 1
#define EfiLoaderData 2
#define PAGE_SIZE 4096ULL
#define FRAMES_BOOT_MAGIC 0x4652414D45534231ULL /* "FRAMESB1" */
#define FRAMES_BOOT_VERSION 4ULL
#define FKRN_HEADER_SIZE 160U
#define FEX_HEADER_SIZE 128U

#define EfiReservedMemoryType 0
#define EfiLoaderCodeType 1
#define EfiLoaderDataType 2
#define EfiBootServicesCode 3
#define EfiBootServicesData 4
#define EfiRuntimeServicesCode 5
#define EfiRuntimeServicesData 6
#define EfiConventionalMemory 7
#define EfiUnusableMemory 8
#define EfiACPIReclaimMemory 9
#define EfiACPIMemoryNVS 10
#define EfiMemoryMappedIO 11
#define EfiMemoryMappedIOPortSpace 12
#define EfiPalCode 13
#define EfiPersistentMemory 14

typedef struct {
    uint32_t Data1;
    uint16_t Data2;
    uint16_t Data3;
    uint8_t Data4[8];
} EFI_GUID;

typedef struct {
    uint64_t Signature;
    uint32_t Revision;
    uint32_t HeaderSize;
    uint32_t CRC32;
    uint32_t Reserved;
} EFI_TABLE_HEADER;

typedef struct EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL;
typedef EFI_STATUS (EFIAPI *EFI_TEXT_STRING)(EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *, CHAR16 *);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_CLEAR)(EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *);
struct EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL {
    void *Reset;
    EFI_TEXT_STRING OutputString;
    void *TestString;
    void *QueryMode;
    void *SetMode;
    void *SetAttribute;
    EFI_TEXT_CLEAR ClearScreen;
    void *SetCursorPosition;
    void *EnableCursor;
    void *Mode;
};

typedef struct {
    uint32_t Type;
    uint32_t Pad;
    EFI_PHYSICAL_ADDRESS PhysicalStart;
    EFI_PHYSICAL_ADDRESS VirtualStart;
    uint64_t NumberOfPages;
    uint64_t Attribute;
} EFI_MEMORY_DESCRIPTOR;

typedef EFI_STATUS (EFIAPI *EFI_ALLOCATE_PAGES)(uint32_t, uint32_t, UINTN, EFI_PHYSICAL_ADDRESS *);
typedef EFI_STATUS (EFIAPI *EFI_FREE_PAGES)(EFI_PHYSICAL_ADDRESS, UINTN);
typedef EFI_STATUS (EFIAPI *EFI_GET_MEMORY_MAP)(UINTN *, EFI_MEMORY_DESCRIPTOR *, UINTN *, UINTN *, uint32_t *);
typedef EFI_STATUS (EFIAPI *EFI_ALLOCATE_POOL)(uint32_t, UINTN, void **);
typedef EFI_STATUS (EFIAPI *EFI_FREE_POOL)(void *);
typedef EFI_STATUS (EFIAPI *EFI_HANDLE_PROTOCOL)(EFI_HANDLE, EFI_GUID *, void **);
typedef EFI_STATUS (EFIAPI *EFI_EXIT_BOOT_SERVICES)(EFI_HANDLE, UINTN);
typedef EFI_STATUS (EFIAPI *EFI_LOCATE_PROTOCOL)(EFI_GUID *, void *, void **);
typedef EFI_STATUS (EFIAPI *EFI_SET_WATCHDOG_TIMER)(UINTN, uint64_t, UINTN, CHAR16 *);

typedef struct {
    EFI_TABLE_HEADER Hdr;
    void *RaiseTPL;
    void *RestoreTPL;
    EFI_ALLOCATE_PAGES AllocatePages;
    EFI_FREE_PAGES FreePages;
    EFI_GET_MEMORY_MAP GetMemoryMap;
    EFI_ALLOCATE_POOL AllocatePool;
    EFI_FREE_POOL FreePool;
    void *CreateEvent;
    void *SetTimer;
    void *WaitForEvent;
    void *SignalEvent;
    void *CloseEvent;
    void *CheckEvent;
    void *InstallProtocolInterface;
    void *ReinstallProtocolInterface;
    void *UninstallProtocolInterface;
    EFI_HANDLE_PROTOCOL HandleProtocol;
    void *Reserved;
    void *RegisterProtocolNotify;
    void *LocateHandle;
    void *LocateDevicePath;
    void *InstallConfigurationTable;
    void *LoadImage;
    void *StartImage;
    void *Exit;
    void *UnloadImage;
    EFI_EXIT_BOOT_SERVICES ExitBootServices;
    void *GetNextMonotonicCount;
    void *Stall;
    EFI_SET_WATCHDOG_TIMER SetWatchdogTimer;
    void *ConnectController;
    void *DisconnectController;
    void *OpenProtocol;
    void *CloseProtocol;
    void *OpenProtocolInformation;
    void *ProtocolsPerHandle;
    void *LocateHandleBuffer;
    EFI_LOCATE_PROTOCOL LocateProtocol;
    void *InstallMultipleProtocolInterfaces;
    void *UninstallMultipleProtocolInterfaces;
    void *CalculateCrc32;
    void *CopyMem;
    void *SetMem;
    void *CreateEventEx;
} EFI_BOOT_SERVICES;

typedef struct {
    EFI_TABLE_HEADER Hdr;
    CHAR16 *FirmwareVendor;
    uint32_t FirmwareRevision;
    EFI_HANDLE ConsoleInHandle;
    void *ConIn;
    EFI_HANDLE ConsoleOutHandle;
    EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *ConOut;
    EFI_HANDLE StandardErrorHandle;
    EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *StdErr;
    void *RuntimeServices;
    EFI_BOOT_SERVICES *BootServices;
    UINTN NumberOfTableEntries;
    void *ConfigurationTable;
} EFI_SYSTEM_TABLE;

typedef struct { EFI_GUID VendorGuid; void *VendorTable; } EFI_CONFIGURATION_TABLE;

EFI_STATUS EFIAPI efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *st);
__attribute__((used)) static void *gFramesRelocationAnchor = (void *)&efi_main;

typedef struct {
    uint32_t Revision;
    EFI_HANDLE ParentHandle;
    EFI_SYSTEM_TABLE *SystemTable;
    EFI_HANDLE DeviceHandle;
    void *FilePath;
    void *Reserved;
    uint32_t LoadOptionsSize;
    void *LoadOptions;
    void *ImageBase;
    uint64_t ImageSize;
    uint32_t ImageCodeType;
    uint32_t ImageDataType;
    void *Unload;
} EFI_LOADED_IMAGE_PROTOCOL;

typedef struct EFI_FILE_PROTOCOL EFI_FILE_PROTOCOL;
typedef EFI_STATUS (EFIAPI *EFI_FILE_OPEN)(EFI_FILE_PROTOCOL *, EFI_FILE_PROTOCOL **, CHAR16 *, uint64_t, uint64_t);
typedef EFI_STATUS (EFIAPI *EFI_FILE_CLOSE)(EFI_FILE_PROTOCOL *);
typedef EFI_STATUS (EFIAPI *EFI_FILE_READ)(EFI_FILE_PROTOCOL *, UINTN *, void *);
typedef EFI_STATUS (EFIAPI *EFI_FILE_GET_INFO)(EFI_FILE_PROTOCOL *, EFI_GUID *, UINTN *, void *);
struct EFI_FILE_PROTOCOL {
    uint64_t Revision;
    EFI_FILE_OPEN Open;
    EFI_FILE_CLOSE Close;
    void *Delete;
    EFI_FILE_READ Read;
    void *Write;
    void *GetPosition;
    void *SetPosition;
    EFI_FILE_GET_INFO GetInfo;
    void *SetInfo;
    void *Flush;
    void *OpenEx;
    void *ReadEx;
    void *WriteEx;
    void *FlushEx;
};

typedef struct EFI_SIMPLE_FILE_SYSTEM_PROTOCOL EFI_SIMPLE_FILE_SYSTEM_PROTOCOL;
typedef EFI_STATUS (EFIAPI *EFI_OPEN_VOLUME)(EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *, EFI_FILE_PROTOCOL **);
struct EFI_SIMPLE_FILE_SYSTEM_PROTOCOL {
    uint64_t Revision;
    EFI_OPEN_VOLUME OpenVolume;
};

typedef struct {
    uint16_t Year;
    uint8_t Month;
    uint8_t Day;
    uint8_t Hour;
    uint8_t Minute;
    uint8_t Second;
    uint8_t Pad1;
    uint32_t Nanosecond;
    int16_t TimeZone;
    uint8_t Daylight;
    uint8_t Pad2;
} EFI_TIME;

typedef struct {
    uint64_t Size;
    uint64_t FileSize;
    uint64_t PhysicalSize;
    EFI_TIME CreateTime;
    EFI_TIME LastAccessTime;
    EFI_TIME ModificationTime;
    uint64_t Attribute;
    CHAR16 FileName[1];
} EFI_FILE_INFO;

typedef struct {
    uint32_t Version;
    uint32_t HorizontalResolution;
    uint32_t VerticalResolution;
    uint32_t PixelFormat;
    uint32_t PixelInformation[4];
    uint32_t PixelsPerScanLine;
} EFI_GRAPHICS_OUTPUT_MODE_INFORMATION;

typedef struct {
    uint32_t MaxMode;
    uint32_t Mode;
    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *Info;
    UINTN SizeOfInfo;
    EFI_PHYSICAL_ADDRESS FrameBufferBase;
    UINTN FrameBufferSize;
} EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE;

typedef struct {
    void *QueryMode;
    void *SetMode;
    void *Blt;
    EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE *Mode;
} EFI_GRAPHICS_OUTPUT_PROTOCOL;

#pragma pack(push,1)
typedef struct {
    uint8_t magic[8];
    uint16_t version;
    uint16_t header_size;
    uint16_t arch;
    uint16_t flags;
    uint32_t abi;
    uint32_t nir;
    uint64_t entry_offset;
    uint64_t code_offset;
    uint64_t code_size;
    uint64_t metadata_offset;
    uint64_t metadata_size;
    uint64_t reserved;
    uint8_t digest[32];
    uint8_t build_id[16];
    uint8_t padding[40];
} FKRN64_HEADER;
#pragma pack(pop)
_Static_assert(sizeof(FKRN64_HEADER)==160, "FKRN64 header must be 160 bytes");

#pragma pack(push,1)
typedef struct {
    uint8_t magic[8];
    uint16_t version;
    uint16_t header_size;
    uint16_t arch;
    uint16_t flags;
    uint32_t abi;
    uint32_t nir;
    uint64_t entry_offset;
    uint64_t code_offset;
    uint64_t code_size;
    uint64_t metadata_offset;
    uint64_t metadata_size;
    uint64_t reserved;
    uint8_t digest[32];
    uint8_t padding[24];
} FEX64_HEADER;
#pragma pack(pop)
_Static_assert(sizeof(FEX64_HEADER)==128, "FEX64 header must be 128 bytes");
_Static_assert(offsetof(EFI_BOOT_SERVICES, HandleProtocol)==152, "UEFI BootServices layout mismatch");
_Static_assert(offsetof(EFI_BOOT_SERVICES, ExitBootServices)==232, "UEFI BootServices layout mismatch");
_Static_assert(offsetof(EFI_BOOT_SERVICES, LocateProtocol)==320, "UEFI BootServices layout mismatch");
_Static_assert(offsetof(EFI_SYSTEM_TABLE, BootServices)==96, "UEFI SystemTable layout mismatch");

typedef struct {
    uint64_t kind;
    uint64_t physical_start;
    uint64_t page_count;
    uint64_t attributes;
} FRAMES_MEMORY_REGION_V1;

typedef struct {
    uint64_t kind;
    uint64_t flags;
    uint64_t address;
    uint64_t size;
    uint64_t entry_offset;
    uint64_t code_offset;
    uint64_t code_size;
    uint64_t reserved;
} FRAMES_BOOT_MODULE_V1;

typedef struct {
    uint64_t magic;
    uint64_t version;
    uint64_t memory_map;
    uint64_t memory_map_entries;
    uint64_t memory_region_size;
    uint64_t framebuffer;
    uint64_t framebuffer_width;
    uint64_t framebuffer_height;
    uint64_t framebuffer_stride;
    uint64_t framebuffer_format;
    uint64_t bootstrap_heap;
    uint64_t bootstrap_heap_pages;
    uint64_t acpi_rsdp;
    uint64_t boot_modules;
    uint64_t boot_module_count;
    uint64_t boot_module_size;
    uint64_t boot_policy_flags;
} FRAMES_BOOT_INFO_V4;

_Static_assert(sizeof(FRAMES_BOOT_MODULE_V1)==64, "FramesBootModuleV1 ABI mismatch");
_Static_assert(sizeof(FRAMES_BOOT_INFO_V4)==136, "FramesBootInfoV4 ABI mismatch");
typedef void (EFIAPI *FRAMES_KERNEL_ENTRY)(FRAMES_BOOT_INFO_V4 *);

static EFI_GUID gLoadedImageProtocolGuid = {0x5B1B31A1,0x9562,0x11d2,{0x8E,0x3F,0x00,0xA0,0xC9,0x69,0x72,0x3B}};
static EFI_GUID gSimpleFileSystemProtocolGuid = {0x964e5b22,0x6459,0x11d2,{0x8e,0x39,0x00,0xa0,0xc9,0x69,0x72,0x3b}};
static EFI_GUID gFileInfoGuid = {0x09576e92,0x6d3f,0x11d2,{0x8e,0x39,0x00,0xa0,0xc9,0x69,0x72,0x3b}};
static EFI_GUID gGraphicsOutputProtocolGuid = {0x9042a9de,0x23dc,0x4a38,{0x96,0xfb,0x7a,0xde,0xd0,0x80,0x51,0x6a}};
static EFI_GUID gAcpi20TableGuid = {0x8868e871,0xe4f1,0x11d3,{0xbc,0x22,0x00,0x80,0xc7,0x3c,0x88,0x81}};
static EFI_GUID gAcpi10TableGuid = {0xeb9d2d30,0x2d88,0x11d3,{0x9a,0x16,0x00,0x90,0x27,0x3f,0xc1,0x4d}};

static void mem_copy(void *dst, const void *src, UINTN n) {
    uint8_t *d=(uint8_t*)dst; const uint8_t *s=(const uint8_t*)src;
    for (UINTN i=0;i<n;i++) d[i]=s[i];
}
static void mem_zero(void *dst, UINTN n) { uint8_t *d=(uint8_t*)dst; for(UINTN i=0;i<n;i++) d[i]=0; }
static int mem_equal(const void *a,const void *b,UINTN n){const uint8_t*x=a,*y=b;for(UINTN i=0;i<n;i++)if(x[i]!=y[i])return 0;return 1;}
static int checksum8_zero(const uint8_t *p, UINTN n){
    uint8_t sum=0; if(!p || n==0) return 0;
    for(UINTN i=0;i<n;i++) sum=(uint8_t)(sum+p[i]);
    return sum==0;
}
static int valid_acpi_rsdp(void *candidate){
    static const uint8_t sig[8]={'R','S','D',' ','P','T','R',' '};
    if(!candidate) return 0;
    const uint8_t *p=(const uint8_t*)candidate;
    if(!mem_equal(p,sig,8) || !checksum8_zero(p,20)) return 0;
    if(p[15]>=2){
        uint32_t len=(uint32_t)p[20]|((uint32_t)p[21]<<8)|((uint32_t)p[22]<<16)|((uint32_t)p[23]<<24);
        if(len<36 || len>4096 || !checksum8_zero(p,len)) return 0;
    }
    return 1;
}
static void *find_acpi_rsdp(EFI_SYSTEM_TABLE *st){
    if(!st || !st->ConfigurationTable) return 0;
    EFI_CONFIGURATION_TABLE *ct=(EFI_CONFIGURATION_TABLE*)st->ConfigurationTable;
    void *acpi1=0,*generic=0;
    for(UINTN i=0;i<st->NumberOfTableEntries;i++){
        void *candidate=ct[i].VendorTable;
        if(mem_equal(&ct[i].VendorGuid,&gAcpi20TableGuid,sizeof(EFI_GUID))){ if(valid_acpi_rsdp(candidate)) return candidate; }
        if(mem_equal(&ct[i].VendorGuid,&gAcpi10TableGuid,sizeof(EFI_GUID))){ if(valid_acpi_rsdp(candidate)) acpi1=candidate; }
        if(!generic && valid_acpi_rsdp(candidate)) generic=candidate;
    }
    if(acpi1) return acpi1;
    return generic;
}

static EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *gConOut;
static void print16(CHAR16 *s) { if (gConOut && gConOut->OutputString) gConOut->OutputString(gConOut,s); }
static void fatal(CHAR16 *s, EFI_STATUS st) {
    (void)st;
    print16(L"\r\nFRAMES BOOT ERROR: "); print16(s); print16(L"\r\nSystem halted.\r\n");
    for (;;) __asm__ __volatile__("hlt");
}

/* Compact SHA-256 implementation used only to verify FKRN64 code+metadata. */
typedef struct { uint32_t h[8]; uint64_t bits; uint8_t buf[64]; uint32_t used; } SHA256_CTX;
static const uint32_t K256[64] = {
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
static uint32_t rotr32(uint32_t x,uint32_t n){return (x>>n)|(x<<(32-n));}
static void sha256_block(SHA256_CTX*c,const uint8_t*b){
    uint32_t w[64]; for(int i=0;i<16;i++)w[i]=((uint32_t)b[i*4]<<24)|((uint32_t)b[i*4+1]<<16)|((uint32_t)b[i*4+2]<<8)|b[i*4+3];
    for(int i=16;i<64;i++){uint32_t s0=rotr32(w[i-15],7)^rotr32(w[i-15],18)^(w[i-15]>>3);uint32_t s1=rotr32(w[i-2],17)^rotr32(w[i-2],19)^(w[i-2]>>10);w[i]=w[i-16]+s0+w[i-7]+s1;}
    uint32_t a=c->h[0],bb=c->h[1],cc=c->h[2],d=c->h[3],e=c->h[4],f=c->h[5],g=c->h[6],h=c->h[7];
    for(int i=0;i<64;i++){uint32_t S1=rotr32(e,6)^rotr32(e,11)^rotr32(e,25);uint32_t ch=(e&f)^((~e)&g);uint32_t t1=h+S1+ch+K256[i]+w[i];uint32_t S0=rotr32(a,2)^rotr32(a,13)^rotr32(a,22);uint32_t maj=(a&bb)^(a&cc)^(bb&cc);uint32_t t2=S0+maj;h=g;g=f;f=e;e=d+t1;d=cc;cc=bb;bb=a;a=t1+t2;}
    c->h[0]+=a;c->h[1]+=bb;c->h[2]+=cc;c->h[3]+=d;c->h[4]+=e;c->h[5]+=f;c->h[6]+=g;c->h[7]+=h;
}
static void sha256_init(SHA256_CTX*c){uint32_t h[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};for(int i=0;i<8;i++)c->h[i]=h[i];c->bits=0;c->used=0;}
static void sha256_update(SHA256_CTX*c,const void*data,UINTN n){const uint8_t*p=data;c->bits+=((uint64_t)n)*8;while(n){UINTN take=64-c->used;if(take>n)take=n;mem_copy(c->buf+c->used,p,take);c->used+=(uint32_t)take;p+=take;n-=take;if(c->used==64){sha256_block(c,c->buf);c->used=0;}}}
static void sha256_final(SHA256_CTX*c,uint8_t out[32]){c->buf[c->used++]=0x80;if(c->used>56){while(c->used<64)c->buf[c->used++]=0;sha256_block(c,c->buf);c->used=0;}while(c->used<56)c->buf[c->used++]=0;for(int i=7;i>=0;i--)c->buf[c->used++]=(uint8_t)(c->bits>>(i*8));sha256_block(c,c->buf);for(int i=0;i<8;i++){out[i*4]=(uint8_t)(c->h[i]>>24);out[i*4+1]=(uint8_t)(c->h[i]>>16);out[i*4+2]=(uint8_t)(c->h[i]>>8);out[i*4+3]=(uint8_t)c->h[i];}}

static uint64_t region_kind(uint32_t t) {
    if (t==EfiConventionalMemory) return 1; /* available */
    if (t==EfiBootServicesCode || t==EfiBootServicesData || t==EfiACPIReclaimMemory) return 2; /* reclaimable after handoff */
    if (t==EfiLoaderCodeType || t==EfiLoaderDataType) return 4; /* preserve: contains kernel/BootInfo/bootstrap allocations */
    if (t==EfiMemoryMappedIO || t==EfiMemoryMappedIOPortSpace) return 3; /* mmio */
    if (t==EfiACPIMemoryNVS || t==EfiRuntimeServicesCode || t==EfiRuntimeServicesData) return 4; /* preserve */
    return 0; /* reserved/unusable */
}

static EFI_STATUS load_file(EFI_BOOT_SERVICES *bs, EFI_HANDLE image, CHAR16 *path, void **out_data, UINTN *out_size) {
    EFI_LOADED_IMAGE_PROTOCOL *loaded=0;
    EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *fs=0;
    EFI_FILE_PROTOCOL *root=0,*file=0;
    EFI_STATUS st=bs->HandleProtocol(image,&gLoadedImageProtocolGuid,(void**)&loaded); if(EFI_ERROR(st))return st;
    st=bs->HandleProtocol(loaded->DeviceHandle,&gSimpleFileSystemProtocolGuid,(void**)&fs); if(EFI_ERROR(st))return st;
    st=fs->OpenVolume(fs,&root); if(EFI_ERROR(st))return st;
    st=root->Open(root,&file,path,EFI_FILE_MODE_READ,0); if(EFI_ERROR(st)){root->Close(root);return st;}
    uint8_t info_buf[512]; UINTN info_sz=sizeof(info_buf);
    st=file->GetInfo(file,&gFileInfoGuid,&info_sz,info_buf); if(EFI_ERROR(st)){file->Close(file);root->Close(root);return st;}
    EFI_FILE_INFO *fi=(EFI_FILE_INFO*)info_buf; if(fi->FileSize==0 || fi->FileSize>(64ULL*1024ULL*1024ULL)){file->Close(file);root->Close(root);return 0x8000000000000001ULL;}
    void *buf=0; st=bs->AllocatePool(EfiLoaderData,(UINTN)fi->FileSize,&buf); if(EFI_ERROR(st)){file->Close(file);root->Close(root);return st;}
    UINTN rd=(UINTN)fi->FileSize; st=file->Read(file,&rd,buf); file->Close(file);root->Close(root);
    if(EFI_ERROR(st) || rd!=(UINTN)fi->FileSize){bs->FreePool(buf);return EFI_ERROR(st)?st:0x8000000000000001ULL;}
    *out_data=buf;*out_size=rd;return EFI_SUCCESS;
}

EFI_STATUS EFIAPI efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *st) {
    EFI_BOOT_SERVICES *bs=st->BootServices; gConOut=st->ConOut;
    if (gConOut && gConOut->ClearScreen) gConOut->ClearScreen(gConOut);
    print16(L"FRAMES 0.9.12\r\n");
    print16(L"Independent Nexus Operating System Bootstrap\r\n\r\n");
    print16(L"[1/8] UEFI loader started\r\n");
    if (bs->SetWatchdogTimer) bs->SetWatchdogTimer(0,0,0,0);

    void *kernel_file=0; UINTN kernel_file_size=0;
    EFI_STATUS s=load_file(bs,image,L"\\Frames\\FramesKernel.fkrn",&kernel_file,&kernel_file_size);
    if(EFI_ERROR(s))fatal(L"Unable to load \\Frames\\FramesKernel.fkrn",s);
    print16(L"[2/8] FramesKernel.fkrn loaded\r\n");

    if(kernel_file_size<FKRN_HEADER_SIZE)fatal(L"Kernel image is truncated",0);
    FKRN64_HEADER *h=(FKRN64_HEADER*)kernel_file;
    static const uint8_t magic[8]={'F','K','R','N','6','4',0,0};
    if(!mem_equal(h->magic,magic,8) || h->version!=1 || h->header_size!=FKRN_HEADER_SIZE)fatal(L"Invalid FKRN64 header",0);
    if(h->arch!=1 || h->abi!=4)fatal(L"Unsupported kernel architecture or ABI",0);
    if(h->code_offset+h->code_size>kernel_file_size || h->metadata_offset+h->metadata_size>kernel_file_size || h->entry_offset>=h->code_size)fatal(L"Invalid FKRN64 section bounds",0);
    uint8_t digest[32]; SHA256_CTX sh; sha256_init(&sh); sha256_update(&sh,(uint8_t*)kernel_file+h->code_offset,(UINTN)h->code_size); sha256_update(&sh,(uint8_t*)kernel_file+h->metadata_offset,(UINTN)h->metadata_size); sha256_final(&sh,digest);
    if(!mem_equal(digest,h->digest,32))fatal(L"FKRN64 SHA-256 integrity check failed",0);
    print16(L"[3/8] FKRN64 header and SHA-256 verified\r\n");

    void *system_file=0; UINTN system_file_size=0;
    s=load_file(bs,image,L"\\Frames\\System.fex",&system_file,&system_file_size);
    if(EFI_ERROR(s))fatal(L"Unable to load \\Frames\\System.fex",s);
    if(system_file_size<FEX_HEADER_SIZE)fatal(L"System.fex is truncated",0);
    FEX64_HEADER *fh=(FEX64_HEADER*)system_file; static const uint8_t fmagic[8]={'F','E','X','6','4',0,0,0};
    if(!mem_equal(fh->magic,fmagic,8) || fh->version!=1 || fh->header_size!=FEX_HEADER_SIZE || fh->arch!=1 || fh->abi!=1)fatal(L"Invalid or unsupported FEX64 System image",0);
    if(fh->code_offset+fh->code_size>system_file_size || fh->metadata_offset+fh->metadata_size>system_file_size || fh->entry_offset>=fh->code_size)fatal(L"Invalid FEX64 System section bounds",0);
    uint8_t fdigest[32]; SHA256_CTX fsh; sha256_init(&fsh); sha256_update(&fsh,(uint8_t*)system_file+fh->code_offset,(UINTN)fh->code_size); sha256_update(&fsh,(uint8_t*)system_file+fh->metadata_offset,(UINTN)fh->metadata_size); sha256_final(&fsh,fdigest);
    if(!mem_equal(fdigest,fh->digest,32))fatal(L"System.fex SHA-256 integrity check failed",0);
    print16(L"[4/8] System.fex loaded and FEX64 SHA-256 verified\r\n");

    UINTN code_pages=(UINTN)((h->code_size+PAGE_SIZE-1)/PAGE_SIZE); EFI_PHYSICAL_ADDRESS code_addr=0;
    s=bs->AllocatePages(AllocateAnyPages,EfiLoaderCode,code_pages,&code_addr); if(EFI_ERROR(s))fatal(L"Unable to allocate executable kernel memory",s);
    mem_zero((void*)(uintptr_t)code_addr,code_pages*PAGE_SIZE); mem_copy((void*)(uintptr_t)code_addr,(uint8_t*)kernel_file+h->code_offset,(UINTN)h->code_size);
    FRAMES_KERNEL_ENTRY kernel_entry=(FRAMES_KERNEL_ENTRY)(uintptr_t)(code_addr+h->entry_offset);
    print16(L"[5/8] Nexus kernel code loaded into executable memory\r\n");

    EFI_GRAPHICS_OUTPUT_PROTOCOL *gop=0; bs->LocateProtocol(&gGraphicsOutputProtocolGuid,0,(void**)&gop);
    EFI_PHYSICAL_ADDRESS bootstrap_heap=0; const UINTN bootstrap_pages=192;
    s=bs->AllocatePages(AllocateAnyPages,EfiLoaderData,bootstrap_pages,&bootstrap_heap); if(EFI_ERROR(s))fatal(L"Unable to allocate Frames bootstrap heap",s);
    mem_zero((void*)(uintptr_t)bootstrap_heap,bootstrap_pages*PAGE_SIZE);
    FRAMES_BOOT_INFO_V4 *bi=0; s=bs->AllocatePool(EfiLoaderData,sizeof(*bi),(void**)&bi); if(EFI_ERROR(s))fatal(L"Unable to allocate FramesBootInfoV4",s); mem_zero(bi,sizeof(*bi));
    bi->magic=FRAMES_BOOT_MAGIC; bi->version=FRAMES_BOOT_VERSION; bi->memory_region_size=sizeof(FRAMES_MEMORY_REGION_V1);
    bi->bootstrap_heap=bootstrap_heap; bi->bootstrap_heap_pages=bootstrap_pages;
    bi->acpi_rsdp=(uint64_t)(uintptr_t)find_acpi_rsdp(st);
    FRAMES_BOOT_MODULE_V1 *mods=0; s=bs->AllocatePool(EfiLoaderData,sizeof(FRAMES_BOOT_MODULE_V1),(void**)&mods); if(EFI_ERROR(s))fatal(L"Unable to allocate Frames boot-module table",s); mem_zero(mods,sizeof(*mods));
    mods[0].kind=1; mods[0].flags=1; mods[0].address=(uint64_t)(uintptr_t)system_file; mods[0].size=system_file_size; mods[0].entry_offset=fh->entry_offset; mods[0].code_offset=fh->code_offset; mods[0].code_size=fh->code_size;
    bi->boot_modules=(uint64_t)(uintptr_t)mods; bi->boot_module_count=1; bi->boot_module_size=sizeof(FRAMES_BOOT_MODULE_V1); bi->boot_policy_flags=1; /* diagnostic-only */
    if(gop && gop->Mode && gop->Mode->Info){bi->framebuffer=gop->Mode->FrameBufferBase;bi->framebuffer_width=gop->Mode->Info->HorizontalResolution;bi->framebuffer_height=gop->Mode->Info->VerticalResolution;bi->framebuffer_stride=gop->Mode->Info->PixelsPerScanLine;bi->framebuffer_format=gop->Mode->Info->PixelFormat;}

    UINTN map_size=0,map_key=0,desc_size=0;uint32_t desc_ver=0;
    s=bs->GetMemoryMap(&map_size,0,&map_key,&desc_size,&desc_ver); if(s!=EFI_BUFFER_TOO_SMALL)fatal(L"Unable to size UEFI memory map",s);
    map_size += desc_size*16 + 4096;
    EFI_MEMORY_DESCRIPTOR *map=0; s=bs->AllocatePool(EfiLoaderData,map_size,(void**)&map); if(EFI_ERROR(s))fatal(L"Unable to allocate UEFI memory map",s);
    UINTN max_regions=(map_size/(desc_size?desc_size:sizeof(EFI_MEMORY_DESCRIPTOR)))+32;
    FRAMES_MEMORY_REGION_V1 *regions=0; s=bs->AllocatePool(EfiLoaderData,max_regions*sizeof(FRAMES_MEMORY_REGION_V1),(void**)&regions); if(EFI_ERROR(s))fatal(L"Unable to allocate normalized Frames memory map",s);
    print16(L"[7/8] BootInfoV4, verified boot modules, ACPI, framebuffer, and memory-map buffers prepared\r\n");
    print16(L"[8/8] Exiting UEFI boot services and entering Nexus kernel...\r\n");

    UINTN actual=map_size; s=bs->GetMemoryMap(&actual,map,&map_key,&desc_size,&desc_ver); if(EFI_ERROR(s))fatal(L"Unable to read final UEFI memory map",s);
    UINTN entries=actual/desc_size; if(entries>max_regions)fatal(L"Memory map grew beyond reserved capacity",0);
    for(UINTN i=0;i<entries;i++){
        EFI_MEMORY_DESCRIPTOR *d=(EFI_MEMORY_DESCRIPTOR*)((uint8_t*)map+i*desc_size);
        regions[i].kind=region_kind(d->Type);regions[i].physical_start=d->PhysicalStart;regions[i].page_count=d->NumberOfPages;regions[i].attributes=d->Attribute;
    }
    bi->memory_map=(uint64_t)(uintptr_t)regions; bi->memory_map_entries=entries;

    /* ExitBootServices can reject a stale map key. Retry using the already allocated buffer; no new allocations occur. */
    for(int attempt=0;attempt<3;attempt++){
        s=bs->ExitBootServices(image,map_key); if(!EFI_ERROR(s))break;
        actual=map_size; s=bs->GetMemoryMap(&actual,map,&map_key,&desc_size,&desc_ver); if(EFI_ERROR(s))break;
        entries=actual/desc_size; if(entries>max_regions)break;
        for(UINTN i=0;i<entries;i++){EFI_MEMORY_DESCRIPTOR*d=(EFI_MEMORY_DESCRIPTOR*)((uint8_t*)map+i*desc_size);regions[i].kind=region_kind(d->Type);regions[i].physical_start=d->PhysicalStart;regions[i].page_count=d->NumberOfPages;regions[i].attributes=d->Attribute;}
        bi->memory_map_entries=entries;
    }
    if(EFI_ERROR(s)) for(;;)__asm__ __volatile__("hlt");

    /* Frames Kernel ABI 4 transition contract: RCX = FramesBootInfoV4*. Nexus 5.10 consumes this as a typed &FramesBootInfoV4 parameter. */
    kernel_entry(bi);
    for(;;)__asm__ __volatile__("hlt");
}
