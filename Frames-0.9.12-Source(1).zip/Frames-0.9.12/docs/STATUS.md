Frames 0.9.12: Full Kernel Continuation Return.

Local status:
- Nexus 5.17.0 continuation ABI regression: PASS required before packaging.
- Frames kernel/FEX/EFI/GPT/FAT32 source verification: required.
- NVMe persistent media write path: absent.
- physical boot approval: BLOCKED.

Runtime evidence inherited from 0.9.11:
- ACPI/MADT/platform: PASS.
- NVMe read-only storage: PASS.
- `FRAMES_USER_COPY_OK`, `FRAMES_RING3_ENTER`, `FRAMES_SYSCALL_ABI_OK`, `FRAMES_FEX_EXIT_OK`, `FRAMES_RING3_RETURN`: observed.
- 0.9.11 then page-faulted on an instruction fetch at the post-exit user thunk because kernel RBP was not restored by the old non-local return primitive.

0.9.12 requires a fresh QEMU/OVMF evidence run.
