# Frames 0.9.12 — Full Kernel Continuation Return

Driven by the real Frames 0.9.11 QEMU/OVMF runtime trace.

## Evidence repaired

0.9.11 cleared ACPI/MADT and NX-bearing user-copy validation, entered ring 3, completed Syscall ABI 1.0 and FEX exit, returned to the kernel, then faulted at user RIP `0x0000400000000812` with page-fault error `0x14`. Intel's page-fault encoding identifies this as a user-mode instruction fetch from a non-present translation. The address is the post-syscall location in the FEX return thunk.

The original Nexus `user_return` restored kernel CR3 and RSP but left RBP pointing into the abandoned ring-0 syscall frame. Nexus kernel functions use RBP frame pointers, so the next epilogue unwound through stale interrupt state and resumed the user thunk.

## Nexus 5.17.0

Adds `user_enter_context` / `user_return_context`, preserving both RSP and RBP across the controlled ring-3 proof. Legacy primitives are retained.

## Frames changes

- dedicated 16-byte kernel continuation record at Process 1 offsets +992/+1000;
- process exit uses the frame-complete return primitive;
- return thunk now executes syscall 0, syscall 1, then syscall 2;
- `FRAMES_USER_SYSCALL_OK` is therefore produced by a real ordinary syscall before the exit syscall;
- physical boot remains blocked and persistent-media writes remain absent.
