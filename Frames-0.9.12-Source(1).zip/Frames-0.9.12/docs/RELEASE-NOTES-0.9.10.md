# Frames 0.9.10 — Runtime Gate Repair 1

## Evidence-driven fixes
The first external 0.9.9 QEMU/OVMF run reached `FRAMES_KERNEL_READY` and earned a PASS for the read-only NVMe storage profile. It also revealed two release-blocking issues.

1. **Bootstrap heap exhaustion**
   - Loader allocation: 64 pages.
   - Current kernel pre-steady-state reservation: 133 pages.
   - The 64-page boundary lands at `display_gate_state`; allocations beginning with `audio_pcm_state` and all later GDT/TSS/ring-3 stack state become zero.
   - 0.9.10 expands the preserved loader heap to 192 pages.

2. **ACPI discovery did not earn runtime markers**
   - 0.9.10 validates RSDP candidates before handoff and adds reason-coded kernel ACPI diagnostics.

Additional repair:
- `qemu_certify.sh` now creates `build/` before OVMF VARS copy.
- stale UEFI banner updated to 0.9.10.

No new hardware capability is claimed until the external runtime rerun provides evidence. Physical boot remains BLOCKED.
